# NoonAI 账号系统部署

## 已实现

- 手机号唯一注册，账号默认为手机号。
- 新手机号首次验证码登录后，需要设置两次一致的密码完成注册。
- 密码至少 6 位，并包含字母、数字、特殊字符中的至少两类。
- 支持手机号 + 密码登录、手机号 + 验证码登录。
- 支持通过手机号验证码重置密码。
- 使用 `HttpOnly` 会话 Cookie，密码使用 `scrypt` 加盐哈希保存。
- 聊天历史、个人资料和界面设置按用户隔离。
- 所有短信发送前必须完成随机滑块验证。
- 验证码 5 分钟有效，同一用途 60 秒内只能发送一次。
- 验证码次数限制和密码登录尝试限制。

## 阿里云短信配置

验证码不能通过“群发助手”发送。网站登录/注册验证码需要后端在用户点击“获取验证码”后，实时调用阿里云短信 `SendSms` API。

1. 在阿里云短信服务中完成企业资质、短信签名和验证码模板审核。
2. 模板中至少包含验证码变量 `${code}`，例如：`${code} 是您的短信验证码，5分钟内有效，请勿泄露。`
3. 创建 RAM 用户，只授予短信发送所需权限，不要使用主账号 AccessKey。
4. 把下面的变量配置到服务器环境中，然后重启 Node 服务。

```env
NODE_ENV=production
SMS_PROVIDER=aliyun
ALIYUN_ACCESS_KEY_ID=你的RAM用户AccessKeyId
ALIYUN_ACCESS_KEY_SECRET=你的RAM用户AccessKeySecret
ALIYUN_SMS_SIGN_NAME=阿里云审核通过的签名名称
ALIYUN_SMS_TEMPLATE_CODE=SMS_123456789
ALIYUN_SMS_REGION_ID=cn-hangzhou
DATA_DIR=/your/persistent-volume/noonai-data
```

`ALIYUN_SMS_SIGN_NAME` 只填写签名名称，不要带 `【】`。`ALIYUN_SMS_TEMPLATE_CODE` 填写模板列表中的模板 Code，而不是模板名称。AccessKey 只能放在服务端 `.env` 或部署平台的加密环境变量中，不能写进 `public/app.js`。

## Webhook 方式

如果不希望服务器直接保存阿里云凭证，也可以继续使用短信中转服务：

```env
NODE_ENV=production
DATA_DIR=/your/persistent-volume/noonai-data
SMS_PROVIDER=webhook
SMS_WEBHOOK_URL=https://your-sms-service.example/send
SMS_WEBHOOK_TOKEN=replace-with-a-long-secret
```

`SMS_WEBHOOK_URL` 会收到 JSON：

```json
{
  "phone": "13800138000",
  "code": "123456",
  "purpose": "register",
  "app": "中午AI",
  "expiresIn": 300,
  "message": "【中午AI】123456 是您的短信验证码，5分钟内有效，请勿泄露。",
  "content": "【中午AI】123456 是您的短信验证码，5分钟内有效，请勿泄露。"
}
```

Webhook 应立即调用短信服务商发送 `message`（`content` 为同值兼容字段），成功时返回任意 `2xx` 状态码。可以用它连接阿里云短信、腾讯云短信或其他短信平台。

## 数据持久化

当前版本把账号和用户数据写入 `DATA_DIR/auth-store.json`，适合单实例 MVP。部署平台必须给 `DATA_DIR` 挂载持久磁盘，否则重启或重新发布可能丢失账号数据。

用户量增加或需要多实例部署前，应迁移到 PostgreSQL/MySQL，并为手机号建立唯一索引。不要让多个 Node 实例同时写同一个 JSON 文件。

## 上线检查

1. 立即轮换曾经写在 `server.js` 中的所有模型 API Key。
2. 在域名上启用 HTTPS；HTTPS 下会话 Cookie 会自动带 `Secure`。
3. 配置阿里云短信或真实短信 Webhook，生产环境不能使用 `SMS_PROVIDER=console`。
4. 配置持久磁盘并备份 `DATA_DIR`。
5. 注册两个测试账号，确认两边历史记录和设置互不可见。
