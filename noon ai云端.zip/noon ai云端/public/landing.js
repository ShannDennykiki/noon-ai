(() => {
  const shell = document.querySelector("#landingShell");
  const canvas = document.querySelector("#ambientCanvas");
  const trailLayer = document.querySelector("#trailLayer");
  const scenes = [...document.querySelectorAll("[data-scene]")];
  const dots = [...document.querySelectorAll("[data-scene-target]")];
  const counterCurrent = document.querySelector("#counterCurrent");
  const exitTransition = document.querySelector("#exitTransition");
  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const coarsePointer = window.matchMedia("(hover: none), (pointer: coarse)").matches;
  const fileMode = window.location.protocol === "file:";
  const appTarget = fileMode ? "./index.html" : "/app";
  const assetPrefix = fileMode ? "." : "";

  document.querySelectorAll("[data-enter]").forEach((link) => {
    link.setAttribute("href", appTarget);
  });

  const palettes = [
    [[216, 120, 117], [240, 174, 135], [184, 63, 98], [230, 143, 146], [139, 48, 82]],
    [[80, 181, 198], [132, 218, 210], [42, 111, 149], [117, 106, 168], [57, 145, 175]],
    [[194, 78, 114], [231, 119, 95], [121, 46, 119], [157, 37, 92], [213, 84, 66]]
  ];

  let activeScene = 0;
  let sceneLocked = false;
  let wheelTotal = 0;
  let touchStartY = 0;
  let background = null;
  let audioContext = null;
  let soundBlocked = false;
  const sounds = {
    title: {
      src: `${assetPrefix}/assets/sounds/title-hover.mp3`,
      volume: 0.82,
      buffer: null,
      promise: null,
      lastPlayedAt: 0
    },
    header: {
      src: `${assetPrefix}/assets/sounds/open-hover.mp3`,
      volume: 0.82,
      buffer: null,
      promise: null,
      lastPlayedAt: 0
    }
  };
  Object.values(sounds).forEach((sound) => {
    sound.html = new Audio(sound.src);
    sound.html.preload = "auto";
    sound.html.volume = sound.volume;
    sound.html.load();
  });

  const titleAnimations = new WeakMap();

  function getAudioContext() {
    if (!audioContext) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (AudioContext) {
        audioContext = new AudioContext({ latencyHint: "interactive" });
      }
    }
    return audioContext;
  }

  function loadSoundBuffer(sound) {
    if (sound.buffer) return Promise.resolve(sound.buffer);
    if (sound.promise) return sound.promise;
    const context = getAudioContext();
    if (!context) return Promise.reject(new Error("Web Audio unavailable"));
    sound.promise = fetch(sound.src)
      .then((response) => {
        if (!response.ok) throw new Error(`Audio HTTP ${response.status}`);
        return response.arrayBuffer();
      })
      .then((data) => context.decodeAudioData(data))
      .then((buffer) => {
        sound.buffer = buffer;
        return buffer;
      })
      .catch((error) => {
        sound.promise = null;
        throw error;
      });
    return sound.promise;
  }

  Object.values(sounds).forEach((sound) => loadSoundBuffer(sound).catch(() => {}));

  function splitTitle(title) {
    const label = title.textContent;
    title.setAttribute("aria-label", label);
    title.textContent = "";
    [...label].forEach((character) => {
      const span = document.createElement("span");
      span.className = "title-char";
      span.setAttribute("aria-hidden", "true");
      span.textContent = character === " " ? "\u00a0" : character;
      title.appendChild(span);
    });
  }

  function playTitleAnimation(title, hoverReplay = false) {
    const characters = [...title.querySelectorAll(".title-char")];
    const previous = titleAnimations.get(title) || [];
    previous.forEach((animation) => animation.cancel());

    const duration = hoverReplay ? 1200 : 1400;
    const stagger = hoverReplay ? 40 : 60;
    const animations = characters.map((character, index) => character.animate([
      {
        transform: "translate3d(-30px, 0, 0)",
        clipPath: "inset(0% 100% 120% -5%)"
      },
      {
        transform: "translate3d(0, 0, 0)",
        clipPath: "inset(0% -100% -100% -5%)"
      }
    ], {
      duration,
      delay: 50 + (characters.length - index - 1) * stagger,
      easing: "cubic-bezier(.165,.84,.44,1)",
      fill: "both"
    }));
    titleAnimations.set(title, animations);
    if (hoverReplay) playSound("title");
  }

  async function unlockSound() {
    if (fileMode) {
      try {
        await Promise.all(Object.values(sounds).map(async (sound) => {
          sound.html.muted = true;
          await sound.html.play();
          sound.html.pause();
          sound.html.currentTime = 0;
          sound.html.muted = false;
        }));
        soundBlocked = false;
        return true;
      } catch {
        Object.values(sounds).forEach((sound) => { sound.html.muted = false; });
        return false;
      }
    }
    const context = getAudioContext();
    if (!context) return false;
    try {
      await context.resume();
      await Promise.all(Object.values(sounds).map((sound) => loadSoundBuffer(sound)));
      soundBlocked = false;
      return context.state === "running";
    } catch {
      return false;
    }
  }

  async function playSound(name) {
    const sound = sounds[name];
    if (!sound) return;
    const now = performance.now();
    if (now - sound.lastPlayedAt < 120) return;
    sound.lastPlayedAt = now;
    if (fileMode) {
      try {
        sound.html.pause();
        sound.html.currentTime = 0;
        await sound.html.play();
      } catch {
        soundBlocked = true;
      }
      return;
    }

    const context = getAudioContext();
    if (!context) return;

    if (context.state !== "running") {
      const unlocked = await unlockSound();
      if (!unlocked) {
        soundBlocked = true;
        return;
      }
    }

    try {
      const buffer = await loadSoundBuffer(sound);
      const source = context.createBufferSource();
      const gain = context.createGain();
      source.buffer = buffer;
      gain.gain.setValueAtTime(sound.volume, context.currentTime);
      source.connect(gain).connect(context.destination);
      source.start(context.currentTime);
    } catch {
      soundBlocked = true;
    }
  }

  const featureTitles = [...document.querySelectorAll(".feature-title")];
  featureTitles.forEach((title) => {
    splitTitle(title);
    const hitCharacters = [...title.querySelectorAll(".title-char")]
      .filter((character) => character.textContent.trim());
    hitCharacters.forEach((character) => {
      character.addEventListener("pointerenter", (event) => {
        if (event.pointerType === "touch" || title.dataset.glyphHover === "true") return;
        title.dataset.glyphHover = "true";
        playTitleAnimation(title, true);
      });
      character.addEventListener("pointerleave", (event) => {
        if (event.pointerType === "touch") return;
        requestAnimationFrame(() => {
          const hovered = document.elementFromPoint(event.clientX, event.clientY);
          if (!hovered?.closest(".title-char") || hovered.closest(".feature-title") !== title) {
            delete title.dataset.glyphHover;
          }
        });
      });
    });
  });
  document.fonts.load('100px "Safiro Noon"')
    .catch(() => {})
    .finally(() => requestAnimationFrame(() => playTitleAnimation(featureTitles[0])));

  const headerEnter = document.querySelector(".header-enter");
  const buttonLabel = headerEnter?.querySelector(".swap-label");
  if (buttonLabel) {
    const label = buttonLabel.textContent;
    buttonLabel.textContent = "";
    [...label].forEach((character, index) => {
      const wrapper = document.createElement("span");
      wrapper.className = "button-char";
      wrapper.style.setProperty("--char-index", index);
      const primary = document.createElement("span");
      primary.className = "button-char-primary";
      primary.textContent = character === " " ? "\u00a0" : character;
      const secondary = document.createElement("span");
      secondary.className = "button-char-secondary";
      secondary.textContent = character === " " ? "\u00a0" : character;
      secondary.setAttribute("aria-hidden", "true");
      wrapper.append(primary, secondary);
      buttonLabel.appendChild(wrapper);
    });
    headerEnter.addEventListener("pointerenter", (event) => {
      if (event.pointerType === "touch") return;
      headerEnter.classList.add("is-hovering");
      playSound("header");
    });
    headerEnter.addEventListener("pointerleave", () => {
      headerEnter.classList.remove("is-hovering");
    });
  }

  ["pointerdown", "keydown"].forEach((eventName) => {
    window.addEventListener(eventName, () => {
      unlockSound().then((unlocked) => {
        if (unlocked) soundBlocked = false;
      });
    }, { once: true, passive: eventName !== "keydown" });
  });

  function setScene(next) {
    const target = Math.max(0, Math.min(scenes.length - 1, next));
    if (target === activeScene || sceneLocked) return;
    sceneLocked = true;
    const previous = scenes[activeScene];
    previous.classList.add("is-exiting");
    previous.setAttribute("aria-hidden", "true");

    window.setTimeout(() => {
      previous.classList.remove("is-active", "is-exiting");
      activeScene = target;
      const current = scenes[activeScene];
      current.classList.add("is-active");
      current.setAttribute("aria-hidden", "false");
      dots.forEach((dot, index) => dot.classList.toggle("is-active", index === activeScene));
      counterCurrent.textContent = String(activeScene + 1).padStart(2, "0");
      background?.setPalette(palettes[activeScene]);
      playTitleAnimation(current.querySelector(".feature-title"));
      window.setTimeout(() => { sceneLocked = false; }, 700);
    }, 360);
  }

  document.addEventListener("wheel", (event) => {
    if (sceneLocked) return;
    wheelTotal += event.deltaY;
    if (Math.abs(wheelTotal) < 70) return;
    setScene(activeScene + (wheelTotal > 0 ? 1 : -1));
    wheelTotal = 0;
  }, { passive: true });

  document.addEventListener("keydown", (event) => {
    if (["ArrowDown", "ArrowRight", "PageDown", " "].includes(event.key)) {
      event.preventDefault();
      setScene(activeScene + 1);
    } else if (["ArrowUp", "ArrowLeft", "PageUp"].includes(event.key)) {
      event.preventDefault();
      setScene(activeScene - 1);
    }
  });

  document.addEventListener("touchstart", (event) => {
    touchStartY = event.touches[0]?.clientY || 0;
  }, { passive: true });

  document.addEventListener("touchend", (event) => {
    const endY = event.changedTouches[0]?.clientY || touchStartY;
    const delta = touchStartY - endY;
    if (Math.abs(delta) > 55) setScene(activeScene + (delta > 0 ? 1 : -1));
  }, { passive: true });

  document.querySelectorAll("[data-next]").forEach((button) => {
    button.addEventListener("click", () => setScene(activeScene + 1));
  });

  dots.forEach((dot) => {
    dot.addEventListener("click", () => setScene(Number(dot.dataset.sceneTarget)));
  });

  document.querySelectorAll("[data-enter]").forEach((link) => {
    link.addEventListener("click", (event) => {
      event.preventDefault();
      if (exitTransition.classList.contains("is-active")) return;
      shell.classList.add("is-leaving");
      exitTransition.classList.add("is-active");
      window.setTimeout(() => {
        window.location.href = appTarget;
      }, reduceMotion ? 100 : 920);
    });
  });

  const spriteFiles = [
    "01-radiant.png", "02-shaking.png", "03-happy-sparkles.png",
    "04-alert.png", "05-idea.png", "06-speed.png",
    "07-shy-love.png", "08-sad.png", "09-sleepy.png",
    "10-delighted-love.png", "11-surprised.png", "12-drowsy.png",
    "13-starry-eyed.png", "14-playful-tilt.png", "15-love.png",
    "16-confused.png", "17-squeezed-eyes.png", "18-music.png"
  ].map((file) => `${assetPrefix}/assets/image-trail/noon-expressions/${file}`);

  spriteFiles.forEach((src) => {
    const image = new Image();
    image.src = src;
  });

  let spriteIndex = 0;
  let lastTrail = { x: -200, y: -200 };
  let lastTrailAt = 0;
  const maxSprites = coarsePointer ? 7 : 13;

  function spawnTrail(x, y, force = false) {
    const now = performance.now();
    const distance = Math.hypot(x - lastTrail.x, y - lastTrail.y);
    if (!force && (distance < (coarsePointer ? 42 : 58) || now - lastTrailAt < 65)) return;

    const image = document.createElement("img");
    image.className = "trail-sprite";
    image.src = spriteFiles[spriteIndex % spriteFiles.length];
    image.alt = "";
    image.style.left = `${x}px`;
    image.style.top = `${y}px`;
    image.style.setProperty("--rotation", `${(Math.random() * 18 - 9).toFixed(2)}deg`);
    trailLayer.appendChild(image);

    spriteIndex += 1;
    lastTrail = { x, y };
    lastTrailAt = now;
    while (trailLayer.children.length > maxSprites) trailLayer.firstElementChild?.remove();
    image.addEventListener("animationend", () => image.remove(), { once: true });
  }

  document.addEventListener("pointermove", (event) => {
    background?.setPointer(event.clientX, event.clientY);
    if (event.pointerType === "mouse") spawnTrail(event.clientX, event.clientY);
  }, { passive: true });

  document.addEventListener("pointerdown", (event) => {
    background?.setPointer(event.clientX, event.clientY, true);
    if (event.pointerType !== "mouse") spawnTrail(event.clientX, event.clientY, true);
  }, { passive: true });

  function createBackground(targetCanvas) {
    const gl = targetCanvas.getContext("webgl", {
      alpha: false,
      antialias: false,
      powerPreference: "high-performance"
    });
    if (!gl) return null;

    const vertexSource = `
      attribute vec2 position;
      varying vec2 vUv;
      void main() {
        vUv = position * .5 + .5;
        gl_Position = vec4(position, 0.0, 1.0);
      }
    `;

    const fragmentSource = `
      precision highp float;
      varying vec2 vUv;
      uniform vec2 uResolution;
      uniform vec2 uPointer;
      uniform vec2 uVelocity;
      uniform float uTime;
      uniform float uPress;
      uniform float uPointerStrength;
      uniform vec3 uColorA;
      uniform vec3 uColorB;
      uniform vec3 uColorC;
      uniform vec3 uColorD;
      uniform vec3 uBase;

      vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
      vec2 mod289(vec2 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
      vec3 permute(vec3 x) { return mod289(((x * 34.0) + 1.0) * x); }

      float snoise(vec2 v) {
        const vec4 C = vec4(0.211324865405187, 0.366025403784439,
          -0.577350269189626, 0.024390243902439);
        vec2 i = floor(v + dot(v, C.yy));
        vec2 x0 = v - i + dot(i, C.xx);
        vec2 i1 = x0.x > x0.y ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
        vec4 x12 = x0.xyxy + C.xxzz;
        x12.xy -= i1;
        i = mod289(i);
        vec3 p = permute(permute(i.y + vec3(0.0, i1.y, 1.0))
          + i.x + vec3(0.0, i1.x, 1.0));
        vec3 m = max(0.5 - vec3(dot(x0, x0), dot(x12.xy, x12.xy),
          dot(x12.zw, x12.zw)), 0.0);
        m = m * m;
        m = m * m;
        vec3 x = 2.0 * fract(p * C.www) - 1.0;
        vec3 h = abs(x) - 0.5;
        vec3 ox = floor(x + 0.5);
        vec3 a0 = x - ox;
        m *= 1.79284291400159 - 0.85373472095314 * (a0 * a0 + h * h);
        vec3 g;
        g.x = a0.x * x0.x + h.x * x0.y;
        g.yz = a0.yz * x12.xz + h.yz * x12.yw;
        return 130.0 * dot(m, g);
      }

      float fbm(vec2 p) {
        float value = 0.0;
        float amplitude = 0.64;
        mat2 rotation = mat2(.84, -.54, .54, .84);
        for (int i = 0; i < 2; i++) {
          value += amplitude * snoise(p);
          p = rotation * p * 1.92 + vec2(13.7, 8.4);
          amplitude *= 0.36;
        }
        return value;
      }

      float softBlob(vec2 p, vec2 center, vec2 radius) {
        float distanceToCenter = length((p - center) / radius);
        return 1.0 - smoothstep(.12, 1.0, distanceToCenter);
      }

      void main() {
        vec2 uv = vUv;
        float aspect = uResolution.x / uResolution.y;
        vec2 pointerDelta = uv - uPointer;
        pointerDelta.x *= aspect;
        float pointerDistance = length(pointerDelta);
        float t = uTime;

        vec2 fieldUv = vec2(uv.x * aspect, uv.y);
        vec2 warpSeed = fieldUv * .68 + vec2(t * .056, -t * .043);
        float broadWarp = fbm(warpSeed);
        vec2 domainWarp = vec2(
          broadWarp,
          broadWarp * .58 + sin((warpSeed.x + warpSeed.y) * 2.1 + t * .045) * .16
        ) * .052;

        float pointerInfluence = (1.0 - smoothstep(.012, mix(.25, .31, uPress), pointerDistance)) * uPointerStrength;
        vec2 pointerDirection = normalize(pointerDelta + vec2(.0001));
        float pointerSpeed = clamp(length(uVelocity) * 190.0, 0.0, 1.0);
        vec2 movementDirection = normalize(uVelocity + vec2(.0001));
        vec2 movementNormal = vec2(-movementDirection.y, movementDirection.x);
        float softWave = sin(dot(pointerDelta, movementNormal) * 28.0 + t * 1.55);
        vec2 pointerWarp =
          -pointerDirection * pointerInfluence * (.018 + uPress * .010)
          - movementDirection * pointerInfluence * pointerSpeed * .030
          + movementNormal * softWave * pointerInfluence * pointerSpeed * .009;
        vec2 p = uv + domainWarp + pointerWarp;

        vec2 centerA = vec2(
          .78 + sin(t * .245 + .3) * .23 + sin(t * .064 + 2.8) * .05,
          .18 + cos(t * .198 + .8) * .19
        );
        vec2 centerB = vec2(
          .43 + sin(t * .192 + 2.1) * .25,
          .50 + cos(t * .236 + 1.4) * .21 + sin(t * .068) * .04
        );
        vec2 centerC = vec2(
          .12 + sin(t * .224 + 4.2) * .23,
          .82 + cos(t * .174 + 2.7) * .20
        );
        vec2 centerD = vec2(
          .80 + sin(t * .169 + 5.4) * .22 + cos(t * .054) * .04,
          .78 + cos(t * .216 + 4.1) * .19
        );

        vec2 radiusA = vec2(.49, .50) + vec2(
          sin(t * .039 + .7),
          cos(t * .031 + 1.8)
        ) * .045;
        vec2 radiusB = vec2(.38, .46) + vec2(
          cos(t * .046 + 2.4),
          sin(t * .037 + .5)
        ) * .042;
        vec2 radiusC = vec2(.43, .46) + vec2(
          sin(t * .034 + 3.8),
          cos(t * .043 + 2.2)
        ) * .04;
        vec2 radiusD = vec2(.35, .39) + vec2(
          cos(t * .041 + 5.1),
          sin(t * .052 + 4.6)
        ) * .035;

        float blobA = softBlob(p, centerA, radiusA);
        float blobB = softBlob(p, centerB, radiusB);
        float blobC = softBlob(p, centerC, radiusC);
        float blobD = softBlob(p, centerD, radiusD);

        vec3 color = uBase;
        color = mix(color, uColorA, blobA * .92);
        color = mix(color, uColorC, blobC * .72);
        color = mix(color, uColorD, blobD * .56);
        color = mix(color, uColorB, blobB * .87);

        float refraction = pointerInfluence * (.042 + pointerSpeed * .032 + uPress * .026);
        color += vec3(
          refraction * pointerDirection.x * .21,
          refraction * pointerDirection.y * .15,
          -refraction * pointerDirection.x * .16
        );

        float dither = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.5453) - .5;
        color += dither / 510.0;
        gl_FragColor = vec4(color, 1.0);
      }
    `;

    function compile(type, source) {
      const shader = gl.createShader(type);
      gl.shaderSource(shader, source);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        console.warn(gl.getShaderInfoLog(shader));
        gl.deleteShader(shader);
        return null;
      }
      return shader;
    }

    const program = gl.createProgram();
    const vertex = compile(gl.VERTEX_SHADER, vertexSource);
    const fragment = compile(gl.FRAGMENT_SHADER, fragmentSource);
    if (!vertex || !fragment) return null;
    gl.attachShader(program, vertex);
    gl.attachShader(program, fragment);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) return null;
    gl.useProgram(program);

    const buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([
      -1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1
    ]), gl.STATIC_DRAW);
    const position = gl.getAttribLocation(program, "position");
    gl.enableVertexAttribArray(position);
    gl.vertexAttribPointer(position, 2, gl.FLOAT, false, 0, 0);

    const uniforms = {};
    ["uResolution", "uPointer", "uVelocity", "uTime", "uPress", "uPointerStrength", "uColorA", "uColorB", "uColorC", "uColorD", "uBase"].forEach((name) => {
      uniforms[name] = gl.getUniformLocation(program, name);
    });

    let width = 0;
    let height = 0;
    let pointerTarget = { x: .5, y: .5 };
    let pointer = { x: .5, y: .5 };
    let pointerLast = { x: .5, y: .5 };
    let velocity = { x: 0, y: 0 };
    let press = 0;
    let pressTarget = 0;
    let pointerStrength = 0;
    let lastPointerAt = -Infinity;
    let paletteTarget = palettes[0].map((color) => color.map((value) => value / 255));
    const palette = paletteTarget.map((color) => [...color]);
    const startedAt = performance.now();
    let previousFrameAt = startedAt;

    function resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.25) * .66;
      const nextWidth = Math.round(window.innerWidth * dpr);
      const nextHeight = Math.round(window.innerHeight * dpr);
      if (nextWidth === width && nextHeight === height) return;
      width = nextWidth;
      height = nextHeight;
      targetCanvas.width = width;
      targetCanvas.height = height;
      gl.viewport(0, 0, width, height);
    }

    function setPointer(x, y, pressed = false) {
      pointerTarget.x = x / window.innerWidth;
      pointerTarget.y = 1 - y / window.innerHeight;
      lastPointerAt = performance.now();
      if (pressed) {
        pressTarget = 1;
        window.setTimeout(() => { pressTarget = 0; }, 260);
      }
    }

    function setPalette(nextPalette) {
      paletteTarget = nextPalette.map((color) => color.map((value) => value / 255));
    }

    function render(now) {
      resize();
      const deltaSeconds = Math.min((now - previousFrameAt) / 1000, .1);
      previousFrameAt = now;
      const follow = reduceMotion ? 1 : .075;
      pointer.x += (pointerTarget.x - pointer.x) * follow;
      pointer.y += (pointerTarget.y - pointer.y) * follow;
      velocity.x += ((pointer.x - pointerLast.x) - velocity.x) * .18;
      velocity.y += ((pointer.y - pointerLast.y) - velocity.y) * .18;
      pointerLast = { ...pointer };
      press += (pressTarget - press) * .09;
      const pointerStrengthTarget = now - lastPointerAt < 520 ? 1 : 0;
      pointerStrength += (pointerStrengthTarget - pointerStrength) * (pointerStrengthTarget ? .13 : .055);

      palette.forEach((color, index) => {
        color.forEach((value, channel) => {
          const paletteFollow = reduceMotion ? 1 : 1.0 - Math.exp(-deltaSeconds * 3.2);
          color[channel] += (paletteTarget[index][channel] - value) * paletteFollow;
        });
      });

      gl.uniform2f(uniforms.uResolution, width, height);
      gl.uniform2f(uniforms.uPointer, pointer.x, pointer.y);
      gl.uniform2f(uniforms.uVelocity, velocity.x, velocity.y);
      gl.uniform1f(uniforms.uTime, reduceMotion ? 0 : (now - startedAt) / 1000);
      gl.uniform1f(uniforms.uPress, press);
      gl.uniform1f(uniforms.uPointerStrength, reduceMotion ? 0 : pointerStrength);
      gl.uniform3fv(uniforms.uBase, palette[0]);
      gl.uniform3fv(uniforms.uColorA, palette[1]);
      gl.uniform3fv(uniforms.uColorB, palette[2]);
      gl.uniform3fv(uniforms.uColorC, palette[3]);
      gl.uniform3fv(uniforms.uColorD, palette[4]);
      gl.drawArrays(gl.TRIANGLES, 0, 6);
      requestAnimationFrame(render);
    }

    window.addEventListener("resize", resize);
    requestAnimationFrame(render);
    return { setPointer, setPalette };
  }

  background = createBackground(canvas);
  background?.setPalette(palettes[0]);
})();
