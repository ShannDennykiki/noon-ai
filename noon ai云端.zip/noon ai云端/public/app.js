const STORAGE_KEY = "noonai.sessions.v1";
const PROFILE_KEY = "noonai.profile.v1";
const SETTINGS_KEY = "noonai.settings.v1";
const APPEARANCE_KEY = "noonai.appearance.v1";
const APPEARANCE_MODE_KEY = "noonai.appearance-mode.v1";
const APPEARANCE_MIGRATION_KEY = "noonai.appearance-system-migrated.v1";
const DEVICE_ACCOUNTS_KEY = "noonai.device-accounts.v1";
const LETTERPRESS_ENTRY_KEY = "noonai.letterpress-entry.v1";
const RETURN_NEW_CHAT_KEY = "noonai.return-new-chat.v1";
const API_BASE = window.location.protocol === "file:" ? "http://localhost:3000" : "";
const MAX_ATTACHMENTS = 8;
const MAX_ATTACHMENT_SIZE = 500 * 1024 * 1024;
const MAX_TOOL_IMAGE_COUNT = 10;
const systemAppearanceMedia = window.matchMedia("(prefers-color-scheme: light)");

function resolveAppearance(mode) {
  if (mode === "light" || mode === "dark") return mode;
  return systemAppearanceMedia.matches ? "light" : "dark";
}

function applyAppearanceToDocument(theme, mode = "system") {
  document.documentElement.dataset.theme = theme;
  document.documentElement.style.colorScheme = theme;
  if (document.body) document.body.dataset.theme = theme;
  try {
    localStorage.setItem(APPEARANCE_KEY, theme);
    localStorage.setItem(APPEARANCE_MODE_KEY, mode);
  } catch {
    // The page can still use the in-memory theme when storage is unavailable.
  }
}

function initializeAppearance() {
  applyAppearanceToDocument(resolveAppearance(appSettings.appearance), appSettings.appearance);
  const handleSystemAppearanceChange = () => {
    if (appSettings.appearance !== "system") return;
    if (appStarted) applySettings();
    else applyAppearanceToDocument(resolveAppearance("system"), "system");
  };
  if (typeof systemAppearanceMedia.addEventListener === "function") {
    systemAppearanceMedia.addEventListener("change", handleSystemAppearanceChange);
  } else {
    systemAppearanceMedia.addListener(handleSystemAppearanceChange);
  }
}

function createId() {
  if (typeof crypto?.randomUUID === "function") {
    return crypto.randomUUID();
  }

  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0"));
  return `${hex.slice(0, 4).join("")}-${hex.slice(4, 6).join("")}-${hex.slice(6, 8).join("")}-${hex.slice(8, 10).join("")}-${hex.slice(10).join("")}`;
}

const sendArrowIcon = `
  <svg viewBox="0 0 32 32">
    <path d="M16 25V7" />
    <path d="M8.5 14.5 16 7l7.5 7.5" />
  </svg>
`;

const stopIcon = `
  <svg viewBox="0 0 32 32">
    <rect x="8.3" y="8.3" width="15.4" height="15.4" rx="3" fill="currentColor" stroke="none" />
  </svg>
`;

const pinIconMarkup = `
  <path d="M15 4.5 19.5 9l-4 4-1 4-2 2L5 11.5l2-2 4-1 4-4Z" />
  <path d="m9 15-4.5 4.5" />
`;

const unpinIconMarkup = `
  ${pinIconMarkup}
  <path d="M4.5 4.5 19.5 19.5" />
`;

const els = {
  authModal: document.querySelector("#authModal"),
  authClose: document.querySelector(".auth-close"),
  authLoginView: document.querySelector("#authLoginView"),
  authResetView: document.querySelector("#authResetView"),
  authCodeTab: document.querySelector("#authCodeTab"),
  authPasswordTab: document.querySelector("#authPasswordTab"),
  authForm: document.querySelector("#authForm"),
  authPhone: document.querySelector("#authPhone"),
  authPasswordField: document.querySelector("#authPasswordField"),
  authPassword: document.querySelector("#authPassword"),
  authCodeField: document.querySelector("#authCodeField"),
  authCode: document.querySelector("#authCode"),
  authSendCode: document.querySelector("#authSendCode"),
  authInviteField: document.querySelector("#authInviteField"),
  authPasswordOptions: document.querySelector("#authPasswordOptions"),
  authRemember: document.querySelector("#authRemember"),
  authForgot: document.querySelector("#authForgot"),
  authError: document.querySelector("#authError"),
  authSubmit: document.querySelector("#authSubmit"),
  resetForm: document.querySelector("#resetForm"),
  resetPhone: document.querySelector("#resetPhone"),
  resetPassword: document.querySelector("#resetPassword"),
  resetPasswordConfirm: document.querySelector("#resetPasswordConfirm"),
  resetCode: document.querySelector("#resetCode"),
  resetSendCode: document.querySelector("#resetSendCode"),
  resetError: document.querySelector("#resetError"),
  authResetBack: document.querySelector("#authResetBack"),
  setupPasswordDialog: document.querySelector("#setupPasswordDialog"),
  setupPasswordForm: document.querySelector("#setupPasswordForm"),
  setupPassword: document.querySelector("#setupPassword"),
  setupPasswordConfirm: document.querySelector("#setupPasswordConfirm"),
  setupPasswordError: document.querySelector("#setupPasswordError"),
  captchaDialog: document.querySelector("#captchaDialog"),
  captchaImage: document.querySelector("#captchaImage"),
  captchaPiece: document.querySelector("#captchaPiece"),
  captchaSlider: document.querySelector("#captchaSlider"),
  captchaProgress: document.querySelector("#captchaProgress"),
  captchaStatus: document.querySelector("#captchaStatus"),
  captchaClose: document.querySelector("#captchaClose"),
  captchaRefresh: document.querySelector("#captchaRefresh"),
  chatPanel: document.querySelector("#chatPanel"),
  railToggle: document.querySelector("#railToggle"),
  railNewChat: document.querySelector("#railNewChat"),
  railSearch: document.querySelector("#railSearch"),
  railRecent: document.querySelector("#railRecent"),
  railApps: document.querySelector("#railApps"),
  railUser: document.querySelector("#railUser"),
  railAvatar: document.querySelector("#railAvatar"),
  accountMenu: document.querySelector("#accountMenu"),
  accountMenuAvatar: document.querySelector("#accountMenuAvatar"),
  accountMenuName: document.querySelector("#accountMenuName"),
  accountSwitcher: document.querySelector("#accountSwitcher"),
  accountSwitcherList: document.querySelector("#accountSwitcherList"),
  accountSwitcherAdd: document.querySelector("#accountSwitcherAdd"),
  profileModal: document.querySelector("#profileModal"),
  profileAvatarPreview: document.querySelector("#profileAvatarPreview"),
  profileAvatarButton: document.querySelector("#profileAvatarButton"),
  profileAvatarInput: document.querySelector("#profileAvatarInput"),
  profileDisplayName: document.querySelector("#profileDisplayName"),
  profileUsername: document.querySelector("#profileUsername"),
  profileCancel: document.querySelector("#profileCancel"),
  profileSave: document.querySelector("#profileSave"),
  settingsModal: document.querySelector("#settingsModal"),
  settingsClose: document.querySelector("#settingsClose"),
  accountSettingsPanel: document.querySelector("#accountSettingsPanel"),
  accountDeleteModal: document.querySelector("#accountDeleteModal"),
  accountDeleteForm: document.querySelector("#accountDeleteForm"),
  accountDeleteInput: document.querySelector("#accountDeleteInput"),
  accountDeleteError: document.querySelector("#accountDeleteError"),
  accountDeleteCancel: document.querySelector("#accountDeleteCancel"),
  accountDeleteSubmit: document.querySelector("#accountDeleteSubmit"),
  featureConstructionModal: document.querySelector("#featureConstructionModal"),
  featureConstructionClose: document.querySelector("#featureConstructionClose"),
  upgradePlanModal: document.querySelector("#upgradePlanModal"),
  upgradePlanClose: document.querySelector("#upgradePlanClose"),
  storagePanel: document.querySelector("#storagePanel"),
  appearanceValue: document.querySelector("#appearanceValue"),
  accentValue: document.querySelector("#accentValue"),
  accentDot: document.querySelector("#accentDot"),
  languageValue: document.querySelector("#languageValue"),
  zoomValue: document.querySelector("#zoomValue"),
  sidebar: document.querySelector("#sidebar"),
  overlay: document.querySelector("#overlay"),
  openSidebar: document.querySelector("#openSidebar"),
  closeSidebar: document.querySelector("#closeSidebar"),
  sessionList: document.querySelector("#sessionList"),
  newChat: document.querySelector("#newChat"),
  clearAll: document.querySelector("#clearAll"),
  searchSessions: document.querySelector("#searchSessions"),
  conversationTitle: document.querySelector("#conversationTitle"),
  connectionStatus: document.querySelector("#connectionStatus"),
  messageScroll: document.querySelector("#messageScroll"),
  welcome: document.querySelector("#welcome"),
  welcomeBrand: document.querySelector("#welcomeBrand"),
  appsView: document.querySelector("#appsView"),
  dropOverlay: document.querySelector("#dropOverlay"),
  composer: document.querySelector("#composer"),
  fileInput: document.querySelector("#fileInput"),
  attachmentTray: document.querySelector("#attachmentTray"),
  toolsButton: document.querySelector("#toolsButton"),
  toolsMenu: document.querySelector("#toolsMenu"),
  promptInput: document.querySelector("#promptInput"),
  imageModeBar: document.querySelector("#imageModeBar"),
  imageModePill: document.querySelector("#imageModePill"),
  videoModeBar: document.querySelector("#videoModeBar"),
  videoModePill: document.querySelector("#videoModePill"),
  videoFramePicker: document.querySelector("#videoFramePicker"),
  videoFirstFrameButton: document.querySelector("#videoFirstFrameButton"),
  videoLastFrameButton: document.querySelector("#videoLastFrameButton"),
  videoFirstFrameInput: document.querySelector("#videoFirstFrameInput"),
  videoLastFrameInput: document.querySelector("#videoLastFrameInput"),
  videoFirstFramePreview: document.querySelector("#videoFirstFramePreview"),
  videoLastFramePreview: document.querySelector("#videoLastFramePreview"),
  videoFirstFrameRemove: document.querySelector("#videoFirstFrameRemove"),
  videoLastFrameRemove: document.querySelector("#videoLastFrameRemove"),
  webModeBar: document.querySelector("#webModeBar"),
  webModePill: document.querySelector("#webModePill"),
  deepThinkingToggle: document.querySelector("#deepThinkingToggle"),
  aspectButton: document.querySelector("#aspectButton"),
  aspectLabel: document.querySelector("#aspectLabel"),
  aspectMenu: document.querySelector("#aspectMenu"),
  videoAspectButton: document.querySelector("#videoAspectButton"),
  videoAspectLabel: document.querySelector("#videoAspectLabel"),
  videoAspectMenu: document.querySelector("#videoAspectMenu"),
  videoDurationButton: document.querySelector("#videoDurationButton"),
  videoDurationLabel: document.querySelector("#videoDurationLabel"),
  videoDurationMenu: document.querySelector("#videoDurationMenu"),
  sendButton: document.querySelector("#sendButton"),
  sendIcon: document.querySelector("#sendIcon"),
  modelSelect: document.querySelector("#modelSelect"),
  modelToggle: document.querySelector("#modelToggle"),
  modelMenuLabel: document.querySelector("#modelMenuLabel"),
  modelOptions: document.querySelector("#modelOptions"),
  reasoningSelect: document.querySelector("#reasoningSelect"),
  reasoningButton: document.querySelector("#reasoningButton"),
  reasoningLabel: document.querySelector("#reasoningLabel"),
  reasoningMenu: document.querySelector("#reasoningMenu"),
  referencesPanel: document.querySelector("#referencesPanel"),
  closeReferences: document.querySelector("#closeReferences"),
  referencesEmpty: document.querySelector("#referencesEmpty"),
  referencesList: document.querySelector("#referencesList")
};

const chatModelLabels = {
  "gpt-5.5": "GPT 5.5",
  "gpt-5.4": "GPT 5.4",
  "deepseek-v4-pro": "Deepseek v4 pro",
  "claude-opus-4.8": "Claude Opus 4.8",
  "claude-opus-4.7": "Claude Opus 4.7"
};

const settingLabels = {
  appearance: {
    system: { zh: "跟随系统", zht: "跟隨系統", ja: "システム設定", en: "System" },
    dark: { zh: "深色", zht: "深色", ja: "ダーク", en: "Dark" },
    light: { zh: "浅色", zht: "淺色", ja: "ライト", en: "Light" }
  },
  accent: {
    default: { zh: "默认", zht: "預設", ja: "デフォルト", en: "Default" },
    blue: { zh: "蓝色", zht: "藍色", ja: "ブルー", en: "Blue" },
    green: { zh: "绿色", zht: "綠色", ja: "グリーン", en: "Green" },
    yellow: { zh: "黄色", zht: "黃色", ja: "イエロー", en: "Yellow" },
    pink: { zh: "粉色", zht: "粉色", ja: "ピンク", en: "Pink" },
    orange: { zh: "橙色", zht: "橙色", ja: "オレンジ", en: "Orange" },
    purple: { zh: "紫色", zht: "紫色", ja: "パープル", en: "Purple" }
  },
  language: {
    zh: "简体中文",
    zht: "繁體中文",
    ja: "日本語",
    en: "English"
  }
};

const accentColors = {
  default: "#2c2c2c",
  blue: "#1f5fae",
  green: "#1d7f4e",
  yellow: "#916f12",
  pink: "#9f3a74",
  orange: "#a34f14",
  purple: "#6f3cc3"
};

const defaultAccentByTheme = {
  dark: "#2c2c2c",
  light: "#f0f0f0"
};

const defaultAccentTextByTheme = {
  dark: "#ffffff",
  light: "#111111"
};

const uiText = {
  zh: {
    settings: "设置",
    general: "常规",
    personalize: "个性化",
    storage: "存储空间",
    account: "账户",
    appearance: "外观",
    accent: "重点色",
    language: "语言",
    zoom: "缩放",
    newChat: "新对话",
    clearHistory: "清空历史",
    searchPlaceholder: "搜索对话",
    promptPlaceholder: "有问题，尽管问",
    imagePlaceholder: "描述或编辑图像",
    videoPlaceholder: "描述你想创作的视频画面、动作和镜头",
    webPlaceholder: "搜索网页",
    addFiles: "添加照片和文件",
    createImage: "创建图片",
    createVideo: "创建视频",
    deepThinking: "深度思考",
    webSearch: "网页搜索",
    profile: "个人资料",
    upgrade: "升级套餐",
    help: "帮助",
    logout: "退出登录",
    displayName: "显示名称",
    username: "账号",
    cancel: "取消",
    save: "保存",
    editProfile: "编辑个人资料",
    dragFiles: "拖拽文件到这里",
    temporaryChat: "临时聊天",
    temporaryDesc: "此聊天不会出现在聊天历史记录中。",
    image: "图片",
    search: "搜索",
    aspectMenu: "选择图片宽高比",
    referencesTitle: "聊天中的网页",
    referencesEmpty: "尚无网页参考",
    serverConnected: "服务端已连接，可开始对话",
    serverNeedsKey: "请在服务端配置 OPENAI_API_KEY",
    serverError: "服务端连接异常",
    fileNeedsServer: "请先启动本地服务，再从 http://localhost:3000 打开页面。",
    aspectAuto: "自动",
    aspectSquare: "方形",
    aspectPortrait: "竖版",
    aspectStory: "故事版",
    aspectLandscape: "横版",
    aspectWide: "宽屏"
  },
  zht: {
    settings: "設定",
    general: "一般",
    personalize: "個人化",
    storage: "儲存空間",
    account: "帳戶",
    appearance: "外觀",
    accent: "重點色",
    language: "語言",
    zoom: "縮放",
    newChat: "新對話",
    clearHistory: "清除歷史",
    searchPlaceholder: "搜尋對話",
    promptPlaceholder: "有問題，儘管問",
    imagePlaceholder: "描述或編輯圖像",
    videoPlaceholder: "描述你想創作的影片畫面、動作和鏡頭",
    webPlaceholder: "搜尋網頁",
    addFiles: "新增照片和檔案",
    createImage: "建立圖片",
    createVideo: "建立影片",
    deepThinking: "深度思考",
    webSearch: "網頁搜尋",
    profile: "個人資料",
    upgrade: "升級方案",
    help: "說明",
    logout: "登出",
    displayName: "顯示名稱",
    username: "帳號",
    cancel: "取消",
    save: "儲存",
    editProfile: "編輯個人資料",
    dragFiles: "將檔案拖曳到這裡",
    temporaryChat: "臨時聊天",
    temporaryDesc: "此聊天不會出現在聊天記錄中，也不會用於訓練我們的模型。",
    image: "圖片",
    search: "搜尋",
    aspectMenu: "選擇圖片寬高比",
    referencesTitle: "聊天中的網頁",
    referencesEmpty: "尚無網頁參考",
    serverConnected: "服務端已連線，可開始對話",
    serverNeedsKey: "請在服務端配置 OPENAI_API_KEY",
    serverError: "服務端連線異常",
    fileNeedsServer: "請先啟動本機服務，再從 http://localhost:3000 開啟頁面。",
    aspectAuto: "自動",
    aspectSquare: "方形",
    aspectPortrait: "直向",
    aspectStory: "故事版",
    aspectLandscape: "橫向",
    aspectWide: "寬螢幕"
  },
  ja: {
    settings: "設定",
    general: "一般",
    personalize: "パーソナライズ",
    storage: "ストレージ",
    account: "アカウント",
    appearance: "外観",
    accent: "アクセント",
    language: "言語",
    zoom: "ズーム",
    newChat: "新規チャット",
    clearHistory: "履歴を消去",
    searchPlaceholder: "チャットを検索",
    promptPlaceholder: "何でも聞いてください",
    imagePlaceholder: "画像を説明または編集",
    videoPlaceholder: "作成したい動画の映像、動き、カメラワークを説明",
    webPlaceholder: "Webを検索",
    addFiles: "写真とファイルを追加",
    createImage: "画像を作成",
    createVideo: "動画を作成",
    deepThinking: "深く考える",
    webSearch: "Web検索",
    profile: "プロフィール",
    upgrade: "プランをアップグレード",
    help: "ヘルプ",
    logout: "ログアウト",
    displayName: "表示名",
    username: "アカウント",
    cancel: "キャンセル",
    save: "保存",
    editProfile: "プロフィールを編集",
    dragFiles: "ここにファイルをドラッグ",
    temporaryChat: "一時チャット",
    temporaryDesc: "このチャットは履歴に表示されず、モデルの学習にも使用されません。",
    image: "画像",
    search: "検索",
    aspectMenu: "画像の比率を選択",
    referencesTitle: "チャット内のWeb",
    referencesEmpty: "Web参照はまだありません",
    serverConnected: "サーバーに接続済み。会話を開始できます",
    serverNeedsKey: "サーバーで OPENAI_API_KEY を設定してください",
    serverError: "サーバー接続エラー",
    fileNeedsServer: "先にローカルサーバーを起動し、http://localhost:3000 から開いてください。",
    aspectAuto: "自動",
    aspectSquare: "正方形",
    aspectPortrait: "縦長",
    aspectStory: "ストーリー",
    aspectLandscape: "横長",
    aspectWide: "ワイド"
  },
  en: {
    settings: "Settings",
    general: "General",
    personalize: "Personalization",
    storage: "Storage",
    account: "Account",
    appearance: "Appearance",
    accent: "Accent color",
    language: "Language",
    zoom: "Zoom",
    newChat: "New chat",
    clearHistory: "Clear history",
    searchPlaceholder: "Search chats",
    promptPlaceholder: "Ask anything",
    imagePlaceholder: "Describe or edit an image",
    videoPlaceholder: "Describe the video, motion, and camera work",
    webPlaceholder: "Search the web",
    addFiles: "Add photos and files",
    createImage: "Create image",
    createVideo: "Create video",
    deepThinking: "Deep thinking",
    webSearch: "Web search",
    profile: "Profile",
    upgrade: "Upgrade plan",
    help: "Help",
    logout: "Log out",
    displayName: "Display name",
    username: "Account",
    cancel: "Cancel",
    save: "Save",
    editProfile: "Edit profile",
    dragFiles: "Drop files here",
    temporaryChat: "Temporary chat",
    temporaryDesc: "This chat will not appear in history and will not be used to train our models.",
    image: "Image",
    search: "Search",
    aspectMenu: "Choose image aspect ratio",
    referencesTitle: "Web in this chat",
    referencesEmpty: "No web references yet",
    serverConnected: "Server connected. Ready to chat",
    serverNeedsKey: "Configure OPENAI_API_KEY on the server",
    serverError: "Server connection error",
    fileNeedsServer: "Start the local server first, then open http://localhost:3000.",
    aspectAuto: "Auto",
    aspectSquare: "Square",
    aspectPortrait: "Portrait",
    aspectStory: "Story",
    aspectLandscape: "Landscape",
    aspectWide: "Wide"
  }
};

const imageModelLabels = {
  "gpt-image-2": "GPT image 2",
  "nano-banana-pro": "Nano Banana Pro",
  "nano-banana-2": "Nano Banana 2"
};

const videoModelLabels = {
  "sora-2": "Sora2"
};

const modelLabels = {
  ...chatModelLabels,
  ...imageModelLabels,
  ...videoModelLabels
};

const reasoningLabels = {
  minimal: "极速",
  medium: "均衡",
  high: "高级"
};

const aspectLabels = {
  auto: "自动",
  square: "方形",
  portrait: "竖版",
  story: "故事版",
  landscape: "横版",
  wide: "宽屏"
};

const aspectSizes = {
  auto: "1024x1024",
  square: "1024x1024",
  portrait: "1024x1536",
  story: "1024x1536",
  landscape: "1536x1024",
  wide: "1536x1024"
};

let currentUser = null;
let authSessionToken = sessionStorage.getItem("noonai.session-token") || "";
let isStreaming = false;
let state = loadState();
let userProfile = loadUserProfile();
let appSettings = loadSettings();
let authMethod = "code";
let pendingSignupToken = "";
let captchaChallenge = null;
let captchaResolve = null;
let captchaReject = null;
let appStarted = false;
let userDataSyncTimer = null;
let editingProfile = null;
let draftSession = null;
let temporarySession = null;
let activeSessionId = "";
activateLoadedState();
let abortController = null;
let currentStreamingSessionId = "";
let currentStreamingMessageId = "";
let activeMainView = "chat";
let activeRailPanel = "";
let activeMode = "chat";
let selectedImageModel = "gpt-image-2";
let selectedVideoModel = "sora-2";
let selectedAspect = "auto";
let selectedVideoAspect = "wide";
let selectedVideoDuration = 4;
let videoFirstFrame = null;
let videoLastFrame = null;
let pendingAttachments = [];
let editingUserMessageId = "";
let dragDepth = 0;
let mascotEyeFrame = 0;
let mascotPointer = null;
let mascotEyesLocked = false;
let activeSettingsSection = "general";
let storageCategory = "";
let storageData = null;
let storageLoading = false;
let storageError = "";
const storageObjectUrls = new Map();

init();

async function init() {
  initializeAppearance();
  bindGuestAccessGuard();
  bindAuthEvents();
  await bootstrapAuth();
  bindEvents();
}

function startApp(options = {}) {
  if (appStarted) return;
  const guest = Boolean(options.guest);
  appStarted = true;
  hydrateAppsView();
  applySettings();
  if (!guest) {
    handleInitialNewChatRequest();
    saveState();
  }
  render();
  scrollToBottom();
  checkHealth();
}

function bindAuthEvents() {
  els.authClose.addEventListener("click", closeAuthModalForGuest);
  els.authCodeTab.addEventListener("click", () => setAuthMethod("code"));
  els.authPasswordTab.addEventListener("click", () => setAuthMethod("password"));
  els.authSendCode.addEventListener("click", sendAuthCode);
  els.authForm.addEventListener("submit", submitAuthForm);
  els.authForgot.addEventListener("click", showResetPassword);
  els.authResetBack.addEventListener("click", showLoginView);
  els.resetSendCode.addEventListener("click", sendResetCode);
  els.resetForm.addEventListener("submit", submitResetPassword);
  els.setupPasswordForm.addEventListener("submit", completeFirstLogin);
  els.captchaSlider.addEventListener("input", updateCaptchaSlider);
  els.captchaSlider.addEventListener("change", verifyCaptchaSlider);
  els.captchaClose.addEventListener("click", closeCaptcha);
  els.captchaRefresh.addEventListener("click", loadCaptchaChallenge);
  document.querySelectorAll("[data-toggle-password]").forEach((button) => {
    button.addEventListener("click", () => togglePasswordInput(button.dataset.togglePassword, button));
  });
  const rememberedPhone = localStorage.getItem("noonai.remembered-phone") || "";
  if (rememberedPhone) {
    els.authPhone.value = rememberedPhone;
    els.authRemember.checked = true;
  }
  renderAuthForm();
}

async function bootstrapAuth() {
  try {
    if (!authSessionToken) {
      const preferredAccount = getDeviceAccounts()[0];
      if (preferredAccount?.token) setActiveSessionToken(preferredAccount.token);
    }
    let response = await authFetch("/api/auth/me");
    let payload = await response.json();
    if (!payload.user && authSessionToken) {
      setActiveSessionToken("");
      response = await authFetch("/api/auth/me");
      payload = await response.json();
    }
    if (!payload.user) {
      const restored = await restoreRememberedDeviceAccount();
      if (!restored) showAuthModal();
      return;
    }
    await completeAuthentication(payload.user, payload.userData);
  } catch {
    showAuthModal("暂时无法连接登录服务，请刷新页面重试。");
  }
}

function showAuthModal(message = "") {
  if (canBrowseAsGuest() && appStarted && !document.body.classList.contains("guest-mode")) {
    enterGuestMode();
  }
  els.authModal.hidden = false;
  showLoginView();
  renderAuthForm();
  els.authError.textContent = message;
  updateAuthCloseState();
  requestAnimationFrame(() => els.authPhone.focus());
}

function canBrowseAsGuest() {
  return !currentUser && getDeviceAccounts().length === 0;
}

function updateAuthCloseState() {
  const enabled = canBrowseAsGuest();
  els.authClose.disabled = !enabled;
  els.authClose.title = enabled ? "暂不登录，浏览 NoonAI" : "请先完成登录";
  els.authClose.setAttribute("aria-label", enabled ? "暂不登录，浏览 NoonAI" : "请先完成登录");
}

function closeAuthModalForGuest() {
  if (!canBrowseAsGuest()) return;
  els.authModal.hidden = true;
  enterGuestMode();
}

function enterGuestMode() {
  currentUser = null;
  state = { sessions: [] };
  userProfile = normalizeProfile({});
  appSettings = normalizeSettings({});
  draftSession = createSession(false);
  temporarySession = null;
  activeSessionId = draftSession.id;
  activeMainView = "chat";
  activeRailPanel = "";
  pendingAttachments = [];
  document.body.classList.add("guest-mode");

  if (!appStarted) {
    startApp({ guest: true });
    return;
  }

  closeSidebar();
  closeReferencesPanel();
  closeMenus();
  closeSessionMenu();
  closeAccountMenu();
  applySettings();
  render();
  scrollToBottom();
}

function bindGuestAccessGuard() {
  ["pointerdown", "click", "submit", "focusin"].forEach((eventName) => {
    document.addEventListener(eventName, guardGuestInteraction, true);
  });
  document.addEventListener("drop", guardGuestFileDrop, true);
}

function guardGuestInteraction(event) {
  if (currentUser || !els.authModal.hidden) return;
  const target = event.target instanceof Element ? event.target : null;
  const appShell = target?.closest(".app-shell");
  if (!appShell) return;

  const interactive = target.closest(
    "button, input, textarea, select, a, [role='button'], [contenteditable='true'], .welcome-brand"
  );
  if (!interactive) return;

  event.preventDefault();
  event.stopImmediatePropagation();
  interactive.blur?.();
  showAuthModal("登录后即可体验完整功能。");
}

function guardGuestFileDrop(event) {
  if (currentUser || !els.authModal.hidden) return;
  const target = event.target instanceof Element ? event.target : null;
  if (!target?.closest(".app-shell")) return;
  if (!event.dataTransfer?.files?.length) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  showAuthModal("登录后即可上传文件并使用完整功能。");
}

function setAuthMethod(method) {
  authMethod = method === "code" ? "code" : "password";
  renderAuthForm();
}

function renderAuthForm() {
  const usesCode = authMethod === "code";
  els.authCodeTab.classList.toggle("active", usesCode);
  els.authPasswordTab.classList.toggle("active", !usesCode);
  els.authPasswordField.hidden = usesCode;
  els.authCodeField.hidden = !usesCode;
  els.authInviteField.hidden = !usesCode;
  els.authPasswordOptions.hidden = usesCode;
  els.authSubmit.textContent = usesCode ? "注册/登录" : "登录";
  els.authError.textContent = "";
}

async function sendAuthCode() {
  const phone = els.authPhone.value.trim();
  if (!isValidPhone(phone)) return setAuthError(els.authError, "请输入有效的中国大陆手机号。");
  try {
    const captchaToken = await openCaptcha();
    const payload = await authRequest("/api/auth/send-code", {
      phone,
      purpose: "login",
      captchaToken
    });
    if (payload.devCode) els.authCode.value = payload.devCode;
    setAuthError(els.authError, payload.devCode ? `开发模式验证码：${payload.devCode}，5 分钟内有效。` : "验证码已发送，5 分钟内有效。", true);
    startCodeCountdown(els.authSendCode);
  } catch (error) {
    if (error?.message !== "captcha_cancelled") setAuthError(els.authError, error.message);
  }
}

async function submitAuthForm(event) {
  event.preventDefault();
  setAuthBusy(true);
  try {
    const body = {
      phone: els.authPhone.value.trim(),
      password: els.authPassword.value,
      code: els.authCode.value.trim()
    };
    const endpoint = authMethod === "code" ? "/api/auth/login/code" : "/api/auth/login/password";
    const payload = await authRequest(endpoint, body);
    if (payload.needsPassword) {
      pendingSignupToken = payload.signupToken;
      els.setupPasswordDialog.hidden = false;
      els.authLoginView.inert = true;
      requestAnimationFrame(() => els.setupPassword.focus());
      setAuthBusy(false);
      return;
    }
    if (authMethod === "password") {
      if (els.authRemember.checked) localStorage.setItem("noonai.remembered-phone", body.phone);
      else localStorage.removeItem("noonai.remembered-phone");
    }
    await completeAuthentication(payload.user, payload.userData);
  } catch (error) {
    els.authError.textContent = error.message;
    setAuthBusy(false);
  }
}

async function authRequest(endpoint, body) {
  const response = await authFetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || "请求失败，请稍后重试。");
  if (payload.sessionToken) {
    authSessionToken = payload.sessionToken;
    sessionStorage.setItem("noonai.session-token", authSessionToken);
  }
  return payload;
}

function authFetch(endpoint, options = {}) {
  const headers = new Headers(options.headers || {});
  if (authSessionToken) headers.set("Authorization", `Bearer ${authSessionToken}`);
  return fetch(`${API_BASE}${endpoint}`, {
    ...options,
    headers,
    credentials: "same-origin"
  });
}

function setAuthBusy(busy) {
  els.authSubmit.disabled = busy;
  if (busy) els.authError.textContent = "";
}

function showResetPassword() {
  els.authLoginView.hidden = true;
  els.authResetView.hidden = false;
  els.resetPhone.value = els.authPhone.value;
  els.resetError.textContent = "";
  requestAnimationFrame(() => els.resetPhone.focus());
}

function showLoginView() {
  els.authResetView.hidden = true;
  els.authLoginView.hidden = false;
}

async function sendResetCode() {
  const phone = els.resetPhone.value.trim();
  if (!isValidPhone(phone)) return setAuthError(els.resetError, "请输入有效的中国大陆手机号。");
  try {
    const captchaToken = await openCaptcha();
    const payload = await authRequest("/api/auth/send-code", { phone, purpose: "reset", captchaToken });
    if (payload.devCode) els.resetCode.value = payload.devCode;
    setAuthError(els.resetError, payload.devCode ? `开发模式验证码：${payload.devCode}，5 分钟内有效。` : "验证码已发送，5 分钟内有效。", true);
    startCodeCountdown(els.resetSendCode);
  } catch (error) {
    if (error?.message !== "captcha_cancelled") setAuthError(els.resetError, error.message);
  }
}

async function submitResetPassword(event) {
  event.preventDefault();
  const passwordError = validatePasswordInput(els.resetPassword.value, els.resetPasswordConfirm.value);
  if (passwordError) return setAuthError(els.resetError, passwordError);
  const submit = els.resetForm.querySelector("button[type='submit']");
  submit.disabled = true;
  try {
    const payload = await authRequest("/api/auth/reset-password", {
      phone: els.resetPhone.value.trim(),
      password: els.resetPassword.value,
      code: els.resetCode.value.trim()
    });
    await completeAuthentication(payload.user, payload.userData);
  } catch (error) {
    setAuthError(els.resetError, error.message);
  } finally {
    submit.disabled = false;
  }
}

async function completeFirstLogin(event) {
  event.preventDefault();
  const passwordError = validatePasswordInput(els.setupPassword.value, els.setupPasswordConfirm.value);
  if (passwordError) return setAuthError(els.setupPasswordError, passwordError);
  const submit = els.setupPasswordForm.querySelector("button[type='submit']");
  submit.disabled = true;
  try {
    const payload = await authRequest("/api/auth/complete-registration", {
      signupToken: pendingSignupToken,
      password: els.setupPassword.value
    });
    if (!payload.user || !payload.sessionToken) throw new Error("账号创建失败，请重新获取验证码后重试。");
    pendingSignupToken = "";
    els.setupPasswordDialog.hidden = true;
    els.authLoginView.inert = false;
    await completeAuthentication(payload.user, payload.userData, { deferInitialSync: true });
  } catch (error) {
    setAuthError(els.setupPasswordError, error.message);
  } finally {
    submit.disabled = false;
  }
}

function validatePasswordInput(password, confirmation) {
  if (password.length < 6) return "密码至少需要 6 位。";
  const categories = [/[A-Za-z]/.test(password), /\d/.test(password), /[^A-Za-z\d]/.test(password)].filter(Boolean).length;
  if (categories < 2) return "密码需包含字母、数字、特殊字符中的至少两类。";
  if (password !== confirmation) return "两次输入的密码不一致。";
  return "";
}

function isValidPhone(phone) {
  return /^1[3-9]\d{9}$/.test(String(phone).replace(/\D/g, ""));
}

function setAuthError(element, message, success = false) {
  element.textContent = message || "";
  element.style.color = success ? "#d7f7df" : "";
}

function startCodeCountdown(button) {
  let remaining = 60;
  button.disabled = true;
  button.textContent = `${remaining}s`;
  const timer = setInterval(() => {
    remaining -= 1;
    button.textContent = remaining > 0 ? `${remaining}s` : "获取验证码";
    if (remaining <= 0) {
      clearInterval(timer);
      button.disabled = false;
    }
  }, 1000);
}

function togglePasswordInput(id, button) {
  const input = document.getElementById(id);
  if (!input) return;
  input.type = input.type === "password" ? "text" : "password";
  button.textContent = input.type === "password" ? "◉" : "○";
}

async function openCaptcha() {
  await loadCaptchaChallenge();
  els.captchaDialog.hidden = false;
  els.authLoginView.inert = true;
  els.authResetView.inert = true;
  return new Promise((resolve, reject) => {
    captchaResolve = resolve;
    captchaReject = reject;
  });
}

async function loadCaptchaChallenge() {
  const response = await authRequest("/api/auth/captcha", {});
  captchaChallenge = response;
  els.captchaImage.src = response.image;
  els.captchaPiece.src = response.piece;
  els.captchaPiece.style.top = `${response.pieceTop}px`;
  els.captchaPiece.style.width = `${response.pieceWidth}px`;
  els.captchaPiece.style.height = `${response.pieceWidth}px`;
  els.captchaSlider.max = String(response.width - response.pieceWidth);
  els.captchaSlider.value = "0";
  els.captchaPiece.style.left = "0px";
  els.captchaProgress.style.width = `${response.pieceWidth}px`;
  els.captchaStatus.textContent = "请将滑块拖到图片中的缺口位置";
  els.captchaStatus.style.color = "";
}

function updateCaptchaSlider() {
  const value = Number(els.captchaSlider.value);
  els.captchaPiece.style.left = `${value}px`;
  els.captchaProgress.style.width = `${value + (captchaChallenge?.pieceWidth || 52)}px`;
}

async function verifyCaptchaSlider() {
  if (!captchaChallenge) return;
  els.captchaSlider.disabled = true;
  try {
    const payload = await authRequest("/api/auth/verify-captcha", {
      challengeId: captchaChallenge.challengeId,
      position: Number(els.captchaSlider.value)
    });
    els.captchaStatus.textContent = "验证成功";
    els.captchaStatus.style.color = "#d7f7df";
    const resolve = captchaResolve;
    setTimeout(() => {
      finishCaptcha();
      resolve?.(payload.captchaToken);
    }, 250);
  } catch (error) {
    els.captchaStatus.textContent = error.message;
    els.captchaStatus.style.color = "#ff9b94";
    els.captchaSlider.value = "0";
    updateCaptchaSlider();
    els.captchaSlider.disabled = false;
  }
}

function closeCaptcha() {
  const reject = captchaReject;
  finishCaptcha();
  reject?.(new Error("captcha_cancelled"));
}

function finishCaptcha() {
  els.captchaDialog.hidden = true;
  els.captchaSlider.disabled = false;
  els.authLoginView.inert = false;
  els.authResetView.inert = false;
  captchaResolve = null;
  captchaReject = null;
}

async function completeAuthentication(user, initialUserData = null, options = {}) {
  currentUser = user;
  document.body.classList.remove("guest-mode");
  els.authModal.hidden = true;
  await loadUserData(initialUserData, options);
  resetToNewConversationHome();
  rememberCurrentDeviceAccount();
  if (!appStarted) {
    startApp();
    return;
  }
  applySettings();
  render();
  renderProfileState();
  scrollToBottom();
}

function resetToNewConversationHome() {
  activeMainView = "chat";
  activeRailPanel = "";
  activeMode = "chat";
  draftSession = createSession(false);
  temporarySession = null;
  activeSessionId = draftSession.id;
  pendingAttachments = [];
  editingUserMessageId = "";
  dragDepth = 0;

  if (!appStarted) return;

  els.promptInput.value = "";
  els.dropOverlay.hidden = true;
  closeSidebar();
  closeReferencesPanel();
  closeMenus();
  closeSessionMenu();
  closeAccountMenu();
  renderAttachmentTray();
}

function setActiveSessionToken(token = "") {
  authSessionToken = token;
  if (token) sessionStorage.setItem("noonai.session-token", token);
  else sessionStorage.removeItem("noonai.session-token");
}

function getDeviceAccounts() {
  try {
    const accounts = JSON.parse(localStorage.getItem(DEVICE_ACCOUNTS_KEY) || "[]");
    return Array.isArray(accounts)
      ? accounts
        .filter((account) => account?.id && account?.phone && account?.token)
        .sort((a, b) => Number(b.lastUsedAt || 0) - Number(a.lastUsedAt || 0))
      : [];
  } catch {
    localStorage.removeItem(DEVICE_ACCOUNTS_KEY);
    return [];
  }
}

function saveDeviceAccounts(accounts) {
  localStorage.setItem(DEVICE_ACCOUNTS_KEY, JSON.stringify(accounts.slice(0, 12)));
}

function rememberCurrentDeviceAccount() {
  if (!currentUser?.id || !currentUser?.phone || !authSessionToken) return;
  const accounts = getDeviceAccounts().filter((account) => account.id !== currentUser.id);
  accounts.unshift({
    id: currentUser.id,
    phone: currentUser.phone,
    displayName: userProfile.displayName || currentUser.phone,
    token: authSessionToken,
    lastUsedAt: Date.now()
  });
  saveDeviceAccounts(accounts);
  renderAccountSwitcher();
}

function removeDeviceAccount(accountId) {
  saveDeviceAccounts(getDeviceAccounts().filter((account) => account.id !== accountId));
  renderAccountSwitcher();
}

function getDeviceAccountProfile(account) {
  try {
    const cached = JSON.parse(localStorage.getItem(`${PROFILE_KEY}.${account.id}`) || "{}");
    return normalizeProfile({
      ...cached,
      displayName: cached.displayName || account.displayName || account.phone,
      username: account.phone
    });
  } catch {
    return normalizeProfile({ displayName: account.displayName || account.phone, username: account.phone });
  }
}

async function restoreRememberedDeviceAccount() {
  for (const account of getDeviceAccounts()) {
    setActiveSessionToken(account.token);
    try {
      const response = await authFetch("/api/auth/me");
      const payload = await response.json().catch(() => ({}));
      if (response.ok && payload.user) {
        await completeAuthentication(payload.user, payload.userData);
        return true;
      }
    } catch {
      // Try the next account saved in this browser.
    }
    removeDeviceAccount(account.id);
  }
  setActiveSessionToken("");
  return false;
}

async function loadUserData(initialUserData = null, options = {}) {
  let data = initialUserData;
  if (!data) {
    let response = await authFetch("/api/user-data");
    if (!response.ok) {
      await new Promise((resolve) => setTimeout(resolve, 150));
      response = await authFetch("/api/user-data");
    }
    if (!response.ok) {
      currentUser = null;
      throw new Error("用户数据加载失败，请重新登录。");
    }
    data = await response.json();
  }
  const legacyMigrated = localStorage.getItem("noonai.legacy.migrated") === "1";
  if (!data.initialized && !legacyMigrated && Array.isArray(state.sessions) && state.sessions.length) {
    data = { state, profile: userProfile, settings: appSettings };
    localStorage.setItem("noonai.legacy.migrated", "1");
  }
  const cachedState = loadCachedStateForUser(currentUser.id);
  const cachedProfile = loadCachedProfileForUser(currentUser.id);
  const serverState = data.state && Array.isArray(data.state.sessions) ? normalizeState(data.state) : { sessions: [] };
  const serverProfile = normalizeProfile(data.profile || { displayName: currentUser.phone, username: currentUser.phone });
  const recoveredState = serverState.sessions.length === 0 && cachedState.sessions.length > 0;
  const recoveredProfile = isDefaultAccountProfile(serverProfile) && isPersonalizedAccountProfile(cachedProfile);
  state = recoveredState ? cachedState : serverState;
  userProfile = recoveredProfile ? cachedProfile : serverProfile;
  const appearanceMigrationKey = `${APPEARANCE_MIGRATION_KEY}.${currentUser.id}`;
  const appearanceMigrated = localStorage.getItem(appearanceMigrationKey) !== "1";
  appSettings = normalizeSettings({
    ...(data.settings || {}),
    ...(appearanceMigrated ? { appearance: "system" } : {})
  });
  if (appearanceMigrated) localStorage.setItem(appearanceMigrationKey, "1");
  activateLoadedState();
  persistUserDataLocally();
  if ((!data.initialized || recoveredState || recoveredProfile || appearanceMigrated) && !options.deferInitialSync) await syncUserDataNow();
}

function loadCachedStateForUser(userId) {
  try {
    const cached = JSON.parse(localStorage.getItem(`${STORAGE_KEY}.${userId}`) || "{}");
    return Array.isArray(cached.sessions) ? normalizeState(cached) : { sessions: [] };
  } catch {
    return { sessions: [] };
  }
}

function loadCachedProfileForUser(userId) {
  try {
    return normalizeProfile(JSON.parse(localStorage.getItem(`${PROFILE_KEY}.${userId}`) || "{}"));
  } catch {
    return normalizeProfile({});
  }
}

function isDefaultAccountProfile(profile) {
  return !profile.avatar && (!profile.displayName || profile.displayName === currentUser?.phone || profile.displayName === "User");
}

function isPersonalizedAccountProfile(profile) {
  return Boolean(profile.avatar || (profile.displayName && profile.displayName !== currentUser?.phone && profile.displayName !== "User"));
}

function activateLoadedState() {
  draftSession = null;
  temporarySession = null;
  activeSessionId = state.activeSessionId || state.sessions.find((session) => session.messages.length > 0)?.id || "";
  if (state.sessions.some((session) => session.id === activeSessionId)) return;
  const recordedSession = state.sessions.find((session) => session.messages.length > 0);
  if (recordedSession) {
    activeSessionId = recordedSession.id;
  } else {
    draftSession = createSession(false);
    activeSessionId = draftSession.id;
  }
}

function bindEvents() {
  els.newChat.addEventListener("click", startNewChat);
  els.railToggle.addEventListener("click", toggleSidebar);
  els.railNewChat.addEventListener("click", startNewChat);
  els.railSearch.addEventListener("click", openSearch);
  els.railRecent.addEventListener("click", openRecent);
  els.railApps.addEventListener("click", openAppsView);
  els.appsView.addEventListener("click", handleAppsViewClick);
  els.railUser.addEventListener("click", (event) => {
    event.stopPropagation();
    toggleAccountMenu();
  });
  els.accountMenu.addEventListener("click", handleAccountMenuClick);
  els.accountSwitcher.addEventListener("click", handleAccountSwitcherClick);
  els.accountSwitcherAdd.addEventListener("click", openAddAccountLogin);
  els.profileAvatarButton.addEventListener("click", () => els.profileAvatarInput.click());
  els.profileAvatarInput.addEventListener("change", handleProfileAvatarChange);
  els.profileCancel.addEventListener("click", closeProfileModal);
  els.profileSave.addEventListener("click", saveProfileEdits);
  els.profileModal.addEventListener("click", (event) => {
    if (event.target === els.profileModal) closeProfileModal();
  });
  els.settingsClose.addEventListener("click", closeSettingsModal);
  els.settingsModal.addEventListener("click", handleSettingsModalClick);
  els.accountDeleteCancel.addEventListener("click", closeAccountDeleteModal);
  els.accountDeleteInput.addEventListener("input", updateAccountDeleteState);
  els.accountDeleteForm.addEventListener("submit", deleteCurrentAccount);
  els.accountDeleteModal.addEventListener("click", (event) => {
    if (event.target === els.accountDeleteModal) closeAccountDeleteModal();
  });
  els.featureConstructionClose.addEventListener("click", closeFeatureConstructionModal);
  els.featureConstructionModal.addEventListener("click", (event) => {
    if (event.target === els.featureConstructionModal) closeFeatureConstructionModal();
  });
  els.upgradePlanClose.addEventListener("click", closeUpgradePlanModal);
  els.upgradePlanModal.addEventListener("click", (event) => {
    if (event.target === els.upgradePlanModal) closeUpgradePlanModal();
  });

  els.clearAll.addEventListener("click", () => {
    if (!confirm("确定清空所有本地对话历史吗？")) return;
    state.sessions = [];
    draftSession = createSession(false);
    activeSessionId = draftSession.id;
    saveState();
    render();
  });

  els.searchSessions.addEventListener("input", renderSessions);
  els.modelSelect.addEventListener("change", updateSessionSettings);
  els.reasoningSelect.addEventListener("change", updateSessionSettings);
  els.toolsButton.addEventListener("click", (event) => {
    event.stopPropagation();
    toggleMenu("tools");
  });
  els.reasoningButton.addEventListener("click", (event) => {
    event.stopPropagation();
    toggleMenu("reasoning");
  });
  els.aspectButton.addEventListener("click", (event) => {
    event.stopPropagation();
    toggleMenu("aspect");
  });
  els.videoAspectButton.addEventListener("click", (event) => {
    event.stopPropagation();
    toggleMenu("video-aspect");
  });
  els.videoDurationButton.addEventListener("click", (event) => {
    event.stopPropagation();
    toggleMenu("video-duration");
  });
  els.imageModePill.addEventListener("click", () => {
    deactivateImageMode();
    focusComposer();
  });
  els.videoModePill.addEventListener("click", () => {
    deactivateVideoMode();
    focusComposer();
  });
  els.videoFirstFrameButton.addEventListener("click", (event) => {
    if (!event.target.closest("#videoFirstFrameRemove")) els.videoFirstFrameInput.click();
  });
  els.videoLastFrameButton.addEventListener("click", (event) => {
    if (!event.target.closest("#videoLastFrameRemove")) els.videoLastFrameInput.click();
  });
  els.videoFirstFrameRemove.addEventListener("click", (event) => {
    event.stopPropagation();
    setVideoFrame("first", null);
  });
  els.videoLastFrameRemove.addEventListener("click", (event) => {
    event.stopPropagation();
    setVideoFrame("last", null);
  });
  els.videoFirstFrameInput.addEventListener("change", () => {
    loadVideoFrame("first", els.videoFirstFrameInput.files?.[0]);
    els.videoFirstFrameInput.value = "";
  });
  els.videoLastFrameInput.addEventListener("change", () => {
    loadVideoFrame("last", els.videoLastFrameInput.files?.[0]);
    els.videoLastFrameInput.value = "";
  });
  els.webModePill.addEventListener("click", () => {
    deactivateWebMode();
    focusComposer();
  });
  els.deepThinkingToggle.addEventListener("click", () => {
    const session = getActiveSession();
    session.deepseekThinking = !(session.deepseekThinking !== false);
    session.updatedAt = Date.now();
    saveState();
    renderDeepThinkingState();
    focusComposer();
  });
  els.toolsMenu.addEventListener("click", handleToolsMenuClick);
  els.reasoningMenu.addEventListener("click", handleReasoningMenuClick);
  els.aspectMenu.addEventListener("click", handleAspectMenuClick);
  els.videoAspectMenu.addEventListener("click", handleVideoAspectMenuClick);
  els.videoDurationMenu.addEventListener("click", handleVideoDurationMenuClick);
  document.addEventListener("click", () => {
    closeMenus();
    closeSessionMenu();
    closeAccountMenu();
  });
  document.addEventListener("pointermove", handleMascotPointerMove, { passive: true });
  document.addEventListener("mouseleave", resetMascotEyes);
  window.addEventListener("resize", () => {
    closeMenus();
    closeAccountMenu();
  });
  window.addEventListener("blur", resetMascotEyes);
  window.addEventListener("pageshow", handlePageRestore);

  els.composer.addEventListener("submit", (event) => {
    event.preventDefault();
    if (isStreaming) {
      stopStreaming();
      return;
    }
    submitPrompt(els.promptInput.value);
  });

  els.promptInput.addEventListener("input", () => {
    resizeTextarea();
    updateSendState();
  });

  els.promptInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
      event.preventDefault();
      els.composer.requestSubmit();
    }
  });

  els.openSidebar.addEventListener("click", startTemporaryChat);
  els.closeSidebar.addEventListener("click", closeSidebar);
  els.closeReferences.addEventListener("click", closeReferencesPanel);
  els.overlay.addEventListener("click", closeSidebar);
  els.fileInput.addEventListener("change", () => {
    addFiles(els.fileInput.files);
    els.fileInput.value = "";
  });
  els.attachmentTray.addEventListener("click", handleAttachmentTrayClick);
  ["dragenter", "dragover", "dragleave", "drop"].forEach((eventName) => {
    document.addEventListener(eventName, preventFileOpen);
  });
  els.chatPanel.addEventListener("dragenter", handleDragEnter);
  els.chatPanel.addEventListener("dragover", handleDragOver);
  els.chatPanel.addEventListener("dragleave", handleDragLeave);
  els.chatPanel.addEventListener("drop", handleDrop);
  document.addEventListener("keydown", handleGlobalShortcuts);
  els.welcomeBrand.addEventListener("dblclick", toggleMascotEyeLock);

  document.querySelectorAll(".prompt-chip").forEach((button) => {
    button.addEventListener("click", () => {
      if (button.dataset.action === "image") {
        activateImageMode();
        return;
      }
      deactivateImageMode();
      els.promptInput.value = button.dataset.prompt || button.textContent.trim();
      resizeTextarea();
      updateSendState();
      focusComposer();
    });
  });
}

function startNewChat() {
  showChatView();
  const session = createSession(false);
  draftSession = session;
  temporarySession = null;
  activeSessionId = session.id;
  deactivateImageMode();
  deactivateWebMode();
  saveState();
  render();
  focusComposer();
  closeSidebar();
}

function handleInitialNewChatRequest() {
  const params = new URLSearchParams(window.location.search);
  const requestedByUrl = params.get("new") === "1";
  let requestedByReturn = false;
  try {
    requestedByReturn = sessionStorage.getItem(RETURN_NEW_CHAT_KEY) === "1";
    if (requestedByReturn) sessionStorage.removeItem(RETURN_NEW_CHAT_KEY);
  } catch {}
  if (!requestedByUrl && !requestedByReturn) return;
  startNewChat();
  if (requestedByUrl) window.history.replaceState(null, "", window.location.pathname);
}

function handlePageRestore() {
  if (!appStarted || !currentUser) return;
  handleInitialNewChatRequest();
}

function hydrateAppsView() {
  if (!els.appsView) return;
  els.appsView.setAttribute("aria-label", "应用");
  els.appsView.innerHTML = `
    <div class="apps-grid">
      <button class="app-tile" type="button" aria-label="AI 剪辑" data-coming-soon>
        <img class="app-tile-icon" src="./app-ai-edit-icon.png" alt="" aria-hidden="true" />
        <span>AI 剪辑</span>
        <small>素材整理与智能成片</small>
      </button>
      <button class="app-tile" type="button" aria-label="AI 短剧" data-app-url="./ai-drama/index.html">
        <img class="app-tile-icon" src="./app-ai-drama-icon.png" alt="" aria-hidden="true" />
        <span>AI 短剧</span>
        <small>分镜、台词与剧情草稿</small>
      </button>
      <button class="app-tile" type="button" aria-label="活字印刷机" data-app-url="./letterpress/index.html">
        <img class="app-tile-icon" src="./app-letterpress-icon.png" alt="" aria-hidden="true" />
        <span>活字印刷机</span>
        <small>用音节库拼接生成语音</small>
      </button>
      <button class="app-tile" type="button" aria-label="模型测试" data-app-url="./model-test/index.html">
        <img class="app-tile-icon app-model-test-icon" src="./app-model-test-icon.png" alt="" aria-hidden="true" />
        <span>模型测试</span>
        <small>复制题库并生成多维能力报告</small>
      </button>
    </div>
  `;
}

function startTemporaryChat() {
  showChatView();
  const session = createSession(false, { temporary: true });
  temporarySession = session;
  activeSessionId = session.id;
  pendingAttachments = [];
  deactivateImageMode();
  deactivateWebMode();
  renderAttachmentTray();
  saveState();
  render();
  focusComposer();
  closeSidebar();
}

function openSearch() {
  if (activeMainView === "chat" && activeRailPanel === "search" && els.sidebar.classList.contains("open")) {
    closeSidebar();
    return;
  }
  showChatView();
  activeRailPanel = "search";
  openSidebar();
  requestAnimationFrame(() => {
    els.searchSessions.focus();
    els.searchSessions.select();
  });
}

function openRecent() {
  if (activeMainView === "chat" && activeRailPanel === "recent" && els.sidebar.classList.contains("open")) {
    closeSidebar();
    return;
  }
  showChatView();
  activeRailPanel = "recent";
  els.searchSessions.value = "";
  renderSessions();
  openSidebar();
}

function openAppsView() {
  if (activeMainView === "apps") {
    showChatView();
    return;
  }
  activeMainView = "apps";
  activeRailPanel = "";
  deactivateImageMode();
  deactivateWebMode();
  closeSidebar();
  closeReferencesPanel();
  closeMenus();
  closeSessionMenu();
  closeAccountMenu();
  render();
}

function handleAppsViewClick(event) {
  if (event.target.closest("[data-coming-soon]")) {
    openFeatureConstructionModal();
    return;
  }

  const tile = event.target.closest("[data-app-url]");
  if (!tile) return;
  if (tile.dataset.appUrl.includes("/letterpress/")) {
    try {
      sessionStorage.setItem(LETTERPRESS_ENTRY_KEY, JSON.stringify({
        url: window.location.href,
        createdAt: Date.now()
      }));
    } catch {}
  }
  window.location.href = tile.dataset.appUrl;
}

function openFeatureConstructionModal() {
  els.featureConstructionModal.hidden = false;
  requestAnimationFrame(() => els.featureConstructionClose.focus());
}

function closeFeatureConstructionModal() {
  els.featureConstructionModal.hidden = true;
}

function showChatView() {
  const wasAppsView = activeMainView === "apps";
  activeMainView = "chat";
  els.appsView.hidden = true;
  els.chatPanel.classList.remove("apps-open");
  if (wasAppsView && appStarted) render();
  else renderRailNavigationState();
}

function renderRailNavigationState() {
  const sidebarOpen = els.sidebar.classList.contains("open");
  const searchActive = activeMainView === "chat" && sidebarOpen && activeRailPanel === "search";
  const recentActive = activeMainView === "chat" && sidebarOpen && activeRailPanel === "recent";
  const appsActive = activeMainView === "apps";
  [
    [els.railSearch, searchActive],
    [els.railRecent, recentActive],
    [els.railApps, appsActive]
  ].forEach(([button, active]) => {
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", String(active));
  });
  els.railToggle.setAttribute("aria-expanded", String(sidebarOpen));
}

function toggleAccountMenu() {
  if (els.accountMenu.hidden) {
    openAccountMenu();
  } else {
    closeAccountMenu();
  }
}

function openAccountMenu() {
  closeMenus();
  closeSessionMenu();
  els.accountMenu.hidden = false;
  renderAccountSwitcher();
  els.railUser.setAttribute("aria-expanded", "true");
  positionAccountMenu();
}

function closeAccountMenu() {
  els.accountMenu.hidden = true;
  closeAccountSwitcher();
  els.railUser.setAttribute("aria-expanded", "false");
}

function positionAccountMenu() {
  if (els.accountMenu.hidden) return;

  const anchorRect = els.railUser.getBoundingClientRect();
  const menuRect = els.accountMenu.getBoundingClientRect();
  const margin = 12;
  const left = Math.min(window.innerWidth - menuRect.width - margin, anchorRect.right + 12);
  const top = Math.min(
    window.innerHeight - menuRect.height - margin,
    Math.max(margin, anchorRect.bottom - menuRect.height)
  );

  els.accountMenu.style.left = `${scaledCoord(Math.max(margin, left))}px`;
  els.accountMenu.style.top = `${scaledCoord(top)}px`;
}

function toggleAccountSwitcher() {
  if (els.accountSwitcher.hidden) openAccountSwitcher();
  else closeAccountSwitcher();
}

function openAccountSwitcher() {
  renderAccountSwitcher();
  els.accountSwitcher.hidden = false;
  els.accountMenu.querySelector("[data-account-action='switcher']")?.setAttribute("aria-expanded", "true");
  positionAccountSwitcher();
}

function closeAccountSwitcher() {
  els.accountSwitcher.hidden = true;
  els.accountMenu.querySelector("[data-account-action='switcher']")?.setAttribute("aria-expanded", "false");
}

function positionAccountSwitcher() {
  if (els.accountSwitcher.hidden || els.accountMenu.hidden) return;
  const menuRect = els.accountMenu.getBoundingClientRect();
  const switcherRect = els.accountSwitcher.getBoundingClientRect();
  const margin = 12;
  let left = menuRect.right + 10;
  if (left + switcherRect.width > window.innerWidth - margin) left = menuRect.left - switcherRect.width - 10;
  const top = Math.min(window.innerHeight - switcherRect.height - margin, Math.max(margin, menuRect.top));
  els.accountSwitcher.style.left = `${scaledCoord(Math.max(margin, left))}px`;
  els.accountSwitcher.style.top = `${scaledCoord(top)}px`;
}

function renderAccountSwitcher() {
  if (!els.accountSwitcherList) return;
  els.accountSwitcherList.replaceChildren();
  const accounts = getDeviceAccounts();
  accounts.forEach((account) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "account-switcher-item";
    button.dataset.accountId = account.id;

    const avatar = document.createElement("span");
    avatar.className = "user-avatar account-switcher-avatar";
    renderProfileAvatar(avatar, getDeviceAccountProfile(account));

    const identity = document.createElement("span");
    identity.className = "account-switcher-identity";
    const name = document.createElement("strong");
    name.textContent = account.displayName || account.phone;
    const phone = document.createElement("span");
    phone.textContent = account.phone;
    identity.append(name, phone);

    const check = document.createElement("span");
    check.className = "account-switcher-check";
    check.textContent = account.id === currentUser?.id ? "✓" : "";
    button.append(avatar, identity, check);
    els.accountSwitcherList.append(button);
  });
}

async function handleAccountSwitcherClick(event) {
  event.stopPropagation();
  const item = event.target.closest("[data-account-id]");
  if (!item || item.dataset.accountId === currentUser?.id) {
    closeAccountSwitcher();
    return;
  }
  await switchToDeviceAccount(item.dataset.accountId);
}

async function switchToDeviceAccount(accountId) {
  const account = getDeviceAccounts().find((candidate) => candidate.id === accountId);
  if (!account) return;
  const previousAccountId = currentUser?.id || "";
  const previousToken = authSessionToken;
  await syncUserDataNow();
  setActiveSessionToken(account.token);
  try {
    const response = await authFetch("/api/auth/me");
    const payload = await response.json().catch(() => ({}));
    if (!response.ok || !payload.user) throw new Error("此账户的登录状态已过期，请重新登录。");
    await completeAuthentication(payload.user, payload.userData);
    closeAccountMenu();
  } catch (error) {
    removeDeviceAccount(account.id);
    if (previousAccountId && previousAccountId !== account.id && previousToken) {
      const previousAccount = getDeviceAccounts().find((candidate) => candidate.id === previousAccountId);
      if (previousAccount) {
        setActiveSessionToken(previousToken);
        const response = await authFetch("/api/auth/me");
        const payload = await response.json().catch(() => ({}));
        if (response.ok && payload.user) {
          await completeAuthentication(payload.user, payload.userData);
          closeAccountMenu();
          alert(error.message);
          return;
        }
      }
    }
    setActiveSessionToken("");
    currentUser = null;
    showAuthModal(error.message);
  }
}

async function openAddAccountLogin(event) {
  event?.stopPropagation();
  await syncUserDataNow();
  rememberCurrentDeviceAccount();
  closeAccountMenu();
  currentUser = null;
  setActiveSessionToken("");
  els.authPhone.value = "";
  els.authPassword.value = "";
  els.authCode.value = "";
  setAuthMethod("code");
  showAuthModal();
}

async function handleAccountMenuClick(event) {
  event.stopPropagation();
  const item = event.target.closest("[data-account-action]");
  if (!item) return;

  if (item.dataset.accountAction === "switcher") {
    toggleAccountSwitcher();
    return;
  }

  if (item.dataset.accountAction === "upgrade") {
    openUpgradePlanModal();
    return;
  }

  if (item.dataset.accountAction === "personalize") {
    openSettingsModal("personalize");
    return;
  }

  if (item.dataset.accountAction === "profile") {
    openProfileModal();
    return;
  }

  if (item.dataset.accountAction === "settings") {
    openSettingsModal();
    return;
  }

  if (item.dataset.accountAction === "logout") {
    const accountId = currentUser?.id;
    await syncUserDataNow();
    await authFetch("/api/auth/logout", { method: "POST" });
    if (accountId) removeDeviceAccount(accountId);
    currentUser = null;
    setActiveSessionToken("");
    const nextAccount = getDeviceAccounts()[0];
    if (nextAccount) await switchToDeviceAccount(nextAccount.id);
    else showAuthModal();
  }
}

function openProfileModal() {
  editingProfile = { ...userProfile };
  renderProfileForm();
  closeAccountMenu();
  els.profileModal.hidden = false;
  requestAnimationFrame(() => els.profileDisplayName.focus());
}

function closeProfileModal() {
  editingProfile = null;
  els.profileModal.hidden = true;
  els.profileAvatarInput.value = "";
}

async function handleProfileAvatarChange() {
  const file = els.profileAvatarInput.files?.[0];
  if (!file || !file.type.startsWith("image/")) return;

  els.profileSave.disabled = true;
  try {
    const avatar = await resizeAvatarFile(file);
    if (!editingProfile) editingProfile = { ...userProfile };
    editingProfile.avatar = avatar;
    renderProfileAvatar(els.profileAvatarPreview, editingProfile);
  } catch (error) {
    console.error("Unable to process avatar:", error);
    alert("头像处理失败，请换一张图片重试。");
  } finally {
    els.profileSave.disabled = false;
  }
}

function openUpgradePlanModal() {
  closeAccountMenu();
  els.upgradePlanModal.hidden = false;
  requestAnimationFrame(() => els.upgradePlanClose.focus());
}

function closeUpgradePlanModal() {
  els.upgradePlanModal.hidden = true;
}

async function saveProfileEdits() {
  if (!editingProfile) editingProfile = { ...userProfile };

  els.profileSave.disabled = true;
  userProfile = normalizeProfile({
    ...editingProfile,
    displayName: els.profileDisplayName.value.trim() || "User",
    username: currentUser?.phone || editingProfile.username
  });

  try {
    localStorage.setItem(userStorageKey(PROFILE_KEY), JSON.stringify(userProfile));
  } catch (error) {
    console.warn("Profile local cache is full; continuing with server sync.", error);
  }
  closeProfileModal();
  renderProfileState();
  els.profileSave.disabled = false;
  await syncUserDataNow({ allowProfileReset: true });
}

async function resizeAvatarFile(file) {
  const source = await loadAvatarSource(file);
  const sourceWidth = source.width || source.naturalWidth;
  const sourceHeight = source.height || source.naturalHeight;
  const side = Math.min(sourceWidth, sourceHeight);
  const sx = Math.max(0, Math.round((sourceWidth - side) / 2));
  const sy = Math.max(0, Math.round((sourceHeight - side) / 2));
  const size = 384;
  const canvas = document.createElement("canvas");
  canvas.width = size;
  canvas.height = size;
  const context = canvas.getContext("2d", { alpha: false });
  context.fillStyle = "#222222";
  context.fillRect(0, 0, size, size);
  context.drawImage(source, sx, sy, side, side, 0, 0, size, size);
  if (typeof source.close === "function") source.close();
  return canvas.toDataURL("image/jpeg", 0.84);
}

async function loadAvatarSource(file) {
  if (typeof createImageBitmap === "function") return createImageBitmap(file);
  const objectUrl = URL.createObjectURL(file);
  try {
    const image = new Image();
    image.src = objectUrl;
    await image.decode();
    return image;
  } finally {
    URL.revokeObjectURL(objectUrl);
  }
}

function renderProfileForm() {
  if (!editingProfile) editingProfile = { ...userProfile };
  els.profileDisplayName.value = editingProfile.displayName;
  els.profileUsername.value = currentUser?.phone || editingProfile.username;
  els.profileUsername.closest(".profile-field")?.classList.add("profile-field-readonly");
  els.profileUsername.previousElementSibling.textContent = uiText[appSettings.language]?.username || "账号";
  renderProfileAvatar(els.profileAvatarPreview, editingProfile);
}

function renderProfileState() {
  const name = userProfile.displayName || "User";
  els.railUser.dataset.name = name;
  els.accountMenuName.textContent = name;
  renderProfileAvatar(els.railAvatar, userProfile);
  renderProfileAvatar(els.accountMenuAvatar, userProfile);
  rememberCurrentDeviceAccount();
  if (!els.profileModal.hidden) renderProfileForm();
}

function openSettingsModal(section = "general") {
  closeAccountMenu();
  closeSettingsPopover();
  els.settingsModal.hidden = false;
  selectSettingsSection(section);
  renderSettingsModal();
}

function closeSettingsModal() {
  els.settingsModal.hidden = true;
  closeAccountDeleteModal();
  closeSettingsPopover();
  clearStorageObjectUrls();
}

function handleSettingsModalClick(event) {
  if (event.target === els.settingsModal) {
    closeSettingsModal();
    return;
  }

  const navItem = event.target.closest("[data-settings-section]");
  if (navItem) {
    selectSettingsSection(navItem.dataset.settingsSection);
    return;
  }

  const menuButton = event.target.closest("[data-settings-menu]");
  if (menuButton) {
    toggleSettingsMenu(menuButton.dataset.settingsMenu, menuButton);
    return;
  }

  const option = event.target.closest("[data-settings-option]");
  if (option) {
    updateSetting(option.dataset.setting, option.dataset.settingsOption);
    closeSettingsPopover();
    return;
  }

  const storageBack = event.target.closest("[data-storage-back]");
  if (storageBack) {
    storageCategory = "";
    renderStoragePanel();
    return;
  }

  const storageCategoryButton = event.target.closest("[data-storage-category]");
  if (storageCategoryButton) {
    storageCategory = storageCategoryButton.dataset.storageCategory || "";
    renderStoragePanel();
    return;
  }

  const storageDownload = event.target.closest("[data-storage-download]");
  if (storageDownload) {
    downloadStorageItem(storageDownload.dataset.storageDownload);
    return;
  }

  const storageDelete = event.target.closest("[data-storage-delete]");
  if (storageDelete) {
    deleteStoredItem(storageDelete.dataset.storageDelete);
    return;
  }

  if (event.target.closest("[data-delete-account]")) {
    openAccountDeleteModal();
  }
}

function selectSettingsSection(section) {
  const safeSection = ["general", "personalize", "storage", "account"].includes(section) ? section : "general";
  activeSettingsSection = safeSection;
  els.settingsModal.querySelectorAll("[data-settings-section]").forEach((item) => {
    item.classList.toggle("active", item.dataset.settingsSection === safeSection);
  });
  els.settingsModal.querySelectorAll("[data-settings-panel]").forEach((panel) => {
    panel.classList.toggle("active", panel.dataset.settingsPanel === safeSection);
  });
  closeSettingsPopover();
  if (safeSection === "storage") loadStorageData();
  if (safeSection === "account") renderAccountSettings();
}

function toggleSettingsMenu(setting, anchor) {
  const existing = els.settingsModal.querySelector(".settings-popover");
  if (existing?.dataset.setting === setting) {
    closeSettingsPopover();
    return;
  }

  closeSettingsPopover();
  const options = settingOptions(setting);
  if (!options.length) return;

  const popover = document.createElement("div");
  popover.className = `settings-popover ${setting === "accent" ? "accent-menu" : ""}`;
  popover.dataset.setting = setting;
  popover.innerHTML = options.map((option) => renderSettingsOption(setting, option)).join("");
  els.settingsModal.querySelector(".settings-dialog").appendChild(popover);

  const dialogRect = els.settingsModal.querySelector(".settings-dialog").getBoundingClientRect();
  const anchorRect = anchor.getBoundingClientRect();
  const width = setting === "accent" ? 310 : 220;
  popover.style.width = `${width}px`;
  const localRight = scaledCoord(anchorRect.right - dialogRect.left);
  const localBottom = scaledCoord(anchorRect.bottom - dialogRect.top);
  popover.style.left = `${Math.max(12, localRight - width)}px`;
  popover.style.top = `${localBottom + 8}px`;
}

function closeSettingsPopover() {
  els.settingsModal?.querySelector(".settings-popover")?.remove();
}

function uiScale() {
  const scale = Number(appSettings?.zoom || 175) / 175;
  return Number.isFinite(scale) && scale > 0 ? scale : 1;
}

function scaledCoord(value) {
  return value / uiScale();
}

function settingOptions(setting) {
  if (setting === "appearance") return ["system", "dark", "light"];
  if (setting === "accent") return ["default", "blue", "green", "yellow", "pink", "orange", "purple"];
  if (setting === "language") return ["zh", "zht", "ja", "en"];
  if (setting === "zoom") return ["100", "125", "150", "175", "200"];
  return [];
}

function renderSettingsOption(setting, value) {
  const active = String(appSettings[setting]) === String(value);
  const label = settingOptionLabel(setting, value);
  const dot = setting === "accent"
    ? `<span class="accent-dot" style="--dot-color:${accentColors[value] || accentColors.default}"></span>`
    : "";
  return `
    <button class="settings-popover-item ${active ? "active" : ""}" type="button" data-setting="${setting}" data-settings-option="${value}">
      ${dot}<span>${escapeHtml(label)}</span>
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 5 5L20 7" /></svg>
    </button>
  `;
}

function settingOptionLabel(setting, value) {
  const lang = appSettings.language;
  if (setting === "appearance") return settingLabels.appearance[value]?.[lang] || settingLabels.appearance[value]?.zh || value;
  if (setting === "accent") return settingLabels.accent[value]?.[lang] || settingLabels.accent[value]?.zh || value;
  if (setting === "language") return settingLabels.language[value] || value;
  if (setting === "zoom") return `${value}%`;
  return value;
}

function updateSetting(setting, value) {
  if (!["appearance", "accent", "language", "zoom"].includes(setting)) return;
  appSettings = normalizeSettings({
    ...appSettings,
    [setting]: value
  });
  saveSettings();
  applySettings();
  closeMenus();
  closeSessionMenu();
  closeAccountMenu();
  renderSettingsModal();
  renderImageModeState();
  renderVideoModeState();
  renderWebModeState();
  if (setting === "language") checkHealth();
}

function renderSettingsModal() {
  const text = currentText();
  els.settingsModal.querySelector("#settingsTitle").textContent = text.general;
  els.settingsModal.querySelector("[data-settings-panel='personalize'] h2").textContent = text.personalize;
  els.settingsModal.querySelectorAll("[data-settings-section]").forEach((item) => {
    const section = item.dataset.settingsSection;
    item.querySelector("span").textContent = text[section] || section;
  });
  els.settingsModal.querySelector("[data-settings-row='appearance'] > span").textContent = text.appearance;
  els.settingsModal.querySelector("[data-settings-row='accent'] > span").textContent = text.accent;
  els.settingsModal.querySelector("[data-settings-row='language'] > span").textContent = text.language;
  els.settingsModal.querySelector("[data-settings-row='zoom'] > span").textContent = text.zoom;
  els.appearanceValue.textContent = settingOptionLabel("appearance", appSettings.appearance);
  els.accentValue.textContent = settingOptionLabel("accent", appSettings.accent);
  els.accentDot.style.setProperty("--dot-color", accentColors[appSettings.accent] || accentColors.default);
  els.languageValue.textContent = settingOptionLabel("language", appSettings.language);
  els.zoomValue.textContent = settingOptionLabel("zoom", appSettings.zoom);
  if (activeSettingsSection === "storage") renderStoragePanel();
  if (activeSettingsSection === "account") renderAccountSettings();
}

function renderAccountSettings() {
  if (!els.accountSettingsPanel) return;
  els.accountSettingsPanel.innerHTML = `
    <h2>账户</h2>
    <div class="account-settings-list">
      <div class="account-settings-row">
        <span>姓名</span>
        <strong>${escapeHtml(userProfile.displayName || currentUser?.phone || "")}</strong>
      </div>
      <div class="account-settings-row">
        <span>手机号码</span>
        <strong>${escapeHtml(currentUser?.phone || "")}</strong>
      </div>
    </div>
    <div class="account-settings-delete-row">
      <span>删除账户</span>
      <button type="button" data-delete-account>删除</button>
    </div>
  `;
}

function openAccountDeleteModal() {
  els.accountDeleteInput.value = "";
  els.accountDeleteError.textContent = "";
  els.accountDeleteSubmit.disabled = true;
  els.accountDeleteModal.hidden = false;
  requestAnimationFrame(() => els.accountDeleteInput.focus());
}

function closeAccountDeleteModal() {
  if (els.accountDeleteSubmit.dataset.busy === "true") return;
  els.accountDeleteModal.hidden = true;
  els.accountDeleteInput.value = "";
  els.accountDeleteError.textContent = "";
  els.accountDeleteSubmit.disabled = true;
}

function updateAccountDeleteState() {
  const confirmed = els.accountDeleteInput.value === "确认删除";
  els.accountDeleteSubmit.disabled = !confirmed || els.accountDeleteSubmit.dataset.busy === "true";
  if (confirmed) els.accountDeleteError.textContent = "";
}

async function deleteCurrentAccount(event) {
  event.preventDefault();
  if (!currentUser || els.accountDeleteInput.value !== "确认删除") return;

  const deletedAccountId = currentUser.id;
  els.accountDeleteSubmit.dataset.busy = "true";
  els.accountDeleteSubmit.disabled = true;
  els.accountDeleteSubmit.textContent = "正在删除...";
  els.accountDeleteError.textContent = "";
  clearTimeout(userDataSyncTimer);
  userDataSyncTimer = null;

  try {
    const response = await authFetch("/api/auth/account", {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ confirmation: "确认删除" })
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || "账户删除失败，请稍后重试。");

    localStorage.removeItem(`${STORAGE_KEY}.${deletedAccountId}`);
    localStorage.removeItem(`${PROFILE_KEY}.${deletedAccountId}`);
    localStorage.removeItem(`${SETTINGS_KEY}.${deletedAccountId}`);
    removeDeviceAccount(deletedAccountId);
    currentUser = null;
    setActiveSessionToken("");
    els.accountDeleteModal.hidden = true;
    closeSettingsModal();

    const nextAccount = getDeviceAccounts()[0];
    if (nextAccount) await switchToDeviceAccount(nextAccount.id);
    else showAuthModal("账户已删除。你可以使用其他手机号登录或注册。");
  } catch (error) {
    els.accountDeleteError.textContent = error.message || "账户删除失败，请稍后重试。";
  } finally {
    els.accountDeleteSubmit.dataset.busy = "false";
    els.accountDeleteSubmit.textContent = "永久删除账户";
    updateAccountDeleteState();
  }
}

async function loadStorageData() {
  storageLoading = true;
  storageError = "";
  renderStoragePanel();
  try {
    const response = await authFetch("/api/storage");
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || "无法读取存储空间，请稍后再试。");
    storageData = payload;
  } catch (error) {
    storageError = error.message || "无法读取存储空间。";
  } finally {
    storageLoading = false;
    renderStoragePanel();
  }
}

function renderStoragePanel() {
  if (!els.storagePanel) return;
  clearStorageObjectUrls();
  if (storageLoading && !storageData) {
    els.storagePanel.innerHTML = `<div class="storage-state">正在读取存储空间...</div>`;
    return;
  }
  if (storageError && !storageData) {
    els.storagePanel.innerHTML = `
      <div class="storage-state storage-state-error">
        <strong>无法加载存储空间</strong>
        <span>${escapeHtml(storageError)}</span>
        <button type="button" data-storage-retry>重试</button>
      </div>
    `;
    els.storagePanel.querySelector("[data-storage-retry]")?.addEventListener("click", loadStorageData);
    return;
  }

  const data = storageData || { used: 0, limit: 500 * 1024 * 1024, counts: {}, sizes: {}, items: [] };
  if (storageCategory) {
    renderStorageCategory(data);
    return;
  }

  const percent = data.limit ? Math.min(100, (data.used / data.limit) * 100) : 0;
  els.storagePanel.innerHTML = `
    <h2>存储空间</h2>
    <div class="storage-usage">
      <strong>已使用 ${formatStorageSize(data.used)}，共 500 MB</strong>
      <div class="storage-progress" role="progressbar" aria-label="已使用存储空间" aria-valuemin="0" aria-valuemax="500" aria-valuenow="${Math.round(data.used / 1024 / 1024)}">
        <span style="width:${percent}%"></span>
      </div>
    </div>
    <div class="storage-manage-heading">
      <strong>管理存储空间</strong>
      <span>管理你的图片和文件，释放存储空间</span>
    </div>
    <div class="storage-category-list">
      ${renderStorageCategoryRow("file", "文件", data.sizes?.files || 0, data.counts?.files || 0)}
      ${renderStorageCategoryRow("image", "图片", data.sizes?.images || 0, data.counts?.images || 0)}
    </div>
    ${storageLoading ? `<div class="storage-refreshing">正在刷新...</div>` : ""}
  `;
}

function renderStorageCategoryRow(category, label, size, count) {
  return `
    <button class="storage-category-row" type="button" data-storage-category="${category}">
      <span>
        <strong>${label}</strong>
        <small>${formatStorageSize(size)} · ${count} 个${label}</small>
      </span>
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m9 5 7 7-7 7" /></svg>
    </button>
  `;
}

function renderStorageCategory(data) {
  const isImage = storageCategory === "image";
  const label = isImage ? "图片" : "文件";
  const items = (data.items || []).filter((item) => item.category === storageCategory);
  els.storagePanel.innerHTML = `
    <div class="storage-detail-heading">
      <button type="button" data-storage-back aria-label="返回存储空间" title="返回">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="m15 5-7 7 7 7" /></svg>
      </button>
      <div><h2>${label}</h2><span>${items.length} 个${label} · ${formatStorageSize(isImage ? data.sizes?.images : data.sizes?.files)}</span></div>
    </div>
    ${items.length ? `<div class="storage-items ${isImage ? "storage-image-grid" : ""}">${items.map(renderStorageItem).join("")}</div>` : `
      <div class="storage-empty"><strong>暂无${label}</strong><span>用户上传的${label}会显示在这里。</span></div>
    `}
  `;
  if (isImage) hydrateStorageThumbnails(items);
}

function renderStorageItem(item) {
  const image = item.category === "image";
  const safeName = escapeHtml(item.name || "未命名文件");
  return `
    <article class="storage-item ${image ? "storage-image-item" : "storage-file-item"}">
      ${image
        ? `<div class="storage-thumbnail" data-storage-thumbnail="${item.id}"><span>图片</span></div>`
        : `<div class="storage-file-icon">${fileIconMarkup(item)}</div>`}
      <div class="storage-item-info">
        <strong title="${safeName}">${safeName}</strong>
        <span>${formatStorageSize(item.size)} · ${formatStorageDate(item.createdAt)}</span>
      </div>
      <div class="storage-item-actions">
        <button type="button" data-storage-download="${item.id}" aria-label="下载 ${safeName}" title="下载">${storageDownloadIcon()}</button>
        <button type="button" data-storage-delete="${item.id}" aria-label="删除 ${safeName}" title="删除">${storageDeleteIcon()}</button>
      </div>
    </article>
  `;
}

async function hydrateStorageThumbnails(items) {
  await Promise.all(items.map(async (item) => {
    try {
      const response = await authFetch(`/api/storage/items/${item.id}`);
      if (!response.ok) return;
      const objectUrl = URL.createObjectURL(await response.blob());
      storageObjectUrls.set(item.id, objectUrl);
      const target = els.storagePanel.querySelector(`[data-storage-thumbnail="${item.id}"]`);
      if (target) target.innerHTML = `<img src="${objectUrl}" alt="${escapeHtml(item.name || "上传图片")}" />`;
    } catch {
      // Keep the neutral thumbnail when a preview cannot be loaded.
    }
  }));
}

function clearStorageObjectUrls() {
  storageObjectUrls.forEach((url) => URL.revokeObjectURL(url));
  storageObjectUrls.clear();
}

async function uploadUserFile(file) {
  const response = await authFetch("/api/storage/upload", {
    method: "POST",
    headers: {
      "Content-Type": file.type || "application/octet-stream",
      "X-File-Name": encodeURIComponent(file.name || "未命名文件")
    },
    body: file
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload.error || "文件上传失败。");
  storageData = null;
  return payload.item;
}

async function downloadStorageItem(id) {
  const item = storageData?.items?.find((entry) => entry.id === id);
  if (!item) return;
  try {
    const response = await authFetch(`/api/storage/items/${id}?download=1`);
    if (!response.ok) throw new Error("下载失败");
    const objectUrl = URL.createObjectURL(await response.blob());
    triggerDownload(objectUrl, item.name || "下载文件");
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  } catch (error) {
    alert(error.message || "下载失败，请重试。");
  }
}

async function deleteStoredItem(id) {
  const item = storageData?.items?.find((entry) => entry.id === id);
  if (!item || !confirm(`确定删除“${item.name}”吗？此操作无法撤销。`)) return;
  try {
    const response = await authFetch(`/api/storage/items/${id}`, { method: "DELETE" });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || "删除失败。");
    await loadStorageData();
  } catch (error) {
    alert(error.message || "删除失败，请重试。");
  }
}

function formatStorageSize(bytes) {
  const value = Number(bytes || 0);
  if (value < 1024) return `${value} B`;
  if (value < 1024 * 1024) return `${(value / 1024).toFixed(value >= 100 * 1024 ? 0 : 1)} KB`;
  return `${(value / 1024 / 1024).toFixed(value >= 100 * 1024 * 1024 ? 0 : 2)} MB`;
}

function formatStorageDate(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleDateString("zh-CN", { year: "numeric", month: "2-digit", day: "2-digit" });
}

function storageDownloadIcon() {
  return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v12m0 0 5-5m-5 5-5-5M5 20h14" /></svg>`;
}

function storageDeleteIcon() {
  return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3m-8 0 1 13h8l1-13M10 11v5m4-5v5" /></svg>`;
}

function applySettings() {
  const scale = Number(appSettings.zoom) / 175;
  const resolvedAppearance = resolveAppearance(appSettings.appearance);
  const usesDefaultAccent = appSettings.accent === "default";
  const accentColor = usesDefaultAccent
    ? defaultAccentByTheme[resolvedAppearance] || defaultAccentByTheme.dark
    : accentColors[appSettings.accent] || accentColors.default;
  const accentText = usesDefaultAccent
    ? defaultAccentTextByTheme[resolvedAppearance] || defaultAccentTextByTheme.dark
    : "#ffffff";
  document.documentElement.style.setProperty("--ui-scale", `${scale}`);
  document.documentElement.style.fontSize = "";
  document.documentElement.style.setProperty("--user-bubble-bg", accentColor);
  document.documentElement.style.setProperty("--user-bubble-text", accentText);
  document.documentElement.lang = appSettings.language === "en" ? "en" : appSettings.language === "ja" ? "ja" : "zh-CN";
  applyAppearanceToDocument(resolvedAppearance, appSettings.appearance);
  document.body.dataset.accent = appSettings.accent;
  document.body.dataset.language = appSettings.language;
  localizeStaticText();
}

function localizeStaticText() {
  const text = currentText();
  if (els.newChat) els.newChat.textContent = text.newChat;
  if (els.clearAll) els.clearAll.textContent = text.clearHistory;
  if (els.searchSessions) els.searchSessions.placeholder = text.searchPlaceholder;
  const title = document.querySelector("#profileTitle");
  if (title) title.textContent = text.editProfile;
  document.querySelectorAll(".profile-field span").forEach((span, index) => {
    span.textContent = index === 0 ? text.displayName : text.username;
  });
  if (els.profileCancel) els.profileCancel.textContent = text.cancel;
  if (els.profileSave) els.profileSave.textContent = text.save;
  setAccountActionText("upgrade", text.upgrade);
  setAccountActionText("personalize", text.personalize);
  setAccountActionText("profile", text.profile);
  setAccountActionText("settings", text.settings);
  setAccountActionText("help", text.help);
  setAccountActionText("logout", text.logout);
  setToolText("upload", text.addFiles);
  setToolText("image", text.createImage);
  setToolText("video", text.createVideo);
  setToolText("web", text.webSearch);
  const deepThinkingLabel = els.deepThinkingToggle?.querySelector("span");
  if (deepThinkingLabel) deepThinkingLabel.textContent = text.deepThinking;
  const dropLabel = document.querySelector(".drop-card span");
  if (dropLabel) dropLabel.textContent = text.dragFiles;
  const tempTitle = document.querySelector(".temporary-intro h2");
  if (tempTitle) tempTitle.textContent = text.temporaryChat;
  const tempDesc = document.querySelector(".temporary-intro p");
  if (tempDesc) tempDesc.textContent = text.temporaryDesc;
  const imageModeLabel = document.querySelector("#imageModePill + span, .image-mode-pill span:last-child");
  const imageTextNode = document.querySelector(".image-mode-pill")?.childNodes;
  if (imageTextNode) {
    [...imageTextNode].forEach((node) => {
      if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) node.textContent = ` ${text.image}`;
    });
  }
  const videoTextNode = document.querySelector(".video-mode-pill")?.childNodes;
  if (videoTextNode) {
    [...videoTextNode].forEach((node) => {
      if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) node.textContent = ` ${text.createVideo}`;
    });
  }
  const webTextNode = document.querySelector(".web-mode-pill")?.childNodes;
  if (webTextNode) {
    [...webTextNode].forEach((node) => {
      if (node.nodeType === Node.TEXT_NODE && node.textContent.trim()) node.textContent = ` ${text.search}`;
    });
  }
  const aspectTitle = document.querySelector(".aspect-menu .menu-title");
  if (aspectTitle) aspectTitle.textContent = text.aspectMenu;
  const aspectMap = {
    auto: text.aspectAuto,
    square: text.aspectSquare,
    portrait: text.aspectPortrait,
    story: text.aspectStory,
    landscape: text.aspectLandscape,
    wide: text.aspectWide
  };
  document.querySelectorAll("[data-aspect]").forEach((option) => {
    const label = aspectMap[option.dataset.aspect];
    const span = option.querySelector("span:nth-of-type(2)");
    const em = span?.querySelector("em")?.outerHTML || "";
    if (label && span) span.innerHTML = `${escapeHtml(label)} ${em}`.trim();
  });
  els.aspectLabel.textContent = aspectMap[selectedAspect] || text.aspectAuto;
  const refsTitle = document.querySelector(".references-header h2");
  if (refsTitle) refsTitle.textContent = text.referencesTitle;
  if (els.referencesEmpty) els.referencesEmpty.textContent = text.referencesEmpty;
  if (!els.settingsModal?.hidden) renderSettingsModal();
}

function setAccountActionText(action, value) {
  document.querySelectorAll(`.account-menu-item[data-account-action="${action}"] > span`).forEach((span) => {
    span.textContent = value;
  });
}

function setToolText(tool, value) {
  const item = document.querySelector(`[data-tool="${tool}"]`);
  const label = item?.querySelector("span:not(.menu-chevron):not(.dot-icon)");
  if (label) label.textContent = value;
}

function currentText() {
  return uiText[appSettings.language] || uiText.zh;
}

function localizedAspectLabel(value) {
  const text = currentText();
  const labels = {
    auto: text.aspectAuto,
    square: text.aspectSquare,
    portrait: text.aspectPortrait,
    story: text.aspectStory,
    landscape: text.aspectLandscape,
    wide: text.aspectWide
  };
  return labels[value] || text.aspectAuto;
}

function renderProfileAvatar(target, profile) {
  const avatar = profile?.avatar || "";
  target.textContent = avatar ? "" : getProfileInitials(profile?.displayName || "User");
  target.style.backgroundImage = avatar ? `url("${avatar}")` : "";
}

function getProfileInitials(name) {
  const normalized = String(name || "User").trim();
  if (!normalized) return "US";
  const ascii = normalized.match(/[A-Za-z0-9]/g);
  if (ascii?.length) return ascii.slice(0, 2).join("").toUpperCase();
  return Array.from(normalized).slice(0, 2).join("");
}

function handleGlobalShortcuts(event) {
  if (!currentUser && els.authModal.hidden) {
    const key = event.key.toLowerCase();
    if ((event.ctrlKey || event.metaKey) && (key === "k" || (event.shiftKey && key === "o"))) {
      event.preventDefault();
      event.stopImmediatePropagation();
      showAuthModal("登录后即可使用快捷操作。");
      return;
    }
  }

  if (event.key === "Escape") {
    if (!els.upgradePlanModal.hidden) {
      closeUpgradePlanModal();
      return;
    }
    if (!els.featureConstructionModal.hidden) {
      closeFeatureConstructionModal();
      return;
    }
    if (!els.accountDeleteModal.hidden) {
      closeAccountDeleteModal();
      return;
    }
    if (!els.settingsModal.hidden) {
      closeSettingsModal();
      return;
    }
    if (!els.profileModal.hidden) {
      closeProfileModal();
      return;
    }
    closeAccountMenu();
  }

  if (event.ctrlKey && event.shiftKey && event.key.toLowerCase() === "o") {
    event.preventDefault();
    startNewChat();
    return;
  }

  if (event.ctrlKey && event.key.toLowerCase() === "k") {
    event.preventDefault();
    openSearch();
  }
}

function handleMascotPointerMove(event) {
  if (!currentUser) return;
  if (!els.chatPanel.classList.contains("empty")) return;
  if (mascotEyesLocked) return;

  mascotPointer = { x: event.clientX, y: event.clientY };
  if (mascotEyeFrame) return;

  mascotEyeFrame = requestAnimationFrame(updateMascotEyes);
}

function toggleMascotEyeLock(event) {
  if (!currentUser) {
    showAuthModal("登录后即可体验完整功能。");
    return;
  }
  event.preventDefault();
  mascotEyesLocked = !mascotEyesLocked;
  if (!mascotEyesLocked) {
    mascotPointer = null;
    resetMascotEyes();
  }
}

function updateMascotEyes() {
  mascotEyeFrame = 0;
  if (!mascotPointer || !els.welcomeBrand) return;

  const logo = els.welcomeBrand.querySelector(".welcome-logo");
  const mascot = els.welcomeBrand.querySelector(".welcome-mascot");
  if (!logo || !mascot) return;

  const rect = mascot.getBoundingClientRect();
  if (!rect.width || !rect.height) return;

  const centerX = rect.left + rect.width * 0.515;
  const centerY = rect.top + rect.height * 0.625;
  const x = clamp((mascotPointer.x - centerX) / (rect.width * 0.72), -1, 1);
  const y = clamp((mascotPointer.y - centerY) / (rect.height * 0.78), -1, 1);

  logo.style.setProperty("--eye-x", `${(x * 7).toFixed(2)}px`);
  logo.style.setProperty("--eye-y", `${(y * 4.5).toFixed(2)}px`);
}

function resetMascotEyes() {
  if (mascotEyesLocked) return;
  mascotPointer = null;
  if (mascotEyeFrame) {
    cancelAnimationFrame(mascotEyeFrame);
    mascotEyeFrame = 0;
  }
  els.welcomeBrand?.querySelector(".welcome-logo")?.style.setProperty("--eye-x", "0px");
  els.welcomeBrand?.querySelector(".welcome-logo")?.style.setProperty("--eye-y", "0px");
}

function preventFileOpen(event) {
  if (event.dataTransfer?.types?.includes("Files")) {
    event.preventDefault();
  }
}

function handleDragEnter(event) {
  if (!event.dataTransfer?.types?.includes("Files")) return;
  dragDepth += 1;
  els.dropOverlay.hidden = false;
}

function handleDragOver(event) {
  if (!event.dataTransfer?.types?.includes("Files")) return;
  event.preventDefault();
  event.dataTransfer.dropEffect = "copy";
}

function handleDragLeave(event) {
  if (!event.dataTransfer?.types?.includes("Files")) return;
  dragDepth = Math.max(0, dragDepth - 1);
  if (dragDepth === 0) {
    els.dropOverlay.hidden = true;
  }
}

function handleDrop(event) {
  if (!event.dataTransfer?.files?.length) return;
  event.preventDefault();
  dragDepth = 0;
  els.dropOverlay.hidden = true;
  addFiles(event.dataTransfer.files);
}

async function addFiles(fileList) {
  const files = Array.from(fileList || []);
  if (!files.length) return;

  if (activeMode === "video") {
    await addVideoFrameFiles(files);
    return;
  }

  const slots = Math.max(0, MAX_ATTACHMENTS - pendingAttachments.length);
  const selected = files.slice(0, slots);
  const readableFiles = selected.filter((file) => file.size <= MAX_ATTACHMENT_SIZE);

  if (files.length > slots) {
    showComposerNotice(`最多一次添加 ${MAX_ATTACHMENTS} 个文件。`);
  }

  const oversized = selected.length - readableFiles.length;
  if (oversized > 0) {
    showComposerNotice(`已跳过 ${oversized} 个超过 500MB 的文件。`);
  }

  const results = [];
  for (const file of readableFiles) {
    try {
      const attachment = await readAttachment(file);
      const stored = await uploadUserFile(file);
      results.push({
        status: "fulfilled",
        value: {
          ...attachment,
          storageId: stored.id,
          url: stored.url
        }
      });
    } catch (reason) {
      results.push({ status: "rejected", reason });
    }
  }
  const attachments = results
    .filter((result) => result.status === "fulfilled")
    .map((result) => result.value);
  const failed = results.length - attachments.length;

  if (failed > 0) {
    const firstFailure = results.find((result) => result.status === "rejected");
    showComposerNotice(firstFailure?.reason?.message || `有 ${failed} 个文件上传失败。`);
  }

  pendingAttachments.push(...attachments);
  renderAttachmentTray();
  updateSendState();
  focusComposer();
}

function readAttachment(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.addEventListener("load", () => {
      resolve({
        id: createId(),
        name: file.name,
        type: file.type || inferMimeType(file.name),
        size: file.size,
        dataUrl: reader.result
      });
    });
    reader.addEventListener("error", () => reject(reader.error));
    reader.readAsDataURL(file);
  });
}

function handleAttachmentTrayClick(event) {
  const removeButton = event.target.closest("[data-remove-attachment]");
  if (!removeButton) return;

  pendingAttachments = pendingAttachments.filter((item) => item.id !== removeButton.dataset.removeAttachment);
  renderAttachmentTray();
  updateSendState();
}

function renderAttachmentTray() {
  els.attachmentTray.hidden = pendingAttachments.length === 0;
  els.composer.classList.toggle("has-attachments", pendingAttachments.length > 0);
  els.attachmentTray.innerHTML = pendingAttachments
    .map(renderAttachmentChip)
    .join("");
}

function renderAttachmentChip(attachment) {
  const safeName = escapeHtml(attachment.name);
  const removeButton = `
    <button class="attachment-remove" type="button" data-remove-attachment="${attachment.id}" aria-label="移除 ${safeName}" title="移除">
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <path d="M18 6 6 18M6 6l12 12" />
      </svg>
    </button>
  `;

  if (isImageAttachment(attachment)) {
    return `
      <div class="attachment-chip attachment-image-chip" title="${safeName}">
        <img class="attachment-thumb" src="${escapeHtml(attachment.dataUrl)}" alt="${safeName}" />
        ${removeButton}
      </div>
    `;
  }

  return `
    <div class="attachment-chip attachment-file-chip" title="${safeName}">
      <span class="attachment-file-icon ${escapeHtml(fileIconClass(attachment))}" aria-hidden="true">
        ${fileIconMarkup(attachment)}
      </span>
      <span class="attachment-chip-body">
        <span class="attachment-name">${safeName}</span>
        <span class="attachment-meta">${escapeHtml(fileFormatLabel(attachment))}</span>
      </span>
      ${removeButton}
    </div>
  `;
}

function showComposerNotice(text) {
  els.promptInput.placeholder = text;
  setTimeout(() => {
    renderImageModeState();
    renderVideoModeState();
    renderWebModeState();
    renderDeepThinkingState();
  }, 1800);
}

async function loadVideoFrame(position, file) {
  if (!file) return;
  if (!isSupportedVideoFrameFile(file)) {
    showComposerNotice("首尾帧仅支持 PNG、JPEG 或 WebP 图片。");
    return false;
  }
  if (file.size > 20 * 1024 * 1024) {
    showComposerNotice("首尾帧图片不能超过 20MB。");
    return false;
  }
  try {
    setVideoFrame(position, await readAttachment(file));
    return true;
  } catch {
    showComposerNotice("图片读取失败，请重新选择。");
    return false;
  }
}

function setVideoFrame(position, attachment) {
  if (position === "last") videoLastFrame = attachment;
  else videoFirstFrame = attachment;
  renderVideoFrameState();
  updateSendState();
}

function renderVideoFrameState() {
  renderVideoFramePreview(videoFirstFrame, els.videoFirstFramePreview, els.videoFirstFrameRemove, els.videoFirstFrameButton);
  renderVideoFramePreview(videoLastFrame, els.videoLastFramePreview, els.videoLastFrameRemove, els.videoLastFrameButton);
}

function renderVideoFramePreview(frame, preview, remove, button) {
  const hasFrame = Boolean(frame?.dataUrl);
  preview.hidden = !hasFrame;
  remove.hidden = !hasFrame;
  button.classList.toggle("has-frame", hasFrame);
  if (hasFrame) preview.src = frame.dataUrl;
  else preview.removeAttribute("src");
}

function handleToolsMenuClick(event) {
  const item = event.target.closest("[data-tool]");
  if (!item) return;

  closeMenus();

  if (item.dataset.tool === "upload") {
    if (activeMode === "video" && videoFirstFrame && videoLastFrame) {
      showComposerNotice("首帧和尾帧已上传，请先移除其中一张再更换。");
      focusComposer();
      return;
    }
    els.fileInput.click();
    return;
  }

  if (item.dataset.tool === "image") {
    activateImageMode();
    return;
  }

  if (item.dataset.tool === "video") {
    activateVideoMode();
    return;
  }

  if (item.dataset.tool === "web") {
    activateWebMode();
    return;
  }

  focusComposer();
}

async function addVideoFrameFiles(files) {
  const availablePositions = [
    ...(!videoFirstFrame ? ["first"] : []),
    ...(!videoLastFrame ? ["last"] : [])
  ];

  if (!availablePositions.length) {
    showComposerNotice("首帧和尾帧已上传，请先移除其中一张再更换。");
    return;
  }

  const supported = files.filter(isSupportedVideoFrameFile);
  const rejected = files.length - supported.length;
  let extra = 0;

  for (const file of supported) {
    const position = availablePositions[0];
    if (!position) {
      extra += 1;
      continue;
    }
    if (await loadVideoFrame(position, file)) availablePositions.shift();
  }

  if (rejected > 0) {
    showComposerNotice("创建视频模式仅支持上传 PNG、JPEG 或 WebP 首尾帧图片。");
  } else if (extra > 0) {
    showComposerNotice("创建视频最多上传两张图片，已依次设为首帧和尾帧。");
  }

  renderAttachmentTray();
  updateSendState();
  focusComposer();
}

function isSupportedVideoFrameFile(file) {
  const type = String(file?.type || "").toLowerCase();
  const name = String(file?.name || "").toLowerCase();
  return ["image/png", "image/jpeg", "image/webp"].includes(type)
    || (!type && /\.(png|jpe?g|webp)$/.test(name));
}

function handleReasoningMenuClick(event) {
  event.stopPropagation();

  const modelToggle = event.target.closest("#modelToggle");
  if (modelToggle) {
    const isOpen = els.modelOptions.hidden;
    els.modelOptions.hidden = !isOpen;
    els.modelToggle.setAttribute("aria-expanded", String(isOpen));
    if (isOpen) {
      positionModelOptions();
    }
    return;
  }

  const modelOption = event.target.closest("[data-model]");
  if (modelOption) {
    if (activeMode === "image") {
      selectedImageModel = normalizeImageModelValue(modelOption.dataset.model);
      els.modelSelect.value = selectedImageModel;
      renderModelState();
    } else if (activeMode === "video") {
      selectedVideoModel = normalizeVideoModelValue(modelOption.dataset.model);
      els.modelSelect.value = selectedVideoModel;
      renderModelState();
    } else {
      els.modelSelect.value = normalizeModelValue(modelOption.dataset.model);
      updateSessionSettings();
    }
    closeMenus();
    return;
  }

  const option = event.target.closest("[data-reasoning]");
  if (!option) return;

  els.reasoningSelect.value = option.dataset.reasoning;
  updateSessionSettings();
  closeMenus();
}

function handleAspectMenuClick(event) {
  const option = event.target.closest("[data-aspect]");
  if (!option) return;

  selectedAspect = aspectLabels[option.dataset.aspect] ? option.dataset.aspect : "auto";
  renderImageModeState();
  closeMenus();
  focusComposer();
}

function toggleMenu(menu) {
  closeAccountMenu();
  const showTools = menu === "tools" && els.toolsMenu.hidden;
  const showReasoning = menu === "reasoning" && els.reasoningMenu.hidden;
  const showAspect = menu === "aspect" && els.aspectMenu.hidden;
  const showVideoAspect = menu === "video-aspect" && els.videoAspectMenu.hidden;
  const showVideoDuration = menu === "video-duration" && els.videoDurationMenu.hidden;

  els.toolsMenu.hidden = !showTools;
  els.reasoningMenu.hidden = !showReasoning;
  els.aspectMenu.hidden = !showAspect;
  els.videoAspectMenu.hidden = !showVideoAspect;
  els.videoDurationMenu.hidden = !showVideoDuration;
  els.modelOptions.hidden = !showReasoning;
  els.toolsButton.setAttribute("aria-expanded", String(showTools));
  els.reasoningButton.setAttribute("aria-expanded", String(showReasoning));
  els.aspectButton.setAttribute("aria-expanded", String(showAspect));
  els.videoAspectButton.setAttribute("aria-expanded", String(showVideoAspect));
  els.videoDurationButton.setAttribute("aria-expanded", String(showVideoDuration));

  if (showTools) positionMenu(els.toolsMenu, els.toolsButton, "left");
  if (showReasoning) positionMenu(els.reasoningMenu, els.reasoningButton, "right");
  if (showAspect) positionMenu(els.aspectMenu, els.aspectButton, "left");
  if (showVideoAspect) positionMenu(els.videoAspectMenu, els.videoAspectButton, "left");
  if (showVideoDuration) positionMenu(els.videoDurationMenu, els.videoDurationButton, "left");
}

function closeMenus() {
  els.toolsMenu.hidden = true;
  els.reasoningMenu.hidden = true;
  els.aspectMenu.hidden = true;
  els.videoAspectMenu.hidden = true;
  els.videoDurationMenu.hidden = true;
  els.modelOptions.hidden = true;
  els.toolsButton.setAttribute("aria-expanded", "false");
  els.reasoningButton.setAttribute("aria-expanded", "false");
  els.aspectButton.setAttribute("aria-expanded", "false");
  els.videoAspectButton.setAttribute("aria-expanded", "false");
  els.videoDurationButton.setAttribute("aria-expanded", "false");
  els.modelToggle.setAttribute("aria-expanded", "false");
}

function positionMenu(menu, anchor, align) {
  const anchorRect = anchor.getBoundingClientRect();
  const menuRect = menu.getBoundingClientRect();
  const gap = 14;
  const margin = 12;
  const top = Math.max(margin, anchorRect.top - menuRect.height - gap);
  const rawLeft = align === "right"
    ? anchorRect.right - menuRect.width
    : anchorRect.left;
  const left = Math.min(
    window.innerWidth - menuRect.width - margin,
    Math.max(margin, rawLeft)
  );

  menu.style.top = `${scaledCoord(top)}px`;
  menu.style.left = `${scaledCoord(left)}px`;
}

function positionModelOptions() {
  const gap = 10;
  const margin = 12;
  const menuRect = els.reasoningMenu.getBoundingClientRect();
  const modelOptionsWidth = els.modelOptions.offsetWidth || 190;
  const overflow = menuRect.right + gap + modelOptionsWidth - (window.innerWidth - margin);

  if (overflow > 0) {
    const shiftedLeft = Math.max(margin, menuRect.left - overflow);
    els.reasoningMenu.style.left = `${shiftedLeft}px`;
  }

  els.modelOptions.style.top = `${els.modelToggle.offsetTop}px`;
  els.modelOptions.style.left = `calc(100% + ${gap}px)`;
}

async function submitImagePrompt(rawPrompt) {
  const prompt = rawPrompt.trim();
  if (!prompt || isStreaming) return;
  const aspect = selectedAspect;
  const size = aspectSizes[aspect] || aspectSizes.auto;
  const model = normalizeImageModelValue(selectedImageModel);

  const session = getActiveSession();
  session.messages.push({
    id: createId(),
    role: "user",
    content: prompt,
    createdAt: Date.now()
  });

  if (session.title === "新的对话") {
    session.title = makeTitle(prompt);
  }

  ensureSessionRecorded(session);
  const assistantMessage = {
    id: createId(),
    role: "assistant",
    content: "正在生成图片...",
    createdAt: Date.now(),
    streaming: true,
    toolCallLabel: "调用创建图片工具"
  };

  session.messages.push(assistantMessage);
  session.updatedAt = Date.now();
  setStreaming(true);
  saveState();
  render();
  scrollToBottom();

  currentStreamingSessionId = session.id;
  currentStreamingMessageId = assistantMessage.id;
  const imageController = new AbortController();
  abortController = imageController;

  try {
    const response = await authFetch("/api/image", {
      method: "POST",
      signal: imageController.signal,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, aspect, size, model })
    });

    if (!response.ok) {
      throw new Error(await readError(response));
    }

    const image = await response.json();
    const imageSource = imageSourceFromResponse(image);
    assistantMessage.content = imageSource
      ? `图片已生成：\n\n![生成图片](${imageSource})`
      : "图片生成完成，但接口没有返回图片地址或 base64 内容。";
  } catch (error) {
    assistantMessage.content = assistantMessage.stopped
      ? "任务已停止"
      : `图片生成失败：${error.name === "AbortError" ? "请求超时或已停止。" : error.message}`;
  } finally {
    assistantMessage.streaming = false;
    assistantMessage.finishing = false;
    assistantMessage.finishedAt = Date.now();
    assistantMessage.reveal = true;
    session.updatedAt = Date.now();
    if (currentStreamingMessageId === assistantMessage.id) {
      currentStreamingSessionId = "";
      currentStreamingMessageId = "";
      if (abortController === imageController) abortController = null;
      setStreaming(false);
    }
    saveState();
    renderMessages();
    renderSessions();
    scrollToBottom();
  }
}

async function submitVideoPrompt(rawPrompt) {
  const prompt = rawPrompt.trim();
  if ((!prompt && !videoFirstFrame && !videoLastFrame) || isStreaming) return;
  const firstFrame = videoFirstFrame?.dataUrl || "";
  const lastFrame = videoLastFrame?.dataUrl || "";
  const aspect = selectedVideoAspect;
  const duration = selectedVideoDuration;
  const model = normalizeVideoModelValue(selectedVideoModel);
  const session = getActiveSession();
  const frameDescription = [firstFrame ? "首帧" : "", lastFrame ? "尾帧" : ""].filter(Boolean).join("和");
  const displayPrompt = prompt || `根据上传的${frameDescription || "画面"}创建视频`;

  session.messages.push({
    id: createId(),
    role: "user",
    content: displayPrompt,
    createdAt: Date.now()
  });
  if (session.title === "新的对话") session.title = makeTitle(displayPrompt);
  ensureSessionRecorded(session);

  const assistantMessage = {
    id: createId(),
    role: "assistant",
    content: "正在生成视频...",
    createdAt: Date.now(),
    streaming: true,
    toolCallLabel: "调用创建视频工具"
  };
  session.messages.push(assistantMessage);
  session.updatedAt = Date.now();
  setStreaming(true);
  saveState();
  render();
  scrollToBottom();

  currentStreamingSessionId = session.id;
  currentStreamingMessageId = assistantMessage.id;
  const videoController = new AbortController();
  abortController = videoController;

  try {
    const response = await authFetch("/api/video", {
      method: "POST",
      signal: videoController.signal,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, aspect, duration, model, firstFrame, lastFrame })
    });
    if (!response.ok) throw new Error(await readError(response));
    const video = await response.json();
    const videoSource = normalizeGeneratedVideoUrl(video.url);
    assistantMessage.content = videoSource
      ? `视频已生成：\n\n[video](${videoSource})`
      : "视频生成完成，但接口没有返回可用的视频地址。";
  } catch (error) {
    assistantMessage.content = assistantMessage.stopped
      ? "任务已停止"
      : `视频生成失败：${error.name === "AbortError" ? "请求超时或已停止。" : error.message}`;
  } finally {
    assistantMessage.streaming = false;
    assistantMessage.finishing = false;
    assistantMessage.finishedAt = Date.now();
    assistantMessage.reveal = true;
    session.updatedAt = Date.now();
    if (currentStreamingMessageId === assistantMessage.id) {
      currentStreamingSessionId = "";
      currentStreamingMessageId = "";
      if (abortController === videoController) abortController = null;
      setStreaming(false);
    }
    saveState();
    renderMessages();
    renderSessions();
    scrollToBottom();
  }
}

async function submitPrompt(rawPrompt) {
  let prompt = rawPrompt.trim();
  const attachmentsForMessage = pendingAttachments;
  const hasAttachments = attachmentsForMessage.length > 0;
  const requestedWebMode = activeMode === "web";
  const hasVideoFrames = activeMode === "video" && Boolean(videoFirstFrame || videoLastFrame);
  if ((!prompt && !hasAttachments && !hasVideoFrames) || isStreaming) return;

  if (activeMode === "video") {
    els.promptInput.value = "";
    resizeTextarea();
    updateSendState();
    await submitVideoPrompt(prompt);
    return;
  }

  if (activeMode === "image" && !hasAttachments) {
    els.promptInput.value = "";
    resizeTextarea();
    updateSendState();
    await submitImagePrompt(prompt);
    return;
  }

  const session = getActiveSession();
  if (hasAttachments) {
    deactivateImageMode();
  }
  if (!prompt && hasAttachments) {
    prompt = "请分析这些上传的文件。";
  }

  const userMessage = {
    id: createId(),
    role: "user",
    content: prompt,
    createdAt: Date.now(),
    attachments: attachmentsForMessage.map(publicAttachment),
    webSources: [],
    webContext: ""
  };

  session.messages.push(userMessage);

  if (session.title === "新的对话") {
    session.title = makeTitle(prompt);
  }
  ensureSessionRecorded(session);

  els.promptInput.value = "";
  pendingAttachments = [];
  renderAttachmentTray();
  if (requestedWebMode) {
    deactivateWebMode();
  }
  resizeTextarea();
  render();

  const requestAttachmentsByMessageId = {
    [userMessage.id]: attachmentsForMessage.map(requestAttachment)
  };
  const toolPlan = requestedWebMode
    ? { tool: "web_search", query: makeWebSearchQuery(session, prompt), reason: "用户手动开启网页搜索" }
    : await planToolForPrompt(session, prompt, hasAttachments);

  if (toolPlan.tool === "web_search") {
    await runWebSearchTool(session, userMessage, toolPlan, requestAttachmentsByMessageId);
    return;
  }

  if (toolPlan.tool === "create_image") {
    await runImageCreationTool(session, userMessage, toolPlan);
    return;
  }

  await requestAssistantResponse(session, requestAttachmentsByMessageId);
}

function makeWebSearchQuery(session, prompt) {
  const context = session.messages
    .slice(-6, -1)
    .map((message) => message.content)
    .filter(Boolean)
    .join(" ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(-400);
  return [context, prompt].filter(Boolean).join(" ").slice(0, 500);
}

function shouldAutoSearchWebLegacy(prompt) {
  const text = String(prompt || "").trim();
  return /^(联网搜索|网页搜索|搜索(一下)?(今日|今天|实时|最新|新闻|网页|当前)|查(一下|找|询)?(今日|今天|实时|最新|新闻|当前))/i.test(text);
}

async function planToolForPrompt(session, prompt, hasAttachments = false) {
  if (hasAttachments) {
    return { tool: "none", query: "", prompts: [], count: 0 };
  }

  try {
    const response = await authFetch("/api/tool-plan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: session.model,
        prompt,
        messages: session.messages.slice(-8).map((message) => ({
          role: message.role,
          content: message.content || ""
        }))
      })
    });

    if (!response.ok) {
      throw new Error(await readError(response));
    }

    const plan = normalizeToolPlan(await response.json(), prompt);
    if (plan.tool !== "none") return plan;
  } catch {
    // Fall back to conservative local detection when planning is unavailable.
  }

  if (shouldAutoCreateImage(prompt)) {
    return { tool: "create_image", query: "", prompts: [prompt], count: imageCountFromPrompt(prompt) };
  }

  if (shouldAutoSearchWeb(prompt)) {
    return { tool: "web_search", query: prompt, prompts: [], count: 0 };
  }

  return { tool: "none", query: "", prompts: [], count: 0 };
}

function normalizeToolPlan(plan, prompt) {
  const tool = ["web_search", "create_image"].includes(plan?.tool) ? plan.tool : "none";
  if (tool === "web_search") {
    return {
      tool,
      query: String(plan.query || prompt).trim() || prompt,
      prompts: [],
      count: 0,
      reason: String(plan.reason || "")
    };
  }

  if (tool === "create_image") {
    const prompts = Array.isArray(plan.prompts)
      ? plan.prompts.map((item) => String(item || "").trim()).filter(Boolean)
      : [];
    const count = clamp(Number(plan.count) || prompts.length || imageCountFromPrompt(prompt), 1, MAX_TOOL_IMAGE_COUNT);
    return {
      tool,
      query: "",
      prompts: (prompts.length ? prompts : [prompt]).slice(0, MAX_TOOL_IMAGE_COUNT),
      count,
      reason: String(plan.reason || "")
    };
  }

  return { tool: "none", query: "", prompts: [], count: 0, reason: String(plan?.reason || "") };
}

function shouldAutoSearchWeb(prompt) {
  const text = String(prompt || "").trim();
  return /(联网|网页搜索|搜索网页|查网页|上网查|实时|最新|今天|今日|当前|新闻|天气|价格|股价|汇率|赛程|比分|官网|网址|链接)/i.test(text);
}

function shouldAutoCreateImage(prompt) {
  const text = String(prompt || "").trim();
  if (!text) return false;
  return /(生成|创建|画|绘制|设计|做|制作).{0,12}(图片|图像|插画|照片|海报|头像|壁纸|表情包|封面|logo|图标)|^(画|绘制|生成|创建|设计)(一张|几张|[0-9一二三四五六七八九十]+张)?/i.test(text);
}

function imageCountFromPrompt(prompt) {
  const text = String(prompt || "");
  const digitMatch = text.match(/(\d{1,2})\s*张/);
  if (digitMatch) return clamp(Number(digitMatch[1]), 1, MAX_TOOL_IMAGE_COUNT);

  const chineseNumbers = {
    一: 1,
    两: 2,
    二: 2,
    三: 3,
    四: 4,
    五: 5,
    六: 6,
    七: 7,
    八: 8,
    九: 9,
    十: 10
  };
  const chineseMatch = text.match(/([一两二三四五六七八九十])\s*张/);
  return chineseMatch ? chineseNumbers[chineseMatch[1]] || 1 : 1;
}

async function runWebSearchTool(session, userMessage, toolPlan, requestAttachmentsByMessageId) {
  const assistantMessage = createToolAssistantMessage("调用搜索网页工具");
  session.messages.push(assistantMessage);
  const assistantIndex = session.messages.length - 1;
  session.updatedAt = Date.now();
  setStreaming(true);
  saveState();
  render();
  scrollToBottom();

  const query = String(toolPlan.query || makeWebSearchQuery(session, userMessage.content)).trim();
  const searchResult = await searchWebForPrompt(query || userMessage.content);
  userMessage.webSources = searchResult.sources;
  userMessage.webContext = searchResult.context;
  assistantMessage.webSources = searchResult.sources;
  saveState();

  await requestAssistantResponse(
    session,
    requestAttachmentsByMessageId,
    assistantMessage,
    assistantIndex,
    searchResult.sources
  );
}

async function runImageCreationTool(session, userMessage, toolPlan) {
  const assistantMessage = createToolAssistantMessage("调用创建图片工具");
  session.messages.push(assistantMessage);
  session.updatedAt = Date.now();
  setStreaming(true);
  saveState();
  render();
  scrollToBottom();

  currentStreamingSessionId = session.id;
  currentStreamingMessageId = assistantMessage.id;
  const imageController = new AbortController();
  abortController = imageController;

  const count = clamp(Number(toolPlan.count) || 1, 1, MAX_TOOL_IMAGE_COUNT);
  const prompts = Array.isArray(toolPlan.prompts) && toolPlan.prompts.length
    ? toolPlan.prompts
    : [userMessage.content];
  const aspect = selectedAspect;
  const size = aspectSizes[aspect] || aspectSizes.auto;
  const model = normalizeImageModelValue(selectedImageModel);
  const generated = [];
  const failures = [];

  try {
    for (let index = 0; index < count; index += 1) {
      const imagePrompt = prompts[index] || prompts[0] || userMessage.content;
      const imageSource = await requestGeneratedImage({
        prompt: imagePrompt,
        aspect,
        size,
        model,
        signal: imageController.signal
      });
      if (imageSource) {
        generated.push(`![生成图片 ${index + 1}](${imageSource})`);
      } else {
        failures.push(index + 1);
      }
    }

    assistantMessage.content = generated.length
      ? `图片已生成：\n\n${generated.join("\n\n")}${failures.length ? `\n\n未成功生成：${failures.join("、")}` : ""}`
      : "图片生成完成，但接口没有返回可用图片。";
  } catch (error) {
    assistantMessage.content = assistantMessage.stopped
      ? "任务已停止"
      : `图片生成失败：${error.name === "AbortError" ? "请求超时或已停止。" : error.message}`;
  } finally {
    assistantMessage.streaming = false;
    assistantMessage.finishing = false;
    assistantMessage.finishedAt = Date.now();
    assistantMessage.reveal = true;
    session.updatedAt = Date.now();
    if (currentStreamingMessageId === assistantMessage.id) {
      currentStreamingSessionId = "";
      currentStreamingMessageId = "";
      if (abortController === imageController) abortController = null;
      setStreaming(false);
    }
    saveState();
    renderMessages();
    renderSessions();
    scrollToBottom();
  }
}

function createToolAssistantMessage(label) {
  return {
    id: createId(),
    role: "assistant",
    content: "",
    createdAt: Date.now(),
    startedAt: Date.now(),
    streaming: true,
    toolCallLabel: label,
    webSources: []
  };
}

async function requestGeneratedImage({ prompt, aspect, size, model, signal }) {
  const response = await authFetch("/api/image", {
    method: "POST",
    signal,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ prompt, aspect, size, model })
  });

  if (!response.ok) {
    throw new Error(await readError(response));
  }

  const image = await response.json();
  return imageSourceFromResponse(image);
}

function imageSourceFromResponse(image) {
  if (image?.url) return normalizeGeneratedImageUrl(image.url);
  if (!image?.b64_json) return "";
  return `data:${imageMimeType(image.b64_json)};base64,${image.b64_json}`;
}

function imageMimeType(base64) {
  const value = String(base64 || "").replace(/\s+/g, "");
  if (value.startsWith("/9j/")) return "image/jpeg";
  if (value.startsWith("UklGR")) return "image/webp";
  if (value.startsWith("R0lGOD")) return "image/gif";
  if (value.startsWith("Qk")) return "image/bmp";
  return "image/png";
}

async function requestAssistantResponse(
  session,
  requestAttachmentsByMessageId = {},
  assistantMessage = null,
  assistantIndex = session.messages.length,
  assistantWebSources = []
) {
  if (!assistantMessage) {
    assistantMessage = {
      id: createId(),
      role: "assistant",
      content: "",
      createdAt: Date.now(),
      startedAt: Date.now(),
      streaming: true,
      webSources: assistantWebSources
    };
    session.messages.push(assistantMessage);
    assistantIndex = session.messages.length - 1;
  }

  session.updatedAt = Date.now();
  setStreaming(true);
  saveState();
  render();
  scrollToBottom();

  currentStreamingSessionId = session.id;
  currentStreamingMessageId = assistantMessage.id;
  abortController = new AbortController();
  const chatTimeout = setTimeout(() => abortController?.abort(), 120000);

  try {
    const response = await authFetch("/api/chat", {
      method: "POST",
      signal: abortController.signal,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: session.model,
        reasoningEffort: session.reasoningEffort,
        deepseekThinking: isDeepseekModel(session.model) ? session.deepseekThinking !== false : false,
        messages: session.messages
          .slice(0, assistantIndex)
          .map((message) => ({
            id: message.id,
            role: message.role,
            content: message.content,
            attachments: requestAttachmentsByMessageId[message.id] || [],
            attachmentContext: message.attachmentContext || "",
            webContext: message.webContext || ""
          }))
      })
    });

    if (!response.ok) {
      throw new Error(await readError(response));
    }

    if (!response.body) {
      throw new Error("服务端没有返回可读取的流。");
    }

    await readAssistantStream(response.body, assistantMessage, session);
  } catch (error) {
    if (error.name === "AbortError") {
      if (assistantMessage.stopped) {
        assistantMessage.content = "任务已停止";
      } else {
        assistantMessage.content = "请求超时，请稍后重试。";
      }
    } else {
      assistantMessage.content = `请求失败：${error.message}`;
    }
  } finally {
    clearTimeout(chatTimeout);
    if (!assistantMessage.stopped) {
      assistantMessage.finishing = true;
      renderMessages();
      scrollToBottom();
      await wait(420);
    }
    assistantMessage.streaming = false;
    assistantMessage.finishing = false;
    assistantMessage.finishedAt = Date.now();
    assistantMessage.reveal = true;
    session.updatedAt = Date.now();
    if (currentStreamingMessageId === assistantMessage.id) {
      currentStreamingSessionId = "";
      currentStreamingMessageId = "";
      abortController = null;
      setStreaming(false);
    }
    saveState();
    renderMessages();
    renderSessions();
    scrollToBottom();
  }
}

async function readAssistantStream(body, assistantMessage, session) {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const frames = buffer.split("\n\n");
    buffer = frames.pop() || "";

    for (const frame of frames) {
      const dataLine = frame.split("\n").find((line) => line.startsWith("data:"));
      if (!dataLine) continue;

      const payload = JSON.parse(dataLine.slice(5).trim());

      if (payload.type === "attachment_context") {
        const message = session.messages.find((item) => item.id === payload.messageId);
        if (message) {
          message.attachmentContext = payload.context || "";
          message.attachments = mergeMessageAttachments(message.attachments, payload.attachments);
          saveState();
        }
        continue;
      }

      if (payload.type === "delta") {
        assistantMessage.content += payload.delta;
        scrollToBottom();
      }

      if (payload.type === "error") {
        throw new Error(payload.error || "模型响应失败。");
      }
    }
  }
}

async function readError(response) {
  try {
    const payload = await response.json();
    return payload.error || `服务端返回 HTTP ${response.status}`;
  } catch {
    return `服务端返回 HTTP ${response.status}`;
  }
}

async function searchWebForPrompt(prompt) {
  try {
    const response = await authFetch("/api/web-search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: prompt, maxResults: 6 })
    });

    if (!response.ok) {
      throw new Error(await readError(response));
    }

    const payload = await response.json();
    const sources = Array.isArray(payload.sources) ? payload.sources : [];
    return {
      sources,
      context: buildWebContext(prompt, sources)
    };
  } catch (error) {
    const message = `网页搜索暂时不可用：${error.message}`;
    return {
      sources: [],
      context: `用户请求联网搜索并分析，但本次网页搜索失败。\n失败原因：${message}\n请明确说明无法读取实时网页，并基于已有上下文尽力回答。`
    };
  }
}

function buildWebContext(query, sources) {
  if (!sources.length) {
    return `用户请求联网搜索并分析。\n搜索词：${query}\n搜索结果为空。请说明未找到可用网页资料，并基于已有上下文回答。`;
  }

  return [
    "以下是本轮网页搜索读取到的资料。请结合用户问题进行综合分析；引用事实时优先依据这些网页资料，并在必要时说明来源标题或链接。",
    `搜索词：${query}`,
    ...sources.map((source, index) => [
      `资料 ${index + 1}`,
      `标题：${source.title || "未命名网页"}`,
      `链接：${source.url || ""}`,
      source.snippet ? `摘要：${source.snippet}` : "",
      source.excerpt ? `页面片段：${source.excerpt}` : ""
    ].filter(Boolean).join("\n"))
  ].join("\n\n");
}

function regenerateMessage(messageId) {
  if (isStreaming) return;
  const session = getActiveSession();
  const messageIndex = session.messages.findIndex((message) => message.id === messageId);
  const assistantMessage = session.messages[messageIndex];

  if (messageIndex <= 0 || assistantMessage?.role !== "assistant") return;

  assistantMessage.content = "";
  assistantMessage.streaming = true;
  assistantMessage.finishing = false;
  assistantMessage.reveal = false;
  assistantMessage.startedAt = Date.now();
  delete assistantMessage.finishedAt;
  delete assistantMessage.stopped;

  session.updatedAt = Date.now();
  setStreaming(true);
  saveState();
  renderMessages();
  requestAssistantResponse(session, {}, assistantMessage, messageIndex);
}

function stopStreaming() {
  const session = state.sessions.find((item) => item.id === currentStreamingSessionId) || getActiveSession();
  const message = session.messages.find((item) => item.id === currentStreamingMessageId)
    || [...session.messages].reverse().find((item) => item.role === "assistant" && item.streaming);

  if (message) {
    message.content = "任务已停止";
    message.stopped = true;
    message.streaming = false;
    message.finishing = false;
    message.finishedAt = Date.now();
    message.reveal = true;
    session.updatedAt = Date.now();
  }

  abortController?.abort();
  currentStreamingSessionId = "";
  currentStreamingMessageId = "";
  abortController = null;
  setStreaming(false);
  saveState();
  renderMessages();
  renderSessions();
  scrollToBottom();
}

function setStreaming(value) {
  isStreaming = value;
  els.sendButton.title = value ? "停止" : "发送";
  els.sendButton.ariaLabel = value ? "停止" : "发送";
  updateSendState();
}

function updateSendState() {
  const hasPrompt = Boolean(els.promptInput.value.trim());
  const hasAttachments = pendingAttachments.length > 0;
  const hasVideoFrames = activeMode === "video" && Boolean(videoFirstFrame || videoLastFrame);
  els.chatPanel.classList.toggle("has-input", hasPrompt || hasAttachments || hasVideoFrames || isStreaming);
  els.sendButton.disabled = !isStreaming && !hasPrompt && !hasAttachments && !hasVideoFrames;
  els.sendIcon.innerHTML = isStreaming ? stopIcon : sendArrowIcon;
}

function updateSessionSettings() {
  const session = getActiveSession();
  if (activeMode === "image") {
    selectedImageModel = normalizeImageModelValue(els.modelSelect.value);
    els.modelSelect.value = selectedImageModel;
    renderModelState();
    renderImageModeState();
    renderDeepThinkingState();
    return;
  }
  if (activeMode === "video") {
    selectedVideoModel = normalizeVideoModelValue(els.modelSelect.value);
    els.modelSelect.value = selectedVideoModel;
    renderModelState();
    renderVideoModeState();
    renderDeepThinkingState();
    return;
  }
  session.model = normalizeModelValue(els.modelSelect.value);
  els.modelSelect.value = session.model;
  if (isDeepseekModel(session.model) && typeof session.deepseekThinking !== "boolean") {
    session.deepseekThinking = true;
  }
  session.reasoningEffort = els.reasoningSelect.value;
  session.updatedAt = Date.now();
  saveState();
  renderModelState();
  renderReasoningState();
  renderImageModeState();
  renderVideoModeState();
  renderWebModeState();
  renderDeepThinkingState();
  renderSessions();
}

function render() {
  const session = getActiveSession();
  const isEmpty = session.messages.length === 0;
  const isAppsView = activeMainView === "apps";

  els.chatPanel.classList.toggle("empty", isEmpty);
  els.chatPanel.classList.toggle("temporary", Boolean(session.temporary));
  els.chatPanel.classList.toggle("apps-open", isAppsView);
  els.appsView.hidden = !isAppsView;
  els.messageScroll.hidden = isAppsView;
  els.welcome.hidden = isAppsView || session.messages.length > 0;
  renderRailNavigationState();
  if (!isEmpty) resetMascotEyes();
  els.conversationTitle.textContent = isAppsView ? "应用" : session.title;
  session.model = normalizeModelValue(session.model);
  els.modelSelect.value = session.model;
  els.reasoningSelect.value = session.reasoningEffort;
  renderModelState();
  renderReasoningState();
  renderImageModeState();
  renderVideoModeState();
  renderWebModeState();
  renderDeepThinkingState();
  renderProfileState();
  renderSessions();
  if (isAppsView) {
    els.messageScroll.querySelectorAll(".message").forEach((node) => node.remove());
  } else {
    renderMessages();
  }
  updateSendState();
  suppressNativeTooltips();
}

function suppressNativeTooltips(root = document) {
  root.querySelectorAll("[title]").forEach((node) => {
    if (node.closest(".rail-button")) return;
    node.removeAttribute("title");
  });
}

function renderReasoningState() {
  const value = els.reasoningSelect.value || "high";
  els.reasoningMenu.querySelectorAll("[data-reasoning]").forEach((option) => {
    option.classList.toggle("active", option.dataset.reasoning === value);
  });
}

function renderModelState() {
  const isImageMode = activeMode === "image";
  const isVideoMode = activeMode === "video";
  const value = isImageMode
    ? normalizeImageModelValue(selectedImageModel || els.modelSelect.value)
    : isVideoMode
      ? normalizeVideoModelValue(selectedVideoModel || els.modelSelect.value)
      : normalizeModelValue(els.modelSelect.value);
  if (isImageMode) selectedImageModel = value;
  if (isVideoMode) selectedVideoModel = value;
  els.modelSelect.value = value;
  els.reasoningLabel.textContent = modelLabels[value] || modelLabels["gpt-5.4"];
  els.modelMenuLabel.textContent = modelLabels[value] || modelLabels["gpt-5.4"];
  els.modelOptions.querySelectorAll("[data-model]").forEach((option) => {
    option.classList.toggle("active", option.dataset.model === value);
  });
}

function activateImageMode() {
  activeMode = "image";
  selectedImageModel = normalizeImageModelValue(selectedImageModel);
  els.modelSelect.value = selectedImageModel;
  renderImageModeState();
  renderVideoModeState();
  renderWebModeState();
  renderModelState();
  renderDeepThinkingState();
  resizeTextarea();
  updateSendState();
  focusComposer();
}

function handleVideoAspectMenuClick(event) {
  const option = event.target.closest("[data-video-aspect]");
  if (!option) return;
  selectedVideoAspect = option.dataset.videoAspect === "story" ? "story" : "wide";
  renderVideoModeState();
  closeMenus();
  focusComposer();
}

function handleVideoDurationMenuClick(event) {
  const option = event.target.closest("[data-video-duration]");
  if (!option) return;
  const duration = Number(option.dataset.videoDuration);
  selectedVideoDuration = [4, 8, 12].includes(duration) ? duration : 4;
  renderVideoModeState();
  closeMenus();
  focusComposer();
}

function deactivateImageMode() {
  if (activeMode === "image") activeMode = "chat";
  els.modelSelect.value = getActiveSession().model;
  closeMenus();
  renderImageModeState();
  renderVideoModeState();
  renderWebModeState();
  renderModelState();
  renderDeepThinkingState();
  resizeTextarea();
  updateSendState();
}

function activateVideoMode() {
  activeMode = "video";
  selectedVideoModel = normalizeVideoModelValue(selectedVideoModel);
  els.modelSelect.value = selectedVideoModel;
  migratePendingAttachmentsToVideoFrames();
  renderImageModeState();
  renderVideoModeState();
  renderWebModeState();
  renderModelState();
  renderDeepThinkingState();
  resizeTextarea();
  updateSendState();
  focusComposer();
}

function deactivateVideoMode() {
  if (activeMode === "video") activeMode = "chat";
  els.modelSelect.value = getActiveSession().model;
  closeMenus();
  renderImageModeState();
  renderVideoModeState();
  renderWebModeState();
  renderModelState();
  renderDeepThinkingState();
  resizeTextarea();
  updateSendState();
}

function activateWebMode() {
  activeMode = "web";
  renderImageModeState();
  renderVideoModeState();
  renderWebModeState();
  renderDeepThinkingState();
  resizeTextarea();
  updateSendState();
  focusComposer();
}

function deactivateWebMode() {
  if (activeMode === "web") activeMode = "chat";
  closeMenus();
  renderImageModeState();
  renderVideoModeState();
  renderWebModeState();
  renderDeepThinkingState();
  resizeTextarea();
  updateSendState();
}

function renderImageModeState() {
  const isImageMode = activeMode === "image";
  const text = currentText();
  els.imageModeBar.hidden = !isImageMode;
  els.composer.classList.toggle("image-mode", isImageMode);
  els.reasoningButton.classList.toggle("image-model-button", isImageMode);
  els.reasoningMenu.classList.toggle("image-model-menu", isImageMode);
  if (isImageMode) {
    els.modelSelect.value = selectedImageModel;
  }
  renderModelState();
  els.promptInput.placeholder = isImageMode ? text.imagePlaceholder : text.promptPlaceholder;
  els.aspectLabel.textContent = localizedAspectLabel(selectedAspect);

  els.aspectMenu.querySelectorAll("[data-aspect]").forEach((option) => {
    option.classList.toggle("active", option.dataset.aspect === selectedAspect);
  });
}

function renderVideoModeState() {
  const isVideoMode = activeMode === "video";
  const text = currentText();
  els.fileInput.accept = isVideoMode
    ? "image/png,image/jpeg,image/webp,.png,.jpg,.jpeg,.webp"
    : "image/*,video/*,.txt,.md,.csv,.json,.pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx";
  els.videoModeBar.hidden = !isVideoMode;
  els.videoFramePicker.hidden = !isVideoMode;
  els.composer.classList.toggle("video-mode", isVideoMode);
  els.reasoningButton.classList.toggle("video-model-button", isVideoMode);
  els.reasoningMenu.classList.toggle("video-model-menu", isVideoMode);
  if (isVideoMode) els.modelSelect.value = selectedVideoModel;
  els.videoAspectLabel.textContent = selectedVideoAspect === "story" ? "9:16" : "16:9";
  els.videoDurationLabel.textContent = `${selectedVideoDuration}s`;
  els.videoAspectMenu.querySelectorAll("[data-video-aspect]").forEach((option) => {
    option.classList.toggle("active", option.dataset.videoAspect === selectedVideoAspect);
  });
  els.videoDurationMenu.querySelectorAll("[data-video-duration]").forEach((option) => {
    option.classList.toggle("active", Number(option.dataset.videoDuration) === selectedVideoDuration);
  });
  renderVideoFrameState();
  renderModelState();
  if (isVideoMode) els.promptInput.placeholder = text.videoPlaceholder;
}

function migratePendingAttachmentsToVideoFrames() {
  if (!pendingAttachments.length) return;

  const supported = pendingAttachments.filter(isSupportedVideoFrameFile);
  let index = 0;
  let migratedCount = 0;
  if (!videoFirstFrame && supported[index]) {
    videoFirstFrame = supported[index];
    index += 1;
    migratedCount += 1;
  }
  if (!videoLastFrame && supported[index]) {
    videoLastFrame = supported[index];
    migratedCount += 1;
  }

  const removedCount = pendingAttachments.length - migratedCount;
  pendingAttachments = [];
  renderAttachmentTray();
  renderVideoFrameState();
  if (removedCount > 0) {
    showComposerNotice("创建视频仅保留首帧和尾帧图片，其他附件已移除。");
  }
}

function renderWebModeState() {
  const isWebMode = activeMode === "web";
  const text = currentText();
  els.webModeBar.hidden = !isWebMode;
  els.composer.classList.toggle("web-mode", isWebMode);
  if (isWebMode) {
    els.promptInput.placeholder = text.webPlaceholder;
  } else if (activeMode !== "image" && activeMode !== "video") {
    els.promptInput.placeholder = text.promptPlaceholder;
  }
}

function renderDeepThinkingState() {
  const session = getActiveSession();
  const isDeepseekChat = activeMode !== "image" && activeMode !== "video" && isDeepseekModel(session.model);
  const active = session.deepseekThinking !== false;
  els.deepThinkingToggle.hidden = !isDeepseekChat;
  els.deepThinkingToggle.classList.toggle("active", active);
  els.deepThinkingToggle.setAttribute("aria-pressed", String(active));
  els.composer.classList.toggle("deepseek-mode", isDeepseekChat);
  const label = els.deepThinkingToggle.querySelector("span");
  if (label) label.textContent = currentText().deepThinking;
}

function renderSessions() {
  const query = els.searchSessions.value.trim().toLowerCase();
  const sessions = state.sessions
    .filter((session) => session.messages.length > 0)
    .filter((session) => {
      if (!query) return true;
      return `${session.title} ${session.messages.map((message) => message.content).join(" ")}`
        .toLowerCase()
        .includes(query);
    })
    .sort((a, b) => Number(Boolean(b.pinned)) - Number(Boolean(a.pinned)) || b.updatedAt - a.updatedAt);

  els.sessionList.innerHTML = sessions
    .map((session) => `
      <div class="session-item ${session.id === activeSessionId ? "active" : ""}" data-session-id="${session.id}">
        <button class="session-button" type="button" data-open-session="${session.id}">
          <span class="session-title">${escapeHtml(session.title)}</span>
        </button>
        ${session.pinned ? renderPinnedIcon() : ""}
        <button class="session-more" type="button" data-session-menu="${session.id}" aria-label="\u5bf9\u8bdd\u9009\u9879" title="\u5bf9\u8bdd\u9009\u9879">
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <path d="M5.6 12h.01M12 12h.01M18.4 12h.01" />
          </svg>
        </button>
      </div>
    `)
    .join("");

  els.sessionList.querySelectorAll("[data-open-session]").forEach((button) => {
    button.addEventListener("click", () => {
      showChatView();
      activeSessionId = button.dataset.openSession;
      state.activeSessionId = activeSessionId;
      saveState();
      render();
      closeSidebar();
    });
  });

  els.sessionList.querySelectorAll("[data-session-menu]").forEach((button) => {
    button.addEventListener("click", (event) => {
      event.stopPropagation();
      openSessionMenu(button.dataset.sessionMenu, button);
    });
  });

  suppressNativeTooltips(els.sessionList);
}

function renderPinnedIcon() {
  return `
    <span class="session-pin" aria-label="\u5df2\u9876\u7f6e" title="\u5df2\u9876\u7f6e">
      <svg viewBox="0 0 24 24" aria-hidden="true">
        ${pinIconMarkup}
      </svg>
    </span>
  `;
}

function openSessionMenu(sessionId, anchor) {
  closeSessionMenu();
  const session = state.sessions.find((item) => item.id === sessionId);
  if (!session) return;
  anchor.setAttribute("aria-expanded", "true");

  const menu = document.createElement("div");
  menu.className = "session-menu";
  menu.dataset.sessionMenuOpen = sessionId;
  const pinAction = session.pinned ? "unpin" : "pin";
  const pinLabel = session.pinned ? "取消顶置聊天" : "顶置聊天";
  const pinIcon = session.pinned ? unpinIconMarkup : pinIconMarkup;
  menu.innerHTML = `
    <button type="button" data-session-action="rename">
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <path d="M4 20h4.5L19 9.5a2.1 2.1 0 0 0 0-3L17.5 5a2.1 2.1 0 0 0-3 0L4 15.5V20Z" />
        <path d="m13.5 6 4.5 4.5" />
      </svg>
      <span>\u91cd\u547d\u540d</span>
    </button>
    <button type="button" data-session-action="${pinAction}">
      <svg class="pin-icon" viewBox="0 0 24 24" aria-hidden="true">
        ${pinIcon}
      </svg>
      <span>${pinLabel}</span>
    </button>
    <button type="button" class="danger" data-session-action="delete">
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <path d="M4 7h16" />
        <path d="M9 7V5h6v2" />
        <path d="M6.5 7 7.4 20h9.2l.9-13" />
        <path d="M10 11v5M14 11v5" />
      </svg>
      <span>\u5220\u9664</span>
    </button>
  `;

  menu.addEventListener("click", (event) => {
    event.stopPropagation();
    const action = event.target.closest("[data-session-action]")?.dataset.sessionAction;
    if (!action) return;
    handleSessionAction(action, sessionId);
  });

  document.body.appendChild(menu);
  positionSessionMenu(menu, anchor);
}

function positionSessionMenu(menu, anchor) {
  const anchorRect = anchor.getBoundingClientRect();
  const menuRect = menu.getBoundingClientRect();
  const margin = 10;
  const left = Math.min(window.innerWidth - menuRect.width - margin, Math.max(margin, anchorRect.right - menuRect.width));
  const top = Math.min(window.innerHeight - menuRect.height - margin, anchorRect.bottom + 8);
  menu.style.left = `${left}px`;
  menu.style.top = `${Math.max(margin, top)}px`;
}

function closeSessionMenu() {
  document.querySelectorAll("[data-session-menu]").forEach((button) => {
    button.setAttribute("aria-expanded", "false");
  });
  document.querySelector("[data-session-menu-open]")?.remove();
}

function handleSessionAction(action, sessionId) {
  const session = state.sessions.find((item) => item.id === sessionId);
  if (!session) return;

  if (action === "rename") {
    closeSessionMenu();
    startInlineRename(sessionId);
    return;
  }

  if (action === "pin") {
    session.pinned = true;
    session.updatedAt = Date.now();
  }

  if (action === "unpin") {
    session.pinned = false;
    session.updatedAt = Date.now();
  }

  if (action === "delete") {
    state.sessions = state.sessions.filter((item) => item.id !== sessionId);
    if (!state.sessions.length) {
      draftSession = createSession(false);
    }
    if (activeSessionId === sessionId) {
      activeSessionId = (state.sessions[0] || draftSession).id;
    }
  }

  state.activeSessionId = activeSessionId;
  closeSessionMenu();
  saveState();
  render();
}

function startInlineRename(sessionId) {
  const session = state.sessions.find((item) => item.id === sessionId);
  const item = [...els.sessionList.querySelectorAll("[data-session-id]")]
    .find((node) => node.dataset.sessionId === sessionId);
  if (!session || !item) return;

  item.classList.add("renaming");
  item.innerHTML = `
    <input class="session-rename-input" value="${escapeHtml(session.title)}" aria-label="\u91cd\u547d\u540d\u804a\u5929" />
  `;
  const input = item.querySelector(".session-rename-input");
  input.focus();
  input.select();

  let finished = false;
  const finish = (commit) => {
    if (finished) return;
    finished = true;
    const nextTitle = input.value.trim();
    if (commit && nextTitle) {
      session.title = nextTitle.slice(0, 80);
      session.updatedAt = Date.now();
      saveState();
    }
    renderSessions();
  };

  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") finish(true);
    if (event.key === "Escape") finish(false);
  });
  input.addEventListener("blur", () => finish(true), { once: true });
}

function renderMessages() {
  const session = getActiveSession();
  const normalizedMessages = normalizeStoredMessages(session.messages);
  const messagesChanged = normalizedMessages.length !== session.messages.length
    || normalizedMessages.some((message, index) => message !== session.messages[index]);
  if (messagesChanged) {
    session.messages = normalizedMessages;
    session.updatedAt = Date.now();
    saveState();
  }

  els.welcome.hidden = session.messages.length > 0;
  els.chatPanel.classList.toggle("empty", session.messages.length === 0);
  els.chatPanel.classList.toggle("temporary", Boolean(session.temporary));

  els.messageScroll.querySelectorAll(".message").forEach((node) => node.remove());

  const html = session.messages
    .map((message) => `
      <article class="message ${message.role} ${editingUserMessageId === message.id ? "editing" : ""} ${message.streaming ? "thinking" : ""} ${message.finishing ? "finishing" : ""}" data-message-id="${message.id}">
        <div class="message-body">
          ${message.role === "assistant" ? renderAssistantMessage(message) : renderUserMessage(message)}
        </div>
      </article>
    `)
    .join("");

  els.messageScroll.insertAdjacentHTML("beforeend", html);
  startNoonThinkingAnimations(els.messageScroll);

  els.messageScroll.querySelectorAll(".message.assistant[data-message-id]").forEach((article) => {
    const actions = article.querySelectorAll(".icon-action");
    const moreButton = actions[actions.length - 1];
    if (!moreButton) return;
    if (!findMessageSources(article.dataset.messageId).length) {
      moreButton.hidden = true;
      return;
    }
    moreButton.dataset.references = article.dataset.messageId;
    moreButton.setAttribute("aria-label", "网页资料");
    moreButton.setAttribute("title", "网页资料");
  });

  els.messageScroll.querySelectorAll("[data-copy]").forEach((button) => {
    button.addEventListener("click", async () => {
      const message = getActiveSession().messages.find((item) => item.id === button.dataset.copy);
      if (!message) return;
      await navigator.clipboard.writeText(message.content);
      const original = button.innerHTML;
      button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 5 5L20 7" /></svg>';
      setTimeout(() => (button.innerHTML = original), 1200);
    });
  });

  els.messageScroll.querySelectorAll("[data-feedback]").forEach((button) => {
    button.addEventListener("click", () => {
      toggleAssistantFeedback(button.dataset.feedbackMessage, button.dataset.feedback);
    });
  });

  els.messageScroll.querySelectorAll("[data-user-copy]").forEach((button) => {
    button.addEventListener("click", async () => {
      const message = getActiveSession().messages.find((item) => item.id === button.dataset.userCopy);
      if (!message) return;
      await navigator.clipboard.writeText(message.content || "");
      const original = button.innerHTML;
      button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 5 5L20 7" /></svg>';
      setTimeout(() => (button.innerHTML = original), 1200);
    });
  });

  els.messageScroll.querySelectorAll("[data-user-edit]").forEach((button) => {
    button.addEventListener("click", () => startEditingUserMessage(button.dataset.userEdit));
  });

  els.messageScroll.querySelectorAll("[data-edit-cancel]").forEach((button) => {
    button.addEventListener("click", () => cancelEditingUserMessage());
  });

  els.messageScroll.querySelectorAll("[data-edit-send]").forEach((button) => {
    button.addEventListener("click", () => {
      const input = els.messageScroll.querySelector(`[data-edit-input="${button.dataset.editSend}"]`);
      editAndResubmitUserMessage(button.dataset.editSend, input?.value || "");
    });
  });

  els.messageScroll.querySelectorAll("[data-edit-input]").forEach((input) => {
    input.addEventListener("input", () => resizeUserEditInput(input));
    input.addEventListener("keydown", (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        cancelEditingUserMessage();
      }
      if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
        event.preventDefault();
        editAndResubmitUserMessage(input.dataset.editInput, input.value || "");
      }
    });
    resizeUserEditInput(input);
  });

  els.messageScroll.querySelectorAll("[data-regenerate]").forEach((button) => {
    button.addEventListener("click", () => regenerateMessage(button.dataset.regenerate));
  });

  els.messageScroll.querySelectorAll("[data-references]").forEach((button) => {
    button.addEventListener("click", () => openReferencesPanel(button.dataset.references));
  });

  els.messageScroll.querySelectorAll("[data-download-image]").forEach((button) => {
    button.addEventListener("click", (event) => {
      event.preventDefault();
      downloadGeneratedImage(button.getAttribute("href") || "", button.dataset.downloadName || "noonai-generated-image.png");
    });
  });

  suppressNativeTooltips(els.messageScroll);
}

function renderUserMessage(message) {
  if (editingUserMessageId === message.id) {
    return renderUserMessageEditor(message);
  }

  const attachments = Array.isArray(message.attachments) ? message.attachments : [];
  const imageAttachments = attachments.filter((attachment) => isImageAttachment(attachment) && attachmentPreviewSource(attachment));
  const fileAttachments = attachments.filter((attachment) => !isImageAttachment(attachment) || !attachmentPreviewSource(attachment));
  const hasImages = imageAttachments.length > 0;

  return `
    <div class="user-message-stack ${hasImages ? "has-images" : ""}">
      ${renderUserImageAttachments(imageAttachments)}
      ${renderMessageAttachments(fileAttachments)}
      ${message.content ? `<div class="message-content">${renderMarkdown(message.content || "")}</div>` : ""}
      ${renderUserActions(message.id)}
    </div>
  `;
}

function renderUserImageAttachments(attachments) {
  if (!attachments.length) return "";

  return `
    <div class="message-image-attachments">
      ${attachments.map((attachment) => {
        const safeName = escapeHtml(attachment.name || "上传图片");
        const source = escapeHtml(attachmentPreviewSource(attachment));
        if (!source) return "";
        return `
          <img class="message-image-preview" src="${source}" alt="${safeName}" title="${safeName}" />
        `;
      }).join("")}
    </div>
  `;
}

function attachmentPreviewSource(attachment) {
  return attachment?.dataUrl || attachment?.url || "";
}

function renderUserActions(messageId) {
  return `
    <div class="user-message-actions" aria-label="用户消息操作">
      <button class="icon-action" type="button" data-user-copy="${messageId}" aria-label="复制" title="复制">
        <img class="action-icon-img" src="./action-copy-icon.png" alt="" aria-hidden="true" />
      </button>
      <button class="icon-action" type="button" data-user-edit="${messageId}" aria-label="编辑" title="编辑">
        <svg viewBox="0 0 24 24" aria-hidden="true">
          <path d="M4.8 19.2 8.9 18.4 18.6 8.7a2.5 2.5 0 0 0-3.5-3.5L5.4 14.9 4.8 19.2Z" />
          <path d="m13.7 6.6 3.7 3.7" />
        </svg>
      </button>
    </div>
  `;
}

function renderUserMessageEditor(message) {
  return `
    <div class="user-message-edit-form">
      <textarea class="user-message-edit-input" data-edit-input="${message.id}" rows="1">${escapeHtml(message.content || "")}</textarea>
      <div class="user-message-edit-actions">
        <button class="edit-action cancel" type="button" data-edit-cancel="${message.id}">取消</button>
        <button class="edit-action send" type="button" data-edit-send="${message.id}">发送</button>
      </div>
    </div>
  `;
}

function renderAssistantMessage(message) {
  if (message.streaming && !message.stopped) {
    return renderNoonThinking(message.toolCallLabel || "");
  }

  return `
    <div class="message-content ${message.reveal ? "reveal-response" : ""}">${renderMarkdown(message.content || "没有收到模型回复。")}</div>
    ${message.content ? renderAssistantActions(message) : ""}
  `;
}

function renderNoonThinking(label = "") {
  return `
    <div class="noon-thinking" aria-label="noon 正在思考">
      <span class="noon-logo-thinking" aria-hidden="true">
        <svg class="thinking-mascot" viewBox="0 0 464 356" role="presentation">
          <g class="thinking-rays">
            <line class="thinking-ray" x1="23" y1="235" x2="51" y2="235" />
            <line class="thinking-ray" x1="33" y1="169" x2="62" y2="179" />
            <line class="thinking-ray" x1="70" y1="99" x2="94" y2="118" />
            <line class="thinking-ray" x1="136" y1="47" x2="149" y2="75" />
            <line class="thinking-ray" x1="230" y1="23" x2="230" y2="58" />
            <line class="thinking-ray" x1="323" y1="43" x2="310" y2="72" />
            <line class="thinking-ray" x1="392" y1="96" x2="370" y2="116" />
            <line class="thinking-ray" x1="429" y1="167" x2="401" y2="177" />
            <line class="thinking-ray" x1="441" y1="235" x2="414" y2="235" />
          </g>
          <path class="thinking-body" d="M232 125C310 125 371 184 371 258C371 317 334 329 232 329C130 329 93 317 93 258C93 184 154 125 232 125Z" />
          <path class="thinking-shadow" d="M83 327C130 316 334 316 386 327C334 339 132 339 83 327Z" />
          <g class="thinking-eyes">
            <line x1="210" y1="216" x2="210" y2="250" />
            <line x1="257" y1="216" x2="257" y2="250" />
          </g>
        </svg>
      </span>
      ${label ? `<span class="thinking-tool-label">${escapeHtml(label)}</span>` : ""}
    </div>
  `;
}

function startNoonThinkingAnimations(root) {
  root.querySelectorAll(".noon-logo-thinking").forEach((mascot) => {
    if (mascot.dataset.animated === "true") return;
    mascot.dataset.animated = "true";

    const rays = [...mascot.querySelectorAll(".thinking-ray")];
    const eyes = mascot.querySelector(".thinking-eyes");
    if (rays.length !== 9 || !eyes || matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const lookAt = (index) => {
      if (index < 0) {
        eyes.style.setProperty("--eye-x", "0px");
        eyes.style.setProperty("--eye-y", "0px");
        return;
      }
      const ray = rays[index];
      const targetX = (Number(ray.getAttribute("x1")) + Number(ray.getAttribute("x2"))) / 2;
      const targetY = (Number(ray.getAttribute("y1")) + Number(ray.getAttribute("y2"))) / 2;
      const dx = targetX - 232;
      const dy = targetY - 225;
      const distance = Math.hypot(dx, dy) || 1;
      eyes.style.setProperty("--eye-x", `${(dx / distance) * 17}px`);
      eyes.style.setProperty("--eye-y", `${(dy / distance) * 13}px`);
    };

    let second = 0;
    const advance = () => {
      if (!mascot.isConnected) return false;
      second = (second + 1) % 20;

      if (second >= 1 && second <= 9) {
        const index = second - 1;
        rays[index].classList.add("hidden");
        lookAt(index);
      } else if (second >= 10 && second <= 18) {
        const index = 18 - second;
        rays[index].classList.remove("hidden");
        lookAt(index);
      } else if (second === 19) {
        lookAt(-1);
      } else {
        rays.forEach((ray) => ray.classList.remove("hidden"));
        lookAt(-1);
      }
      return true;
    };

    const timer = setInterval(() => {
      if (!advance()) clearInterval(timer);
    }, 500);
  });
}

function renderMessageAttachments(attachments) {
  if (!Array.isArray(attachments) || attachments.length === 0) return "";

  return `
    <div class="message-attachments">
      ${attachments.map((attachment) => `
        <div class="message-attachment">
          <span class="attachment-icon">${escapeHtml(fileKindLabel(attachment))}</span>
          <span>
            <span class="attachment-name">${escapeHtml(attachment.name || "未命名文件")}</span>
            <span class="attachment-meta">${escapeHtml(formatFileSize(attachment.size || 0))}</span>
          </span>
        </div>
      `).join("")}
    </div>
  `;
}

function renderAssistantActions(message) {
  const messageId = message.id;
  const feedback = message.feedback || "";
  return `
    <div class="message-actions">
      <button class="icon-action" type="button" data-copy="${messageId}" aria-label="复制" title="复制">
        <img class="action-icon-img" src="./action-copy-icon.png" alt="" aria-hidden="true" />
      </button>
      <button class="icon-action feedback-action ${feedback === "like" ? "active" : ""}" type="button" data-feedback="like" data-feedback-message="${messageId}" aria-label="赞" title="赞" aria-pressed="${feedback === "like"}">
        <img class="action-icon-img" src="${feedback === "like" ? "./action-like-active-icon.png" : "./action-like-icon.png"}" alt="" aria-hidden="true" />
      </button>
      <button class="icon-action feedback-action ${feedback === "dislike" ? "active" : ""}" type="button" data-feedback="dislike" data-feedback-message="${messageId}" aria-label="踩" title="踩" aria-pressed="${feedback === "dislike"}">
        <img class="action-icon-img" src="${feedback === "dislike" ? "./action-dislike-active-icon.png" : "./action-dislike-icon.png"}" alt="" aria-hidden="true" />
      </button>
      <button class="icon-action" type="button" aria-label="分享" title="分享">
        <img class="action-icon-img" src="./action-share-icon.png" alt="" aria-hidden="true" />
      </button>
      <button class="icon-action" type="button" data-regenerate="${messageId}" aria-label="重新生成" title="重新生成">
        <img class="action-icon-img" src="./action-regenerate-icon.png" alt="" aria-hidden="true" />
      </button>
      <button class="icon-action" type="button" aria-label="更多" title="更多">
        <img class="action-icon-img" src="./tools-more-icon.png" alt="" aria-hidden="true" />
      </button>
    </div>
  `;
}

function toggleAssistantFeedback(messageId, feedback) {
  if (!["like", "dislike"].includes(feedback)) return;
  const session = getActiveSession();
  const message = session.messages.find((item) => item.id === messageId);
  if (!message || message.role !== "assistant") return;

  if (message.feedback && message.feedback !== feedback) return;
  message.feedback = message.feedback === feedback ? "" : feedback;
  session.updatedAt = Date.now();
  saveState();
  updateAssistantFeedbackButtons(messageId, message.feedback || "");
}

function updateAssistantFeedbackButtons(messageId, feedback) {
  const article = els.messageScroll.querySelector(`.message.assistant[data-message-id="${messageId}"]`);
  if (!article) return;

  article.querySelectorAll("[data-feedback]").forEach((button) => {
    const isActive = button.dataset.feedback === feedback;
    const type = button.dataset.feedback;
    const icon = button.querySelector(".action-icon-img");

    button.classList.toggle("active", isActive);
    button.setAttribute("aria-pressed", String(isActive));
    if (icon && type === "like") {
      icon.src = isActive ? "./action-like-active-icon.png" : "./action-like-icon.png";
    }
    if (icon && type === "dislike") {
      icon.src = isActive ? "./action-dislike-active-icon.png" : "./action-dislike-icon.png";
    }
  });
}

function startEditingUserMessage(messageId) {
  if (isStreaming) return;
  const message = getActiveSession().messages.find((item) => item.id === messageId);
  if (!message || message.role !== "user") return;
  editingUserMessageId = messageId;
  renderMessages();
  requestAnimationFrame(() => {
    const input = els.messageScroll.querySelector(`[data-edit-input="${messageId}"]`);
    if (!input) return;
    input.focus();
    input.setSelectionRange(input.value.length, input.value.length);
    resizeUserEditInput(input);
  });
}

function cancelEditingUserMessage() {
  if (!editingUserMessageId) return;
  editingUserMessageId = "";
  renderMessages();
}

function resizeUserEditInput(input) {
  input.style.height = "auto";
  input.style.height = `${Math.min(220, input.scrollHeight)}px`;
}

async function editAndResubmitUserMessage(messageId, content) {
  if (isStreaming) return;
  const session = getActiveSession();
  const messageIndex = session.messages.findIndex((message) => message.id === messageId);
  const message = session.messages[messageIndex];
  const nextContent = content.trim();
  if (messageIndex < 0 || message?.role !== "user" || !nextContent) return;

  message.content = nextContent;
  message.updatedAt = Date.now();
  message.attachmentContext = "";
  message.webContext = "";
  message.webSources = [];
  session.messages = session.messages.slice(0, messageIndex + 1);
  session.updatedAt = Date.now();
  editingUserMessageId = "";
  saveState();
  renderMessages();
  renderSessions();

  await requestAssistantResponse(session, {
    [message.id]: (message.attachments || []).map(requestAttachment)
  });
}

function openReferencesPanel(messageId) {
  const sources = findMessageSources(messageId);

  els.referencesEmpty.hidden = sources.length > 0;
  els.referencesList.innerHTML = sources
    .map((source) => `
      <a class="reference-card" href="${escapeHtml(source.url || "#")}" target="_blank" rel="noreferrer">
        <span class="reference-domain">${escapeHtml(source.domain || domainFromUrl(source.url) || "网页")}</span>
        <strong>${escapeHtml(source.title || "未命名网页")}</strong>
        <span>${escapeHtml(source.snippet || source.excerpt || "点击打开网页查看详情。")}</span>
      </a>
    `)
    .join("");

  els.referencesPanel.hidden = false;
  els.chatPanel.classList.add("references-open");
}

function findMessageSources(messageId) {
  const session = getActiveSession();
  const messageIndex = session.messages.findIndex((item) => item.id === messageId);
  const message = session.messages[messageIndex];
  if (Array.isArray(message?.webSources) && message.webSources.length) {
    return message.webSources;
  }

  for (let index = messageIndex - 1; index >= 0; index -= 1) {
    const previous = session.messages[index];
    if (Array.isArray(previous?.webSources) && previous.webSources.length) {
      return previous.webSources;
    }
    if (previous?.role === "assistant") break;
  }

  return [];
}

function closeReferencesPanel() {
  els.referencesPanel.hidden = true;
  els.chatPanel.classList.remove("references-open");
}

function domainFromUrl(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

function publicAttachment(attachment) {
  const item = {
    id: attachment.id,
    name: attachment.name,
    type: attachment.type,
    size: attachment.size,
    kind: fileKindLabel(attachment),
    storageId: attachment.storageId || "",
    url: attachment.url || ""
  };
  if (isImageAttachment(attachment) && attachment.dataUrl) {
    item.dataUrl = attachment.dataUrl;
  }
  return item;
}

function requestAttachment(attachment) {
  return {
    id: attachment.id,
    name: attachment.name,
    type: attachment.type,
    size: attachment.size,
    dataUrl: attachment.dataUrl,
    storageId: attachment.storageId || "",
    url: attachment.url || ""
  };
}

function mergeMessageAttachments(currentAttachments, incomingAttachments) {
  if (!Array.isArray(incomingAttachments)) return currentAttachments;
  const currentById = new Map((Array.isArray(currentAttachments) ? currentAttachments : []).map((attachment) => [attachment.id, attachment]));
  return incomingAttachments.map((attachment) => {
    const current = currentById.get(attachment.id) || {};
    return {
      ...current,
      ...attachment,
      dataUrl: attachment.dataUrl || current.dataUrl || ""
    };
  });
}

function fileKindLabel(file) {
  const name = String(file?.name || "").toLowerCase();
  const type = String(file?.type || "");
  if (type.startsWith("image/")) return "图";
  if (type.startsWith("video/")) return "视";
  if (name.endsWith(".pdf") || type.includes("pdf")) return "PDF";
  if (name.endsWith(".doc") || name.endsWith(".docx")) return "DOC";
  if (name.endsWith(".ppt") || name.endsWith(".pptx")) return "PPT";
  if (name.endsWith(".xls") || name.endsWith(".xlsx") || name.endsWith(".csv")) return "表";
  if (name.endsWith(".json")) return "{}";
  if (type.startsWith("text/") || name.endsWith(".txt") || name.endsWith(".md")) return "文";
  return "FILE";
}

function isImageAttachment(file) {
  return String(file?.type || "").startsWith("image/");
}

function fileFormatLabel(file) {
  const name = String(file?.name || "").toLowerCase();
  const type = String(file?.type || "");
  if (type.startsWith("video/")) return "视频";
  if (name.endsWith(".pdf") || type.includes("pdf")) return "PDF";
  if (name.endsWith(".doc") || name.endsWith(".docx")) return "Word 文档";
  if (name.endsWith(".ppt") || name.endsWith(".pptx")) return "演示文稿";
  if (name.endsWith(".xls") || name.endsWith(".xlsx") || name.endsWith(".csv")) return "电子表格";
  if (name.endsWith(".json")) return "JSON";
  if (type.startsWith("text/") || name.endsWith(".txt") || name.endsWith(".md")) return "文本";
  return "文件";
}

function fileIconClass(file) {
  const name = String(file?.name || "").toLowerCase();
  const type = String(file?.type || "");
  if (name.endsWith(".xls") || name.endsWith(".xlsx") || name.endsWith(".csv")) return "sheet";
  if (name.endsWith(".pdf") || type.includes("pdf")) return "pdf";
  if (name.endsWith(".doc") || name.endsWith(".docx")) return "doc";
  if (name.endsWith(".ppt") || name.endsWith(".pptx")) return "deck";
  if (type.startsWith("video/")) return "video";
  return "generic";
}

function fileIconMarkup(file) {
  const iconClass = fileIconClass(file);
  if (iconClass === "sheet") {
    return `
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <rect x="5" y="4" width="14" height="16" rx="3" />
        <path d="M5 10h14M10 10v10" />
      </svg>
    `;
  }
  if (iconClass === "video") {
    return `
      <svg viewBox="0 0 24 24" aria-hidden="true">
        <rect x="4" y="6" width="12" height="12" rx="3" />
        <path d="m16 10 4-2.3v8.6L16 14" />
      </svg>
    `;
  }
  return `
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M7 3.5h7l4 4V20a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 6 20V5a1.5 1.5 0 0 1 1-1.5Z" />
      <path d="M14 3.5V8h4" />
    </svg>
  `;
}

function inferMimeType(name) {
  const lower = String(name || "").toLowerCase();
  if (lower.endsWith(".pdf")) return "application/pdf";
  if (lower.endsWith(".docx")) return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
  if (lower.endsWith(".pptx")) return "application/vnd.openxmlformats-officedocument.presentationml.presentation";
  if (lower.endsWith(".xlsx")) return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  if (lower.endsWith(".csv")) return "text/csv";
  if (lower.endsWith(".json")) return "application/json";
  if (lower.endsWith(".md")) return "text/markdown";
  if (lower.endsWith(".txt")) return "text/plain";
  return "application/octet-stream";
}

function formatFileSize(bytes) {
  const size = Number(bytes) || 0;
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(size < 10 * 1024 ? 1 : 0)} KB`;
  return `${(size / 1024 / 1024).toFixed(size < 10 * 1024 * 1024 ? 1 : 0)} MB`;
}

function formatThinkingTime(message) {
  const startedAt = message.startedAt || message.createdAt || Date.now();
  const finishedAt = message.finishedAt || (message.streaming ? Date.now() : startedAt + 1000);
  const seconds = Math.max(1, Math.round((finishedAt - startedAt) / 1000));
  return seconds < 60 ? `${seconds}秒` : `${Math.round(seconds / 60)}分钟`;
}

function renderMarkdown(text) {
  const safe = escapeHtml(text);
  const blocks = safe.split(/```/);

  return blocks
    .map((block, index) => {
      if (index % 2 === 1) {
        const lines = block.replace(/^\w+\n/, "");
        return `<pre><code>${lines}</code></pre>`;
      }

      return block
        .split(/\n{2,}/)
        .map((paragraph) => {
          const formatted = paragraph
            .replace(/\[video\]\(([^)]+)\)/g, (_, src) => renderGeneratedVideo(src))
            .replace(/!\[([^\]]*)\]\(([^)]+)\)/g, (_, alt, src) => renderGeneratedImage(alt, src))
            .replace(/`([^`]+)`/g, "<code>$1</code>")
            .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
            .replace(/\n/g, "<br />");
          return `<p>${formatted}</p>`;
        })
        .join("");
    })
    .join("");
}

function renderGeneratedImage(alt, src) {
  const resolvedSrc = normalizeGeneratedImageUrl(src);
  const downloadName = generatedImageDownloadName(resolvedSrc);
  return `
    <span class="generated-image-wrap">
      <img class="generated-image" alt="${alt}" src="${resolvedSrc}" />
      <a class="generated-image-download" href="${resolvedSrc}" download="${downloadName}" data-download-image data-download-name="${downloadName}" aria-label="下载原图">
        <img src="./generated-image-download-icon.png" alt="" aria-hidden="true" />
      </a>
    </span>
  `;
}

function renderGeneratedVideo(src) {
  const resolvedSrc = normalizeGeneratedVideoUrl(src);
  return `
    <span class="generated-video-wrap">
      <video class="generated-video" src="${resolvedSrc}" controls playsinline preload="metadata"></video>
      <a class="generated-video-download" href="${resolvedSrc}" download="noonai-sora-video.mp4">下载视频</a>
    </span>
  `;
}

function normalizeGeneratedImageUrl(src) {
  const value = String(src || "").trim();
  if (window.location.protocol === "file:" && value.startsWith("/api/generated-images/")) {
    return `${API_BASE}${value}`;
  }
  return value;
}

function normalizeGeneratedVideoUrl(src) {
  const value = String(src || "").trim();
  if (window.location.protocol === "file:" && value.startsWith("/api/generated-videos/")) {
    return `${API_BASE}${value}`;
  }
  return value;
}

async function downloadGeneratedImage(src, filename) {
  if (!src) return;

  if (src.startsWith("data:")) {
    triggerDownload(src, filename);
    return;
  }

  try {
    const response = await fetch(src);
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const blob = await response.blob();
    const objectUrl = URL.createObjectURL(blob);
    triggerDownload(objectUrl, filenameFromBlob(filename, blob));
    setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
  } catch {
    triggerDownload(src, filename);
  }
}

function triggerDownload(href, filename) {
  const link = document.createElement("a");
  link.href = href;
  link.download = filename || "noonai-generated-image.png";
  link.rel = "noreferrer";
  document.body.appendChild(link);
  link.click();
  link.remove();
}

function generatedImageDownloadName(src) {
  return `noonai-generated-image.${imageExtensionFromSrc(src)}`;
}

function filenameFromBlob(filename, blob) {
  const extension = imageExtensionFromMime(blob?.type || "");
  if (!extension) return filename;
  return filename.replace(/\.[a-z0-9]+$/i, `.${extension}`);
}

function imageExtensionFromSrc(src) {
  const dataMatch = String(src || "").match(/^data:image\/([a-z0-9.+-]+);/i);
  if (dataMatch) return normalizeImageExtension(dataMatch[1]);
  const pathMatch = String(src || "").match(/\.([a-z0-9]+)(?:[?#].*)?$/i);
  return normalizeImageExtension(pathMatch?.[1] || "png");
}

function imageExtensionFromMime(mime) {
  const match = String(mime || "").match(/^image\/([a-z0-9.+-]+)$/i);
  return match ? normalizeImageExtension(match[1]) : "";
}

function normalizeImageExtension(value) {
  const lower = String(value || "").toLowerCase();
  if (lower === "jpeg" || lower === "pjpeg") return "jpg";
  if (lower === "svg+xml") return "svg";
  if (["png", "jpg", "webp", "gif", "bmp", "svg"].includes(lower)) return lower;
  return "png";
}

function createSession(append = true, options = {}) {
  const session = {
    id: createId(),
    title: options.temporary ? "临时聊天" : "新的对话",
    model: "gpt-5.4",
    reasoningEffort: "high",
    deepseekThinking: true,
    pinned: false,
    temporary: Boolean(options.temporary),
    createdAt: Date.now(),
    updatedAt: Date.now(),
    messages: []
  };

  if (append) {
    state.sessions.unshift(session);
  }

  return session;
}

function getActiveSession() {
  let session = state.sessions.find((item) => item.id === activeSessionId);
  if (!session) {
    if (temporarySession?.id === activeSessionId) {
      session = temporarySession;
    } else if (draftSession?.id === activeSessionId) {
      session = draftSession;
    } else {
      session = createSession(false);
      draftSession = session;
      activeSessionId = session.id;
    }
  }
  state.activeSessionId = activeSessionId;
  return session;
}

function ensureSessionRecorded(session) {
  if (!session || session.messages.length === 0) return;
  if (session.temporary) {
    activeSessionId = session.id;
    state.activeSessionId = activeSessionId;
    return;
  }

  if (!state.sessions.some((item) => item.id === session.id)) {
    state.sessions.unshift(session);
  }

  if (draftSession?.id === session.id) {
    draftSession = null;
  }

  if (session.title === "新的对话") {
    session.title = makeTitle(session.messages[0]?.content || "");
  }

  activeSessionId = session.id;
  state.activeSessionId = activeSessionId;
}

function getFirstRecordedSession() {
  const recorded = state.sessions.find((session) => session.messages.length > 0);
  if (recorded) return recorded;

  draftSession = createSession(false);
  activeSessionId = draftSession.id;
  return draftSession;
}

function loadUserProfile() {
  try {
    return normalizeProfile(JSON.parse(localStorage.getItem(userStorageKey(PROFILE_KEY)) || "{}"));
  } catch {
    localStorage.removeItem(userStorageKey(PROFILE_KEY));
    return normalizeProfile({});
  }
}

function loadSettings() {
  try {
    const storedSettings = localStorage.getItem(userStorageKey(SETTINGS_KEY));
    if (storedSettings) {
      const parsedSettings = JSON.parse(storedSettings);
      const storedAppearance = localStorage.getItem(APPEARANCE_MODE_KEY);
      if (["system", "dark", "light"].includes(storedAppearance)) parsedSettings.appearance = storedAppearance;
      else if (localStorage.getItem(APPEARANCE_MIGRATION_KEY) !== "1") parsedSettings.appearance = "system";
      return normalizeSettings(parsedSettings);
    }
    const storedAppearance = localStorage.getItem(APPEARANCE_MODE_KEY);
    return normalizeSettings({ appearance: storedAppearance });
  } catch {
    localStorage.removeItem(userStorageKey(SETTINGS_KEY));
    return normalizeSettings({});
  }
}

function normalizeSettings(settings) {
  const appearance = ["system", "dark", "light"].includes(settings?.appearance) ? settings.appearance : "system";
  const accent = accentColors[settings?.accent] ? settings.accent : "default";
  const language = uiText[settings?.language] ? settings.language : "zh";
  const zoom = ["100", "125", "150", "175", "200"].includes(String(settings?.zoom)) ? String(settings.zoom) : "175";
  return { appearance, accent, language, zoom };
}

function saveSettings() {
  localStorage.setItem(userStorageKey(SETTINGS_KEY), JSON.stringify(appSettings));
  scheduleUserDataSync();
}

function normalizeProfile(profile) {
  return {
    displayName: String(profile?.displayName || "User").trim() || "User",
    username: String(currentUser?.phone || profile?.username || "").trim(),
    avatar: typeof profile?.avatar === "string" ? profile.avatar : ""
  };
}

function loadState() {
  try {
    const parsed = JSON.parse(localStorage.getItem(userStorageKey(STORAGE_KEY)) || "{}");
    if (Array.isArray(parsed.sessions) && parsed.sessions.length) {
      return normalizeState(parsed);
    }
  } catch {
    localStorage.removeItem(userStorageKey(STORAGE_KEY));
  }

  return { sessions: [] };
}

function normalizeState(rawState) {
  rawState.sessions = rawState.sessions
    .map((session) => ({
      ...session,
      title: session.title || "新的对话",
      model: normalizeModelValue(session.model),
      reasoningEffort: normalizeReasoningValue(session.reasoningEffort),
      deepseekThinking: typeof session.deepseekThinking === "boolean" ? session.deepseekThinking : true,
      pinned: Boolean(session.pinned),
      messages: normalizeStoredMessages(session.messages)
    }))
    .filter((session) => session.messages.length > 0);
  return rawState;
}

function normalizeStoredMessages(messages) {
  if (!Array.isArray(messages)) return [];

  return messages
    .filter((message) => !isStaleApiKeyError(message))
    .map((message) => {
      if (message.role === "assistant" && message.streaming && !isStreaming) {
        return {
          ...message,
          content: message.content && message.content !== "正在生成图片..." ? message.content : "任务已停止",
          streaming: false,
          finishing: false,
          stopped: true,
          reveal: true,
          finishedAt: Date.now()
        };
      }
      if (message.role === "assistant" && !message.streaming && !message.finishedAt) {
        return {
          ...message,
          finishedAt: (message.startedAt || message.createdAt || Date.now()) + 1000
        };
      }
      return message;
    });
}

function isStaleApiKeyError(message) {
  const content = String(message?.content || "");
  return message?.role === "assistant"
    && (
      content.includes("OPENAI_API_KEY is not configured")
      || content.includes("API_KEY is not configured")
      || content.includes("is not configured on the server")
    );
}

function normalizeReasoningValue(value) {
  return reasoningLabels[value] ? value : "high";
}

function normalizeModelValue(value) {
  return chatModelLabels[value] ? value : "gpt-5.4";
}

function isDeepseekModel(value) {
  return normalizeModelValue(value) === "deepseek-v4-pro";
}

function normalizeImageModelValue(value) {
  return imageModelLabels[value] ? value : "gpt-image-2";
}

function normalizeVideoModelValue(value) {
  return videoModelLabels[value] ? value : "sora-2";
}

function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

function saveState() {
  state.activeSessionId = activeSessionId;
  try {
    localStorage.setItem(userStorageKey(STORAGE_KEY), JSON.stringify(state));
  } catch (error) {
    console.warn("Conversation cache is full; server sync will continue.", error);
  }
  scheduleUserDataSync();
}

function userStorageKey(baseKey) {
  return currentUser?.id ? `${baseKey}.${currentUser.id}` : baseKey;
}

function persistUserDataLocally() {
  try {
    localStorage.setItem(userStorageKey(STORAGE_KEY), JSON.stringify(state));
    localStorage.setItem(userStorageKey(PROFILE_KEY), JSON.stringify(userProfile));
    localStorage.setItem(userStorageKey(SETTINGS_KEY), JSON.stringify(appSettings));
  } catch (error) {
    console.warn("User data local cache is full; server sync will continue.", error);
  }
}

function scheduleUserDataSync() {
  if (!currentUser || !appStarted) return;
  clearTimeout(userDataSyncTimer);
  userDataSyncTimer = setTimeout(syncUserDataNow, 600);
}

async function syncUserDataNow(options = {}) {
  if (!currentUser) return;
  clearTimeout(userDataSyncTimer);
  userDataSyncTimer = null;
  persistUserDataLocally();
  try {
    const response = await authFetch("/api/user-data", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        state,
        profile: userProfile,
        settings: appSettings,
        ...(options.allowProfileReset ? { allowProfileReset: true } : {})
      })
    });
    if (response.status === 401) {
      console.warn("User data sync was not authorized; the next authenticated action will retry.");
    }
  } catch {
    // Keep the user-specific local copy and retry after the next change.
  }
}

function makeTitle(prompt) {
  return prompt.replace(/\s+/g, " ").slice(0, 28) || "新的对话";
}

function resizeTextarea() {
  const value = els.promptInput.value;
  const lineCount = value ? value.split("\n").length : 1;
  const shouldExpandByContent = lineCount > 1 || value.length > 72;

  els.composer.classList.remove("expanded");
  els.promptInput.style.height = "auto";
  const collapsedHeight = els.promptInput.scrollHeight;
  const isExpanded = activeMode !== "image"
    && activeMode !== "video"
    && activeMode !== "web"
    && (shouldExpandByContent || collapsedHeight > 52);

  els.composer.classList.toggle("expanded", isExpanded);
  els.promptInput.style.height = "auto";
  const resizedHeight = els.promptInput.scrollHeight;
  els.promptInput.style.height = `${Math.min(isExpanded ? 220 : 48, resizedHeight)}px`;
}

function scrollToBottom() {
  requestAnimationFrame(() => {
    els.messageScroll.scrollTop = els.messageScroll.scrollHeight;
  });
}

function focusComposer() {
  requestAnimationFrame(() => els.promptInput.focus());
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function toggleSidebar() {
  if (els.sidebar.classList.contains("open")) {
    closeSidebar();
    return;
  }
  openSidebar();
}

function openSidebar() {
  els.sidebar.classList.add("open");
  els.overlay.classList.add("open");
  renderRailNavigationState();
}

function closeSidebar() {
  els.sidebar.classList.remove("open");
  els.overlay.classList.remove("open");
  activeRailPanel = "";
  renderRailNavigationState();
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

async function checkHealth() {
  const text = currentText();
  try {
    const response = await fetch(`${API_BASE}/api/health`);
    const health = await response.json();
    els.connectionStatus.textContent = health.hasApiKey
      ? text.serverConnected
      : text.serverNeedsKey;
  } catch {
    els.connectionStatus.textContent = window.location.protocol === "file:"
      ? text.fileNeedsServer
      : text.serverError;
  }
}
