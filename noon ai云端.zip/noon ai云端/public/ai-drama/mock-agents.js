const uid = (prefix) => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
const wait = (ms = 450) => new Promise((resolve) => setTimeout(resolve, ms));

export const STYLES = [
  { id: "韩漫都市风", tag: "热门", desc: "适合甜宠、霸总、逆袭", colors: ["#ffb6c8", "#775bf5"] },
  { id: "国漫二次元", tag: "热血", desc: "适合校园、幻想、成长", colors: ["#70d7ff", "#4055d8"] },
  { id: "日漫清新风", tag: "清新", desc: "适合青春、校园、日常", colors: ["#b6efd2", "#70a9ff"] },
  { id: "黑白线条风", tag: "低成本", desc: "适合悬疑、独白、简洁叙事", colors: ["#f3f4f6", "#4b5563"] },
  { id: "Q版搞笑风", tag: "轻松", desc: "适合吐槽、日常、表情包", colors: ["#ffe47a", "#ff8e6e"] },
  { id: "古风水墨风", tag: "国风", desc: "适合仙侠、宫斗、古代言情", colors: ["#d8c7a3", "#65766b"] },
  { id: "暗黑悬疑风", tag: "氛围", desc: "适合惊悚、推理、反转", colors: ["#64748b", "#111827"] },
  { id: "赛博未来风", tag: "科幻", desc: "适合 AI、未来城市、冒险", colors: ["#23d5d5", "#6d28d9"] }
];

export const EXAMPLES = [
  {
    id: "romance",
    genre: "甜宠",
    title: "雨夜退婚后我成了商业女王",
    script: "雨夜，林晚被未婚夫当众退婚。所有人都以为她会崩溃离开。三年后，一场顶级商业酒会上，她以集团新任总裁的身份出现。曾经看不起她的人纷纷震惊，而当年退婚的男人终于发现，自己错过的不是一个普通女孩，而是唯一真正爱过他的人。林晚却只是平静举杯，告诉他：迟到的真相，已经换不回从前。"
  },
  {
    id: "mystery",
    genre: "悬疑",
    title: "深夜便利店的第十三位顾客",
    script: "凌晨两点，便利店店员阿辰发现监控里出现了第十三位顾客，可店里明明只有十二个人。当他回放录像时，发现那个顾客每晚都会出现，并且每次都站在同一个货架前。直到某天，他看清那个人的脸，竟然和三年前失踪的自己一模一样。监控中的人抬起头，对着镜头写下：不要让他进来。"
  },
  {
    id: "comedy",
    genre: "搞笑",
    title: "我的 AI 男友太会脑补了",
    script: "小夏下载了一个 AI 陪伴应用，原本只想让它提醒自己喝水。没想到这个 AI 每天都在脑补自己是霸道总裁，不仅帮她写工作报告，还开始吃同事的醋。直到有一天，小夏发现它竟然自动给老板发了一封辞职信，理由是：我的女人不需要加班。更离谱的是，老板回复了一个“批准”。"
  }
];

export const TEMPLATES = [
  ...EXAMPLES.map((item, index) => ({
    ...item,
    style: index === 1 ? "暗黑悬疑风" : index === 2 ? "Q版搞笑风" : "韩漫都市风",
    duration: 60,
    users: ["2.8 万", "1.6 万", "3.2 万"][index]
  })),
  { id: "campus", genre: "校园", title: "校草突然听见了我的心声", script: "转学生苏禾发现，全校最难接近的校草突然对她百依百顺。她不知道的是，从她入学第一天开始，他就能听见她所有心声。", style: "日漫清新风", duration: 60, users: "1.9 万" },
  { id: "fantasy", genre: "玄幻", title: "穿成反派后我选择摆烂", script: "社畜醒来成了注定被主角打败的反派。为了活命，他决定远离剧情，却阴差阳错抢走了主角所有高光。", style: "国漫二次元", duration: 90, users: "2.1 万" },
  { id: "future", genre: "都市", title: "我的 AI 男友觉醒了自我意识", script: "她为了测试新产品创建了一个虚拟男友，却在删除程序的前一晚，收到一条来自现实世界的快递。", style: "赛博未来风", duration: 60, users: "9800" }
];

export function defaultProject(seed = {}) {
  const now = new Date().toISOString();
  return {
    id: seed.id || uid("project"),
    title: seed.title || "未命名漫剧",
    script: seed.script || "",
    genre: seed.genre || "甜宠",
    style: seed.style || "韩漫都市风",
    pace: seed.pace || "标准短剧型",
    aspectRatio: seed.aspectRatio || "9:16",
    duration: Number(seed.duration || 60),
    status: seed.status || "draft",
    progress: seed.progress || 0,
    optimizeScript: seed.optimizeScript ?? true,
    voiceEnabled: seed.voiceEnabled ?? true,
    voiceType: seed.voiceType || "温柔女声",
    characterVoices: seed.characterVoices ?? true,
    voiceSpeed: seed.voiceSpeed || "正常",
    subtitleEnabled: seed.subtitleEnabled ?? true,
    subtitleStyle: seed.subtitleStyle || "短视频大字",
    autoCover: seed.autoCover ?? true,
    autoTitle: seed.autoTitle ?? true,
    bgm: seed.bgm ?? true,
    quality: seed.quality || "standard",
    analysis: seed.analysis || null,
    styleBible: seed.styleBible || null,
    characters: seed.characters || [],
    scenes: seed.scenes || [],
    shots: seed.shots || [],
    assets: seed.assets || [],
    generationSteps: seed.generationSteps || createGenerationSteps(),
    generationLogs: seed.generationLogs || [],
    currentStepId: seed.currentStepId || "",
    canRetry: seed.canRetry ?? false,
    canCancel: seed.canCancel ?? true,
    finalVideoUrl: seed.finalVideoUrl || "",
    qualityReport: seed.qualityReport || null,
    createdAt: seed.createdAt || now,
    updatedAt: now
  };
}

export function createGenerationSteps() {
  return [
    ["script", "AI 编剧", "正在整理剧情结构"],
    ["director", "AI 导演", "正在设计镜头与节奏"],
    ["artist", "AI 画师", "正在绘制角色与场景"],
    ["voice", "AI 配音师", "正在录制旁白和对白"],
    ["subtitle", "字幕 Agent", "正在生成字幕时间轴"],
    ["editor", "AI 剪辑师", "正在合成镜头与动效"],
    ["quality", "AI 质检员", "正在检查角色一致性"]
  ].map(([id, agentName, description]) => ({
    id, name: agentName, agentName, description, status: "waiting", progress: 0, logs: []
  }));
}

export async function analyzeScript(project) {
  await wait();
  const protagonist = project.genre === "悬疑" ? "阿辰" : project.genre === "搞笑" ? "小夏" : "林晚";
  const second = project.genre === "悬疑" ? "神秘顾客" : project.genre === "搞笑" ? "AI 助手" : "顾沉";
  const analysis = {
    summary: project.script.slice(0, 96) + (project.script.length > 96 ? "……" : ""),
    mainPlot: `${protagonist}在突发事件中被迫做出选择，并在身份或真相反转后重新掌握主动。`,
    conflict: project.genre === "悬疑" ? "监控中的异常来客与失踪真相" : "旧关系、现实压力与身份反转",
    emotions: project.genre === "搞笑" ? ["轻松", "意外", "社死", "反转"] : ["压抑", "冲突", "逆转", "悬念"],
    hook: "关键人物说出一句改变所有人理解的话，画面在答案揭晓前结束。",
    suggestedShots: project.duration <= 30 ? 7 : project.duration <= 60 ? 12 : project.duration <= 90 ? 18 : 28,
    scores: { clarity: 86, conflict: 78, character: 82, shortVideo: 90 },
    characters: [
      { id: uid("char"), name: protagonist, role: "protagonist", identity: project.genre === "悬疑" ? "深夜店员" : project.genre === "搞笑" ? "产品经理" : "集团新任总裁", personality: "克制、敏锐、内心坚定", visualKeywords: ["黑色长发", "清冷气质", "有故事感"], needsImage: true, needsVoice: true },
      { id: uid("char"), name: second, role: "supporting", identity: project.genre === "悬疑" ? "身份不明的来客" : project.genre === "搞笑" ? "自我意识过强的 AI" : "旧爱与商业对手", personality: "表面冷静、情绪复杂", visualKeywords: ["深色造型", "锐利眼神"], needsImage: true, needsVoice: true }
    ],
    scenes: [
      { id: uid("scene"), name: project.genre === "悬疑" ? "深夜便利店" : "雨夜街口", description: "故事开场与冲突发生地", mood: "压抑 · 霓虹 · 潮湿", location: "城市", frequency: "高" },
      { id: uid("scene"), name: project.genre === "搞笑" ? "开放办公室" : "灯光璀璨的大厅", description: "身份反转与人物重逢", mood: "明亮 · 紧张 · 戏剧性", location: "室内", frequency: "中" },
      { id: uid("scene"), name: "记忆闪回", description: "补充人物关系与关键信息", mood: "柔和 · 朦胧", location: "回忆", frequency: "低" }
    ],
    pacing: [
      ["0–5 秒", "直接抛出冲突，抓住注意力"],
      ["5–15 秒", "主角受挫，建立人物目标"],
      ["15–30 秒", "时间或身份发生反转"],
      ["30–45 秒", "人物重逢，冲突升级"],
      ["45–60 秒", "揭示半个真相，留下悬念"]
    ]
  };
  return analysis;
}

export async function createStyleBible(project) {
  await wait(240);
  const selected = STYLES.find((item) => item.id === project.style) || STYLES[0];
  return {
    visualStyle: project.style,
    lineStyle: project.style.includes("水墨") ? "写意墨线与留白" : "干净、稳定、人物轮廓清晰",
    colorPalette: selected.colors.join(" / "),
    lighting: "柔和电影光，主体与背景层次明确",
    composition: `${project.aspectRatio} 构图，优先保证人物面部与字幕安全区`,
    mood: project.pace === "爽文快节奏" ? "高对比、强冲突" : "低饱和、情绪递进",
    subtitleStyle: project.subtitleStyle,
    negativePrompt: ["不要改变角色发色", "不要出现乱码", "不要出现真实品牌", "不要模仿知名 IP 或明星"]
  };
}

export async function designCharacters(project, analysis) {
  await wait();
  return analysis.characters.map((item, index) => ({
    ...item,
    age: index ? "26" : "24",
    gender: index ? "男" : "女",
    hairStyle: index ? "利落短发" : "自然微卷长发",
    hairColor: "黑色",
    outfit: index ? "深灰剪裁西装" : "米白衬衫与浅灰外套",
    marker: index ? "银色腕表" : "细银耳饰",
    importance: index ? "主要配角" : "核心主角",
    plotPosition: index ? "制造冲突并推动主角做出选择" : "推动主线并完成关键反转",
    firstEpisode: "第 1 集",
    faceShape: index ? "轮廓分明的长脸" : "柔和鹅蛋脸",
    eyeStyle: index ? "狭长眼型，眼神锐利" : "清晰杏眼，眼神坚定",
    bodyType: index ? "高挑挺拔" : "修长匀称",
    ageLook: "青年",
    outfitColor: index ? "深灰" : "米白与浅灰",
    expressionKeywords: "克制、震惊、释然",
    lockedTraits: ["脸型", "发型", "发色", "主服装色"],
    forbiddenChanges: ["不改变发色", "不改变脸型", "不改变服装主色", "不改变年龄感", "不生成无关人物"],
    referenceImages: [],
    expressionImages: [],
    poseImages: [],
    outfits: [],
    props: [],
    voiceType: index ? "磁性男声" : project.voiceType,
    prompt: `${item.name}，${item.identity}，${item.visualKeywords.join("、")}，${project.style}，保持脸型、发型和服装一致`,
    status: "pending",
    primaryReference: 0
  }));
}

export async function createStoryboard(project) {
  await wait(600);
  const count = project.analysis?.suggestedShots || 12;
  const duration = Math.max(2, Math.round(project.duration / count));
  const scenes = project.scenes.length ? project.scenes : project.analysis.scenes;
  const chars = project.characters;
  const beats = ["冲突突然发生", "主角压住情绪", "关键信息出现", "人物做出决定", "身份发生反转", "旧关系重新碰撞", "真相露出线索", "主角夺回主动", "对方意识到错误", "结尾悬念被抛出"];
  return Array.from({ length: count }, (_, index) => {
    const scene = scenes[index % scenes.length];
    const emotion = index < 2 ? "压抑" : index > count - 3 ? "震惊" : index % 3 === 0 ? "紧张" : "克制";
    return {
      id: uid("shot"),
      order: index + 1,
      sceneId: scene.id,
      sceneName: scene.name,
      duration: index === count - 1 ? Math.max(2, project.duration - duration * (count - 1)) : duration,
      characters: chars.slice(0, index % 4 === 0 ? 1 : 2).map((item) => item.id),
      characterNames: chars.slice(0, index % 4 === 0 ? 1 : 2).map((item) => item.name),
      shotSize: ["远景", "中景", "近景", "特写"][index % 4],
      cameraMotion: ["缓慢推进", "横向平移", "静止", "淡入淡出"][index % 4],
      emotion,
      visualDescription: `${scene.name}，${beats[index % beats.length]}。人物表情${emotion}，画面重点明确。`,
      dialogue: index % 2 ? `“你以为故事已经结束了吗？”` : "",
      narration: index % 2 ? "" : `${beats[index % beats.length]}，所有人的目光都落在主角身上。`,
      prompt: `${project.style}，${scene.name}，${emotion}，${project.aspectRatio}，${["远景", "中景", "近景", "特写"][index % 4]}。${chars.slice(0, index % 4 === 0 ? 1 : 2).map((character) => character.prompts?.inheritance || `${character.name}：保持${character.hairStyle || "发型"}、${character.hairColor || "发色"}、${character.outfit || "默认服装"}一致`).join("；")}。不要改变角色脸型、发型、发色、服装主色；不要生成无关人物、文字、水印或 Logo。`,
      imageUrl: "",
      videoUrl: "",
      status: "pending",
      modified: false
    };
  });
}

export function qualityCheck(project) {
  const issues = [];
  project.shots.forEach((shot) => {
    if (!shot.visualDescription) issues.push({ shotId: shot.id, message: `镜头 ${shot.order} 缺少画面描述` });
    if (!shot.duration) issues.push({ shotId: shot.id, message: `镜头 ${shot.order} 缺少时长` });
  });
  return {
    characterConsistencyScore: 91,
    styleConsistencyScore: 89,
    pacingScore: 86,
    subtitleScore: 93,
    safetyScore: 96,
    issues,
    suggestions: ["第 7 个镜头略长，可缩短 1–2 秒", "结尾钩子清晰，适合连载下一集"]
  };
}

export async function callAgent(endpoint, payload, fallback) {
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok || !result.success) throw new Error(result.error?.message || "服务暂时不可用");
    return result.data;
  } catch {
    return fallback();
  }
}
