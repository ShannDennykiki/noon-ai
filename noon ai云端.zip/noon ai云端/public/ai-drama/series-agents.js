const uid = (prefix) => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
const now = () => new Date().toISOString();

export function estimateEpisodeCount(charCount, density = "标准改编型") {
  const multiplier = density === "剧情压缩型" ? 0.75 : density === "细节保留型" ? 1.3 : 1;
  let count = 1;
  if (charCount > 30000) count = Math.round(28 * multiplier);
  else if (charCount > 10000) count = Math.round(14 * multiplier);
  else if (charCount > 1500) count = Math.round(6 * multiplier);
  return Math.max(1, Math.min(40, count));
}

export function scriptLengthGuide(charCount) {
  if (charCount > 50000) return { type: "danger", text: "当前版本最多支持 5 万字，请拆分为多个系列项目。", range: "超出上限" };
  if (charCount > 30000) return { type: "success", text: "这是一个完整系列剧本，建议拆成 20–40 集制作。", range: "20–40 集" };
  if (charCount > 10000) return { type: "success", text: "这是一个长篇剧本，建议拆成 8–20 集制作。", range: "8–20 集" };
  if (charCount > 1500) return { type: "info", text: "这是一个中篇剧本，建议拆成 3–8 集制作。", range: "3–8 集" };
  if (charCount >= 300) return { type: "info", text: "适合生成 1 集 30–90 秒短漫剧，也可以继续补充为系列故事。", range: "1 集" };
  return { type: "warning", text: "内容较短，建议作为单集短漫剧制作。", range: "1 集" };
}

export function createSeriesProject(seed = {}) {
  const createdAt = now();
  return {
    id: seed.id || uid("series"),
    kind: "series",
    title: seed.title || "未命名连续漫剧",
    originalScript: seed.originalScript || "",
    scriptCharCount: seed.originalScript?.length || 0,
    genre: seed.genre || "都市",
    targetEpisodeDuration: Number(seed.targetEpisodeDuration || 60),
    targetEpisodeCount: seed.targetEpisodeCount || 0,
    splitMode: seed.splitMode || "自动智能分集",
    densityMode: seed.densityMode || "标准改编型",
    style: seed.style || "韩漫都市风",
    pace: seed.pace || "标准短剧型",
    aspectRatio: seed.aspectRatio || "9:16",
    quality: seed.quality || "standard",
    status: seed.status || "draft",
    progress: seed.progress || 0,
    analysis: seed.analysis || null,
    seriesBible: seed.seriesBible || null,
    episodes: seed.episodes || [],
    globalCharacters: seed.globalCharacters || [],
    globalScenes: seed.globalScenes || [],
    plotThreads: seed.plotThreads || [],
    continuityReports: seed.continuityReports || [],
    batchJob: seed.batchJob || null,
    createdAt: seed.createdAt || createdAt,
    updatedAt: createdAt
  };
}

function detectChapterRanges(text) {
  const matches = [...text.matchAll(/(?:^|\n)\s*(第[一二三四五六七八九十百\d]+[章节幕集]|Chapter\s+\d+)[^\n]*/gi)];
  if (!matches.length) return [];
  return matches.map((match, index) => ({
    id: uid("chapter"),
    title: match[0].trim(),
    startChar: match.index,
    endChar: matches[index + 1]?.index || text.length
  }));
}

export function ingestLongScript(series) {
  const normalizedScript = series.originalScript.replace(/\r\n/g, "\n").replace(/[ \t]+\n/g, "\n").replace(/\n{4,}/g, "\n\n\n").trim();
  return {
    normalizedScript,
    charCount: normalizedScript.length,
    detectedChapters: detectChapterRanges(normalizedScript),
    possibleCharacters: ["林晚", "顾承", "沈薇", "周启"],
    possibleScenes: ["雨夜酒店门口", "集团会议室", "顶层办公室", "慈善酒会"],
    warnings: normalizedScript.length < 1500 ? ["文本较短，系列集数可能较少"] : []
  };
}

export function chunkScript(text, size = 3000, overlap = 300) {
  const chunks = [];
  let start = 0;
  while (start < text.length) {
    let end = Math.min(text.length, start + size);
    if (end < text.length) {
      const candidates = [text.lastIndexOf("\n", end), text.lastIndexOf("。", end), text.lastIndexOf("！", end), text.lastIndexOf("？", end)];
      const safeEnd = Math.max(...candidates);
      if (safeEnd > start + size * 0.65) end = safeEnd + 1;
    }
    chunks.push({ id: uid("chunk"), index: chunks.length, startChar: start, endChar: end, text: text.slice(start, end) });
    if (end >= text.length) break;
    start = Math.max(start + 1, end - overlap);
  }
  return chunks;
}

export function analyzeSeries(series) {
  const ingest = ingestLongScript(series);
  const episodeCount = series.targetEpisodeCount || estimateEpisodeCount(ingest.charCount, series.densityMode);
  const characters = [
    ["林晚", "protagonist", "归国集团继承人", "冷静、坚韧、善于隐藏情绪", "找出当年真相并守住家族事业"],
    ["顾承", "main_supporting", "投资集团负责人", "克制、骄傲、内心愧疚", "弥补过去的选择"],
    ["沈薇", "villain", "竞争集团千金", "精明、强势、控制欲强", "阻止女主身份与真相曝光"],
    ["周启", "supporting", "女主助理", "可靠、幽默、观察敏锐", "帮助女主完成商业反击"]
  ].map(([name, role, identity, personality, motivation], index) => ({
    id: uid("gchar"), seriesId: series.id, name, aliases: [], role, identity,
    age: String(24 + index * 2), gender: index === 0 || index === 2 ? "女" : "男",
    personality, motivation, relationshipMap: [],
    appearance: {
      faceShape: index === 0 ? "柔和鹅蛋脸" : "轮廓清晰",
      hairStyle: index === 0 ? "黑色长卷发" : index === 2 ? "栗色长发" : "利落短发",
      hairColor: index === 2 ? "栗色" : "黑色", eyeStyle: "清晰有神",
      outfit: index === 0 ? "米白衬衫、浅灰外套" : index === 2 ? "酒红色套装" : "深色都市正装",
      accessories: index === 0 ? ["紫色耳坠"] : [], colorPalette: index === 0 ? ["#F5F1EA", "#AEB4C1"] : ["#252A34", "#596173"]
    },
    lockedTraits: ["脸型", "发型", "发色", "服装主色"],
    forbiddenChanges: ["不要无剧情理由改变发色", "不要模仿真实明星"],
    voiceProfile: { voiceType: index === 0 ? "温柔女声" : index === 2 ? "冷艳女声" : "磁性男声", speakingStyle: "自然短句", emotionRange: ["克制", "震惊", "坚定"] },
    referenceImages: [], expressionImages: [], firstAppearsInEpisode: index < 2 ? 1 : index + 1,
    appearsInEpisodes: Array.from({ length: Math.max(1, episodeCount - index) }, (_, i) => i + index + 1),
    developmentArc: index === 0 ? "从被动离开到主动揭开真相" : "随主线逐步改变立场",
    currentStatusByEpisode: {}, status: "pending"
  }));
  characters[0].relationshipMap = [
    { targetCharacterId: characters[1].id, relationType: "旧爱", description: "误会、疏离，随后共同追查真相", statusByEpisode: { "1": "决裂", "3": "重新相遇", "6": "发现真相" } },
    { targetCharacterId: characters[2].id, relationType: "竞争对手", description: "商业与情感双重冲突", statusByEpisode: { "2": "正面交锋" } }
  ];
  const scenes = [
    ["雨夜酒店门口", "城市室外", "潮湿、压抑、霓虹反光", true],
    ["集团会议室", "现代办公空间", "冷静、克制、权力感", true],
    ["顶层办公室", "现代办公空间", "低饱和、安静、疏离", true],
    ["慈善酒会大厅", "高端宴会空间", "华丽、紧张、戏剧性", false]
  ].map(([name, locationType, mood, recurring], index) => ({
    id: uid("gscene"), seriesId: series.id, name, locationType,
    description: `${name}是推动关键冲突的重要场景。`, mood,
    visualKeywords: ["电影光", "空间层次明确", recurring ? "固定结构" : "大型人群"],
    colorPalette: index === 0 ? ["#34304D", "#8B7DFF"] : ["#E8E9EE", "#5C6370"],
    recurringProps: recurring ? ["固定灯具", "玻璃门", "主桌位置"] : ["舞台", "香槟塔"],
    firstAppearsInEpisode: index + 1, appearsInEpisodes: [index + 1, index + 3, index + 6].filter((n) => n <= episodeCount),
    referenceImages: [], lockedDetails: recurring ? ["空间结构", "主色调", "固定道具位置"] : ["灯光风格"],
    forbiddenChanges: ["不要无解释改变时代背景"], recurring
  }));
  const threads = [
    ["女主身份反转", "main", 1, Math.min(8, episodeCount), [characters[0].id, characters[1].id]],
    ["当年退婚真相", "mystery", 1, Math.min(10, episodeCount), [characters[0].id, characters[1].id, characters[2].id]],
    ["商业复仇计划", "revenge", 2, Math.min(12, episodeCount), [characters[0].id, characters[2].id]],
    ["旧爱关系修复", "romance", 3, Math.min(episodeCount, 14), [characters[0].id, characters[1].id]]
  ].map(([title, type, startsInEpisode, resolvedInEpisode, relatedCharacters]) => ({
    id: uid("thread"), seriesId: series.id, title,
    description: `${title}贯穿多个单集，并在关键节点推进。`, type,
    status: startsInEpisode === 1 ? "active" : "not_started",
    startsInEpisode, resolvedInEpisode, relatedCharacters,
    relatedScenes: scenes.slice(0, 2).map((item) => item.id), progressByEpisode: {}
  }));
  return {
    ingest, chunks: chunkScript(ingest.normalizedScript), episodeCount,
    logline: "被当众退婚的女孩三年后以集团继承人身份回归，在商业复仇与旧爱真相之间重新选择人生。",
    storySummary: ingest.normalizedScript.slice(0, 420) + (ingest.normalizedScript.length > 420 ? "……" : ""),
    mainPlot: "女主回归后追查家族与退婚真相，同时面对商业对手和旧爱关系。",
    mainConflict: "个人情感、家族秘密与商业利益彼此纠缠。",
    tone: "都市、克制、反转、成长",
    targetAudience: "18–35 岁短视频漫剧观众",
    emotionalArc: "委屈离开 → 隐忍成长 → 强势回归 → 真相撕裂 → 主动和解",
    characters, scenes, plotThreads: threads,
    rhythm: [
      ["开端", "0–12%", "第 1–3 集", "压抑、冲突"],
      ["冲突升级", "12–30%", "第 3–8 集", "紧张、试探"],
      ["第一次反转", "30–45%", "第 8–12 集", "震惊、失控"],
      ["关系破裂", "45–60%", "第 12–17 集", "愤怒、失望"],
      ["真相浮现", "60–78%", "第 17–22 集", "怀疑、悲伤"],
      ["高潮", "78–92%", "第 22–26 集", "爆发、反击"],
      ["结局", "92–100%", "最后 2 集", "释然、新钩子"]
    ]
  };
}

export function buildSeriesBible(series, analysis) {
  const createdAt = now();
  return {
    id: uid("bible"), seriesId: series.id, logline: analysis.logline,
    storySummary: analysis.storySummary, genre: series.genre, tone: analysis.tone,
    targetAudience: analysis.targetAudience, worldSetting: "现代都市商业世界，现实规则为主，不出现超自然能力。",
    timeSetting: "当代，主线包含三年时间跳跃", locationSetting: "沿海一线城市",
    mainConflict: analysis.mainConflict, emotionalArc: analysis.emotionalArc,
    themeKeywords: ["身份反转", "真相", "成长", "选择"],
    visualStyleBible: {
      visualStyle: series.style, lineStyle: "干净精致线条", colorPalette: "低饱和紫灰与暖肤色",
      lighting: "柔和电影光", composition: `${series.aspectRatio} 竖屏人物优先构图`,
      mood: "都市克制感", subtitleStyle: "短视频大字",
      negativePrompt: ["画风突变", "真实品牌", "知名 IP", "明星脸"]
    },
    characterRules: ["主角发型、发色、脸型和服装主色不得随意变化", "角色称呼和身份前后一致"],
    sceneRules: ["常驻场景空间结构不得变化", "重复场景沿用参考图和主色调"],
    continuityRules: [
      "角色关系变化必须遵循上一集结尾", "每集开头承接上一集结尾",
      "每集结尾留下下一集钩子", "已解决误会不能重新作为未解决问题",
      "同一世界观规则不能冲突"
    ],
    forbiddenChanges: ["不要改变主角发色", "不要改变主角服装主色", "不要把现代都市变成古风", "不要让已离开的角色无解释出现", "不要生成知名 IP、明星脸或真实品牌 Logo"],
    createdAt, updatedAt: createdAt
  };
}

const episodeNames = ["雨夜退婚", "她消失了", "三年后归来", "酒会重逢", "身份曝光", "戒指的真相", "办公室对峙", "旧照片", "匿名短信", "第一次反击", "证人失踪", "关系破裂", "秘密股东", "被篡改的合同", "母亲的录音", "真正的幕后人", "最后一场酒会", "迟到的道歉", "主动离开", "新的选择"];

export function planEpisodes(series, analysis) {
  const count = analysis.episodeCount;
  const charsPerEpisode = Math.ceil(series.originalScript.length / count);
  return Array.from({ length: count }, (_, index) => {
    const startChar = index * charsPerEpisode;
    const endChar = Math.min(series.originalScript.length, (index + 1) * charsPerEpisode);
    const title = episodeNames[index % episodeNames.length] + (index >= episodeNames.length ? ` · ${Math.floor(index / episodeNames.length) + 1}` : "");
    const previous = index ? `承接第 ${index} 集结尾：上一条关键线索仍未解释。` : "本集为系列开端";
    const next = index < count - 1 ? `一个新证据把所有人的怀疑引向第 ${index + 2} 集。` : "本季核心冲突暂时解决，同时留下新人物线索。";
    return {
      id: uid("episode"), seriesId: series.id, episodeNumber: index + 1,
      title, sourceRange: { startChar, endChar }, sourceText: series.originalScript.slice(startChar, endChar),
      summary: `本集围绕“${title}”推进主线，主角获得一条关键信息并作出新的选择。`,
      previousEpisodeSummary: previous, nextEpisodeHook: next,
      openingHook: index === 0 ? "婚礼现场，未婚夫突然宣布取消婚约。" : `画面直接承接上一集未解答的关键动作。`,
      coreConflict: index % 3 === 0 ? "身份与关系正面碰撞" : "主角追查真相时遭到新的阻碍",
      emotionalBeat: ["压抑 → 决绝", "试探 → 紧张", "平静 → 震惊"][index % 3],
      endingHook: next,
      involvedCharacters: analysis.characters.slice(0, index % 4 === 0 ? 2 : 3).map((item) => item.id),
      involvedScenes: analysis.scenes.slice(0, index % 3 === 0 ? 1 : 2).map((item) => item.id),
      activePlotThreads: analysis.plotThreads.filter((item) => item.startsInEpisode <= index + 1 && (!item.resolvedInEpisode || item.resolvedInEpisode >= index + 1)).map((item) => item.id),
      targetDuration: series.targetEpisodeDuration,
      estimatedShotCount: series.targetEpisodeDuration <= 60 ? 12 : series.targetEpisodeDuration <= 90 ? 18 : 24,
      shots: [], assets: [], continuityNotes: [previous, next],
      status: "outline_ready", progress: 0, important: index % 5 === 4,
      createdAt: now(), updatedAt: now()
    };
  });
}

export function createEpisodeShots(series, episode) {
  const characters = series.globalCharacters.filter((item) => episode.involvedCharacters.includes(item.id));
  const scenes = series.globalScenes.filter((item) => episode.involvedScenes.includes(item.id));
  return Array.from({ length: episode.estimatedShotCount }, (_, index) => {
    const scene = scenes[index % Math.max(1, scenes.length)] || series.globalScenes[0];
    return {
      id: uid("eshot"), order: index + 1, sceneId: scene?.id, sceneName: scene?.name || "主场景",
      duration: Math.max(2, Math.round(episode.targetDuration / episode.estimatedShotCount)),
      characters: characters.map((item) => item.id), characterNames: characters.map((item) => item.name),
      shotSize: ["远景", "中景", "近景", "特写"][index % 4],
      cameraMotion: ["缓慢推进", "横向平移", "静止", "淡入淡出"][index % 4],
      emotion: ["克制", "紧张", "震惊", "坚定"][index % 4],
      visualDescription: `${scene?.name || "主场景"}，承接系列设定，推进“${episode.title}”的核心冲突。`,
      dialogue: index % 2 ? "“这件事，还远没有结束。”" : "",
      narration: index % 2 ? "" : episode.summary,
      prompt: `${series.seriesBible?.visualStyleBible.visualStyle || series.style}，继承锁定角色与场景，${series.aspectRatio}`,
      status: "pending",
      continuity: {
        characters: characters.map((item) => `${item.name} · 已锁定外貌`),
        scene: `${scene?.name || "主场景"} · ${scene?.lockedDetails?.length ? "已锁定背景" : "待锁定"}`,
        previous: episode.previousEpisodeSummary,
        next: episode.nextEpisodeHook
      }
    };
  });
}

export function checkContinuity(series, episode = null) {
  const number = episode?.episodeNumber || Math.max(1, Math.min(series.episodes.length, 4));
  const issues = [];
  const unlocked = series.globalCharacters.find((item) => item.status !== "locked");
  if (unlocked) issues.push({
    id: uid("issue"), level: "warning", type: "character_appearance", episodeNumber: number,
    title: `${unlocked.name} 的外貌尚未完全锁定`,
    description: "后续集数可能出现发型或服装主色变化。",
    suggestion: "在系列设定书中锁定角色参考图与服装主色。", autoFixAvailable: true
  });
  if (number > 1) issues.push({
    id: uid("issue"), level: "info", type: "missing_context", episodeNumber: number,
    title: `第 ${number} 集开头承接可以更明确`,
    description: `当前开头已引用上一集，但缺少一个视觉动作作为连接。`,
    suggestion: "补充上一集结尾物件或人物动作的特写。", autoFixAvailable: true
  });
  const score = Math.max(70, 96 - issues.length * 4);
  return {
    id: uid("continuity"), seriesId: series.id, episodeId: episode?.id,
    score, characterConsistencyScore: unlocked ? 86 : 96, sceneConsistencyScore: 92,
    plotContinuityScore: 90, emotionContinuityScore: 89, styleConsistencyScore: 94,
    issues, suggestions: ["优先锁定主要角色参考图", "每集开头保留上一集结尾的视觉元素"], createdAt: now()
  };
}
