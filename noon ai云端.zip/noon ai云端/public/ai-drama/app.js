import {
  STYLES, EXAMPLES, TEMPLATES, defaultProject, createGenerationSteps,
  analyzeScript, createStyleBible, designCharacters, createStoryboard,
  qualityCheck, callAgent
} from "./mock-agents.js";
import {
  createSeriesProject, estimateEpisodeCount, scriptLengthGuide, analyzeSeries,
  buildSeriesBible, planEpisodes, createEpisodeShots, checkContinuity
} from "./series-agents.js";
import {
  loadSeriesProjects, saveSeriesProject, deleteSeriesProject, clearSeriesProjects
} from "./series-store.js";

const STORAGE_KEY = "noonai.ai-drama.v1";
const SETTINGS_KEY = "noonai.ai-drama.settings.v1";
const WELCOME_KEY = "noonai.ai-drama.welcome.v1";
const NOON_PROFILE_KEY = "noonai.profile.v1";
const NOON_DEVICE_ACCOUNTS_KEY = "noonai.device-accounts.v1";
const page = document.querySelector("#page");
const shell = document.querySelector("#appShell");
const modalRoot = document.querySelector("#modalRoot");
const toastStack = document.querySelector("#toastStack");
const mainNav = document.querySelector("#mainNav");
const topbarContext = document.querySelector("#topbarContext");
const topbarTitle = document.querySelector("#topbarTitle");
const topbarDescription = document.querySelector("#topbarDescription");
const topbarFlow = document.querySelector("#topbarFlow");
const topSearchWrap = document.querySelector("#topSearchWrap");
const globalSearch = document.querySelector("#globalSearch");
const searchSuggestions = document.querySelector("#searchSuggestions");
const topbarCreate = document.querySelector("#topbarCreate");
const createProjectMenu = document.querySelector("#createProjectMenu");
const workspaceButton = document.querySelector("#workspaceButton");
const workspaceAvatar = document.querySelector("#workspaceAvatar");
const workspaceName = document.querySelector("#workspaceName");
const workspaceMenu = document.querySelector("#workspaceMenu");
const SIDEBAR_COLLAPSE_KEY = "noonai.ai-drama.sidebar-collapsed";
const SIDEBAR_NAV_GROUPS = [
  {
    title: "创作",
    items: [
      { label: "首页", href: "/", icon: "home" },
      { label: "我的项目", href: "/projects", icon: "folder" },
      { label: "新建漫剧", href: "/create", icon: "film" }
    ]
  },
  {
    title: "资源",
    items: [
      { label: "模板中心", href: "/templates", icon: "template" },
      { label: "素材库", href: "/assets", icon: "image" }
    ]
  },
  {
    title: "支持",
    items: [
      { label: "帮助教程", href: "/help", icon: "bulb" },
      { label: "设置", href: "/settings", icon: "settings" }
    ]
  }
];
const NAV_ICON_ASSETS = {
  home: "./assets/nav-home.png",
  folder: "./assets/nav-projects.png",
  film: "./assets/nav-create.png",
  template: "./assets/nav-templates.png",
  image: "./assets/nav-assets.png",
  bulb: "./assets/nav-help.png",
  settings: "../settings-general-icon.png"
};
let generationTimer = 0;
let playbackTimer = 0;
let activeCharacterId = "";
let activeCharacterTab = "base";
let activeShotId = "";
let projectFilter = "all";
let templateFilter = "全部";
let assetFilter = "全部";
let searchTerm = "";
let editorDraft = null;
let playing = false;
let playbackProgress = 0;
let seriesSaveTimer = 0;
let seriesAnalysisTimer = 0;
let batchTimer = 0;
let activeBibleSection = "story";
let visibleEpisodeCount = 10;
let noonAccountIdentity = { displayName: "创作者", phone: "", avatar: "" };

const state = loadState();
const settings = loadSettings();
state.seriesProjects = await loadSeriesProjects();
noonAccountIdentity = await loadNoonAccountIdentity();
renderWorkspaceIdentity();

function loadState() {
  try {
    const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
    return {
      projects: Array.isArray(data.projects) ? data.projects : [],
      currentProjectId: data.currentProjectId || "",
      seriesProjects: [],
      activeSeriesId: data.activeSeriesId || ""
    };
  } catch {
    return { projects: [], currentProjectId: "", seriesProjects: [], activeSeriesId: "" };
  }
}

function loadSettings() {
  try {
    return {
      defaultStyle: "韩漫都市风",
      defaultAspect: "9:16",
      defaultPace: "标准短剧型",
      defaultVoice: "温柔女声",
      defaultSubtitle: "短视频大字",
      quality: "standard",
      safetyCheck: true,
      avoidIp: true,
      avoidRealPeople: true,
      ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || "{}")
    };
  } catch {
    return {};
  }
}

function cachedNoonAccountIdentity() {
  try {
    const accounts = JSON.parse(localStorage.getItem(NOON_DEVICE_ACCOUNTS_KEY) || "[]");
    const account = Array.isArray(accounts)
      ? accounts.filter((item) => item?.id && item?.phone).sort((a, b) => Number(b.lastUsedAt || 0) - Number(a.lastUsedAt || 0))[0]
      : null;
    if (!account) return { displayName: "创作者", phone: "", avatar: "" };
    const profile = JSON.parse(localStorage.getItem(`${NOON_PROFILE_KEY}.${account.id}`) || "{}");
    return {
      displayName: String(profile.displayName || account.displayName || account.phone || "创作者"),
      phone: String(account.phone || profile.username || ""),
      avatar: typeof profile.avatar === "string" ? profile.avatar : ""
    };
  } catch {
    return { displayName: "创作者", phone: "", avatar: "" };
  }
}

async function loadNoonAccountIdentity() {
  const cached = cachedNoonAccountIdentity();
  try {
    const token = sessionStorage.getItem("noonai.session-token") || "";
    const headers = token ? { Authorization: `Bearer ${token}` } : {};
    const response = await fetch("/api/auth/me", { headers, credentials: "same-origin" });
    const payload = await response.json();
    if (!response.ok || !payload.user) return cached;
    return {
      displayName: String(payload.userData?.profile?.displayName || payload.user.phone || cached.displayName),
      phone: String(payload.user.phone || cached.phone),
      avatar: typeof payload.userData?.profile?.avatar === "string" ? payload.userData.profile.avatar : cached.avatar
    };
  } catch {
    return cached;
  }
}

function accountInitials(name) {
  const normalized = String(name || "创作者").trim();
  const ascii = normalized.match(/[A-Za-z0-9]/g);
  if (ascii?.length) return ascii.slice(0, 2).join("").toUpperCase();
  return Array.from(normalized).slice(0, 2).join("");
}

function renderWorkspaceIdentity() {
  const name = noonAccountIdentity.displayName || noonAccountIdentity.phone || "创作者";
  workspaceName.textContent = name;
  workspaceButton.title = `${name} · 本地工作区`;
  workspaceAvatar.textContent = noonAccountIdentity.avatar ? "" : accountInitials(name);
  workspaceAvatar.style.backgroundImage = noonAccountIdentity.avatar ? `url("${noonAccountIdentity.avatar}")` : "";
  workspaceAvatar.classList.toggle("has-image", Boolean(noonAccountIdentity.avatar));
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({
    projects: state.projects,
    currentProjectId: state.currentProjectId,
    activeSeriesId: state.activeSeriesId,
    seriesIndex: state.seriesProjects.map((item) => ({
      id: item.id, title: item.title, status: item.status, progress: item.progress,
      scriptCharCount: item.scriptCharCount, updatedAt: item.updatedAt
    }))
  }));
}

function currentSeries() {
  return state.seriesProjects.find((item) => item.id === state.activeSeriesId) || null;
}

function setCurrentSeries(series) {
  const normalized = createSeriesProject(series);
  const index = state.seriesProjects.findIndex((item) => item.id === normalized.id);
  if (index >= 0) state.seriesProjects[index] = normalized;
  else state.seriesProjects.unshift(normalized);
  state.activeSeriesId = normalized.id;
  saveState();
  scheduleSeriesSave(normalized, 0);
  return normalized;
}

function patchSeries(patch, series = currentSeries(), delay = 500) {
  if (!series) return null;
  Object.assign(series, patch, { updatedAt: new Date().toISOString() });
  saveState();
  scheduleSeriesSave(series, delay);
  return series;
}

function scheduleSeriesSave(series, delay = 900) {
  clearTimeout(seriesSaveTimer);
  if (delay === 0) {
    saveSeriesProject(series).catch(() => toast("长剧本自动保存失败，请稍后重试"));
    return;
  }
  seriesSaveTimer = setTimeout(async () => {
    try {
      await saveSeriesProject(series);
    } catch {
      toast("长剧本自动保存失败，请稍后重试");
    }
  }, delay);
}

function saveSettings() {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

function currentProject() {
  return state.projects.find((item) => item.id === state.currentProjectId) || null;
}

function setCurrent(project) {
  const normalized = defaultProject(project);
  const index = state.projects.findIndex((item) => item.id === normalized.id);
  if (index >= 0) state.projects[index] = normalized;
  else state.projects.unshift(normalized);
  state.currentProjectId = normalized.id;
  saveState();
  return normalized;
}

function patchProject(patch, project = currentProject()) {
  if (!project) return null;
  Object.assign(project, patch, { updatedAt: new Date().toISOString() });
  saveState();
  return project;
}

function routePath() {
  const hash = location.hash.slice(1) || "/";
  return hash.startsWith("/") ? hash : `/${hash}`;
}

function go(path) {
  location.hash = path;
}

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" })[char]);
}

function renderSidebarNavigation() {
  mainNav.innerHTML = SIDEBAR_NAV_GROUPS.map((group) => `<section class="nav-group">
    <div class="nav-group-title">${group.title}</div>
    <div class="nav-group-items">${group.items.map((item) => `<a href="#${item.href}" data-route="${item.href}" title="${item.label}">
      <img class="sidebar-nav-icon ${item.icon === "settings" ? "settings-icon" : ""}" src="${NAV_ICON_ASSETS[item.icon]}" alt="" />
      <span class="sidebar-label">${item.label}</span>
    </a>`).join("")}</div>
  </section>`).join("");
}

function staticTopbarMeta(path) {
  const meta = {
    "/": ["首页", "开始制作你的 AI 漫剧", true],
    "/projects": ["我的项目", "管理你的单集和连续漫剧项目", true],
    "/create": ["创建漫剧", "选择单集、长篇或模板开始创作", false],
    "/templates": ["模板中心", "选择模板，快速开始创作", true],
    "/assets": ["素材库", "管理角色、场景、分镜和音频素材", true],
    "/help": ["帮助教程", "快速了解漫剧制作流程", false],
    "/settings": ["设置", "调整默认生成偏好和工作区设置", false]
  };
  return meta[path] || null;
}

function createFlowMeta(path) {
  const steps = [
    ["/create/script", "剧本"], ["/create/style", "风格"], ["/create/analysis", "分析"],
    ["/create/characters", "角色"], ["/create/storyboard", "分镜"], ["/create/generating", "生成"]
  ];
  const seriesSteps = [
    ["/create/series-script", "剧本导入"], ["/create/series-analysis", "全局分析"],
    ["/create/series-bible", "系列设定"], ["/create/episode-plan", "分集规划"]
  ];
  const list = path.startsWith("/create/series") || path === "/create/episode-plan" ? seriesSteps : steps;
  const activeIndex = list.findIndex(([route]) => route === path);
  if (activeIndex < 0) return null;
  return {
    title: list === seriesSteps ? "创建连续漫剧" : "创建单集漫剧",
    description: `当前步骤：${list[activeIndex][1]}`,
    steps: list.map(([, label], index) => ({ label, state: index < activeIndex ? "done" : index === activeIndex ? "active" : "" }))
  };
}

function dynamicTopbarMeta(path) {
  const flow = createFlowMeta(path);
  if (flow) return { ...flow, showSearch: false };
  if (/^\/project\/[^/]+\/editor$/.test(path)) {
    const project = currentProject();
    const shot = project?.shots.find((item) => item.id === activeShotId) || project?.shots[0];
    return { title: project?.title || "项目编辑器", description: `已保存 · ${project?.shots.length || 0} 个镜头 · ${durationLabel(project?.duration || 0)}`, showSearch: false };
  }
  if (/^\/project\/[^/]+\/export$/.test(path)) {
    const project = currentProject();
    return { title: project?.title || "导出漫剧", description: "检查成片并选择导出规格", showSearch: false };
  }
  if (/^\/series\/[^/]+/.test(path)) {
    const parts = path.split("/").filter(Boolean);
    const series = state.seriesProjects.find((item) => item.id === parts[1]) || currentSeries();
    const episodeId = parts[3] === "episode" ? parts[4] : "";
    const episode = series?.episodes.find((item) => item.id === episodeId);
    if (episode) return { title: `第 ${String(episode.episodeNumber).padStart(2,"0")} 集：${episode.title}`, description: `已保存 · ${episode.shots?.length || 0} 个镜头 · ${episode.targetDuration || 0} 秒`, showSearch: false };
    const completed = series?.episodes.filter((item) => item.status === "completed").length || 0;
    const score = series?.continuityReports?.at(-1)?.score;
    return { title: series?.title || "连续漫剧", description: `${series?.episodes.length || 0} 集 · 已完成 ${completed} 集${score ? ` · 连续性评分 ${score}` : ""}`, showSearch: false };
  }
  const staticMeta = staticTopbarMeta(path) || ["漫剧工厂 AI", "AI 漫剧创作工作区", true];
  return { title: staticMeta[0], description: staticMeta[1], showSearch: staticMeta[2] };
}

function updateTopbar(path) {
  const meta = dynamicTopbarMeta(path);
  topbarTitle.textContent = meta.title;
  topbarDescription.textContent = meta.description;
  topSearchWrap.hidden = !meta.showSearch;
  topbarFlow.hidden = !meta.steps;
  topbarContext.hidden = false;
  if (meta.steps) {
    topbarFlow.innerHTML = meta.steps.map((item) => `<span class="${item.state}">${item.state === "done" ? "✓ " : ""}${item.label}</span>`).join("");
  } else {
    topbarFlow.innerHTML = "";
  }
  globalSearch.placeholder = path === "/projects" ? "搜索项目名称、角色或标签" : "搜索项目、角色或模板";
}

function searchableItems(query = "") {
  const normalized = query.trim().toLowerCase();
  const projects = state.projects.map((item) => ({ type: "项目", title: item.title, detail: `${item.genre} · ${statusText(item.status)}`, path: "/projects" }));
  const characters = state.projects.flatMap((project) => project.characters.map((item) => ({ type: "角色", title: item.name, detail: `${item.identity} · ${project.title}`, path: "/projects" })));
  const templates = TEMPLATES.map((item) => ({ type: "模板", title: item.title, detail: `${item.genre} · ${item.style}`, path: "/templates" }));
  const assets = allAssets().map((item) => ({ type: "素材", title: item.name, detail: `${item.type} · ${item.projectTitle}`, path: "/assets" }));
  const items = [...projects, ...characters, ...templates, ...assets];
  return items.filter((item) => !normalized || `${item.title} ${item.detail} ${item.type}`.toLowerCase().includes(normalized)).slice(0, 6);
}

function renderSearchSuggestions() {
  const items = searchableItems(globalSearch.value);
  searchSuggestions.innerHTML = `<header><span>${globalSearch.value ? "搜索结果" : "快速查找"}</span><span>${items.length} 项</span></header>
    ${items.length ? items.map((item) => `<button class="search-suggestion" data-search-go="${item.path}" type="button">
      <span>${item.type.slice(0,1)}</span><span><strong>${escapeHtml(item.title)}</strong><small>${escapeHtml(item.detail)}</small></span><i>→</i>
    </button>`).join("") : `<div class="asset-empty">没有找到匹配内容</div>`}`;
  searchSuggestions.hidden = false;
}

function startCreateShortcut(mode) {
  createProjectMenu.hidden = true;
  topbarCreate.setAttribute("aria-expanded", "false");
  if (mode === "templates") return go("/templates");
  if (mode === "series") {
    setCurrentSeries(createSeriesProject({
      style: settings.defaultStyle, aspectRatio: settings.defaultAspect,
      pace: settings.defaultPace, quality: settings.quality
    }));
    return go("/create/series-script");
  }
  setCurrent(defaultProject({ title: "未命名漫剧" }));
  return go("/create/script");
}

function formatDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "刚刚" : new Intl.DateTimeFormat("zh-CN", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }).format(date);
}

function statusText(status) {
  return ({ draft: "草稿中", analyzing: "分析中", storyboarding: "分镜中", generating: "生成中", completed: "已完成", failed: "生成失败" })[status] || "草稿中";
}

function durationLabel(seconds) {
  return seconds >= 180 ? `${seconds / 60} 分钟` : `${seconds} 秒`;
}

function shotCountFor(duration) {
  return duration <= 30 ? 7 : duration <= 60 ? 12 : duration <= 90 ? 18 : 28;
}

function stepper(active) {
  const steps = [["script", "剧本"], ["style", "风格"], ["analysis", "分析"], ["characters", "角色"], ["storyboard", "分镜"], ["generating", "生成"]];
  const currentIndex = steps.findIndex(([id]) => id === active);
  return `<div class="stepper-wrap"><div class="stepper">${steps.map(([id, label], index) => `
    <div class="step ${index < currentIndex ? "done" : ""} ${index === currentIndex ? "active" : ""}">
      <i>${index < currentIndex ? "✓" : index + 1}</i><span>${label}</span>
    </div>`).join("")}</div></div>`;
}

function seriesStepper(active) {
  const steps = [["script", "剧本导入"], ["analysis", "全局分析"], ["bible", "系列设定"], ["episodes", "分集规划"], ["production", "单集制作"], ["batch", "批量生成"]];
  const currentIndex = steps.findIndex(([id]) => id === active);
  return `<div class="stepper-wrap"><div class="stepper">${steps.map(([id, label], index) => `
    <div class="step ${index < currentIndex ? "done" : ""} ${index === currentIndex ? "active" : ""}">
      <i>${index < currentIndex ? "✓" : index + 1}</i><span>${label}</span>
    </div>`).join("")}</div></div>`;
}

function ensureSeries() {
  let series = currentSeries();
  if (!series) {
    series = setCurrentSeries(createSeriesProject({
      style: settings.defaultStyle, aspectRatio: settings.defaultAspect,
      pace: settings.defaultPace, quality: settings.quality
    }));
  }
  return series;
}

function seriesStatusText(status) {
  return ({
    draft: "草稿", analyzing: "分析中", bible_ready: "设定已生成",
    episodes_ready: "分集已完成", generating: "制作中",
    partially_completed: "部分完成", completed: "已完成", failed: "失败"
  })[status] || "草稿";
}

function episodeStatusText(status) {
  return ({
    outline_pending: "待规划", outline_ready: "待制作", storyboard_pending: "待分镜",
    storyboard_ready: "分镜已完成", generating: "制作中", completed: "已完成",
    failed: "失败", needs_review: "需要检查"
  })[status] || "待制作";
}

function pageHead(title, description, action = "") {
  return `<header class="page-head"><div><div class="eyebrow">漫剧工厂 AI</div><h1>${title}</h1><p>${description}</p></div>${action}</header>`;
}

function stickyActions(left, right) {
  return `<div class="sticky-actions"><div>${left}</div><div>${right}</div></div>`;
}

function statusBadge(project) {
  return `<span class="status ${project.status}">${statusText(project.status)}</span>`;
}

function projectCard(project) {
  return `<article class="card project-card" data-project-card="${project.id}">
    <div class="project-cover"><span>${escapeHtml(project.genre)} · ${escapeHtml(project.style)}</span></div>
    <div class="project-body">
      <div style="display:flex;align-items:center;gap:8px"><h3 style="flex:1">${escapeHtml(project.title)}</h3>${statusBadge(project)}</div>
      <div class="meta-row"><span>${durationLabel(project.duration)}</span><span>·</span><span>${project.aspectRatio}</span><span>·</span><span>更新于 ${formatDate(project.updatedAt)}</span></div>
      <div class="progress"><span style="width:${project.progress || (project.status === "completed" ? 100 : 8)}%"></span></div>
      <div class="card-actions">
        <button data-project-action="open" data-id="${project.id}">${project.status === "completed" ? "查看成片" : "继续编辑"}</button>
        <button data-project-action="duplicate" data-id="${project.id}">复制</button>
        <button data-project-action="export" data-id="${project.id}">导出</button>
        <button data-project-action="delete" data-id="${project.id}">删除</button>
      </div>
    </div>
  </article>`;
}

function seriesCard(series) {
  const completed = series.episodes.filter((item)=>item.status==="completed").length;
  const report = series.continuityReports.at(-1);
  return `<article class="card project-card series-project-card">
    <div class="project-cover"><span>连续漫剧 · ${series.episodes.length || "待规划"} 集</span><strong class="series-cover-count">${completed}/${series.episodes.length || 0}</strong></div>
    <div class="project-body">
      <div style="display:flex;align-items:center;gap:8px"><h3 style="flex:1">${escapeHtml(series.title)}</h3><span class="status ${series.status}">${seriesStatusText(series.status)}</span></div>
      <div class="meta-row"><span>${series.scriptCharCount.toLocaleString()} 字</span><span>·</span><span>${series.genre}</span><span>·</span><span>连续性 ${report?.score || "—"} 分</span></div>
      <div class="progress"><span style="width:${series.episodes.length ? completed/series.episodes.length*100 : series.progress}%"></span></div>
      <div class="card-actions"><button data-series-action="open" data-id="${series.id}">管理系列</button><button data-series-action="episodes" data-id="${series.id}">查看集数</button><button data-series-action="batch" data-id="${series.id}">批量生成</button><button data-series-action="delete" data-id="${series.id}">删除</button></div>
    </div>
  </article>`;
}

function renderDashboard() {
  const recent = state.projects.slice(0, 3);
  page.innerHTML = `
    <section class="hero card">
      <div class="hero-copy">
        <div class="eyebrow">支持最多 5 万字 · 单集与连续剧双模式</div>
        <h1>一键把剧本变成漫剧</h1>
        <p>AI 自动拆分多集，统一角色形象、场景背景和剧情衔接。</p>
        <div class="button-row"><button class="primary" data-create-mode="series">开始制作长篇漫剧</button><button class="secondary" data-go="/templates">查看分集模板</button></div>
      </div>
    </section>
    <section class="section series-capabilities">
      <header class="capability-heading">
        <div>
          <h2>从长篇理解到跨集一致，AI 管理整部剧</h2>
          <p>复杂能力藏在幕后，你只需要确认系列设定和每集大纲。</p>
        </div>
        <div class="capability-tags" aria-label="核心能力">
          <span>✦ 支持 5 万字长剧本</span>
          <span>✓ 自动拆分 1–40 集</span>
          <span>✓ 跨集角色一致</span>
        </div>
      </header>

      <div class="series-capability-grid">
        <article class="capability-card capability-primary">
          <span class="capability-step">01</span>
          <div class="primary-feature-copy">
            <img class="capability-art capability-art-large" src="./assets/features/script-analysis.png" alt="" />
            <div>
              <h3>长剧本智能拆解</h3>
              <p>阅读最多 5 万字，识别章节、人物和关键反转。</p>
              <small>按剧情节点拆分，不切断重要转折。</small>
            </div>
          </div>
          <div class="script-analysis-panel" aria-label="剧本分析示例">
            <span><b>8</b>识别人物</span>
            <span><b>12</b>关键场景</span>
            <span><b>5</b>剧情线索</span>
            <span><b>24</b>建议集数</span>
          </div>
          <div class="feature-flow"><span>导入剧本</span><i>→</i><span>全局分析</span><i>→</i><span>系列设定</span></div>
        </article>

        <article class="capability-card capability-compact">
          <span class="capability-step">02</span>
          <img class="capability-art" src="./assets/features/episode-planning.png" alt="" />
          <h3>多集自动规划</h3>
          <p>每集都有标题、开头钩子、核心冲突与结尾悬念。</p>
          <div class="episode-timeline" aria-hidden="true"><span>01</span><i></i><span>02</span><i></i><span>03</span><i></i><span>…</span></div>
          <small>支持 1–40 集连续规划</small>
        </article>

        <article class="capability-card capability-compact">
          <span class="capability-step">03</span>
          <img class="capability-art" src="./assets/features/character-lock.png" alt="" />
          <h3>角色形象跨集锁定</h3>
          <p>用系列角色库统一发型、服装、声线和关系变化。</p>
          <div class="character-dots" aria-hidden="true"><i></i><i></i><i></i><span>角色库已锁定</span></div>
          <small>每一集继承同一套角色设定</small>
        </article>

        <article class="capability-card capability-compact">
          <span class="capability-step">04</span>
          <img class="capability-art" src="./assets/features/continuity-check.png" alt="" />
          <h3>剧情连续性检查</h3>
          <p>检查上集承接、人物关系、场景和世界观矛盾。</p>
          <div class="continuity-pill"><b>92%</b><span>连续性良好</span></div>
          <small>输出连续性评分与修复建议</small>
        </article>

        <article class="capability-card capability-compact">
          <span class="capability-step">05</span>
          <img class="capability-art" src="./assets/features/batch-generation.png" alt="" />
          <h3>批量生成漫剧</h3>
          <p>可先做第 1 集、前 3 集，或全部未完成集数。</p>
          <div class="batch-preview"><span><i style="width:72%"></i></span><b>生成中 72%</b></div>
          <small>支持暂停、重试和继续</small>
        </article>

        <article class="capability-card capability-wide">
          <span class="capability-step">06</span>
          <img class="capability-art capability-art-wide" src="./assets/features/series-assets.png" alt="" />
          <div class="wide-feature-copy">
            <h3>系列素材库管理</h3>
            <p>角色、场景、分镜、配音和成片按系列归档，后续集数可直接复用。</p>
            <small>避免重复生成，保持画风和设定统一。</small>
          </div>
          <div class="asset-pills" aria-label="素材分类">
            <span>角色库</span><span>场景库</span><span>分镜图</span><span>配音</span><span>字幕</span><span>成片</span>
          </div>
        </article>
      </div>

      <div class="capability-cta">
        <div><strong>准备好制作连续漫剧了吗？</strong><p>上传长剧本，AI 会先帮你整理成系列设定和分集规划。</p></div>
        <button class="primary" data-create-mode="series">开始制作长篇漫剧</button>
      </div>
    </section>
    <section class="section">
      <div class="section-title"><div><h2>最近项目</h2><p>继续上次的创作，或者从一个新故事开始。</p></div><button class="text-button" data-go="/projects">查看全部 →</button></div>
      ${recent.length ? `<div class="project-grid">${recent.map(projectCard).join("")}</div>` : emptyState("▦", "还没有漫剧项目", "输入一个故事，AI 会帮你生成角色、分镜、配音和成片。", "创建第一个漫剧", "/create")}
    </section>`;
}

function emptyState(icon, title, description, button, path) {
  return `<div class="card empty-state"><div class="empty-icon">${icon}</div><h2>${title}</h2><p>${description}</p><button class="primary" data-go="${path}">${button}</button></div>`;
}

function renderProjects() {
  const filtered = state.projects.filter((item) => {
    const statusMatch = projectFilter === "all" || item.status === projectFilter;
    const text = `${item.title} ${item.genre} ${item.style}`.toLowerCase();
    return statusMatch && text.includes(searchTerm.toLowerCase());
  });
  const filteredSeries = state.seriesProjects.filter((item) => {
    const text = `${item.title} ${item.genre}`.toLowerCase();
    const statusMatch = projectFilter === "all"
      || (projectFilter === "completed" && item.status === "completed")
      || (projectFilter === "generating" && item.status === "generating")
      || (projectFilter === "failed" && item.status === "failed")
      || (projectFilter === "draft" && ["draft","analyzing","bible_ready","episodes_ready","partially_completed"].includes(item.status));
    return statusMatch && text.includes(searchTerm.toLowerCase());
  });
  page.innerHTML = `
    ${pageHead("我的漫剧项目", "查看、编辑和导出你的 AI 漫剧作品。", `<button class="primary" data-go="/create">＋ 新建漫剧</button>`)}
    <div class="filterbar">
      ${[["all","全部"],["draft","草稿中"],["generating","生成中"],["completed","已完成"],["failed","生成失败"]].map(([id,label]) => `<button class="chip ${projectFilter === id ? "active" : ""}" data-project-filter="${id}">${label}</button>`).join("")}
      <label class="field"><input id="projectSearch" value="${escapeHtml(searchTerm)}" placeholder="搜索项目名称、角色、标签" /></label>
    </div>
    ${filteredSeries.length ? `<div class="section-title"><div><h2>连续漫剧系列</h2><p>管理分集、系列设定和批量生成。</p></div></div><div class="project-grid">${filteredSeries.map(seriesCard).join("")}</div>` : ""}
    ${filtered.length ? `<div class="section-title" style="margin-top:28px"><div><h2>单集短漫剧</h2></div></div><div class="project-grid">${filtered.map(projectCard).join("")}</div>` : ""}
    ${!filtered.length && !filteredSeries.length ? emptyState("▦", state.projects.length || state.seriesProjects.length ? "没有找到匹配项目" : "还没有漫剧项目", "创建单集短漫剧，或导入最长 5 万字剧本制作连续漫剧。", "创建第一个漫剧", "/create") : ""}`;
}

function renderCreate() {
  page.innerHTML = `
    ${pageHead("创建新的漫剧", "先选择单集短漫剧或长篇连续漫剧，AI 会使用对应的制作流程。")}
    <div class="choice-grid">
      <button class="choice-card" data-create-mode="script"><div class="feature-icon">✎</div><h2>制作单集短漫剧</h2><p>适合 300–1500 字短剧本，快速生成一条 30–90 秒漫剧。</p><span class="primary small">进入单集流程</span></button>
      <button class="choice-card series-choice" data-create-mode="series"><span class="tag">推荐</span><div class="feature-icon">▦</div><h2>制作长篇连续漫剧</h2><p>适合 1500–50000 字长剧本，AI 自动拆分多集并保持角色与剧情连续。</p><span class="primary small">进入长篇流程</span></button>
      <button class="choice-card" data-go="/templates"><div class="feature-icon">◇</div><h2>从模板开始</h2><p>选择热门漫剧模板，一键套用推荐设置。</p><span class="primary small">浏览模板</span></button>
    </div>
    <div class="notice info" style="margin-top:22px"><strong>不知道选哪个？</strong><br>一个故事只做一条视频，选“单集短漫剧”；小说片段、连续剧情或超过 1500 字，选“长篇连续漫剧”。</div>`;
}

function ensureProject() {
  let project = currentProject();
  if (!project) {
    project = setCurrent(defaultProject({
      style: settings.defaultStyle,
      aspectRatio: settings.defaultAspect,
      pace: settings.defaultPace,
      voiceType: settings.defaultVoice,
      subtitleStyle: settings.defaultSubtitle,
      quality: settings.quality
    }));
  }
  return project;
}

function scriptNotice(length) {
  if (length > 5000) return ["danger", "内容较长，建议拆成多集生成。当前 MVP 建议控制在 5000 字以内。"];
  if (length >= 300) return ["success", "这个长度很适合生成短漫剧，AI 可以直接拆解人物和分镜。"];
  if (length > 0 && length < 50) return ["warning", "内容较短，AI 可能需要自动扩写剧情。建议至少输入 50 字。"];
  return ["info", "推荐字数 300–1500 字。故事越具体，角色和分镜越稳定。"];
}

function renderScript() {
  const project = ensureProject();
  const [noticeType, noticeText] = scriptNotice(project.script.length);
  page.innerHTML = `
    ${stepper("script")}
    ${pageHead("输入你的故事", "粘贴剧本、小说片段或一句话创意。AI 会先理解内容，再进入制作流程。")}
    <div class="wizard-grid">
      <section class="card form-card">
        <div class="form-grid">
          <label class="field span-2"><span>项目名称 *</span><input id="scriptTitle" value="${escapeHtml(project.title === "未命名漫剧" ? "" : project.title)}" placeholder="例如：雨夜重逢的她" /></label>
          <label class="field"><span>剧本类型</span><select id="scriptGenre">${["甜宠","都市","悬疑","玄幻","搞笑","校园","古风","其他"].map((item) => `<option ${project.genre === item ? "selected" : ""}>${item}</option>`).join("")}</select></label>
          <label class="field"><span>目标时长</span><select id="scriptDuration">${[30,60,90,180].map((item) => `<option value="${item}" ${project.duration === item ? "selected" : ""}>${durationLabel(item)}</option>`).join("")}</select></label>
          <label class="textarea-field span-2 script-box">
            <div class="input-topline"><span class="label">剧本内容 *</span><span><b id="scriptCount">${project.script.length}</b> 字 · 预计 ${durationLabel(project.duration)}</span></div>
            <textarea id="scriptContent" placeholder="请在这里粘贴你的剧本、小说片段或故事梗概。&#10;&#10;例如：女主在雨夜被未婚夫退婚，三年后她成为商业女王……">${escapeHtml(project.script)}</textarea>
          </label>
          <div class="notice ${noticeType} span-2" id="scriptNotice">${noticeText}</div>
          <div class="span-2 toggle-row">
            <div class="toggle-copy"><strong>让 AI 自动优化剧情节奏</strong><small>AI 会帮你补充开头钩子、冲突、反转和结尾悬念。</small></div>
            <label class="switch"><input id="optimizeScript" type="checkbox" ${project.optimizeScript ? "checked" : ""}><i></i></label>
          </div>
        </div>
      </section>
      <aside class="card pad">
        <h2>好剧本公式</h2>
        <p class="card-sub">人物 + 目标 + 阻碍 + 反转 + 悬念</p>
        <div class="notice info" style="margin-top:16px">女主被退婚 → 三年后回归 → 男主发现真相 → 她已经不再回头</div>
        <ul class="tip-list"><li>开头 3 秒要有冲突</li><li>人物关系要清楚</li><li>台词尽量短</li><li>每 5–8 秒出现新信息</li><li>结尾最好留下悬念</li></ul>
        <h3>一键填入示例</h3>
        <div class="card-actions">${EXAMPLES.map((item) => `<button data-example="${item.id}">${item.genre}示例</button>`).join("")}</div>
      </aside>
    </div>
    ${stickyActions(`<button class="secondary" data-go="/create">← 返回选择</button><button class="secondary" data-action="save-script">保存草稿</button>`, `<button class="primary" data-action="script-next">下一步：选择画风 →</button>`)}`;
}

function saveScriptForm(showToast = false) {
  const project = ensureProject();
  patchProject({
    title: document.querySelector("#scriptTitle")?.value.trim() || project.title,
    script: document.querySelector("#scriptContent")?.value || project.script,
    genre: document.querySelector("#scriptGenre")?.value || project.genre,
    duration: Number(document.querySelector("#scriptDuration")?.value || project.duration),
    optimizeScript: Boolean(document.querySelector("#optimizeScript")?.checked)
  }, project);
  if (showToast) toast("草稿已保存");
  return project;
}

function renderSeriesScript() {
  const series = ensureSeries();
  const guide = scriptLengthGuide(series.originalScript.length);
  const recommended = estimateEpisodeCount(series.originalScript.length, series.densityMode);
  page.innerHTML = `
    ${seriesStepper("script")}
    ${pageHead("导入长篇剧本", "你可以粘贴小说片段、连续短剧剧本、分镜脚本或故事大纲。AI 会先阅读完整内容，再拆成多集。")}
    <div class="wizard-grid">
      <section class="card form-card">
        <div class="form-grid">
          <label class="field span-2"><span>系列名称 *</span><input id="seriesTitle" value="${escapeHtml(series.title === "未命名连续漫剧" ? "" : series.title)}" placeholder="例如：雨夜归来 · 第一季" /></label>
          <label class="field"><span>剧本类型</span><select id="seriesGenre">${["甜宠","都市","悬疑","玄幻","搞笑","校园","古风","职场","其他"].map((item) => `<option ${series.genre === item ? "selected" : ""}>${item}</option>`).join("")}</select></label>
          <label class="field"><span>单集目标时长</span><select id="seriesDuration">${[30,60,90,180,300].map((item) => `<option value="${item}" ${series.targetEpisodeDuration === item ? "selected" : ""}>${durationLabel(item)}</option>`).join("")}</select></label>
          <label class="field"><span>分集方式</span><select id="seriesSplitMode">${["自动智能分集","按字数平均分集","按剧情节点分集","按章节标题分集","手动分集"].map((item) => `<option ${series.splitMode === item ? "selected" : ""}>${item}</option>`).join("")}</select></label>
          <label class="field"><span>单集节奏密度</span><select id="seriesDensity">${["剧情压缩型","标准改编型","细节保留型"].map((item) => `<option ${series.densityMode === item ? "selected" : ""}>${item}</option>`).join("")}</select></label>
          <label class="field span-2"><span>目标集数（可选）</span><input id="seriesTargetCount" type="number" min="1" max="40" value="${series.targetEpisodeCount || ""}" placeholder="留空则由 AI 推荐" /></label>
          <label class="textarea-field span-2 series-script-box">
            <div class="input-topline"><span class="label">完整剧本 *</span><span><b id="seriesCount">${series.originalScript.length}</b> / 50000 字 · 剩余 <b id="seriesRemaining">${Math.max(0, 50000-series.originalScript.length)}</b> 字</span></div>
            <textarea id="seriesContent" maxlength="50000" placeholder="请粘贴完整长篇剧本。支持章节标题、场景标记、人物对白和故事大纲……">${escapeHtml(series.originalScript)}</textarea>
          </label>
          <div class="notice ${guide.type} span-2" id="seriesNotice">${guide.text}</div>
          <div class="series-estimate span-2">
            <div><strong id="recommendedEpisodes">${series.targetEpisodeCount || recommended}</strong><span>推荐集数</span></div>
            <div><strong id="recommendedDuration">${durationLabel(series.targetEpisodeDuration)}</strong><span>推荐单集时长</span></div>
            <div><strong id="recommendedShots">${(series.targetEpisodeCount || recommended) * shotCountFor(series.targetEpisodeDuration)}</strong><span>预计总镜头</span></div>
          </div>
        </div>
      </section>
      <aside class="card pad">
        <h2>长剧本如何制作成漫剧？</h2>
        <ol class="series-guide">
          <li><strong>阅读全剧</strong><span>AI 理解人物、世界观和主线剧情。</span></li>
          <li><strong>建立系列设定书</strong><span>锁定角色形象和重要场景。</span></li>
          <li><strong>智能拆分多集</strong><span>每集都有开头钩子和结尾悬念。</span></li>
          <li><strong>选择生成范围</strong><span>先做第 1 集，或批量生成前 3 集。</span></li>
          <li><strong>自动继承设定</strong><span>后续集数保持人物、场景和剧情连续。</span></li>
        </ol>
        <div class="notice info"><strong>新手推荐设置</strong><br>自动智能分集 · 60 秒 · 标准改编型 · 先生成前 3 集</div>
        <p class="card-sub" style="margin-top:16px">长剧本文本使用浏览器 IndexedDB 保存，自动保存经过延迟处理，输入时不会频繁卡顿。</p>
      </aside>
    </div>
    ${stickyActions(`<button class="secondary" data-go="/create">← 返回模式选择</button><button class="secondary" data-action="save-series-script">保存草稿</button>`, `<button class="primary" data-action="analyze-series">开始全局分析 →</button>`)}`;
}

function readSeriesScriptForm(showToast = false) {
  const series = ensureSeries();
  const content = document.querySelector("#seriesContent")?.value ?? series.originalScript;
  patchSeries({
    title: document.querySelector("#seriesTitle")?.value.trim() || series.title,
    originalScript: content,
    scriptCharCount: content.length,
    genre: document.querySelector("#seriesGenre")?.value || series.genre,
    targetEpisodeDuration: Number(document.querySelector("#seriesDuration")?.value || series.targetEpisodeDuration),
    splitMode: document.querySelector("#seriesSplitMode")?.value || series.splitMode,
    densityMode: document.querySelector("#seriesDensity")?.value || series.densityMode,
    targetEpisodeCount: Number(document.querySelector("#seriesTargetCount")?.value || 0)
  }, series, 1000);
  if (showToast) toast("长剧本已保存到本地");
  return series;
}

function updateSeriesScriptFeedback() {
  const content = document.querySelector("#seriesContent");
  if (!content) return;
  const count = content.value.length;
  const density = document.querySelector("#seriesDensity")?.value || "标准改编型";
  const customCount = Number(document.querySelector("#seriesTargetCount")?.value || 0);
  const duration = Number(document.querySelector("#seriesDuration")?.value || 60);
  const recommended = customCount || estimateEpisodeCount(count, density);
  const guide = scriptLengthGuide(count);
  document.querySelector("#seriesCount").textContent = count;
  document.querySelector("#seriesRemaining").textContent = Math.max(0, 50000 - count);
  document.querySelector("#seriesNotice").className = `notice ${guide.type} span-2`;
  document.querySelector("#seriesNotice").textContent = guide.text;
  document.querySelector("#recommendedEpisodes").textContent = recommended;
  document.querySelector("#recommendedDuration").textContent = durationLabel(duration);
  document.querySelector("#recommendedShots").textContent = recommended * shotCountFor(duration);
}

async function startSeriesAnalysis() {
  const series = readSeriesScriptForm();
  if (!document.querySelector("#seriesTitle")?.value.trim()) return toast("请先输入系列名称");
  if (series.originalScript.trim().length < 50) return toast("剧本内容太短，建议至少输入 50 字");
  if (series.originalScript.length > 50000) return toast("当前版本最多支持 5 万字，请拆分为多个系列项目");
  patchSeries({ status: "analyzing", progress: 5 }, series, 0);
  buttonLoading(document.querySelector('[data-action="analyze-series"]'), "正在读取长剧本…");
  await new Promise((resolve) => setTimeout(resolve, 650));
  const analysis = analyzeSeries(series);
  patchSeries({
    analysis,
    globalCharacters: analysis.characters,
    globalScenes: analysis.scenes,
    plotThreads: analysis.plotThreads,
    status: "analyzing",
    progress: 55
  }, series, 0);
  await new Promise((resolve) => setTimeout(resolve, 550));
  series.seriesBible = buildSeriesBible(series, analysis);
  series.episodes = planEpisodes(series, analysis);
  patchSeries({ status: "episodes_ready", progress: 100 }, series, 0);
  go("/create/series-analysis");
}

function renderSeriesAnalysis() {
  const series = ensureSeries();
  const a = series.analysis;
  if (!a) return go("/create/series-script");
  page.innerHTML = `
    ${seriesStepper("analysis")}
    ${pageHead("AI 已完成长剧本全局分析", "系统已识别人物、场景、剧情主线和适合拆分的集数。请确认后继续。", `<button class="secondary" data-action="reanalyze-series">重新分析</button>`)}
    <div class="series-overview-grid">
      <section class="card pad series-summary-card">
        <div class="eyebrow">全局故事概览</div><h2>${escapeHtml(a.logline)}</h2>
        <p>${escapeHtml(a.storySummary)}</p>
        <dl class="definition-list"><div><dt>主线剧情</dt><dd>${escapeHtml(a.mainPlot)}</dd></div><div><dt>核心冲突</dt><dd>${escapeHtml(a.mainConflict)}</dd></div><div><dt>情绪基调</dt><dd>${escapeHtml(a.tone)}</dd></div><div><dt>目标受众</dt><dd>${escapeHtml(a.targetAudience)}</dd></div></dl>
      </section>
      <div class="series-kpis">
        <div class="card stat-card"><strong>${a.episodeCount}</strong><span>推荐总集数</span></div>
        <div class="card stat-card"><strong>${durationLabel(series.targetEpisodeDuration)}</strong><span>单集时长</span></div>
        <div class="card stat-card"><strong>${a.characters.length}</strong><span>全局角色</span></div>
        <div class="card stat-card"><strong>${a.scenes.length}</strong><span>重要场景</span></div>
      </div>
    </div>
    <section class="section"><div class="section-title"><div><h2>人物识别</h2><p>主角和高频角色会进入全局角色设定库。</p></div><button class="text-button" data-action="add-series-character">＋ 新增人物</button></div>
      <div class="series-card-grid">${series.globalCharacters.map((item) => `<article class="card series-entity-card"><div class="avatar">${item.name.slice(0,1)}</div><div><h3>${escapeHtml(item.name)}</h3><p>${escapeHtml(item.identity)} · ${item.role === "protagonist" ? "主角" : item.role === "villain" ? "反派 / 对手" : "重要配角"}</p><div class="meta-row"><span>首次出现：第 ${item.firstAppearsInEpisode} 集</span><span>·</span><span>需要形象锁定</span></div></div></article>`).join("")}</div>
    </section>
    <section class="section analysis-grid">
      <div class="card pad"><h2>场景识别</h2><div class="mini-card-list">${series.globalScenes.map((item) => `<div class="mini-card"><header><strong>${escapeHtml(item.name)}</strong><span class="status">${item.recurring ? "常驻" : "临时"}</span></header><p>${escapeHtml(item.locationType)} · ${escapeHtml(item.mood)}</p><p>首次出现：第 ${item.firstAppearsInEpisode} 集</p></div>`).join("")}</div></div>
      <div class="card pad"><h2>剧情线索</h2><div class="mini-card-list">${series.plotThreads.map((item) => `<div class="mini-card"><header><strong>${escapeHtml(item.title)}</strong><span class="status ${item.status}">${item.status === "active" ? "进行中" : "待开始"}</span></header><p>第 ${item.startsInEpisode} 集开始 · 预计第 ${item.resolvedInEpisode} 集解决</p></div>`).join("")}</div></div>
    </section>
    <section class="section card pad"><h2>剧情节奏图</h2><div class="series-rhythm">${a.rhythm.map(([name,range,episodes,emotion]) => `<div><strong>${name}</strong><span>${range}</span><small>${episodes}<br>${emotion}</small></div>`).join("")}</div></section>
    ${stickyActions(`<button class="secondary" data-go="/create/series-script">← 返回修改剧本</button><button class="secondary" data-action="reanalyze-series">重新分析</button>`, `<button class="primary" data-go="/create/series-bible">确认分析，建立系列设定 →</button>`)}`;
}

function renderSeriesBible() {
  const series = ensureSeries();
  const bible = series.seriesBible;
  if (!bible) return go("/create/series-analysis");
  const sections = [["story","故事设定"],["visual","视觉风格"],["characters","角色设定库"],["scenes","场景设定库"],["threads","剧情线索"],["rules","连续性规则"],["forbidden","禁止变化项"]];
  page.innerHTML = `
    ${seriesStepper("bible")}
    ${pageHead("系列设定书", "这是整部漫剧的“制作说明书”。后续所有集数都会继承这里的角色、场景、世界观和连续性规则。")}
    <div class="bible-layout">
      <aside class="card bible-nav">${sections.map(([id,label]) => `<button class="${activeBibleSection === id ? "active" : ""}" data-bible-section="${id}">${label}</button>`).join("")}</aside>
      <section class="card form-card">${renderBibleSection(series, bible)}</section>
    </div>
    ${stickyActions(`<button class="secondary" data-go="/create/series-analysis">← 返回全局分析</button><button class="secondary" data-action="save-bible">保存设定</button>`, `<button class="primary" data-go="/create/episode-plan">确认设定，查看分集规划 →</button>`)}`;
}

function renderBibleSection(series, bible) {
  if (activeBibleSection === "story") return `<h2>故事设定</h2><p class="card-sub">所有集数共享的世界观和故事核心。</p><div class="form-grid" style="margin-top:18px">
    <label class="textarea-field span-2"><span>故事一句话</span><textarea data-bible-field="logline">${escapeHtml(bible.logline)}</textarea></label>
    <label class="textarea-field span-2"><span>故事简介</span><textarea data-bible-field="storySummary">${escapeHtml(bible.storySummary)}</textarea></label>
    ${characterField("类型","genre",bible.genre).replace("data-character-field","data-bible-field")}${characterField("情绪基调","tone",bible.tone).replace("data-character-field","data-bible-field")}
    ${characterField("世界观","worldSetting",bible.worldSetting).replace("data-character-field","data-bible-field")}${characterField("时间背景","timeSetting",bible.timeSetting).replace("data-character-field","data-bible-field")}
    ${characterField("地点背景","locationSetting",bible.locationSetting).replace("data-character-field","data-bible-field")}${characterField("核心冲突","mainConflict",bible.mainConflict).replace("data-character-field","data-bible-field")}
  </div>`;
  if (activeBibleSection === "visual") {
    const style = bible.visualStyleBible;
    return `<h2>视觉风格</h2><p class="card-sub">禁止不同集数出现突兀的画风变化。</p><div class="form-grid" style="margin-top:18px">${Object.entries({
      visualStyle:"画风",lineStyle:"线条",colorPalette:"色彩",lighting:"光影",composition:"构图",mood:"镜头语言",subtitleStyle:"字幕风格"
    }).map(([key,label]) => `<label class="field"><span>${label}</span><input data-style-bible-field="${key}" value="${escapeHtml(style[key] || "")}" /></label>`).join("")}</div><div class="notice warning" style="margin-top:18px">禁止变化：${style.negativePrompt.join("、")}</div>`;
  }
  if (activeBibleSection === "characters") return `<div class="section-title"><div><h2>角色设定库</h2><p>角色形象和声线会跨集复用。</p></div></div><div class="series-card-grid">${series.globalCharacters.map((item) => `<article class="series-lock-card"><div class="character-image" data-initial="${item.name.slice(0,1)}"><span>角色参考</span></div><h3>${escapeHtml(item.name)}</h3><p>${escapeHtml(item.identity)} · ${escapeHtml(item.appearance.outfit)}</p><div class="meta-row"><span>出现 ${item.appearsInEpisodes.length} 集</span><span>·</span><span>${item.voiceProfile.voiceType}</span></div><div class="card-actions"><button data-series-character-action="generate" data-id="${item.id}">生成参考图</button><button data-series-character-action="lock" data-id="${item.id}">${item.status === "locked" ? "已锁定" : "锁定角色"}</button><button data-series-character-action="relations" data-id="${item.id}">查看关系</button></div></article>`).join("")}</div>`;
  if (activeBibleSection === "scenes") return `<h2>场景设定库</h2><p class="card-sub">常驻场景会锁定空间结构、主色调和固定道具。</p><div class="series-card-grid" style="margin-top:18px">${series.globalScenes.map((item) => `<article class="series-lock-card"><div class="scene-reference">${escapeHtml(item.name)}</div><h3>${escapeHtml(item.name)}</h3><p>${escapeHtml(item.mood)}</p><div class="meta-row"><span>${item.recurring ? "常驻场景" : "临时场景"}</span><span>·</span><span>出现 ${item.appearsInEpisodes.length} 集</span></div><div class="card-actions"><button data-series-scene-action="generate" data-id="${item.id}">生成参考图</button><button data-series-scene-action="lock" data-id="${item.id}">锁定场景</button></div></article>`).join("")}</div>`;
  if (activeBibleSection === "threads") return `<h2>剧情线索</h2><p class="card-sub">查看主线、感情线、复仇线和悬疑线在各集的推进状态。</p><div class="thread-list">${series.plotThreads.map((item) => `<article><header><strong>${escapeHtml(item.title)}</strong><span class="status ${item.status}">${item.status === "active" ? "进行中" : "待开始"}</span></header><p>${escapeHtml(item.description)}</p><div class="thread-track"><span style="left:${Math.round(item.startsInEpisode/series.episodes.length*100)}%;right:${100-Math.round(item.resolvedInEpisode/series.episodes.length*100)}%"></span></div><small>开始：第 ${item.startsInEpisode} 集 · 推进：第 ${Math.ceil((item.startsInEpisode+item.resolvedInEpisode)/2)} 集 · 解决：第 ${item.resolvedInEpisode} 集</small></article>`).join("")}</div>`;
  if (activeBibleSection === "rules") return `<h2>连续性规则</h2><p class="card-sub">AI 会在每集生成后逐条检查。</p><div class="rule-list">${bible.continuityRules.concat(bible.characterRules,bible.sceneRules).map((item,index) => `<label><span>${index+1}</span><input value="${escapeHtml(item)}" data-continuity-rule="${index}" /></label>`).join("")}</div><button class="secondary" style="margin-top:14px" data-action="add-continuity-rule">＋ 新增规则</button>`;
  return `<h2>禁止变化项</h2><p class="card-sub">这些规则会自动加入每个镜头的 Negative Prompt。</p><div class="forbidden-list">${bible.forbiddenChanges.map((item) => `<span>× ${escapeHtml(item)}</span>`).join("")}</div><label class="field" style="margin-top:18px"><span>新增禁止项</span><input id="newForbidden" placeholder="例如：不要改变主角紫色耳坠" /></label><button class="secondary" style="margin-top:10px" data-action="add-forbidden">添加</button>`;
}

function saveBible(showToast = true) {
  const series = ensureSeries();
  document.querySelectorAll("[data-bible-field]").forEach((input) => { series.seriesBible[input.dataset.bibleField] = input.value; });
  document.querySelectorAll("[data-style-bible-field]").forEach((input) => { series.seriesBible.visualStyleBible[input.dataset.styleBibleField] = input.value; });
  patchSeries({ status: "bible_ready" }, series, 0);
  if (showToast) toast("系列设定书已保存");
}

function renderEpisodePlan() {
  const series = ensureSeries();
  if (!series.episodes.length) return go("/create/series-analysis");
  const totalShots = series.episodes.reduce((sum, item) => sum + item.estimatedShotCount, 0);
  page.innerHTML = `
    ${seriesStepper("episodes")}
    ${pageHead("分集规划", "AI 已将长剧本拆成适合短视频发布的连续剧集。你可以调整标题、顺序和结尾钩子。", `<div class="button-row"><button class="secondary" data-action="check-series-continuity">检查连续性</button><button class="primary" data-action="open-batch-modal">批量生成</button></div>`)}
    <div class="storyboard-stats series-plan-stats">
      <div class="card stat-card"><strong>${series.scriptCharCount.toLocaleString()}</strong><span>总字数</span></div>
      <div class="card stat-card"><strong>${series.episodes.length}</strong><span>规划集数</span></div>
      <div class="card stat-card"><strong>${durationLabel(series.targetEpisodeDuration)}</strong><span>单集时长</span></div>
      <div class="card stat-card"><strong>${totalShots}</strong><span>预计总镜头</span></div>
      <div class="card stat-card"><strong>${series.globalCharacters.length}</strong><span>主要角色</span></div>
      <div class="card stat-card"><strong>${series.globalScenes.filter((item) => item.recurring).length}</strong><span>常驻场景</span></div>
    </div>
    <div class="batch-toolbar card">
      <button data-action="optimize-episodes">✦ 一键优化分集节奏</button>
      <button data-action="strengthen-hooks">强化结尾钩子</button>
      <button data-action="check-series-continuity">检查剧情连续性</button>
      <button data-action="batch-first-three">批量生成前 3 集</button>
    </div>
    <div class="episode-plan-list">${series.episodes.slice(0, visibleEpisodeCount).map((episode,index) => episodePlanCard(series, episode, index)).join("")}</div>
    ${visibleEpisodeCount < series.episodes.length ? `<div class="load-more"><p>已显示前 ${visibleEpisodeCount} 集，共 ${series.episodes.length} 集。为保证长列表流畅，其余集数按需加载。</p><button class="secondary" data-action="load-more-episodes">继续加载 10 集</button></div>` : ""}
    ${stickyActions(`<button class="secondary" data-go="/create/series-bible">← 返回系列设定</button>`, `<button class="primary" data-go="/series/${series.id}">保存规划，进入系列项目 →</button>`)}`;
}

function episodePlanCard(series, episode, index) {
  const characters = series.globalCharacters.filter((item) => episode.involvedCharacters.includes(item.id)).map((item) => item.name);
  const scenes = series.globalScenes.filter((item) => episode.involvedScenes.includes(item.id)).map((item) => item.name);
  return `<article class="card episode-plan-card ${episode.important ? "important" : ""}">
    <div class="episode-number"><small>第</small><strong>${String(episode.episodeNumber).padStart(2,"0")}</strong><small>集</small></div>
    <div class="episode-plan-main">
      <header><div><h2>${escapeHtml(episode.title)}</h2><p>原文范围：第 ${episode.sourceRange.startChar.toLocaleString()}–${episode.sourceRange.endChar.toLocaleString()} 字</p></div><span class="status ${episode.status}">${episodeStatusText(episode.status)}</span></header>
      <div class="episode-outline-grid">
        <div><small>本集摘要</small><p>${escapeHtml(episode.summary)}</p></div>
        <div><small>核心冲突</small><p>${escapeHtml(episode.coreConflict)}</p></div>
        <div><small>开头钩子</small><p>${escapeHtml(episode.openingHook)}</p></div>
        <div><small>结尾钩子</small><p>${escapeHtml(episode.endingHook)}</p></div>
      </div>
      <div class="meta-row"><span>${episode.targetDuration} 秒</span><span>·</span><span>${episode.estimatedShotCount} 镜头</span><span>·</span><span>${characters.join("、")}</span><span>·</span><span>${scenes.join("、")}</span></div>
      <div class="episode-bridge"><span>承接：${escapeHtml(episode.previousEpisodeSummary)}</span><span>引出：${escapeHtml(episode.nextEpisodeHook)}</span></div>
      <div class="card-actions"><button data-episode-action="edit" data-id="${episode.id}">编辑本集</button><button data-episode-action="split" data-id="${episode.id}">拆分为两集</button><button data-episode-action="up" data-id="${episode.id}">上移</button><button data-episode-action="down" data-id="${episode.id}">下移</button><button data-episode-action="important" data-id="${episode.id}">${episode.important ? "取消重点" : "标记重点集"}</button><button data-episode-action="produce" data-id="${episode.id}">生成本集分镜</button></div>
    </div>
  </article>`;
}

function openEpisodeModal(episodeId) {
  const series = ensureSeries();
  const episode = series.episodes.find((item) => item.id === episodeId);
  if (!episode) return;
  modalRoot.innerHTML = `<section class="modal episode-modal"><h2>编辑第 ${episode.episodeNumber} 集 · ${escapeHtml(episode.title)}</h2><p>调整本集看点及与前后集的衔接。</p><div class="form-grid">
    <label class="field span-2"><span>集数标题</span><input id="episodeTitle" value="${escapeHtml(episode.title)}" /></label>
    <label class="textarea-field span-2"><span>本集摘要</span><textarea id="episodeSummary">${escapeHtml(episode.summary)}</textarea></label>
    <label class="textarea-field span-2"><span>开头钩子</span><textarea id="episodeOpening">${escapeHtml(episode.openingHook)}</textarea></label>
    <label class="textarea-field span-2"><span>核心冲突</span><textarea id="episodeConflict">${escapeHtml(episode.coreConflict)}</textarea></label>
    <label class="field"><span>情绪节奏</span><input id="episodeEmotion" value="${escapeHtml(episode.emotionalBeat)}" /></label>
    <label class="field"><span>预计时长</span><input id="episodeDuration" type="number" min="30" max="300" value="${episode.targetDuration}" /></label>
    <label class="textarea-field span-2"><span>结尾钩子</span><textarea id="episodeEnding">${escapeHtml(episode.endingHook)}</textarea></label>
    <label class="textarea-field span-2"><span>承接上一集</span><textarea id="episodePrevious">${escapeHtml(episode.previousEpisodeSummary)}</textarea></label>
    <label class="textarea-field span-2"><span>引出下一集</span><textarea id="episodeNext">${escapeHtml(episode.nextEpisodeHook)}</textarea></label>
  </div><div class="modal-actions"><button class="secondary" data-modal-close>取消</button><button class="primary" data-save-episode="${episode.id}">保存本集</button></div></section>`;
}

function handleEpisodeAction(action, id) {
  const series = ensureSeries();
  const index = series.episodes.findIndex((item) => item.id === id);
  if (index < 0) return;
  if (action === "edit") return openEpisodeModal(id);
  if (action === "produce") return go(`/series/${series.id}/episode/${id}/storyboard`);
  if (action === "important") series.episodes[index].important = !series.episodes[index].important;
  if (action === "up" && index > 0) [series.episodes[index-1],series.episodes[index]] = [series.episodes[index],series.episodes[index-1]];
  if (action === "down" && index < series.episodes.length-1) [series.episodes[index+1],series.episodes[index]] = [series.episodes[index],series.episodes[index+1]];
  if (action === "split") {
    const original = series.episodes[index];
    const midpoint = Math.floor((original.sourceRange.startChar + original.sourceRange.endChar) / 2);
    const copy = structuredClone(original);
    copy.id = `episode_${Date.now()}`;
    copy.title = `${original.title} · 下`;
    copy.sourceRange = { startChar: midpoint, endChar: original.sourceRange.endChar };
    copy.sourceText = series.originalScript.slice(midpoint, original.sourceRange.endChar);
    original.title = `${original.title} · 上`;
    original.sourceRange.endChar = midpoint;
    original.sourceText = series.originalScript.slice(original.sourceRange.startChar, midpoint);
    series.episodes.splice(index + 1, 0, copy);
  }
  series.episodes.forEach((item, i) => { item.episodeNumber = i + 1; });
  patchSeries({}, series, 0);
  renderEpisodePlan();
}

function openBatchModal(defaultRange = "first3") {
  const series = ensureSeries();
  modalRoot.innerHTML = `<section class="modal"><h2>批量生成多集漫剧</h2><p>每集生成前会继承系列设定，生成后执行连续性检查。</p><div class="form-grid">
    <label class="field span-2"><span>生成范围</span><select id="batchRange"><option value="first1">仅第 1 集</option><option value="first3" ${defaultRange==="first3"?"selected":""}>前 3 集</option><option value="first5">前 5 集</option><option value="all">全部未完成集数</option></select></label>
    <label class="field"><span>生成模式</span><select id="batchQuality"><option value="draft">草稿模式</option><option value="standard" selected>标准模式</option><option value="high">高清模式</option></select></label>
    <label class="field"><span>连续性检查</span><select id="batchContinuity"><option value="each">每集生成后检查</option><option value="end">全部生成后检查</option><option value="none">不检查</option></select></label>
    <div class="toggle-row span-2"><div class="toggle-copy"><strong>每集生成前暂停确认</strong><small>推荐新手开启，便于检查标题和钩子。</small></div><label class="switch"><input id="batchPause" type="checkbox" checked><i></i></label></div>
  </div><div class="modal-actions"><button class="secondary" data-modal-close>取消</button><button class="primary" data-start-batch="${series.id}">开始批量生成</button></div></section>`;
}

function renderSeriesDetail(seriesId) {
  const series = state.seriesProjects.find((item) => item.id === seriesId);
  if (!series) return go("/projects");
  state.activeSeriesId = series.id; saveState();
  const completed = series.episodes.filter((item) => item.status === "completed").length;
  const report = series.continuityReports.at(-1);
  page.innerHTML = `
    ${pageHead(series.title, `${seriesStatusText(series.status)} · ${series.episodes.length} 集 · ${series.scriptCharCount.toLocaleString()} 字`, `<div class="button-row"><button class="secondary" data-go="/create/series-bible">系列设定书</button><button class="primary" data-action="continue-series">继续制作下一集</button></div>`)}
    <section class="card series-hero">
      <div class="series-cover">系列<br><strong>${series.episodes.length}</strong> 集</div>
      <div><div class="eyebrow">连续漫剧项目</div><h2>${escapeHtml(series.seriesBible?.logline || series.analysis?.logline || series.title)}</h2><p>${escapeHtml(series.seriesBible?.storySummary || "")}</p><div class="progress"><span style="width:${series.episodes.length ? completed/series.episodes.length*100 : 0}%"></span></div><div class="meta-row"><span>已完成 ${completed}/${series.episodes.length} 集</span><span>·</span><span>角色 ${series.globalCharacters.length}</span><span>·</span><span>场景 ${series.globalScenes.length}</span><span>·</span><span>连续性 ${report?.score || 92} 分</span></div></div>
    </section>
    <div class="series-tabs"><a href="#seriesOverview">总览</a><a href="#seriesEpisodes">集数</a><a href="#seriesCharacters">角色库</a><a href="#seriesScenes">场景库</a><a href="#seriesThreads">剧情线索</a><a href="#seriesContinuity">连续性检查</a><button data-action="open-batch-modal">批量生成</button></div>
    <section class="section series-dashboard-grid" id="seriesOverview">
      <div class="card pad"><h2>当前制作进度</h2><div class="series-kpis compact"><div><strong>${completed}</strong><span>已完成</span></div><div><strong>${series.episodes.filter((i)=>i.status==="generating").length}</strong><span>制作中</span></div><div><strong>${series.episodes.length-completed}</strong><span>待制作</span></div></div></div>
      <div class="card pad"><h2>下一集建议</h2><p>${escapeHtml(series.episodes.find((item)=>item.status!=="completed")?.title || "全部集数已完成")}</p><p class="card-sub">${escapeHtml(series.episodes.find((item)=>item.status!=="completed")?.openingHook || "可以开始整季导出。")}</p></div>
      <div class="card pad continuity-score"><span>连续性评分</span><strong>${report?.score || 92}</strong><small>角色、场景、剧情和风格综合评分</small></div>
    </section>
    <section class="section" id="seriesEpisodes"><div class="section-title"><div><h2>集数</h2><p>每一集都继承系列设定，并保留独立制作入口。</p></div><button class="primary small" data-action="open-batch-modal">批量生成</button></div>
      <div class="series-episode-table">${series.episodes.map((episode) => `<div><span class="episode-table-number">${String(episode.episodeNumber).padStart(2,"0")}</span><span><strong>${escapeHtml(episode.title)}</strong><small>${episode.targetDuration} 秒 · ${episode.estimatedShotCount} 镜头</small></span><span class="status ${episode.status}">${episodeStatusText(episode.status)}</span><span>${episode.continuityScore || "—"} 分</span><span class="card-actions"><button data-series-episode="${episode.id}">${episode.status === "completed" ? "预览" : "制作本集"}</button><button data-episode-action="edit" data-id="${episode.id}">编辑</button></span></div>`).join("")}</div>
    </section>
    <section class="section" id="seriesCharacters"><div class="section-title"><div><h2>全局角色库</h2><p>同一套角色参考跨集复用。</p></div></div><div class="series-card-grid">${series.globalCharacters.map((item)=>`<article class="card series-entity-card"><span class="avatar">${item.name.slice(0,1)}</span><div><h3>${escapeHtml(item.name)} ${item.status==="locked"?"🔒":""}</h3><p>${escapeHtml(item.identity)} · 出现 ${item.appearsInEpisodes.length} 集</p><small>${escapeHtml(item.appearance.hairStyle)} · ${escapeHtml(item.appearance.outfit)}</small></div></article>`).join("")}</div></section>
    <section class="section analysis-grid" id="seriesScenes"><div class="card pad"><h2>场景库</h2><div class="mini-card-list">${series.globalScenes.map((item)=>`<div class="mini-card"><header><strong>${escapeHtml(item.name)}</strong><span class="status">${item.recurring?"常驻":"临时"}</span></header><p>${escapeHtml(item.mood)} · 出现 ${item.appearsInEpisodes.length} 集</p></div>`).join("")}</div></div>
      <div class="card pad" id="seriesThreads"><h2>剧情线索</h2><div class="thread-list compact">${series.plotThreads.map((item)=>`<article><header><strong>${escapeHtml(item.title)}</strong><span>${item.startsInEpisode} → ${item.resolvedInEpisode} 集</span></header><div class="thread-track"><span style="left:${item.startsInEpisode/series.episodes.length*100}%;right:${100-item.resolvedInEpisode/series.episodes.length*100}%"></span></div></article>`).join("")}</div></div>
    </section>
    <section class="section card pad" id="seriesContinuity"><div class="section-title"><div><h2>连续性检查</h2><p>检查角色外貌、场景背景、剧情衔接和风格一致性。</p></div><button class="secondary" data-action="check-series-continuity">立即检查</button></div>${report ? continuityReportHtml(report) : `<div class="notice info">尚未运行连续性检查。建议在批量生成前先检查一次系列设定。</div>`}</section>`;
}

function continuityReportHtml(report) {
  return `<div class="continuity-metrics">${[["总体",report.score],["角色",report.characterConsistencyScore],["场景",report.sceneConsistencyScore],["剧情",report.plotContinuityScore],["情绪",report.emotionContinuityScore],["风格",report.styleConsistencyScore]].map(([label,score])=>`<div><strong>${score}</strong><span>${label}</span></div>`).join("")}</div><div class="continuity-issues">${report.issues.map((issue)=>`<article class="${issue.level}"><span>!</span><div><strong>${escapeHtml(issue.title)}</strong><p>${escapeHtml(issue.description)}</p><small>建议：${escapeHtml(issue.suggestion)}</small></div>${issue.autoFixAvailable?`<button class="secondary" data-auto-fix="${issue.id}">自动修复 Prompt</button>`:""}</article>`).join("") || `<div class="notice success">✓ 没有发现明显的跨集矛盾。</div>`}</div>`;
}

function routeSeriesParts(path) {
  const match = path.match(/^\/series\/([^/]+)(?:\/episode\/([^/]+)\/(storyboard|generating|editor|export)|\/batch-generate)?$/);
  return match ? { seriesId: match[1], episodeId: match[2] || "", view: match[3] || (path.endsWith("/batch-generate") ? "batch" : "detail") } : null;
}

function renderSeriesEpisodeStoryboard(seriesId, episodeId) {
  const series = state.seriesProjects.find((item) => item.id === seriesId);
  const episode = series?.episodes.find((item) => item.id === episodeId);
  if (!series || !episode) return go(`/series/${seriesId}`);
  state.activeSeriesId = series.id; saveState();
  if (!episode.shots.length) {
    episode.shots = createEpisodeShots(series, episode);
    episode.status = "storyboard_ready";
    patchSeries({}, series, 0);
  }
  const involvedCharacters = series.globalCharacters.filter((item)=>episode.involvedCharacters.includes(item.id));
  const involvedScenes = series.globalScenes.filter((item)=>episode.involvedScenes.includes(item.id));
  page.innerHTML = `
    ${seriesStepper("production")}
    ${pageHead(`正在制作：第 ${String(episode.episodeNumber).padStart(2,"0")} 集 · ${escapeHtml(episode.title)}`, `已继承：${involvedCharacters.length} 个角色设定、${involvedScenes.length} 个场景设定、${episode.activePlotThreads.length} 条剧情线索`, `<button class="secondary" data-go="/series/${series.id}">返回系列项目</button>`)}
    <div class="episode-context-bar"><span>🔒 角色与场景已继承系列设定</span><span>承接上集：${escapeHtml(episode.previousEpisodeSummary)}</span><span>下集钩子：${escapeHtml(episode.nextEpisodeHook)}</span></div>
    <div class="storyboard-stats"><div class="card stat-card"><strong>${episode.shots.length}</strong><span>本集镜头</span></div><div class="card stat-card"><strong>${episode.targetDuration}s</strong><span>目标时长</span></div><div class="card stat-card"><strong>${involvedCharacters.length}</strong><span>继承角色</span></div><div class="card stat-card"><strong>${involvedScenes.length}</strong><span>继承场景</span></div></div>
    <div class="shot-timeline">${episode.shots.map((shot,index)=>`<div class="shot-row"><div class="shot-time">${timecode(shotStart(episode.shots,index))}<strong>镜头 ${String(index+1).padStart(2,"0")}</strong></div><article class="card shot-card"><div class="shot-head"><h3>${escapeHtml(shot.sceneName)}</h3><span class="status">${shot.duration} 秒</span><span class="status">${shot.emotion}</span></div><div class="shot-content"><div class="shot-thumb">${String(index+1).padStart(2,"0")}<br>${shot.shotSize}</div><div><div class="shot-fields"><div><small>画面</small>${escapeHtml(shot.visualDescription)}</div><div><small>对白 / 旁白</small>${escapeHtml(shot.dialogue || shot.narration)}</div><div><small>继承角色</small>${shot.continuity.characters.join("、")}</div><div><small>继承场景</small>${escapeHtml(shot.continuity.scene)}</div></div><div class="shot-continuity"><span>承接：${escapeHtml(shot.continuity.previous)}</span><span>引出：${escapeHtml(shot.continuity.next)}</span></div></div></div></article></div>`).join("")}</div>
    ${stickyActions(`<button class="secondary" data-go="/series/${series.id}">← 返回系列项目</button>`, `<button class="primary" data-generate-series-episode="${episode.id}">生成第 ${episode.episodeNumber} 集漫剧 →</button>`)}`;
}

function startSeriesEpisodeGeneration(seriesId, episodeId) {
  const series = state.seriesProjects.find((item) => item.id === seriesId);
  const episode = series?.episodes.find((item) => item.id === episodeId);
  if (!series || !episode) return;
  episode.status = "generating"; episode.progress = 0;
  series.status = "generating";
  patchSeries({}, series, 0);
  go(`/series/${series.id}/episode/${episode.id}/generating`);
}

function renderSeriesEpisodeGenerating(seriesId, episodeId) {
  const series = state.seriesProjects.find((item) => item.id === seriesId);
  const episode = series?.episodes.find((item) => item.id === episodeId);
  if (!series || !episode) return go(`/series/${seriesId}`);
  const done = episode.status === "completed";
  page.innerHTML = `${seriesStepper("production")}${pageHead(done ? `第 ${episode.episodeNumber} 集已生成完成` : `正在生成第 ${episode.episodeNumber} 集`, done ? "连续性检查已完成，成片已保存到系列项目。" : "AI 正在继承系列设定并生成画面、配音、字幕与成片。")}
    <div class="generation-grid"><section class="card big-progress"><div class="progress-ring" style="--progress:${episode.progress}"><strong>${episode.progress}%</strong></div><h2>${done ? "制作完成" : "单集生产流水线运行中"}</h2><p class="card-sub">${escapeHtml(episode.title)} · ${episode.shots.length} 个镜头</p><div class="generation-steps" style="margin-top:20px">${["构建单集上下文","优化本集剧本","生成分镜提示词","生成画面与配音","合成视频","连续性检查"].map((name,index)=>`<div class="generation-step ${episode.progress >= (index+1)*16 ? "completed" : episode.progress >= index*16 ? "running" : ""}"><i>${episode.progress >= (index+1)*16 ? "✓" : "·"}</i><div><strong>${name}</strong><small>${index===0?"继承 Series Bible、角色库和场景库":"保持跨集设定一致"}</small></div></div>`).join("")}</div></section><section class="card live-preview"><div class="live-art">第 ${episode.episodeNumber} 集<br>${escapeHtml(episode.title)}</div><div class="log-box">${(episode.generationLogs||["正在准备单集上下文包…"]).slice(-20).map((item)=>`<div>${escapeHtml(item)}</div>`).join("")}</div></section></div>
    ${done ? `<div class="button-row" style="justify-content:center;margin-top:20px"><button class="primary" data-go="/series/${series.id}">返回系列项目</button><button class="secondary" data-go="/series/${series.id}/episode/${episode.id}/storyboard">查看分镜</button></div>` : ""}`;
  if (!done) runSeriesEpisodeGeneration(series, episode);
}

function runSeriesEpisodeGeneration(series, episode) {
  clearTimeout(seriesAnalysisTimer);
  seriesAnalysisTimer = setTimeout(() => {
    episode.progress = Math.min(100, episode.progress + 20);
    episode.generationLogs ||= [];
    episode.generationLogs.push(`[${new Date().toLocaleTimeString("zh-CN")}] 第 ${episode.episodeNumber} 集进度 ${episode.progress}%`);
    if (episode.progress >= 100) {
      episode.status = "completed";
      episode.finalVideoUrl = `mock://series/${series.id}/episode/${episode.id}`;
      const report = checkContinuity(series, episode);
      episode.continuityScore = report.score;
      series.continuityReports.push(report);
      const completed = series.episodes.filter((item)=>item.status==="completed").length;
      series.status = completed === series.episodes.length ? "completed" : "partially_completed";
    }
    patchSeries({}, series, 0);
    renderSeriesEpisodeGenerating(series.id, episode.id);
  }, 550);
}

function renderBatchGeneration(seriesId) {
  const series = state.seriesProjects.find((item)=>item.id===seriesId);
  if (!series) return go("/projects");
  state.activeSeriesId=series.id; saveState();
  const job = series.batchJob || { episodeIds:[], currentIndex:0, status:"idle", progress:0, logs:[] };
  const current = series.episodes.find((item)=>item.id===job.episodeIds?.[job.currentIndex]);
  page.innerHTML = `${seriesStepper("batch")}${pageHead(job.status==="completed"?"批量生成完成":"正在批量生成连续漫剧", job.status==="completed"?"所选集数已完成生成与连续性检查。":"系统会逐集继承设定、生成成片并执行连续性检查。", `<button class="secondary" data-go="/series/${series.id}">返回系列项目</button>`)}
    <div class="batch-progress-layout"><section class="card pad"><div class="section-title"><div><h2>总体进度</h2><p>${job.episodeIds.length} 集生成任务</p></div><strong class="batch-percent">${job.progress}%</strong></div><div class="progress"><span style="width:${job.progress}%"></span></div><div class="series-kpis compact"><div><strong>${job.currentIndex}</strong><span>已完成</span></div><div><strong>${current?.episodeNumber || "—"}</strong><span>当前集</span></div><div><strong>${job.failedCount||0}</strong><span>失败</span></div><div><strong>${series.continuityReports.length}</strong><span>检查报告</span></div></div><div class="batch-episode-list">${job.episodeIds.map((id,index)=>{const ep=series.episodes.find((item)=>item.id===id); return `<div class="${index<job.currentIndex?"done":index===job.currentIndex&&job.status==="running"?"active":""}"><span>${index<job.currentIndex?"✓":index+1}</span><strong>第 ${ep?.episodeNumber} 集 · ${escapeHtml(ep?.title||"")}</strong><small>${index<job.currentIndex?"已完成":index===job.currentIndex&&job.status==="running"?"生成中":"等待中"}</small></div>`}).join("")}</div></section><section class="card"><div class="live-art">${current?`正在制作第 ${current.episodeNumber} 集<br>${escapeHtml(current.title)}`:"批量任务已完成"}</div><div class="log-box">${job.logs.slice(-100).map((item)=>`<div>${escapeHtml(item)}</div>`).join("")||"<div>正在初始化批量生成调度器…</div>"}</div></section></div>
    ${job.status==="completed"?`<div class="button-row" style="justify-content:center;margin-top:20px"><button class="primary" data-go="/series/${series.id}">查看系列项目</button></div>`:`<div class="button-row" style="justify-content:center;margin-top:20px"><button class="danger-button" data-action="cancel-batch">取消批量生成</button></div>`}`;
  if (job.status==="running") runBatchTick(series);
}

function startBatch(series, range = "first3") {
  const unfinished = series.episodes.filter((item)=>item.status!=="completed");
  const limit = range==="first1"?1:range==="first3"?3:range==="first5"?5:unfinished.length;
  const selected = unfinished.slice(0,limit);
  series.batchJob = { episodeIds:selected.map((item)=>item.id), currentIndex:0, status:"running", progress:0, failedCount:0, logs:[`[${new Date().toLocaleTimeString("zh-CN")}] 已创建 ${selected.length} 集批量任务`] };
  series.status="generating";
  patchSeries({},series,0);
  go(`/series/${series.id}/batch-generate`);
}

function runBatchTick(series) {
  clearTimeout(batchTimer);
  batchTimer=setTimeout(()=>{
    const job=series.batchJob;
    const episode=series.episodes.find((item)=>item.id===job.episodeIds[job.currentIndex]);
    if (!episode) { job.status="completed"; job.progress=100; patchSeries({},series,0); return renderBatchGeneration(series.id); }
    episode.status="completed"; episode.progress=100; episode.shots=episode.shots.length?episode.shots:createEpisodeShots(series,episode); episode.finalVideoUrl=`mock://series/${series.id}/episode/${episode.id}`;
    const report=checkContinuity(series,episode); episode.continuityScore=report.score; series.continuityReports.push(report);
    job.logs.push(`[${new Date().toLocaleTimeString("zh-CN")}] 第 ${episode.episodeNumber} 集已完成，连续性 ${report.score} 分`);
    job.currentIndex+=1; job.progress=Math.round(job.currentIndex/job.episodeIds.length*100);
    if(job.currentIndex>=job.episodeIds.length){job.status="completed"; series.status=series.episodes.every((item)=>item.status==="completed")?"completed":"partially_completed";}
    patchSeries({},series,0); renderBatchGeneration(series.id);
  },700);
}

function renderStyle() {
  const project = ensureProject();
  page.innerHTML = `
    ${stepper("style")}
    ${pageHead("设置画风与生成方案", "不用写 Prompt。选择你喜欢的样式，AI 会自动把它转换成制作参数。")}
    <div class="wizard-grid">
      <section class="card form-card">
        <div class="config-section"><h3>选择漫剧画风</h3><p>不同画风会影响角色、场景、线条和色彩表现。</p>
          <div class="style-grid">${STYLES.map((item) => `<button class="select-card ${project.style === item.id ? "active" : ""}" data-style="${item.id}"><span class="tag">${item.tag}</span><div class="style-preview" style="--c1:${item.colors[0]};--c2:${item.colors[1]}"></div><div class="select-card-copy"><strong>${item.id}</strong><small>${item.desc}</small></div></button>`).join("")}</div>
        </div>
        <div class="config-section"><h3>选择剧情节奏</h3><p>标准短剧型最适合第一次使用。</p>
          <div class="option-row">${[
            ["慢节奏情绪型","氛围多、台词慢、镜头停留久"],
            ["标准短剧型","剧情清晰、节奏均衡、适合新手"],
            ["爽文快节奏","冲突密集、反转快、适合短视频"]
          ].map(([id,desc]) => `<button class="option ${project.pace === id ? "active" : ""}" data-pace="${id}"><strong>${id}${id === "标准短剧型" ? " · 推荐" : ""}</strong><small>${desc}</small></button>`).join("")}</div>
        </div>
        <div class="config-section"><h3>选择画幅</h3><p>系统会预留字幕安全区，并自动调整人物构图。</p>
          <div class="option-row">${[["9:16","竖屏 · 抖音/快手"],["16:9","横屏 · B站/YouTube"],["1:1","方形 · 社媒图文"]].map(([id,desc]) => `<button class="option ${project.aspectRatio === id ? "active" : ""}" data-aspect="${id}"><strong>${id}</strong><small>${desc}</small></button>`).join("")}</div>
        </div>
        <div class="config-section"><h3>配音设置</h3>
          <div class="form-grid">
            <div class="toggle-row span-2"><div class="toggle-copy"><strong>生成配音</strong><small>自动区分旁白和角色对白。</small></div><label class="switch"><input id="voiceEnabled" type="checkbox" ${project.voiceEnabled ? "checked" : ""}><i></i></label></div>
            <label class="field"><span>旁白声音</span><select id="voiceType">${["温柔女声","磁性男声","活泼少女","沉稳旁白","搞笑夸张"].map((item) => `<option ${project.voiceType === item ? "selected" : ""}>${item}</option>`).join("")}</select></label>
            <label class="field"><span>语速</span><select id="voiceSpeed">${["慢","正常","快"].map((item) => `<option ${project.voiceSpeed === item ? "selected" : ""}>${item}</option>`).join("")}</select></label>
          </div>
        </div>
        <div class="config-section"><h3>字幕与包装</h3>
          <div class="form-grid"><label class="field"><span>字幕样式</span><select id="subtitleStyle">${["短视频大字","漫画气泡","底部白字","简洁无边框"].map((item) => `<option ${project.subtitleStyle === item ? "selected" : ""}>${item}</option>`).join("")}</select></label>
          <div class="toggle-row"><div class="toggle-copy"><strong>自动字幕</strong><small>根据配音生成时间轴。</small></div><label class="switch"><input id="subtitleEnabled" type="checkbox" ${project.subtitleEnabled ? "checked" : ""}><i></i></label></div>
          <div class="toggle-row"><div class="toggle-copy"><strong>自动生成封面</strong></div><label class="switch"><input id="autoCover" type="checkbox" ${project.autoCover ? "checked" : ""}><i></i></label></div>
          <div class="toggle-row"><div class="toggle-copy"><strong>添加背景音乐</strong></div><label class="switch"><input id="bgm" type="checkbox" ${project.bgm ? "checked" : ""}><i></i></label></div></div>
        </div>
        <details><summary>高级设置：生成质量与成本</summary><div class="details-body"><div class="option-row">${[["draft","草稿模式","快速、低成本、低清占位"],["standard","标准模式","推荐默认，质量与速度均衡"],["high","高清模式","更高分辨率、耗时更长"]].map(([id,label,desc]) => `<button class="option ${project.quality === id ? "active" : ""}" data-quality="${id}"><strong>${label}</strong><small>${desc}</small></button>`).join("")}</div></div></details>
        <div class="notice warning" style="margin-top:18px">请不要上传涉及侵权、违法、色情、极端暴力或真实个人隐私的内容。系统会尽量避免生成与知名 IP、明星或真实人物高度相似的角色。</div>
      </section>
      <aside class="card pad" style="position:sticky;top:90px">
        <h2>当前生成方案</h2><p class="card-sub">参数变化会实时更新。</p>
        <div class="summary-list" id="styleSummary"></div>
        <div class="notice info">预计生成：<strong>${shotCountFor(project.duration)} 个镜头</strong><br>约 2 个主要角色 · 1 条旁白音轨 · 1 个最终视频</div>
      </aside>
    </div>
    ${stickyActions(`<button class="secondary" data-go="/create/script">← 上一步</button><button class="secondary" data-action="save-style">保存草稿</button>`, `<button class="primary" data-action="style-next">开始 AI 分析 →</button>`)}`;
  updateStyleSummary();
}

function readStyleForm() {
  const project = ensureProject();
  return patchProject({
    voiceEnabled: Boolean(document.querySelector("#voiceEnabled")?.checked),
    voiceType: document.querySelector("#voiceType")?.value || project.voiceType,
    voiceSpeed: document.querySelector("#voiceSpeed")?.value || project.voiceSpeed,
    subtitleEnabled: Boolean(document.querySelector("#subtitleEnabled")?.checked),
    subtitleStyle: document.querySelector("#subtitleStyle")?.value || project.subtitleStyle,
    autoCover: Boolean(document.querySelector("#autoCover")?.checked),
    bgm: Boolean(document.querySelector("#bgm")?.checked)
  }, project);
}

function updateStyleSummary() {
  const project = ensureProject();
  const node = document.querySelector("#styleSummary");
  if (!node) return;
  node.innerHTML = [
    ["作品类型", project.genre], ["画风", project.style], ["节奏", project.pace],
    ["画幅", `${project.aspectRatio} ${project.aspectRatio === "9:16" ? "竖屏" : project.aspectRatio === "16:9" ? "横屏" : "方形"}`],
    ["预计时长", durationLabel(project.duration)], ["预计镜头", `${shotCountFor(project.duration)} 个`],
    ["配音", project.voiceEnabled ? project.voiceType : "关闭"], ["字幕", project.subtitleEnabled ? project.subtitleStyle : "关闭"],
    ["生成质量", ({draft:"草稿",standard:"标准",high:"高清"})[project.quality]]
  ].map(([label,value]) => `<div class="summary-item"><span>${label}</span><strong>${escapeHtml(value)}</strong></div>`).join("");
}

async function startAnalysis() {
  const project = readStyleForm();
  patchProject({ status: "analyzing", progress: 12 });
  buttonLoading(document.querySelector('[data-action="style-next"]'), "AI 正在阅读剧本…");
  project.analysis = await callAgent("/api/agent/analyze-script", project, () => analyzeScript(project));
  project.scenes = project.analysis.scenes;
  project.styleBible = await callAgent("/api/agent/create-style", project, () => createStyleBible(project));
  project.characters = await callAgent("/api/agent/design-characters", { project, analysis: project.analysis }, () => designCharacters(project, project.analysis));
  patchProject({ status: "draft", progress: 28 });
  go("/create/analysis");
}

function renderAnalysis() {
  const project = ensureProject();
  if (!project.analysis) {
    page.innerHTML = `${stepper("analysis")}${emptyState("✦","还没有分析结果","请先完成剧本和风格设置，让 AI 理解你的故事。","返回风格设置","/create/style")}`;
    return;
  }
  const a = project.analysis;
  page.innerHTML = `
    ${stepper("analysis")}
    ${pageHead("AI 已完成剧本分析", "AI 已读完你的剧本，并整理成可制作的漫剧方案。请确认故事结构、人物和节奏。", `<button class="secondary" data-action="reanalyze">重新分析</button>`)}
    <div class="notice success" style="margin-bottom:18px">✓ 开头冲突明确，人物目标清晰，适合直接进入分镜制作。后续仍然可以修改。</div>
    <div class="score-grid">${[
      ["故事清晰度",a.scores.clarity,"主线目标清楚"],
      ["冲突强度",a.scores.conflict,"反转点可以继续加强"],
      ["角色完整度",a.scores.character,"主要人物关系已识别"],
      ["短视频适配度",a.scores.shortVideo,"开头抓人，结尾有钩子"]
    ].map(([label,score,note]) => `<div class="card score-card"><span>${label}</span><strong>${score}%</strong><div class="progress"><span style="width:${score}%"></span></div><small>${note}</small></div>`).join("")}</div>
    <div class="analysis-grid">
      <section class="card pad"><h2>故事摘要</h2><p class="card-sub">${escapeHtml(a.summary)}</p>
        <dl class="definition-list"><div><dt>主线剧情</dt><dd>${escapeHtml(a.mainPlot)}</dd></div><div><dt>核心冲突</dt><dd>${escapeHtml(a.conflict)}</dd></div><div><dt>情绪关键词</dt><dd>${a.emotions.map((item) => `<span class="status">${item}</span>`).join(" ")}</dd></div><div><dt>结尾钩子</dt><dd>${escapeHtml(a.hook)}</dd></div><div><dt>制作建议</dt><dd>${durationLabel(project.duration)} · ${a.suggestedShots} 个镜头</dd></div></dl>
      </section>
      <section class="card pad"><div class="section-title"><div><h2>识别人物</h2><p>可在下一步继续调整详细设定。</p></div><button class="text-button" data-action="add-analysis-character">＋ 新增</button></div>
        <div class="mini-card-list">${project.characters.map((item) => `<div class="mini-card"><header><strong>${escapeHtml(item.name)}</strong><span class="status">${item.role === "protagonist" ? "主角" : "配角"}</span></header><p>${escapeHtml(item.identity)} · ${escapeHtml(item.personality)}</p><p>生成形象：是 · 需要配音：${item.needsVoice ? "是" : "否"}</p></div>`).join("")}</div>
      </section>
      <section class="card pad"><h2>场景识别</h2><div class="mini-card-list">${project.scenes.map((item) => `<div class="mini-card"><header><strong>${escapeHtml(item.name)}</strong><span class="status">${item.frequency}频</span></header><p>${escapeHtml(item.description)}</p><p>${escapeHtml(item.mood)}</p></div>`).join("")}</div></section>
      <section class="card pad"><h2>剧情节奏</h2><div class="timeline-list">${a.pacing.map(([time,text]) => `<div class="timeline-point"><strong>${time}</strong><span>${text}</span></div>`).join("")}</div></section>
    </div>
    <div class="notice info" style="margin-top:18px">确认分析后，AI 会根据这些信息生成角色和分镜。角色名称、画面和台词后续都可以继续修改。</div>
    ${stickyActions(`<button class="secondary" data-go="/create/script">← 返回修改剧本</button><button class="secondary" data-action="reanalyze">重新分析</button>`, `<button class="primary" data-go="/create/characters">确认分析，下一步 →</button>`)}`;
}

async function reanalyze() {
  const project = ensureProject();
  toast("AI 正在重新理解你的故事…");
  project.analysis = await analyzeScript(project);
  project.scenes = project.analysis.scenes;
  project.characters = await designCharacters(project, project.analysis);
  patchProject({});
  render();
}

const CHARACTER_TABS = [
  ["base", "基础设定"], ["views", "三视图"], ["expressions", "表情库"],
  ["outfits", "服装与道具"], ["poses", "姿势动作"],
  ["consistency", "一致性检查"], ["prompts", "高级 Prompt"]
];
const THREE_VIEW_TYPES = [
  ["front_full_body", "正面全身", "front"], ["side_full_body", "侧面全身", "side"], ["back_full_body", "背面全身", "back"]
];
const POSE_TYPES = [
  ["neutral_stand", "中性站立"], ["look_back", "侧身回头"], ["thinking", "低头沉思"],
  ["shocked_up", "抬头震惊"], ["phone", "拿手机"], ["leave", "转身离开"]
];

function splitList(value) {
  return String(value || "").split(/[、,，\n]/).map((item) => item.trim()).filter(Boolean);
}

function setCharacterValue(target, path, value) {
  const parts = path.split(".");
  let node = target;
  parts.slice(0, -1).forEach((part) => {
    if (!node[part] || typeof node[part] !== "object") node[part] = {};
    node = node[part];
  });
  node[parts.at(-1)] = value;
}

function getCharacterValue(target, path) {
  return path.split(".").reduce((node, part) => node?.[part], target);
}

function topicExpression(genre) {
  return ({ "甜宠": ["shy", "害羞"], "悬疑": ["fear", "恐惧"], "搞笑": ["speechless", "无语"], "古风": ["restrained", "克制"], "玄幻": ["determined", "坚定"], "都市": ["cold_smile", "冷笑"] })[genre] || ["determined", "坚定"];
}

function characterReferencePrompt(character, project) {
  const style = project.styleBible || {};
  return `请生成角色三视图设定图，包含正面全身、侧面全身、背面全身。

角色姓名：${character.name}
角色身份：${character.identity}
年龄：${character.age || "未设定"}
性别：${character.gender || "未设定"}
脸型：${character.appearance.faceShape || "未设定"}
眼睛：${character.appearance.eyeStyle || "未设定"}
发型：${character.appearance.hairStyle || "未设定"}
发色：${character.appearance.hairColor || "未设定"}
服装：${character.defaultOutfit.description || "未设定"}
服装主色：${character.defaultOutfit.mainColor || "未设定"}
标志物：${character.accessories || "无"}
气质：${character.appearance.visualKeywords.join("、") || "未设定"}

画风：${style.visualStyle || project.style}
线条：${style.lineStyle || "干净稳定"}
色彩：${style.colorPalette || "统一配色"}

要求：三个视角必须是同一个角色；发型、发色、服装、身材比例一致；中性站姿；干净背景；不要多余人物、文字、水印或 Logo；不要改变年龄感或服装。`;
}

function expressionPrompt(character, name, project) {
  return `请基于已锁定角色参考图生成表情图。角色：${character.name}。已锁定特征：${character.lockedTraits.join("、")}。表情：${name}。保持脸型、发型、发色、服装和年龄感一致，只改变表情，正面半身或头像构图，干净背景，${project.style}，不要多余人物、文字、水印或 Logo。`;
}

function characterLockPrompt(character) {
  return `角色 ${character.name} 必须保持以下特征：
- 发型：${character.appearance.hairStyle || "保持主参考图"}
- 发色：${character.appearance.hairColor || "保持主参考图"}
- 脸型：${character.appearance.faceShape || "保持主参考图"}
- 眼睛：${character.appearance.eyeStyle || "保持主参考图"}
- 默认服装：${character.defaultOutfit.description || "保持主参考图"}
- 标志物：${character.accessories || "无"}
- 气质：${character.appearance.visualKeywords.join("、") || character.personality}

禁止：${character.forbiddenChanges.join("；") || "不要改变发色、脸型、服装主色和年龄感；不要生成无关人物"}`;
}

function makeReference(character, type, label, prompt, status = "empty") {
  return {
    id: `ref_${character.id}_${type}_${Date.now().toString(36)}`,
    characterId: character.id, type, label, url: "", prompt, status,
    isPrimaryReference: false, isLocked: false, createdAt: new Date().toISOString()
  };
}

function normalizeCharacter(character, project, index = 0) {
  character.role ||= index === 0 ? "protagonist" : "supporting";
  character.importance ||= character.role === "protagonist" ? "核心主角" : "主要配角";
  character.plotPosition ||= character.role === "protagonist" ? "推动主线并完成关键选择" : "制造冲突或协助主角";
  character.firstEpisode ||= "第 1 集";
  character.motivation ||= "";
  character.speakingStyle ||= "自然、符合身份";
  character.commonEmotions ||= character.expressionKeywords || "克制、震惊、释然";
  character.emotionArc ||= "从压抑到主动";
  character.relationships ||= "待补充";
  character.appearance ||= {};
  Object.assign(character.appearance, {
    faceShape: character.appearance.faceShape || character.faceShape || "",
    eyeStyle: character.appearance.eyeStyle || character.eyeStyle || "",
    hairStyle: character.appearance.hairStyle || character.hairStyle || "",
    hairColor: character.appearance.hairColor || character.hairColor || "",
    bodyType: character.appearance.bodyType || character.bodyType || "",
    height: character.appearance.height || character.height || "",
    ageLook: character.appearance.ageLook || character.ageLook || "",
    visualKeywords: Array.isArray(character.appearance.visualKeywords)
      ? character.appearance.visualKeywords
      : (Array.isArray(character.visualKeywords) ? character.visualKeywords : splitList(character.visualKeywords))
  });
  character.defaultOutfit ||= {
    id: `outfit_${character.id}_default`, name: "默认服装",
    description: character.outfit || "", mainColor: character.outfitColor || "",
    usageScene: "常规剧情", appearsInEpisodes: [1], referenceImageUrl: "",
    isDefault: true, isLocked: false
  };
  character.outfits = Array.isArray(character.outfits) && character.outfits.length ? character.outfits : [character.defaultOutfit];
  character.props = Array.isArray(character.props) ? character.props : [];
  character.accessories ||= character.marker || "";
  character.commonProps ||= "";
  character.lockedTraits = Array.isArray(character.lockedTraits) ? character.lockedTraits : splitList(character.lockedTraits);
  character.forbiddenChanges = Array.isArray(character.forbiddenChanges) && character.forbiddenChanges.length
    ? character.forbiddenChanges : ["不改变发色", "不改变脸型", "不改变服装主色", "不改变年龄感", "不生成无关人物"];
  character.referenceImages = Array.isArray(character.referenceImages) ? character.referenceImages.filter((item) => item && typeof item === "object") : [];
  character.expressionImages = Array.isArray(character.expressionImages) ? character.expressionImages : [];
  character.poseImages = Array.isArray(character.poseImages) ? character.poseImages : [];
  character.lockOptions ||= {
    hairStyle: character.role === "protagonist", hairColor: character.role === "protagonist",
    faceShape: character.role === "protagonist", outfitColor: character.role === "protagonist",
    accessories: character.role === "protagonist", voice: character.role === "protagonist"
  };
  character.assetProgress ||= {};
  character.prompts ||= {};
  character.prompts.master = character.prompts.master || character.prompt || `${character.name}，${character.identity}，${project.style}，人物主体清晰`;
  character.prompts.threeViews = character.prompts.threeViews || characterReferencePrompt(character, project);
  character.prompts.expression = character.prompts.expression || expressionPrompt(character, "中性", project);
  character.prompts.negative = character.prompts.negative || "不要改变角色脸型、发型、发色、服装主色和年龄感；不要出现多余人物、文字、水印、Logo。";
  character.prompts.inheritance = characterLockPrompt(character);
  return character;
}

function baseInfoReady(character) {
  return Boolean(character.name && character.identity && character.age && character.gender && character.personality
    && character.plotPosition && character.firstEpisode
    && character.appearance.faceShape && character.appearance.eyeStyle
    && character.appearance.hairStyle && character.appearance.hairColor
    && character.appearance.bodyType && character.appearance.ageLook
    && character.appearance.visualKeywords.length
    && character.defaultOutfit.description && character.defaultOutfit.mainColor
    && character.forbiddenChanges.length);
}

function assetsReady(list, count) {
  return list.filter((item) => ["generated", "locked"].includes(item.status)).length >= count;
}

function characterProgress(character) {
  const progress = {
    baseInfo: baseInfoReady(character),
    threeViews: assetsReady(character.referenceImages.filter((item) => THREE_VIEW_TYPES.some(([type]) => type === item.type)), 3),
    expressions: assetsReady(character.expressionImages, 6),
    outfits: Boolean(character.defaultOutfit.description && character.defaultOutfit.mainColor),
    poses: assetsReady(character.poseImages, 6),
    consistencyChecked: Boolean(character.consistencyReport)
  };
  character.assetProgress = progress;
  return (progress.baseInfo ? 20 : 0) + (progress.threeViews ? 30 : 0) + (progress.expressions ? 20 : 0)
    + (progress.outfits ? 10 : 0) + (progress.poses ? 10 : 0) + (progress.consistencyChecked ? 10 : 0);
}

function threeViewsLocked(character) {
  const views = character.referenceImages.filter((item) => THREE_VIEW_TYPES.some(([type]) => type === item.type));
  return views.length === 3 && views.every((item) => item.isLocked);
}

function characterStatusInfo(character) {
  if (character.status === "needs_review" || character.status === "needs_edit") return ["needs_edit", "需修改"];
  if (character.status === "locked" || threeViewsLocked(character) && character.consistencyReport?.score >= 80) return ["locked", "已锁定"];
  if (!baseInfoReady(character)) return ["pending", "待设定"];
  if (!assetsReady(character.referenceImages, 3)) return ["pending", "三视图待生成"];
  if (!assetsReady(character.expressionImages, 6)) return ["pending", "表情待生成"];
  return ["generating", "待检查"];
}

function roleLabel(role) {
  return ({ protagonist: "主角", main_supporting: "重要配角", supporting: "配角", villain: "反派", extra: "群演" })[role] || "配角";
}

function renderCharacters() {
  const project = ensureProject();
  if (!project.characters.length) return go("/create/analysis");
  project.characters.forEach((item, index) => normalizeCharacter(item, project, index));
  if (!activeCharacterId || !project.characters.some((item) => item.id === activeCharacterId)) activeCharacterId = project.characters[0].id;
  const character = project.characters.find((item) => item.id === activeCharacterId);
  const progress = characterProgress(character);
  const [statusClass, statusTextValue] = characterStatusInfo(character);
  page.innerHTML = `
    ${stepper("characters")}
    ${pageHead("角色设定", "先锁定角色的三视图，再生成表情、服装和动作库。后续所有分镜都会继承这些设定。")}
    <div class="character-guide notice info"><strong>角色三视图就像角色的身份证。</strong> AI 会用它记住角色的脸、发型、服装和整体比例；锁定后仍可手动解锁修改。</div>
    <div class="character-layout character-workbench-layout">
      <aside class="card character-list">${project.characters.map((item, index) => {
        normalizeCharacter(item, project, index);
        const itemProgress = characterProgress(item);
        const [itemClass, itemStatus] = characterStatusInfo(item);
        return `<button class="character-tab ${item.id === character.id ? "active" : ""}" data-character="${item.id}">
          <span class="avatar">${escapeHtml(item.name.slice(0,1))}</span>
          <span class="character-tab-copy"><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.identity)}</small></span>
          <span class="importance">${escapeHtml(item.importance)}</span><span class="status ${itemClass}">${itemStatus}</span>
          <span class="character-progress-label">角色完整度 ${itemProgress}%</span><span class="character-mini-progress"><i style="width:${itemProgress}%"></i></span>
        </button>`;
      }).join("")}<button class="secondary add-character-button" data-action="add-character">＋ 新增角色</button></aside>
      <section class="card character-workbench">
        <header class="character-workbench-head">
          <div><div class="character-title-line"><h2>${escapeHtml(character.name)}</h2><span class="status ${statusClass}">${statusTextValue}</span></div><p>${escapeHtml(character.identity)} · ${roleLabel(character.role)} · ${escapeHtml(character.importance)}</p></div>
          <div class="character-completion"><strong>${progress}%</strong><span>角色完整度</span></div>
        </header>
        <nav class="character-workbench-tabs">${CHARACTER_TABS.map(([id, label]) => `<button class="${activeCharacterTab === id ? "active" : ""}" data-character-tab="${id}">${label}</button>`).join("")}</nav>
        <div class="character-tab-panel">${characterTabContent(character, project)}</div>
      </section>
    </div>
    ${stickyActions(`<button class="secondary" data-go="/create/analysis">← 上一步</button><button class="secondary" data-action="save-character">保存设定</button>`, `<button class="primary" data-action="characters-next">确认角色，生成分镜 →</button>`)}`;
}

function characterTabContent(character, project) {
  if (activeCharacterTab === "views") return threeViewsTab(character);
  if (activeCharacterTab === "expressions") return expressionsTab(character, project);
  if (activeCharacterTab === "outfits") return outfitsTab(character);
  if (activeCharacterTab === "poses") return posesTab(character);
  if (activeCharacterTab === "consistency") return consistencyTab(character);
  if (activeCharacterTab === "prompts") return promptsTab(character);
  return baseCharacterTab(character);
}

function baseCharacterTab(character) {
  const lockLabels = [["hairStyle","锁定发型"],["hairColor","锁定发色"],["faceShape","锁定脸型"],["outfitColor","锁定服装主色"],["accessories","锁定标志物"],["voice","锁定声线"]];
  return `<div class="character-panel-head"><div><h2>基础设定</h2><p>先明确角色身份、外貌和默认形象，再生成视觉资产。</p></div><button class="secondary" data-action="recommend-character">✦ AI 推荐设定</button></div>
    <div class="character-form-section"><h3>1. 基础信息</h3><div class="form-grid">
      ${characterField("姓名","name",character.name)}${characterField("角色身份","identity",character.identity)}
      ${characterSelect("角色重要度","importance",character.importance,["核心主角","主要配角","普通配角","反派","群演"])}
      ${characterField("年龄","age",character.age)}${characterSelect("性别","gender",character.gender,["女","男","非二元","未设定"])}
      ${characterField("性格关键词","personality",character.personality)}
      ${characterField("剧情定位","plotPosition",character.plotPosition)}${characterField("首次出现集数","firstEpisode",character.firstEpisode)}
    </div></div>
    <div class="character-form-section"><h3>2. 外貌特征</h3><div class="form-grid">
      ${characterField("脸型","appearance.faceShape",character.appearance.faceShape)}${characterField("眼睛","appearance.eyeStyle",character.appearance.eyeStyle)}
      ${characterField("发型","appearance.hairStyle",character.appearance.hairStyle)}${characterField("发色","appearance.hairColor",character.appearance.hairColor)}
      ${characterField("身高体型","appearance.bodyType",character.appearance.bodyType)}${characterField("年龄感","appearance.ageLook",character.appearance.ageLook)}
      ${characterField("气质关键词","appearance.visualKeywords",character.appearance.visualKeywords.join("、"),"span-2")}
    </div></div>
    <div class="character-form-section"><h3>3. 服装与标志物</h3><div class="form-grid">
      ${characterField("默认服装","defaultOutfit.description",character.defaultOutfit.description,"span-2")}
      ${characterField("服装主色","defaultOutfit.mainColor",character.defaultOutfit.mainColor)}
      ${characterField("标志性配饰","accessories",character.accessories)}
      ${characterField("常用道具","commonProps",character.commonProps)}
      ${characterField("禁止变化项","forbiddenChanges",character.forbiddenChanges.join("、"))}
    </div></div>
    <div class="character-form-section"><h3>4. 性格与情绪</h3><div class="form-grid">
      ${characterField("性格描述","personality",character.personality)}${characterField("说话方式","speakingStyle",character.speakingStyle)}
      ${characterField("常见情绪","commonEmotions",character.commonEmotions)}${characterField("情绪变化弧线","emotionArc",character.emotionArc)}
      ${characterField("与其他角色关系","relationships",character.relationships,"span-2")}
    </div></div>
    <div class="character-form-section"><h3>5. 角色锁定项</h3><div class="lock-option-grid">${lockLabels.map(([id,label]) => `<label><input type="checkbox" data-character-lock="${id}" ${character.lockOptions[id] ? "checked" : ""}><span>${label}</span></label>`).join("")}</div><p class="card-sub">主角默认全部开启。锁定项会写入后续每个分镜的生成 Prompt。</p></div>`;
}

function assetStateText(status) {
  return ({ empty: "未生成", pending: "未生成", generating: "生成中", generated: "已生成", locked: "已锁定", failed: "生成失败", needs_review: "需重生成" })[status] || "未生成";
}

function referenceCard(reference, type, label, silhouette) {
  const status = reference?.status || "empty";
  const refId = reference?.id || "";
  return `<article class="reference-card">
    <div class="reference-visual ${status === "generating" ? "skeleton" : ""} ${status === "empty" ? "empty" : ""}">
      <div class="character-silhouette ${silhouette}"><i></i><b></b></div>
      ${reference?.isPrimaryReference ? `<span class="primary-reference-badge">主参考</span>` : ""}
      ${reference?.isLocked ? `<span class="locked-reference-badge">🔒 已锁定</span>` : ""}
    </div>
    <header><div><h3>${label}</h3><small>${status === "generated" || status === "locked" ? "可作为参考图" : "统一服装 · 中性站姿"}</small></div><span class="status ${status}">${assetStateText(status)}</span></header>
    <div class="reference-actions">
      <button data-generate-reference="${type}">${status === "empty" ? "生成" : "重新生成"}</button>
      <button ${!refId ? "disabled" : ""} data-primary-reference="${refId}">设为主参考</button>
      <button ${!refId ? "disabled" : ""} data-view-reference="${refId}">查看大图</button>
    </div>
  </article>`;
}

function threeViewsTab(character) {
  const views = character.referenceImages.filter((item) => THREE_VIEW_TYPES.some(([type]) => type === item.type));
  const ready = assetsReady(views, 3);
  return `<div class="character-panel-head"><div><h2>角色三视图</h2><p>三视图会作为角色主参考，保证后续镜头中人物不变脸、不换发型、不乱换服装。</p></div></div>
    <div class="notice info character-tip"><strong>三视图就像角色的身份证。</strong> 请先使用统一服装和中性站姿生成正面、侧面、背面全身图。</div>
    <div class="three-view-grid">${THREE_VIEW_TYPES.map(([type,label,silhouette]) => referenceCard(views.find((item) => item.type === type),type,label,silhouette)).join("")}</div>
    <div class="asset-toolbar"><button class="primary" data-action="generate-three-views">${ready ? "重新生成三视图" : "生成三视图"}</button><button class="secondary" data-action="lock-three-views" ${ready ? "" : "disabled"}>${threeViewsLocked(character) ? "解锁三视图" : "锁定三视图"}</button></div>
    <div class="notice ${threeViewsLocked(character) ? "success" : "info"}">${threeViewsLocked(character) ? "✓ 三视图已锁定，后续分镜会优先继承这组参考。" : "锁定后，后续分镜会优先继承这组三视图；仍可手动解锁修改。"}</div>`;
}

function expressionsTab(character, project) {
  const topic = topicExpression(project.genre);
  const expressions = [
    ["neutral","中性","·"],["happy","开心","⌣"],["sad","难过","⌢"],
    ["angry","愤怒","⌁"],["shocked","震惊","!"],topic,
    ...character.expressionImages.filter((item) => item.type.startsWith("custom_")).map((item) => [item.type,item.label,"✦"])
  ];
  return `<div class="character-panel-head"><div><h2>表情库</h2><p>用于对白、反应和情绪爆发镜头，建议在三视图锁定后生成。</p></div><button class="secondary" data-action="add-expression">＋ 新增表情</button></div>
    ${threeViewsLocked(character) ? "" : `<div class="notice warning character-tip">建议先生成并锁定三视图，再生成表情库，这样角色更稳定。</div>`}
    <div class="expression-grid">${expressions.map(([type,label,symbol]) => {
      const reference = character.expressionImages.find((item) => item.type === type);
      const status = reference?.status || "empty";
      return `<article class="expression-card"><div class="expression-visual ${status === "generating" ? "skeleton" : ""}"><span class="expression-face">${symbol}</span></div><header><strong>${label}</strong><span class="status ${status}">${assetStateText(status)}</span></header><button data-generate-expression="${type}" data-expression-label="${label}">${status === "empty" ? "生成" : "重新生成"}</button></article>`;
    }).join("")}</div>
    <div class="asset-toolbar"><button class="primary" data-action="generate-expressions">生成表情库</button><button class="secondary" data-action="add-expression">新增表情</button></div>
    <p class="card-sub">表情库不是必须第一步生成，但建议在正式制作前完成。它能让对白和情绪镜头更稳定。</p>`;
}

function outfitsTab(character) {
  return `<div class="character-panel-head"><div><h2>服装与道具</h2><p>默认形象必须稳定；场景服装和特殊剧情服装可以按集数管理。</p></div><button class="secondary" data-action="add-outfit">＋ 新增服装</button></div>
    <div class="outfit-grid">${character.outfits.map((outfit) => `<article class="outfit-card"><div class="outfit-visual"><span>♙</span><i style="background:${escapeHtml(outfit.mainColor || "#8b82ff")}"></i></div><div><div class="character-title-line"><h3>${escapeHtml(outfit.name)}</h3>${outfit.isDefault ? `<span class="status locked">默认</span>` : ""}</div><p>${escapeHtml(outfit.description || "待补充服装描述")}</p><small>${escapeHtml(outfit.usageScene || "未指定场景")} · 第 ${outfit.appearsInEpisodes.join("、") || "—"} 集</small></div><button data-toggle-outfit-lock="${outfit.id}">${outfit.isLocked ? "解锁" : "锁定"}</button></article>`).join("")}</div>
    <div class="character-form-section"><div class="character-panel-head"><div><h3>标志性道具</h3><p>关键道具可绑定相关剧情和出现集数。</p></div><button class="secondary" data-action="add-prop">＋ 新增道具</button></div>
    ${character.props.length ? `<div class="prop-list">${character.props.map((prop) => `<article><span>◇</span><div><strong>${escapeHtml(prop.name)}</strong><p>${escapeHtml(prop.description)} · ${escapeHtml(prop.storyMeaning)}</p><small>第 ${prop.appearsInEpisodes.join("、") || "—"} 集 ${prop.isKeyProp ? "· 关键线索" : ""}</small></div></article>`).join("")}</div>` : `<div class="asset-empty">还没有道具。可添加戒指盒、手机、武器等剧情物件。</div>`}</div>`;
}

function posesTab(character) {
  return `<div class="character-panel-head"><div><h2>姿势动作</h2><p>动作库用于后续镜头生成。当前可先使用 AI 自动生成，正式制作时再按镜头补充。</p></div></div>
    <div class="pose-grid">${POSE_TYPES.map(([type,label]) => {
      const reference = character.poseImages.find((item) => item.type === type);
      const status = reference?.status || "empty";
      return `<article class="pose-card"><div class="pose-visual ${status === "generating" ? "skeleton" : ""}"><div class="character-silhouette pose-${type}"><i></i><b></b></div></div><strong>${label}</strong><span class="status ${status}">${assetStateText(status)}</span></article>`;
    }).join("")}</div><div class="asset-toolbar"><button class="primary" data-action="generate-poses">AI 生成默认动作库</button></div>`;
}

function consistencyTab(character) {
  const report = character.consistencyReport;
  const checks = [
    ["基础设定完整", baseInfoReady(character)], ["三视图已生成", assetsReady(character.referenceImages,3)],
    ["三视图已锁定", threeViewsLocked(character)], ["发型明确", Boolean(character.appearance.hairStyle)],
    ["发色明确", Boolean(character.appearance.hairColor)], ["服装主色明确", Boolean(character.defaultOutfit.mainColor)],
    ["标志物明确", Boolean(character.accessories)], ["表情库已生成", assetsReady(character.expressionImages,6)],
    ["禁止变化项已填写", Boolean(character.forbiddenChanges.length)], ["无相互矛盾设定", (report?.issues || []).every((item) => item.level !== "critical")]
  ];
  return `<div class="character-panel-head"><div><h2>一致性检查</h2><p>连续漫剧最容易出现角色变脸。完成三视图和锁定项后，可以显著降低这个问题。</p></div></div>
    <div class="consistency-score-card"><div class="progress-ring" style="--progress:${report?.score || 0}"><strong>${report?.score ?? "—"}${report ? "%" : ""}</strong></div><div><h3>角色一致性评分</h3><p>${report ? report.score >= 85 ? "设定较完整，可以进入分镜制作。" : "仍有关键设定需要补充。" : "运行检查后，系统会评估角色资产完整度和冲突项。"}</p></div></div>
    <div class="consistency-check-grid">${checks.map(([label,passed]) => `<div class="${passed ? "passed" : ""}"><span>${passed ? "✓" : "!"}</span>${label}</div>`).join("")}</div>
    ${report?.issues?.length ? `<div class="consistency-issue-list">${report.issues.map((issue) => `<article class="${issue.level}"><span>!</span><div><strong>${escapeHtml(issue.title)}</strong><p>${escapeHtml(issue.description)}</p><small>建议：${escapeHtml(issue.suggestion)}</small></div></article>`).join("")}</div>` : ""}
    <div class="asset-toolbar"><button class="secondary" data-action="auto-complete-character">自动补全设定</button><button class="secondary" data-action="check-character">重新检查</button><button class="primary" data-action="confirm-lock-character">确认并锁定角色</button></div>`;
}

function promptsTab(character) {
  return `<div class="character-panel-head"><div><h2>高级 Prompt</h2><p>小白用户无需修改。这里用于高级用户微调角色生成提示词。</p></div></div>
    <details><summary>角色主 Prompt</summary><div class="details-body"><textarea data-character-field="prompts.master">${escapeHtml(character.prompts.master)}</textarea></div></details>
    <details><summary>三视图 Prompt</summary><div class="details-body"><textarea class="prompt-textarea" data-character-field="prompts.threeViews">${escapeHtml(character.prompts.threeViews)}</textarea></div></details>
    <details><summary>表情 Prompt</summary><div class="details-body"><textarea data-character-field="prompts.expression">${escapeHtml(character.prompts.expression)}</textarea></div></details>
    <details><summary>Negative Prompt</summary><div class="details-body"><textarea data-character-field="prompts.negative">${escapeHtml(character.prompts.negative)}</textarea></div></details>
    <details><summary>后续分镜继承 Prompt</summary><div class="details-body"><textarea class="prompt-textarea" data-character-field="prompts.inheritance">${escapeHtml(character.prompts.inheritance)}</textarea><p class="card-sub">这段内容会自动注入每个涉及该角色的 Shot 图像 Prompt。</p></div></details>`;
}

function characterField(label, field, value = "", className = "") {
  return `<label class="field ${className}"><span>${label}</span><input data-character-field="${field}" value="${escapeHtml(value || "")}" /></label>`;
}

function characterSelect(label, field, value, options) {
  return `<label class="field"><span>${label}</span><select data-character-field="${field}">${options.map((item) => `<option ${item === value ? "selected" : ""}>${item}</option>`).join("")}</select></label>`;
}

function saveCharacter(showToast = true) {
  const project = ensureProject();
  const character = project.characters.find((item) => item.id === activeCharacterId);
  if (!character) return;
  document.querySelectorAll("[data-character-field]").forEach((input) => {
    const field = input.dataset.characterField;
    let value = input.value;
    if (["lockedTraits","forbiddenChanges","appearance.visualKeywords"].includes(field)) value = splitList(value);
    setCharacterValue(character, field, value);
  });
  document.querySelectorAll("[data-character-lock]").forEach((input) => {
    character.lockOptions[input.dataset.characterLock] = input.checked;
  });
  character.hairStyle = character.appearance.hairStyle;
  character.hairColor = character.appearance.hairColor;
  character.outfit = character.defaultOutfit.description;
  character.marker = character.accessories;
  character.prompts.inheritance = characterLockPrompt(character);
  character.prompts.threeViews = characterReferencePrompt(character, project);
  characterProgress(character);
  patchProject({});
  if (showToast) toast("角色设定已保存");
}

async function generateCharacterAssets(kind, type = "", label = "") {
  saveCharacter(false);
  const project = ensureProject();
  const character = project.characters.find((item) => item.id === activeCharacterId);
  const specs = type ? [[type, label]] : kind === "views" ? THREE_VIEW_TYPES.map(([assetType, assetLabel]) => [assetType, assetLabel])
    : kind === "expressions" ? [["neutral","中性"],["happy","开心"],["sad","难过"],["angry","愤怒"],["shocked","震惊"],topicExpression(project.genre)]
    : kind === "poses" ? POSE_TYPES : [[type,label]];
  const collection = kind === "views" ? character.referenceImages : kind === "expressions" ? character.expressionImages : character.poseImages;
  specs.forEach(([assetType, assetLabel]) => {
    let reference = collection.find((item) => item.type === assetType);
    if (!reference) {
      reference = makeReference(character, assetType, assetLabel, kind === "expressions" ? expressionPrompt(character, assetLabel, project) : character.prompts.threeViews);
      collection.push(reference);
    }
    reference.status = "generating";
    reference.isLocked = false;
  });
  character.status = "generating";
  patchProject({});
  renderCharacters();
  await new Promise((resolve) => setTimeout(resolve, kind === "views" ? 1100 : 850));
  specs.forEach(([assetType]) => {
    const reference = collection.find((item) => item.type === assetType);
    reference.status = "generated";
    reference.createdAt = new Date().toISOString();
  });
  if (kind === "views" && !collection.some((item) => item.isPrimaryReference)) {
    const primary = collection.find((item) => item.type === "front_full_body") || collection.find((item) => item.type === type);
    if (primary) primary.isPrimaryReference = true;
  }
  character.status = "generated";
  characterProgress(character);
  patchProject({});
  renderCharacters();
  toast(`${character.name} 的${kind === "views" ? "三视图" : kind === "expressions" ? "表情库" : kind === "poses" ? "动作库" : label}已生成`);
}

function runCharacterConsistency(character) {
  const issues = [];
  if (!baseInfoReady(character)) issues.push({ id: "base", level: "warning", title: "基础设定不完整", description: "角色的年龄、性别、发型、服装或主色仍为空。", suggestion: "使用“自动补全设定”，或回到基础设定补充字段。" });
  if (!assetsReady(character.referenceImages, 3)) issues.push({ id: "views", level: "critical", title: "三视图尚未生成", description: "缺少统一的正面、侧面和背面全身参考。", suggestion: "先生成完整三视图。" });
  else if (!threeViewsLocked(character)) issues.push({ id: "lock", level: "critical", title: "三视图尚未锁定", description: "后续镜头无法稳定继承主参考。", suggestion: "检查三视图后点击“锁定三视图”。" });
  if (!character.defaultOutfit.mainColor) issues.push({ id: "color", level: "warning", title: "服装描述过于模糊", description: "默认服装缺少明确主色。", suggestion: "补充上衣、外套、下装和主色。" });
  if (!assetsReady(character.expressionImages, 6)) issues.push({ id: "expression", level: "info", title: "表情库尚未完成", description: "对白和情绪镜头可能需要临时重新设计表情。", suggestion: "正式制作前生成 6 个基础表情。" });
  const score = Math.max(35, 100 - issues.reduce((sum, item) => sum + (item.level === "critical" ? 18 : item.level === "warning" ? 10 : 5), 0));
  character.consistencyReport = { score, issues, checkedAt: new Date().toISOString() };
  character.status = issues.some((item) => item.level === "critical") ? "needs_review" : score >= 85 ? "locked" : "base_ready";
  characterProgress(character);
  return character.consistencyReport;
}

function injectCharacterPrompts(project, shots) {
  return shots.map((shot) => {
    const involved = project.characters.filter((character) => shot.characters.includes(character.id));
    const scene = project.scenes.find((item) => item.id === shot.sceneId);
    const locks = involved.map((character) => character.prompts?.inheritance || characterLockPrompt(character)).join("\n\n");
    const forbidden = [...new Set(involved.flatMap((character) => character.forbiddenChanges || []))];
    return {
      ...shot,
      prompt: `镜头画面描述：\n${shot.visualDescription}\n\n出现角色：\n${locks || "无角色"}\n\n场景：\n${scene?.description || shot.sceneName}\n\n画风：\n${project.styleBible?.visualStyle || project.style}；${project.styleBible?.lineStyle || ""}；${project.styleBible?.colorPalette || ""}\n\n镜头：\n${shot.shotSize}，${shot.cameraMotion}\n\n禁止：\n${forbidden.join("；")}\n不要改变角色脸型、发型、发色、服装主色。不要生成无关人物。不要出现文字、水印、Logo。`
    };
  });
}

async function proceedToStoryboard() {
  const project = ensureProject();
  buttonLoading(document.querySelector('[data-action="characters-next"]'), "AI 导演正在拆分镜头…");
  const shots = await callAgent("/api/agent/create-storyboard", project, () => createStoryboard(project));
  project.shots = injectCharacterPrompts(project, shots);
  patchProject({ status: "storyboarding", progress: 40 });
  modalRoot.innerHTML = "";
  go("/create/storyboard");
}

async function charactersNext(force = false) {
  saveCharacter(false);
  const project = ensureProject();
  const protagonists = project.characters.filter((item) => item.role === "protagonist");
  const incomplete = protagonists.filter((item) => !assetsReady(item.referenceImages, 3) || !threeViewsLocked(item)
    || !item.appearance.hairStyle || !item.defaultOutfit.description
    || !item.referenceImages.some((reference) => reference.isPrimaryReference) || !item.forbiddenChanges.length);
  if (!force && incomplete.length) {
    modalRoot.innerHTML = `<section class="modal"><div class="modal-warning-icon">!</div><h2>角色设定还不完整</h2><p>建议先完成主角三视图并锁定，这样后续分镜更稳定。</p><div class="modal-character-list">${incomplete.map((item) => `<span>${escapeHtml(item.name)}：缺少三视图、锁定项或主参考图</span>`).join("")}</div><div class="modal-actions"><button class="secondary" data-modal-close>继续完善角色</button><button class="primary" data-force-character-next>仍然进入分镜</button></div></section>`;
    return;
  }
  return proceedToStoryboard();
}

function shotStart(shots, index) {
  return shots.slice(0, index).reduce((sum, item) => sum + Number(item.duration), 0);
}

function timecode(seconds) {
  return `${String(Math.floor(seconds / 60)).padStart(2,"0")}:${String(seconds % 60).padStart(2,"0")}`;
}

function renderStoryboard() {
  const project = ensureProject();
  if (!project.shots.length) {
    page.innerHTML = `${stepper("storyboard")}${emptyState("▦","还没有分镜","请先确认角色，让 AI 导演把故事拆成镜头。","返回角色设定","/create/characters")}`;
    return;
  }
  const total = project.shots.reduce((sum,item) => sum + Number(item.duration), 0);
  page.innerHTML = `
    ${stepper("storyboard")}
    ${pageHead("分镜脚本", "每个分镜就是视频里的一个画面片段。你可以直接使用，也可以修改画面、台词和时长。", `<button class="secondary" data-action="pace-check">节奏检查</button>`)}
    <div class="notice info" style="margin-bottom:18px"><strong>分镜是什么？</strong> AI 把故事拆成一个个镜头，每个镜头会生成一张画面，并配上台词、动效和时长。</div>
    <div class="storyboard-stats">
      <div class="card stat-card"><strong>${project.shots.length}</strong><span>总镜头数</span></div>
      <div class="card stat-card"><strong>${total}s</strong><span>预计时长</span></div>
      <div class="card stat-card"><strong>${project.characters.length}</strong><span>主要角色</span></div>
      <div class="card stat-card"><strong>${project.scenes.length}</strong><span>场景数量</span></div>
    </div>
    <div class="shot-timeline">${project.shots.map((shot,index) => {
      const start = shotStart(project.shots,index);
      return `<div class="shot-row"><div class="shot-time">${timecode(start)} - ${timecode(start + Number(shot.duration))}<strong>镜头 ${String(index+1).padStart(2,"0")}</strong></div>
        <article class="card shot-card" data-shot-card="${shot.id}">
          <div class="shot-head"><h3>${escapeHtml(shot.sceneName)}</h3><span class="status">${shot.duration} 秒</span><span class="status">${escapeHtml(shot.emotion)}</span><span class="status ${shot.status}">${shot.status === "completed" ? "已生成" : "待生成"}</span></div>
          ${!shot.visualDescription || !shot.characters.length ? `<div class="notice warning" style="margin-bottom:13px">这个镜头缺少${!shot.visualDescription ? "画面描述" : "人物"}，建议补充后再生成。</div>` : ""}
          <div class="shot-content"><div class="shot-thumb">${String(index+1).padStart(2,"0")}<br>${escapeHtml(shot.shotSize)}</div><div class="shot-fields">
            <div><small>画面</small>${escapeHtml(shot.visualDescription)}</div><div><small>人物</small>${escapeHtml(shot.characterNames.join("、") || "无人物")}</div>
            <div><small>台词</small>${escapeHtml(shot.dialogue || "无")}</div><div><small>旁白</small>${escapeHtml(shot.narration || "无")}</div>
            <div><small>镜头运动</small>${escapeHtml(shot.cameraMotion)}</div><div><small>景别</small>${escapeHtml(shot.shotSize)}</div>
          </div></div>
          <div class="card-actions"><button data-shot-action="edit" data-id="${shot.id}">编辑</button><button data-shot-action="duplicate" data-id="${shot.id}">复制</button><button data-shot-action="up" data-id="${shot.id}">上移</button><button data-shot-action="down" data-id="${shot.id}">下移</button><button data-shot-action="regenerate" data-id="${shot.id}">重新生成</button><button data-shot-action="delete" data-id="${shot.id}">删除</button></div>
        </article></div>`;
    }).join("")}</div>
    ${stickyActions(`<button class="secondary" data-go="/create/characters">← 返回角色设定</button>`, `<button class="primary" data-action="start-generation">一键生成漫剧 →</button>`)}`;
}

function openShotModal(shotId) {
  const project = ensureProject();
  const shot = project.shots.find((item) => item.id === shotId);
  if (!shot) return;
  modalRoot.innerHTML = `<section class="modal"><h2>编辑镜头 ${shot.order}</h2><p>调整画面、台词、镜头运动和时长。</p>
    <div class="form-grid">
      <label class="textarea-field span-2"><span>画面描述</span><textarea id="modalVisual">${escapeHtml(shot.visualDescription)}</textarea></label>
      <label class="textarea-field span-2"><span>台词</span><textarea id="modalDialogue">${escapeHtml(shot.dialogue)}</textarea></label>
      <label class="textarea-field span-2"><span>旁白</span><textarea id="modalNarration">${escapeHtml(shot.narration)}</textarea></label>
      <label class="field"><span>景别</span><select id="modalShotSize">${["远景","中景","近景","特写"].map((item) => `<option ${shot.shotSize === item ? "selected" : ""}>${item}</option>`).join("")}</select></label>
      <label class="field"><span>镜头运动</span><select id="modalMotion">${["缓慢推进","横向平移","轻微震动","淡入淡出","静止"].map((item) => `<option ${shot.cameraMotion === item ? "selected" : ""}>${item}</option>`).join("")}</select></label>
      <label class="field"><span>时长（1–10 秒）</span><input id="modalDuration" type="number" min="1" max="10" value="${shot.duration}" /></label>
      <label class="field"><span>情绪</span><input id="modalEmotion" value="${escapeHtml(shot.emotion)}" /></label>
    </div>
    <div class="modal-actions"><button class="secondary" data-modal-close>取消</button><button class="primary" data-save-shot="${shot.id}">保存镜头</button></div></section>`;
}

function handleShotAction(action, id) {
  const project = ensureProject();
  const index = project.shots.findIndex((item) => item.id === id);
  if (index < 0) return;
  if (action === "edit") return openShotModal(id);
  if (action === "duplicate") {
    const copy = { ...project.shots[index], id: `shot_${Date.now()}`, modified: true };
    project.shots.splice(index + 1, 0, copy);
  }
  if (action === "up" && index > 0) [project.shots[index - 1], project.shots[index]] = [project.shots[index], project.shots[index - 1]];
  if (action === "down" && index < project.shots.length - 1) [project.shots[index + 1], project.shots[index]] = [project.shots[index], project.shots[index + 1]];
  if (action === "regenerate") {
    project.shots[index].status = "completed";
    project.shots[index].visualDescription += "（已由 AI 重新优化构图）";
    toast(`镜头 ${index + 1} 已重新生成`);
  }
  if (action === "delete") return confirmModal("删除这个镜头？", "删除后会重新计算总时长，你仍可通过复制其他镜头补回。", () => {
    project.shots.splice(index, 1); normalizeShots(project); renderStoryboard();
  });
  normalizeShots(project);
  renderStoryboard();
}

function normalizeShots(project) {
  project.shots.forEach((item, index) => { item.order = index + 1; });
  patchProject({});
}

function paceCheck() {
  const project = ensureProject();
  const long = project.shots.find((item) => item.duration > 5);
  modalRoot.innerHTML = `<section class="modal"><h2>节奏检查完成</h2><div class="notice success">✓ 节奏良好：前 5 秒有冲突，结尾保留了悬念。</div><p>${long ? `建议：第 ${long.order} 个镜头略长，可以从 ${long.duration} 秒缩短到 4 秒。` : "各镜头时长分布均衡，当前方案适合短视频观看。"}</p><div class="modal-actions"><button class="primary" data-modal-close>知道了</button></div></section>`;
}

function startGeneration() {
  const project = ensureProject();
  project.generationSteps = createGenerationSteps();
  project.generationLogs = [];
  project.progress = 0;
  project.status = "generating";
  project.canCancel = true;
  project.canRetry = false;
  patchProject({});
  go("/create/generating");
}

function renderGenerating() {
  const project = ensureProject();
  const complete = project.status === "completed";
  const failed = project.status === "failed";
  const activeStep = project.generationSteps.find((item) => item.status === "running");
  page.innerHTML = `
    ${stepper("generating")}
    ${pageHead(complete ? "你的漫剧已经生成完成！" : failed ? "生成中断了" : "AI 制作团队正在工作", complete ? "角色、画面、配音、字幕和视频已全部准备好。" : failed ? "可能是某个镜头描述不够清晰，或者生成服务暂时不可用。" : "你可以留在这里看制作过程，也可以稍后从项目列表回来。")}
    ${failed ? `<div class="notice danger" style="margin-bottom:18px">失败原因：${escapeHtml(project.generationError || "分镜画面生成超时")}。你可以重试当前步骤，或返回分镜页优化描述。</div>` : ""}
    <div class="generation-grid">
      <section class="card big-progress">
        <div class="progress-ring" style="--progress:${project.progress}"><strong>${project.progress}%</strong></div>
        <h2>${complete ? "制作完成" : failed ? "等待你的选择" : activeStep?.description || "正在准备制作流程"}</h2>
        <p class="card-sub">${complete ? `共生成 ${project.shots.length} 个镜头、${project.characters.length} 个角色和 1 条成片` : "预计剩余时间：大约几分钟（演示模式会更快）"}</p>
        <div class="generation-steps" style="margin-top:22px">${project.generationSteps.map((step) => `<div class="generation-step ${step.status}"><i>${step.status === "completed" ? "✓" : step.status === "running" ? "◌" : step.status === "failed" ? "!" : "·"}</i><div><strong>${step.name}</strong><small>${step.description}</small></div><span class="status ${step.status}">${({waiting:"等待中",running:"进行中",completed:"已完成",failed:"失败"})[step.status]}</span></div>`).join("")}</div>
      </section>
      <section class="card live-preview">
        <div class="live-art">${complete ? "成片预览已就绪" : activeStep?.name || "AI 制作团队"}</div>
        <div class="log-box" id="generationLog">${project.generationLogs.length ? project.generationLogs.map((item) => `<div>${escapeHtml(item)}</div>`).join("") : "<div>正在初始化 Agent 工作流…</div>"}</div>
      </section>
    </div>
    <div class="button-row" style="justify-content:center;margin-top:20px">
      ${complete ? `<button class="primary" data-go="/project/${project.id}/editor">立即预览</button><button class="secondary" data-go="/project/${project.id}/editor">继续编辑</button><button class="secondary" data-go="/project/${project.id}/export">导出视频</button>` :
      failed ? `<button class="primary" data-action="retry-generation">重试</button><button class="secondary" data-go="/create/storyboard">返回分镜</button><button class="secondary" data-action="view-logs">查看日志</button>` :
      `<button class="secondary" data-action="later">稍后查看</button><button class="danger-button" data-action="cancel-generation">取消生成</button>`}
    </div>`;
  if (project.status === "generating") runGeneration(project);
}

function runGeneration(project) {
  clearInterval(generationTimer);
  let stepIndex = project.generationSteps.findIndex((item) => item.status !== "completed");
  if (stepIndex < 0) return finishGeneration(project);
  const tick = () => {
    if (project.status !== "generating") return clearInterval(generationTimer);
    project.generationSteps.forEach((step, index) => {
      if (index < stepIndex) { step.status = "completed"; step.progress = 100; }
      else if (index === stepIndex) { step.status = "running"; step.progress = 55; project.currentStepId = step.id; }
    });
    project.progress = Math.min(96, Math.round((stepIndex / project.generationSteps.length) * 100 + 8));
    const step = project.generationSteps[stepIndex];
    project.generationLogs.push(`[${new Date().toLocaleTimeString("zh-CN",{hour:"2-digit",minute:"2-digit",second:"2-digit"})}] ${step.description}`);
    if (step.id === "artist") project.shots.forEach((shot, index) => { if (index <= stepIndex * 2) shot.status = "completed"; });
    step.status = "completed";
    step.progress = 100;
    project.progress = Math.min(96, Math.round(((stepIndex + 1) / project.generationSteps.length) * 100));
    saveState();
    stepIndex += 1;
    if (stepIndex >= project.generationSteps.length) {
      clearInterval(generationTimer);
      setTimeout(() => finishGeneration(project), 650);
    } else {
      renderGenerating();
    }
  };
  generationTimer = window.setTimeout(tick, 700);
}

function finishGeneration(project) {
  project.generationSteps.forEach((step) => { step.status = "completed"; step.progress = 100; });
  project.shots.forEach((shot) => { shot.status = "completed"; shot.imageUrl = `mock://${shot.id}`; });
  project.status = "completed";
  project.progress = 100;
  project.finalVideoUrl = `mock://video/${project.id}`;
  project.qualityReport = qualityCheck(project);
  project.assets = buildAssets(project);
  project.generationLogs.push(`[${new Date().toLocaleTimeString("zh-CN")}] 质量检查完成，成片已就绪`);
  patchProject({});
  renderGenerating();
}

function buildAssets(project) {
  return [
    ...project.characters.map((item) => ({ id: `asset_${item.id}`, projectId: project.id, type: "角色", name: `${item.name} 角色参考`, createdAt: new Date().toISOString() })),
    ...project.scenes.map((item) => ({ id: `asset_${item.id}`, projectId: project.id, type: "场景", name: item.name, createdAt: new Date().toISOString() })),
    ...project.shots.map((item) => ({ id: `asset_${item.id}`, projectId: project.id, type: "分镜图", name: `镜头 ${item.order} · ${item.sceneName}`, createdAt: new Date().toISOString() })),
    { id: `audio_${project.id}`, projectId: project.id, type: "音频", name: "完整配音与旁白", createdAt: new Date().toISOString() },
    { id: `video_${project.id}`, projectId: project.id, type: "视频", name: `${project.title} 成片`, createdAt: new Date().toISOString() },
    { id: `subtitle_${project.id}`, projectId: project.id, type: "字幕", name: `${project.title}.srt`, createdAt: new Date().toISOString() }
  ];
}

function routeProjectId(path) {
  return path.match(/^\/project\/([^/]+)/)?.[1] || "";
}

function setRouteProject(path) {
  const id = routeProjectId(path);
  if (id && state.projects.some((item) => item.id === id)) {
    state.currentProjectId = id;
    saveState();
  }
}

function renderEditor() {
  const project = ensureProject();
  if (!project.shots.length) return go("/create/storyboard");
  if (!activeShotId || !project.shots.some((item) => item.id === activeShotId)) activeShotId = project.shots[0].id;
  const shot = project.shots.find((item) => item.id === activeShotId);
  if (!editorDraft || editorDraft.id !== shot.id) editorDraft = { ...shot };
  page.classList.add("editor-shell");
  page.innerHTML = `
    ${pageHead(project.title, `${statusText(project.status)} · ${project.shots.length} 个镜头 · ${durationLabel(project.duration)} · ${project.aspectRatio}`, `<div class="button-row"><button class="secondary" data-action="regenerate-project">重新生成</button><button class="primary" data-go="/project/${project.id}/export">导出</button></div>`)}
    <div class="editor-grid">
      <aside class="card shot-sidebar">${project.shots.map((item,index) => `<button class="shot-list-item ${item.id === shot.id ? "active" : ""}" data-editor-shot="${item.id}"><div class="shot-thumb">${String(index+1).padStart(2,"0")}</div><span><strong>镜头 ${index+1}${item.modified ? " •" : ""}</strong><small>${item.duration}s · ${escapeHtml(item.sceneName)}</small></span></button>`).join("")}</aside>
      <section class="card player-card">
        <div class="video-stage"><div class="video-frame ratio-${project.aspectRatio.replace(":","-")}"><button class="play-button" data-action="toggle-play">${playing ? "Ⅱ" : "▶"}</button><span style="position:absolute;bottom:18px;left:18px;right:18px;text-align:center;font-weight:700">${escapeHtml(shot.dialogue || shot.narration || project.title)}</span></div></div>
        <div class="player-controls"><button class="icon-button" data-action="toggle-play">${playing ? "Ⅱ" : "▶"}</button><span id="playTime">${timecode(Math.round(project.duration * playbackProgress / 100))}</span><div class="progress"><span id="playProgress" style="width:${playbackProgress}%"></span></div><span>${timecode(project.duration)}</span></div>
        <div class="editor-timeline">${project.shots.map((item,index) => `<button class="timeline-clip ${item.id === shot.id ? "active" : ""}" style="--duration:${Math.max(1,item.duration)}" title="${escapeHtml(item.visualDescription)}" data-editor-shot="${item.id}">${index+1}</button>`).join("")}</div>
      </section>
      <aside class="card inspector">
        <p class="unsaved" ${hasEditorChanges(shot) ? "" : "hidden"}>有未保存修改</p>
        <h2>镜头 ${shot.order}</h2><p class="card-sub">${escapeHtml(shot.sceneName)} · ${shot.duration} 秒</p>
        <details open><summary>镜头画面</summary><div class="details-body"><label class="textarea-field"><span>画面描述</span><textarea data-editor-field="visualDescription">${escapeHtml(editorDraft.visualDescription)}</textarea></label><button class="secondary" style="margin-top:9px" data-action="regenerate-shot">重新生成画面</button></div></details>
        <details open><summary>台词与旁白</summary><div class="details-body"><label class="textarea-field"><span>台词</span><textarea data-editor-field="dialogue">${escapeHtml(editorDraft.dialogue)}</textarea></label><label class="textarea-field" style="margin-top:10px"><span>旁白</span><textarea data-editor-field="narration">${escapeHtml(editorDraft.narration)}</textarea></label></div></details>
        <details><summary>字幕样式</summary><div class="details-body"><label class="field"><span>样式</span><select data-editor-project="subtitleStyle">${["短视频大字","漫画气泡","底部白字","简洁无边框"].map((item) => `<option ${project.subtitleStyle === item ? "selected" : ""}>${item}</option>`).join("")}</select></label></div></details>
        <details><summary>镜头动效</summary><div class="details-body"><label class="field"><span>动效</span><select data-editor-field="cameraMotion">${["缓慢推进","横向平移","轻微震动","淡入淡出","静止"].map((item) => `<option ${editorDraft.cameraMotion === item ? "selected" : ""}>${item}</option>`).join("")}</select></label><label class="field" style="margin-top:10px"><span>时长</span><input type="number" min="1" max="10" data-editor-field="duration" value="${editorDraft.duration}" /></label></div></details>
        <div class="button-row" style="margin-top:17px"><button class="primary" data-action="save-editor-shot">保存当前镜头</button><button class="secondary" data-action="discard-editor">放弃修改</button><button class="secondary" data-action="recompose">重新合成</button></div>
      </aside>
    </div>`;
}

function hasEditorChanges(shot) {
  return editorDraft && ["visualDescription","dialogue","narration","cameraMotion","duration"].some((field) => String(editorDraft[field]) !== String(shot[field]));
}

function saveEditorShot() {
  const project = ensureProject();
  const shot = project.shots.find((item) => item.id === activeShotId);
  if (!shot) return;
  document.querySelectorAll("[data-editor-field]").forEach((input) => { editorDraft[input.dataset.editorField] = input.type === "number" ? Number(input.value) : input.value; });
  Object.assign(shot, editorDraft, { modified: true });
  const subtitle = document.querySelector("[data-editor-project='subtitleStyle']");
  if (subtitle) project.subtitleStyle = subtitle.value;
  patchProject({});
  toast("当前镜头已保存");
  editorDraft = { ...shot };
  renderEditor();
}

function togglePlayback() {
  playing = !playing;
  clearInterval(playbackTimer);
  if (playing) {
    playbackTimer = setInterval(() => {
      playbackProgress += 1;
      if (playbackProgress >= 100) { playbackProgress = 0; playing = false; clearInterval(playbackTimer); }
      const bar = document.querySelector("#playProgress");
      const time = document.querySelector("#playTime");
      if (bar) bar.style.width = `${playbackProgress}%`;
      if (time) time.textContent = timecode(Math.round(ensureProject().duration * playbackProgress / 100));
    }, 250);
  }
  renderEditor();
}

function renderExport() {
  const project = ensureProject();
  const unsaved = project.shots.filter((item) => item.modified && item.status !== "completed").length;
  page.innerHTML = `
    ${pageHead("导出与发布", "选择平台和清晰度，检查无误后生成最终文件。")}
    <div class="export-grid">
      <section class="card export-preview"><div class="video-frame ratio-${project.aspectRatio.replace(":","-")}"><button class="play-button">▶</button><span style="position:absolute;bottom:18px">${escapeHtml(project.title)}</span></div></section>
      <section class="card form-card">
        <h2>导出设置</h2><p class="card-sub">检测到 ${project.aspectRatio} ${project.aspectRatio === "9:16" ? "竖屏，推荐用于抖音、快手、小红书和 YouTube Shorts" : "画幅，请选择对应平台"}。</p>
        <div class="form-grid" style="margin-top:18px">
          <label class="field"><span>视频清晰度</span><select id="exportResolution"><option>720p</option><option selected>1080p</option><option>2K</option><option>4K · 高级版</option></select></label>
          <label class="field"><span>格式</span><select id="exportFormat"><option>MP4</option><option>MOV</option></select></label>
          <label class="field span-2"><span>平台预设</span><select id="exportPlatform"><option>抖音 / 快手 · 9:16</option><option>小红书 · 9:16 / 1:1</option><option>B站 · 16:9</option><option>YouTube Shorts · 9:16</option></select></label>
          <div class="toggle-row span-2"><div class="toggle-copy"><strong>导出字幕文件</strong><small>同时生成 SRT 文件。</small></div><label class="switch"><input id="exportSrt" type="checkbox" checked><i></i></label></div>
          <div class="toggle-row span-2"><div class="toggle-copy"><strong>导出分镜图片包</strong></div><label class="switch"><input id="exportShots" type="checkbox"><i></i></label></div>
          <div class="toggle-row span-2"><div class="toggle-copy"><strong>导出项目工程文件</strong></div><label class="switch"><input id="exportProject" type="checkbox"><i></i></label></div>
        </div>
        <h3 style="margin-top:20px">导出前检查</h3><div class="check-list">
          <div class="check-item ${project.status === "completed" ? "good" : "warn"}">视频${project.status === "completed" ? "已生成完成" : "尚未完成生成"}</div>
          <div class="check-item ${project.subtitleEnabled ? "good" : "warn"}">字幕${project.subtitleEnabled ? "已生成" : "未开启"}</div>
          <div class="check-item ${project.shots.some((item) => item.status === "failed") ? "warn" : "good"}">${project.shots.some((item) => item.status === "failed") ? "存在失败镜头" : "没有失败镜头"}</div>
          <div class="check-item ${unsaved ? "warn" : "good"}">${unsaved ? `还有 ${unsaved} 个镜头未保存` : "所有修改已保存"}</div>
        </div>
        <div id="exportProgress"></div>
        <div class="button-row"><button class="primary" data-action="start-export" ${project.status !== "completed" ? "disabled" : ""}>开始导出</button><button class="secondary" data-go="/project/${project.id}/editor">返回编辑</button></div>
      </section>
    </div>`;
}

function startExport(button) {
  buttonLoading(button, "正在导出 0%");
  let progress = 0;
  const node = document.querySelector("#exportProgress");
  node.innerHTML = `<div class="progress" style="margin:18px 0"><span style="width:0"></span></div>`;
  const timer = setInterval(() => {
    progress += 20;
    button.textContent = `正在导出 ${progress}%`;
    node.querySelector("span").style.width = `${progress}%`;
    if (progress >= 100) {
      clearInterval(timer);
      node.innerHTML = `<div class="notice success" style="margin:18px 0">✓ 导出完成。演示版本已生成模拟下载文件。</div><div class="button-row" style="margin-bottom:18px"><button class="secondary" data-action="download-video">下载视频</button><button class="secondary" data-action="download-srt">下载字幕</button><button class="secondary" data-action="copy-link">复制作品链接</button><button class="secondary" data-action="next-episode">创建下一集</button></div>`;
      button.textContent = "重新导出";
      button.disabled = false;
    }
  }, 350);
}

function downloadMock(type) {
  const project = ensureProject();
  const content = type === "srt" ? `1\n00:00:00,000 --> 00:00:04,000\n${project.shots[0]?.narration || project.title}\n` : `漫剧工厂 AI 演示导出\n项目：${project.title}\n格式：模拟视频文件\n`;
  const blob = new Blob([content], { type: type === "srt" ? "text/plain;charset=utf-8" : "text/plain;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `${project.title}.${type === "srt" ? "srt" : "mp4.txt"}`;
  link.click();
  URL.revokeObjectURL(link.href);
}

function allAssets() {
  return state.projects.flatMap((project) => (project.assets || []).map((asset) => ({ ...asset, projectTitle: project.title })));
}

function renderAssets() {
  const assets = allAssets().filter((item) => assetFilter === "全部" || item.type === assetFilter).filter((item) => `${item.name} ${item.projectTitle}`.toLowerCase().includes(searchTerm.toLowerCase()));
  page.innerHTML = `
    ${pageHead("素材库", "管理生成过的角色、场景、分镜图、配音、字幕和成片素材。")}
    <div class="filterbar">${["全部","角色","场景","分镜图","音频","视频","字幕"].map((item) => `<button class="chip ${assetFilter === item ? "active" : ""}" data-asset-filter="${item}">${item}</button>`).join("")}</div>
    ${assets.length ? `<div class="asset-grid">${assets.map((item) => `<article class="card asset-card"><div class="asset-thumb">${item.type === "音频" ? "♫" : item.type === "视频" ? "▶" : item.type === "字幕" ? "字" : item.type.slice(0,1)}</div><div class="project-body"><h3>${escapeHtml(item.name)}</h3><div class="meta-row"><span>${item.type}</span><span>·</span><span>${escapeHtml(item.projectTitle)}</span></div><div class="card-actions"><button>查看</button><button data-asset-reuse="${item.id}">复用</button><button data-asset-delete="${item.id}">删除</button></div></div></article>`).join("")}</div>` : emptyState("▣","素材库还是空的","完成一次生成后，角色、场景和音频会自动保存在这里。","去生成漫剧","/create")}`;
}

function renderTemplates() {
  const categories = ["全部","甜宠","逆袭","悬疑","搞笑","校园","古风","玄幻","职场"];
  const templates = TEMPLATES.filter((item) => templateFilter === "全部" || item.genre === templateFilter || (templateFilter === "逆袭" && item.id === "romance"));
  page.innerHTML = `
    ${pageHead("模板中心", "选择一个故事模板，快速生成你的第一条漫剧。")}
    <div class="filterbar">${categories.map((item) => `<button class="chip ${templateFilter === item ? "active" : ""}" data-template-filter="${item}">${item}</button>`).join("")}</div>
    ${templates.length ? `<div class="template-grid">${templates.map((item) => `<article class="card template-card"><div class="template-cover">${escapeHtml(item.title.slice(0,1))}</div><div class="project-body"><div class="meta-row"><span class="status">${item.genre}</span><span class="status">${item.style}</span></div><h3 style="margin-top:12px">${escapeHtml(item.title)}</h3><p>${escapeHtml(item.script)}</p><div class="meta-row"><span>推荐 ${durationLabel(item.duration)}</span><span>·</span><span>${item.users} 人使用</span></div><button class="primary small" style="width:100%;margin-top:14px" data-use-template="${item.id}">使用模板</button></div></article>`).join("")}</div>` : emptyState("◇","暂时没有找到匹配模板","可以换一个分类，或者直接从剧本开始。","从剧本开始","/create/script")}`;
}

function useTemplate(id) {
  const template = TEMPLATES.find((item) => item.id === id);
  if (!template) return;
  setCurrent(defaultProject({ title: template.title, script: template.script, genre: template.genre, style: template.style, duration: template.duration }));
  toast("模板已填入，推荐风格也设置好了");
  go("/create/script");
}

function renderSettings() {
  page.innerHTML = `
    ${pageHead("设置", "配置默认生成偏好、安全策略和本地数据。")}
    <div class="settings-grid">
      <section class="card settings-card"><h2>账户设置</h2><div class="form-grid"><label class="field span-2"><span>昵称</span><input value="${escapeHtml(noonAccountIdentity.displayName)}" readonly /></label><label class="field span-2"><span>电话号码</span><input value="${escapeHtml(noonAccountIdentity.phone || "未登录")}" readonly /></label></div><p class="card-sub account-sync-note">账户信息与 NoonAI 主页保持同步，如需修改昵称请前往主页的个人资料设置。</p></section>
      <section class="card settings-card"><h2>默认生成设置</h2><div class="form-grid">
        <label class="field"><span>默认画风</span><select data-setting="defaultStyle">${STYLES.map((item) => `<option ${settings.defaultStyle === item.id ? "selected" : ""}>${item.id}</option>`).join("")}</select></label>
        <label class="field"><span>默认画幅</span><select data-setting="defaultAspect">${["9:16","16:9","1:1"].map((item) => `<option ${settings.defaultAspect === item ? "selected" : ""}>${item}</option>`).join("")}</select></label>
        <label class="field"><span>默认节奏</span><select data-setting="defaultPace">${["慢节奏情绪型","标准短剧型","爽文快节奏"].map((item) => `<option ${settings.defaultPace === item ? "selected" : ""}>${item}</option>`).join("")}</select></label>
        <label class="field"><span>默认配音</span><select data-setting="defaultVoice">${["温柔女声","磁性男声","活泼少女","沉稳旁白"].map((item) => `<option ${settings.defaultVoice === item ? "selected" : ""}>${item}</option>`).join("")}</select></label>
      </div></section>
      <section class="card settings-card"><h2>成本与质量</h2><div class="option-row">${[["draft","草稿模式","快"],["standard","标准模式","推荐"],["high","高清模式","高质量"]].map(([id,label,desc]) => `<button class="option ${settings.quality === id ? "active" : ""}" data-setting-quality="${id}"><strong>${label}</strong><small>${desc}</small></button>`).join("")}</div></section>
      <section class="card settings-card"><h2>安全与版权</h2>
        ${[["safetyCheck","自动检测敏感内容"],["avoidIp","避免生成知名 IP 相似角色"],["avoidRealPeople","避免使用真实明星脸"]].map(([id,label]) => `<div class="toggle-row"><div class="toggle-copy"><strong>${label}</strong></div><label class="switch"><input data-setting="${id}" type="checkbox" ${settings[id] ? "checked" : ""}><i></i></label></div>`).join("")}
      </section>
      <section class="card settings-card" style="grid-column:1/-1"><h2>数据管理</h2><p class="card-sub">项目数据保存在当前浏览器。你可以导出备份，或清空全部本地项目。</p><div class="button-row" style="margin-top:16px"><button class="secondary" data-action="export-data">导出项目数据</button><button class="danger-button" data-action="clear-data">清空本地项目</button></div></section>
    </div>`;
}

function renderHelp() {
  page.innerHTML = `
    ${pageHead("帮助与新手引导", "不需要懂剪辑或 Prompt，跟着六步向导就能完成第一条漫剧。")}
    <section class="card pad"><h2>3 分钟快速上手</h2><div class="feature-grid" style="margin-top:18px">${[
      ["1","输入剧本","粘贴 300–1500 字故事"],
      ["2","选择风格","挑选画风、节奏与画幅"],
      ["3","确认角色","采用 AI 推荐并锁定形象"],
      ["4","确认分镜","像看时间线一样检查镜头"]
    ].map(([num,title,desc]) => `<div class="feature-card"><div class="feature-icon">${num}</div><h3>${title}</h3><p>${desc}</p></div>`).join("")}</div><div class="button-row" style="margin-top:18px"><button class="primary" data-go="/create">开始制作</button><button class="secondary" data-go="/templates">先看看示例</button></div></section>
    <section class="section"><div class="section-title"><div><h2>常见问题</h2><p>把专业术语翻译成容易执行的操作。</p></div></div><div class="faq-list">
      <details><summary>为什么角色会变？</summary><p>先在角色页生成参考图，再点击“锁定角色形象”。系统会把发型、服装、脸型和主色调写入每个镜头提示词。</p></details>
      <details><summary>如何让画风更统一？</summary><p>尽量不要在生成中途更换画风；如果需要更换，建议重新生成整套分镜画面。</p></details>
      <details><summary>如何缩短生成时间？</summary><p>在风格设置的高级选项中选择“草稿模式”，先确认构图和节奏，再切换到高清模式。</p></details>
      <details><summary>如何重新生成某个镜头？</summary><p>在分镜页或成片编辑器中选中镜头，点击“重新生成画面”，其他镜头不会受影响。</p></details>
      <details><summary>如何导出视频？</summary><p>生成完成后进入导出页，选择清晰度、格式和平台预设。演示版本会生成模拟下载文件。</p></details>
    </div></section>`;
}

function welcomeModal() {
  if (localStorage.getItem(WELCOME_KEY) === "1") return;
  modalRoot.innerHTML = `<section class="modal"><div class="feature-icon">漫</div><h2>欢迎来到漫剧工厂 AI</h2><p>三步理解这个产品：输入剧本 → 选择画风 → 一键生成漫剧。角色和分镜都可以在生成前修改。</p><div class="feature-grid" style="grid-template-columns:repeat(3,1fr);margin-top:18px"><div><strong>1. 输入剧本</strong><p>故事梗概也可以</p></div><div><strong>2. 选择画风</strong><p>无需编写 Prompt</p></div><div><strong>3. 一键生成</strong><p>过程随时可见</p></div></div><label style="display:flex;gap:8px;align-items:center;margin-top:18px;color:var(--muted);font-size:13px"><input id="hideWelcome" type="checkbox" style="width:auto;height:auto"> 以后不再显示</label><div class="modal-actions"><button class="secondary" data-welcome="examples">先看看示例</button><button class="primary" data-welcome="start">开始制作</button></div></section>`;
}

function confirmModal(title, description, onConfirm) {
  modalRoot.innerHTML = `<section class="modal"><h2>${title}</h2><p>${description}</p><div class="modal-actions"><button class="secondary" data-modal-close>取消</button><button class="danger-button" id="modalConfirm">确认</button></div></section>`;
  document.querySelector("#modalConfirm").onclick = () => { modalRoot.innerHTML = ""; onConfirm(); };
}

function toast(message) {
  const node = document.createElement("div");
  node.className = "toast";
  node.textContent = message;
  toastStack.append(node);
  setTimeout(() => node.remove(), 2600);
}

function buttonLoading(button, text) {
  if (!button) return;
  button.disabled = true;
  button.dataset.originalText = button.textContent;
  button.textContent = text;
}

function duplicateProject(id) {
  const original = state.projects.find((item) => item.id === id);
  if (!original) return;
  const copy = structuredClone(original);
  copy.id = `project_${Date.now()}`;
  copy.title = `${original.title} 副本`;
  copy.createdAt = copy.updatedAt = new Date().toISOString();
  state.projects.unshift(copy);
  saveState();
  toast("项目副本已创建");
  render();
}

function openProject(id) {
  const project = state.projects.find((item) => item.id === id);
  if (!project) return;
  state.currentProjectId = id;
  saveState();
  if (project.status === "completed") go(`/project/${id}/editor`);
  else if (project.status === "generating") go("/create/generating");
  else if (project.shots.length) go("/create/storyboard");
  else if (project.characters.length) go("/create/characters");
  else if (project.analysis) go("/create/analysis");
  else if (project.script) go("/create/style");
  else go("/create/script");
}

function handlePageClick(event) {
  const goButton = event.target.closest("[data-go]");
  if (goButton) return go(goButton.dataset.go);
  const create = event.target.closest("[data-create-mode]");
  if (create) {
    if (create.dataset.createMode === "series") {
      setCurrentSeries(createSeriesProject({
        style: settings.defaultStyle, aspectRatio: settings.defaultAspect,
        pace: settings.defaultPace, quality: settings.quality
      }));
      return go("/create/series-script");
    }
    setCurrent(defaultProject({ title: "未命名漫剧", script: create.dataset.createMode === "idea" ? "我有一个故事：主角在最失意的时候，意外发现了一个足以改变命运的秘密。" : "" }));
    return go("/create/script");
  }
  const filter = event.target.closest("[data-project-filter]");
  if (filter) { projectFilter = filter.dataset.projectFilter; return renderProjects(); }
  const projectAction = event.target.closest("[data-project-action]");
  if (projectAction) {
    const { projectAction: action, id } = projectAction.dataset;
    if (action === "open") return openProject(id);
    if (action === "duplicate") return duplicateProject(id);
    if (action === "export") { state.currentProjectId = id; saveState(); return go(`/project/${id}/export`); }
    if (action === "delete") return confirmModal("删除这个项目？", "项目、角色、分镜和本地素材会一起删除，此操作无法撤销。", () => {
      state.projects = state.projects.filter((item) => item.id !== id); if (state.currentProjectId === id) state.currentProjectId = ""; saveState(); renderProjects(); toast("项目已删除");
    });
  }
  const seriesAction = event.target.closest("[data-series-action]");
  if (seriesAction) {
    const series = state.seriesProjects.find((item)=>item.id===seriesAction.dataset.id);
    if (!series) return;
    state.activeSeriesId=series.id; saveState();
    if (seriesAction.dataset.seriesAction === "open" || seriesAction.dataset.seriesAction === "episodes") return go(`/series/${series.id}`);
    if (seriesAction.dataset.seriesAction === "batch") return openBatchModal();
    if (seriesAction.dataset.seriesAction === "delete") return confirmModal("删除这个连续漫剧系列？","长剧本、系列设定、全部集数和连续性报告都会删除。", async()=>{state.seriesProjects=state.seriesProjects.filter((item)=>item.id!==series.id); await deleteSeriesProject(series.id); if(state.activeSeriesId===series.id)state.activeSeriesId="";saveState();renderProjects();toast("系列项目已删除");});
  }
  if (event.target.closest('[data-action="save-series-script"]')) return readSeriesScriptForm(true);
  if (event.target.closest('[data-action="analyze-series"]')) return startSeriesAnalysis();
  if (event.target.closest('[data-action="reanalyze-series"]')) {
    const series=ensureSeries(); series.analysis=analyzeSeries(series); series.globalCharacters=series.analysis.characters; series.globalScenes=series.analysis.scenes; series.plotThreads=series.analysis.plotThreads; series.seriesBible=buildSeriesBible(series,series.analysis); series.episodes=planEpisodes(series,series.analysis); patchSeries({},series,0); toast("全局分析已更新"); return renderSeriesAnalysis();
  }
  const bibleSection = event.target.closest("[data-bible-section]");
  if (bibleSection) { saveBible(false); activeBibleSection=bibleSection.dataset.bibleSection; return renderSeriesBible(); }
  if (event.target.closest('[data-action="save-bible"]')) return saveBible();
  if (event.target.closest('[data-action="add-continuity-rule"]')) { const s=ensureSeries(); s.seriesBible.continuityRules.push("新增连续性规则"); patchSeries({},s,0); return renderSeriesBible(); }
  if (event.target.closest('[data-action="add-forbidden"]')) { const value=document.querySelector("#newForbidden")?.value.trim(); if(value){const s=ensureSeries();s.seriesBible.forbiddenChanges.push(value);patchSeries({},s,0);renderSeriesBible();toast("禁止变化项已添加");} }
  const charAction=event.target.closest("[data-series-character-action]");
  if(charAction){const s=ensureSeries();const c=s.globalCharacters.find((item)=>item.id===charAction.dataset.id);if(!c)return;if(charAction.dataset.seriesCharacterAction==="generate"){c.referenceImages=["mock-reference"];c.status="generated";toast(`${c.name} 的参考图已生成`);}if(charAction.dataset.seriesCharacterAction==="lock"){c.status="locked";toast(`${c.name} 已跨集锁定`);}if(charAction.dataset.seriesCharacterAction==="relations"){modalRoot.innerHTML=`<section class="modal"><h2>${escapeHtml(c.name)} · 角色关系</h2>${c.relationshipMap.length?c.relationshipMap.map((r)=>{const target=s.globalCharacters.find((i)=>i.id===r.targetCharacterId);return `<div class="mini-card"><strong>${escapeHtml(r.relationType)} · ${escapeHtml(target?.name||"未知角色")}</strong><p>${escapeHtml(r.description)}</p></div>`}).join(""):`<p>当前没有已记录的关系变化。</p>`}<div class="modal-actions"><button class="primary" data-modal-close>知道了</button></div></section>`;return;}patchSeries({},s,0);renderSeriesBible();}
  const sceneAction=event.target.closest("[data-series-scene-action]");
  if(sceneAction){const s=ensureSeries();const scene=s.globalScenes.find((item)=>item.id===sceneAction.dataset.id);if(sceneAction.dataset.seriesSceneAction==="generate"){scene.referenceImages=["mock-reference"];toast(`${scene.name} 的场景参考图已生成`);}else{scene.locked=true;toast(`${scene.name} 已锁定背景结构`);}patchSeries({},s,0);renderSeriesBible();}
  const episodeAction=event.target.closest("[data-episode-action]"); if(episodeAction) return handleEpisodeAction(episodeAction.dataset.episodeAction,episodeAction.dataset.id);
  if(event.target.closest('[data-action="optimize-episodes"]')){const s=ensureSeries();s.episodes.forEach((ep,i)=>{ep.emotionalBeat=["冲突升级","信息反转","情绪爆发"][i%3]});patchSeries({},s,0);toast("已优化每 3–5 集的小高潮节奏");return renderEpisodePlan();}
  if(event.target.closest('[data-action="strengthen-hooks"]')){const s=ensureSeries();s.episodes.forEach((ep)=>{ep.endingHook=`${ep.endingHook} 镜头在答案揭晓前切黑。`});patchSeries({},s,0);toast("所有结尾钩子已强化");return renderEpisodePlan();}
  if(event.target.closest('[data-action="check-series-continuity"]')){const s=ensureSeries();const report=checkContinuity(s);s.continuityReports.push(report);patchSeries({},s,0);toast(`连续性检查完成：${report.score} 分`);return routePath().startsWith("/series/")?renderSeriesDetail(s.id):renderEpisodePlan();}
  if(event.target.closest('[data-action="open-batch-modal"]')) return openBatchModal();
  if(event.target.closest('[data-action="batch-first-three"]')) return openBatchModal("first3");
  if(event.target.closest('[data-action="load-more-episodes"]')){visibleEpisodeCount=Math.min(visibleEpisodeCount+10,ensureSeries().episodes.length);return renderEpisodePlan();}
  if(event.target.closest('[data-action="continue-series"]')){const s=ensureSeries();const ep=s.episodes.find((item)=>item.status!=="completed")||s.episodes[0];return ep&&go(`/series/${s.id}/episode/${ep.id}/storyboard`);}
  const seriesEpisode=event.target.closest("[data-series-episode]");if(seriesEpisode){const s=ensureSeries();return go(`/series/${s.id}/episode/${seriesEpisode.dataset.seriesEpisode}/storyboard`);}
  const generateEpisode=event.target.closest("[data-generate-series-episode]");if(generateEpisode){const s=ensureSeries();return startSeriesEpisodeGeneration(s.id,generateEpisode.dataset.generateSeriesEpisode);}
  if(event.target.closest('[data-action="cancel-batch"]')){const s=ensureSeries();s.batchJob.status="cancelled";patchSeries({},s,0);toast("批量任务已取消，可稍后继续");return go(`/series/${s.id}`);}
  const autoFix=event.target.closest("[data-auto-fix]");if(autoFix){const s=ensureSeries();s.globalCharacters.forEach((item)=>item.status="locked");patchSeries({},s,0);toast("已把锁定特征加入后续镜头 Prompt");return renderSeriesDetail(s.id);}
  const example = event.target.closest("[data-example]");
  if (example) {
    const item = EXAMPLES.find((entry) => entry.id === example.dataset.example);
    document.querySelector("#scriptTitle").value = item.title; document.querySelector("#scriptContent").value = item.script; document.querySelector("#scriptGenre").value = item.genre; updateScriptFeedback(); saveScriptForm(); toast("示例已填入");
  }
  if (event.target.closest('[data-action="save-script"]')) return saveScriptForm(true);
  if (event.target.closest('[data-action="script-next"]')) {
    const project = saveScriptForm();
    if (!document.querySelector("#scriptTitle").value.trim()) return toast("请先输入项目名称");
    if (project.script.trim().length < 50) return toast("剧本内容太短，建议至少输入 50 字");
    return go("/create/style");
  }
  const style = event.target.closest("[data-style]"); if (style) { patchProject({ style: style.dataset.style }); renderStyle(); }
  const pace = event.target.closest("[data-pace]"); if (pace) { patchProject({ pace: pace.dataset.pace }); renderStyle(); }
  const aspect = event.target.closest("[data-aspect]"); if (aspect) { patchProject({ aspectRatio: aspect.dataset.aspect }); renderStyle(); }
  const quality = event.target.closest("[data-quality]"); if (quality) { patchProject({ quality: quality.dataset.quality }); renderStyle(); }
  if (event.target.closest('[data-action="save-style"]')) { readStyleForm(); toast("生成方案已保存"); }
  if (event.target.closest('[data-action="style-next"]')) return startAnalysis();
  if (event.target.closest('[data-action="reanalyze"]')) return reanalyze();
  const characterTab = event.target.closest("[data-character]"); if (characterTab) { saveCharacter(false); activeCharacterId = characterTab.dataset.character; activeCharacterTab = "base"; renderCharacters(); }
  const workbenchTab = event.target.closest("[data-character-tab]"); if (workbenchTab) { saveCharacter(false); activeCharacterTab = workbenchTab.dataset.characterTab; return renderCharacters(); }
  if (event.target.closest('[data-action="save-character"]')) return saveCharacter();
  if (event.target.closest('[data-action="generate-three-views"]')) return generateCharacterAssets("views");
  if (event.target.closest('[data-action="generate-expressions"]')) return generateCharacterAssets("expressions");
  if (event.target.closest('[data-action="generate-poses"]')) return generateCharacterAssets("poses");
  const generateReference = event.target.closest("[data-generate-reference]"); if (generateReference) return generateCharacterAssets("views", generateReference.dataset.generateReference, THREE_VIEW_TYPES.find(([type]) => type === generateReference.dataset.generateReference)?.[1]);
  const generateExpression = event.target.closest("[data-generate-expression]"); if (generateExpression) return generateCharacterAssets("expressions", generateExpression.dataset.generateExpression, generateExpression.dataset.expressionLabel);
  if (event.target.closest('[data-action="lock-three-views"]')) {
    const c = ensureProject().characters.find((item) => item.id === activeCharacterId); const shouldLock = !threeViewsLocked(c);
    c.referenceImages.filter((item) => THREE_VIEW_TYPES.some(([type]) => type === item.type)).forEach((item) => { item.isLocked = shouldLock; item.status = shouldLock ? "locked" : "generated"; });
    c.status = shouldLock ? "three_views_ready" : "base_ready"; patchProject({}); toast(shouldLock ? "三视图已锁定" : "三视图已解锁"); return renderCharacters();
  }
  const primaryReference = event.target.closest("[data-primary-reference]"); if (primaryReference) {
    const c = ensureProject().characters.find((item) => item.id === activeCharacterId); c.referenceImages.forEach((item) => item.isPrimaryReference = item.id === primaryReference.dataset.primaryReference);
    c.masterReferenceImageId = primaryReference.dataset.primaryReference; patchProject({}); toast("已设为主参考图"); return renderCharacters();
  }
  const viewReference = event.target.closest("[data-view-reference]"); if (viewReference) {
    const c = ensureProject().characters.find((item) => item.id === activeCharacterId); const reference = c.referenceImages.find((item) => item.id === viewReference.dataset.viewReference);
    modalRoot.innerHTML = `<section class="modal reference-modal"><div class="reference-visual"><div class="character-silhouette ${THREE_VIEW_TYPES.find(([type]) => type === reference.type)?.[2] || "front"}"><i></i><b></b></div></div><h2>${escapeHtml(c.name)} · ${escapeHtml(reference.label)}</h2><p>Mock 角色参考图 · ${assetStateText(reference.status)}</p><div class="modal-actions"><button class="danger-button" data-delete-reference="${reference.id}">删除参考图</button><button class="primary" data-modal-close>关闭</button></div></section>`; return;
  }
  if (event.target.closest('[data-action="recommend-character"]') || event.target.closest('[data-action="auto-complete-character"]')) {
    const c = ensureProject().characters.find((item) => item.id === activeCharacterId); normalizeCharacter(c, ensureProject());
    c.age ||= "24"; c.gender ||= c.role === "protagonist" ? "女" : "男"; c.appearance.faceShape ||= "柔和鹅蛋脸"; c.appearance.eyeStyle ||= "清晰杏眼，眼神坚定";
    c.appearance.hairStyle ||= "自然微卷长发"; c.appearance.hairColor ||= "黑色"; c.appearance.bodyType ||= "修长匀称"; c.appearance.ageLook ||= "青年";
    c.defaultOutfit.description ||= "米白衬衫、浅灰外套与深色长裤"; c.defaultOutfit.mainColor ||= "米白与浅灰"; c.accessories ||= "细银耳饰";
    c.commonProps ||= "手机"; c.forbiddenChanges = ["不改变发色","不改变脸型","不改变服装主色","不改变年龄感","不生成无关人物"];
    c.prompts.threeViews = characterReferencePrompt(c, ensureProject()); c.prompts.inheritance = characterLockPrompt(c); patchProject({}); toast("已补充 AI 推荐设定，保留了手动内容"); return renderCharacters();
  }
  if (event.target.closest('[data-action="check-character"]')) { const c = ensureProject().characters.find((item) => item.id === activeCharacterId); const report = runCharacterConsistency(c); patchProject({}); toast(`一致性检查完成：${report.score}%`); return renderCharacters(); }
  if (event.target.closest('[data-action="confirm-lock-character"]')) {
    const c = ensureProject().characters.find((item) => item.id === activeCharacterId); c.referenceImages.forEach((item) => { if (item.status === "generated") item.status = "locked"; item.isLocked = true; });
    if (!c.referenceImages.some((item) => item.isPrimaryReference) && c.referenceImages.length) c.referenceImages[0].isPrimaryReference = true;
    const report = runCharacterConsistency(c); c.status = report.score >= 75 ? "locked" : "needs_review"; patchProject({}); toast(report.score >= 75 ? "角色已确认并锁定" : "仍有关键问题，请继续完善"); return renderCharacters();
  }
  if (event.target.closest('[data-action="add-outfit"]')) {
    modalRoot.innerHTML = `<section class="modal"><h2>新增服装</h2><p>为场景服装、正式服装或特殊剧情服装建立可复用设定。</p><div class="form-grid"><label class="field"><span>名称</span><input id="newOutfitName" placeholder="例如：正式酒会礼服"></label><label class="field"><span>使用场景</span><input id="newOutfitScene" placeholder="例如：商业酒会"></label><label class="field span-2"><span>服装描述</span><input id="newOutfitDescription" placeholder="上衣、外套、下装与材质"></label><label class="field"><span>主色</span><input id="newOutfitColor" placeholder="例如：深蓝与银色"></label><label class="field"><span>出现集数</span><input id="newOutfitEpisodes" placeholder="例如：1、3、8"></label></div><div class="modal-actions"><button class="secondary" data-modal-close>取消</button><button class="primary" data-save-new-outfit>保存服装</button></div></section>`; return;
  }
  const outfitLock = event.target.closest("[data-toggle-outfit-lock]"); if (outfitLock) { const c = ensureProject().characters.find((item) => item.id === activeCharacterId); const outfit = c.outfits.find((item) => item.id === outfitLock.dataset.toggleOutfitLock); outfit.isLocked = !outfit.isLocked; patchProject({}); return renderCharacters(); }
  if (event.target.closest('[data-action="add-prop"]')) {
    modalRoot.innerHTML = `<section class="modal"><h2>新增道具</h2><p>记录道具的剧情意义和出现集数，便于后续镜头持续继承。</p><div class="form-grid"><label class="field"><span>道具名称</span><input id="newPropName" placeholder="例如：戒指盒"></label><label class="field"><span>出现集数</span><input id="newPropEpisodes" placeholder="例如：1、8"></label><label class="field span-2"><span>道具描述</span><input id="newPropDescription" placeholder="外观、材质与颜色"></label><label class="field span-2"><span>相关剧情</span><input id="newPropMeaning" placeholder="例如：退婚剧情关键道具"></label><label class="toggle-row span-2"><span class="toggle-copy"><strong>关键线索</strong><small>后续分镜会优先保留这个道具。</small></span><span class="switch"><input id="newPropKey" type="checkbox"><i></i></span></label></div><div class="modal-actions"><button class="secondary" data-modal-close>取消</button><button class="primary" data-save-new-prop>保存道具</button></div></section>`; return;
  }
  if (event.target.closest('[data-action="add-expression"]')) {
    modalRoot.innerHTML = `<section class="modal"><h2>新增表情</h2><p>添加一个题材或剧情专属表情，生成时会继承已锁定的角色外形。</p><div class="form-grid"><label class="field"><span>表情名称</span><input id="newExpressionName" placeholder="例如：心动"></label><label class="field"><span>情绪说明</span><input id="newExpressionDescription" placeholder="例如：克制地露出惊喜"></label></div><div class="modal-actions"><button class="secondary" data-modal-close>取消</button><button class="primary" data-save-new-expression>添加并生成</button></div></section>`; return;
  }
  if (event.target.closest('[data-action="add-character"]') || event.target.closest('[data-action="add-analysis-character"]')) {
    modalRoot.innerHTML = `<section class="modal"><h2>新增角色</h2><p>先填写最基本的信息，进入工作台后可继续完善三视图、表情和服装资产。</p><div class="form-grid">${characterField("姓名","new.name","")}${characterField("身份","new.identity","")}${characterSelect("角色重要度","new.importance","主要配角",["核心主角","主要配角","普通配角","反派","群演"])}${characterSelect("性别","new.gender","女",["女","男","非二元","未设定"])}${characterField("年龄","new.age","")}${characterField("简短描述","new.description","","span-2")}</div><div class="modal-actions"><button class="secondary" data-modal-close>取消</button><button class="primary" data-save-new-character>创建角色</button></div></section>`; return;
  }
  if (event.target.closest('[data-action="characters-next"]')) return charactersNext();
  const shotAction = event.target.closest("[data-shot-action]"); if (shotAction) return handleShotAction(shotAction.dataset.shotAction, shotAction.dataset.id);
  if (event.target.closest('[data-action="pace-check"]')) return paceCheck();
  if (event.target.closest('[data-action="start-generation"]')) return startGeneration();
  if (event.target.closest('[data-action="later"]')) { toast("任务已保存，可从项目列表继续查看"); return go("/projects"); }
  if (event.target.closest('[data-action="cancel-generation"]')) return confirmModal("取消这次生成？", "已完成的角色和分镜会保留，你可以稍后恢复。", () => { clearInterval(generationTimer); patchProject({ status:"draft", canCancel:false }); go("/projects"); });
  if (event.target.closest('[data-action="retry-generation"]')) { const p=ensureProject(); p.status="generating"; p.canRetry=false; const failed=p.generationSteps.find((s)=>s.status==="failed"); if(failed) failed.status="waiting"; patchProject({}); return renderGenerating(); }
  const editorShot = event.target.closest("[data-editor-shot]"); if (editorShot) { activeShotId = editorShot.dataset.editorShot; editorDraft = null; return renderEditor(); }
  if (event.target.closest('[data-action="toggle-play"]')) return togglePlayback();
  if (event.target.closest('[data-action="save-editor-shot"]')) return saveEditorShot();
  if (event.target.closest('[data-action="discard-editor"]')) { editorDraft = null; toast("已放弃未保存修改"); return renderEditor(); }
  if (event.target.closest('[data-action="regenerate-shot"]')) { editorDraft.visualDescription += "，重新优化人物构图与电影光影"; toast("画面已重新生成"); return renderEditor(); }
  if (event.target.closest('[data-action="recompose"]')) { saveEditorShot(); toast("当前镜头已重新合成"); }
  if (event.target.closest('[data-action="regenerate-project"]')) return startGeneration();
  const exportButton = event.target.closest('[data-action="start-export"]'); if (exportButton) return startExport(exportButton);
  if (event.target.closest('[data-action="download-video"]')) return downloadMock("video");
  if (event.target.closest('[data-action="download-srt"]')) return downloadMock("srt");
  if (event.target.closest('[data-action="copy-link"]')) { navigator.clipboard?.writeText(location.href); return toast("作品链接已复制"); }
  if (event.target.closest('[data-action="next-episode"]')) { const p=ensureProject(); setCurrent(defaultProject({ title:`${p.title} · 下一集`, genre:p.genre, style:p.style, pace:p.pace, aspectRatio:p.aspectRatio })); return go("/create/script"); }
  const assetFilterButton = event.target.closest("[data-asset-filter]"); if (assetFilterButton) { assetFilter = assetFilterButton.dataset.assetFilter; return renderAssets(); }
  const templateFilterButton = event.target.closest("[data-template-filter]"); if (templateFilterButton) { templateFilter = templateFilterButton.dataset.templateFilter; return renderTemplates(); }
  const template = event.target.closest("[data-use-template]"); if (template) return useTemplate(template.dataset.useTemplate);
  const settingQuality = event.target.closest("[data-setting-quality]"); if (settingQuality) { settings.quality = settingQuality.dataset.settingQuality; saveSettings(); renderSettings(); toast("默认质量已更新"); }
  if (event.target.closest('[data-action="export-data"]')) { const blob = new Blob([JSON.stringify(state,null,2)],{type:"application/json"}); const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="漫剧工厂项目备份.json"; a.click(); URL.revokeObjectURL(a.href); }
  if (event.target.closest('[data-action="clear-data"]')) return confirmModal("清空全部本地项目？","所有项目、角色、分镜和素材都会被删除。",()=>{state.projects=[];state.currentProjectId="";saveState();renderSettings();toast("本地项目已清空");});
}

function updateScriptFeedback() {
  const content = document.querySelector("#scriptContent");
  if (!content) return;
  const count = content.value.length;
  document.querySelector("#scriptCount").textContent = count;
  const [type, text] = scriptNotice(count);
  const notice = document.querySelector("#scriptNotice");
  notice.className = `notice ${type} span-2`;
  notice.textContent = text;
}

function handlePageInput(event) {
  if (event.target.id === "scriptContent") { updateScriptFeedback(); saveScriptForm(); }
  if (["scriptTitle","scriptGenre","scriptDuration","optimizeScript"].includes(event.target.id)) saveScriptForm();
  if (event.target.id === "seriesContent") { updateSeriesScriptFeedback(); readSeriesScriptForm(); }
  if (["seriesTitle","seriesGenre","seriesDuration","seriesSplitMode","seriesDensity","seriesTargetCount"].includes(event.target.id)) { updateSeriesScriptFeedback(); readSeriesScriptForm(); }
  if (event.target.matches("[data-bible-field],[data-style-bible-field]")) saveBible(false);
  if (["voiceEnabled","voiceType","voiceSpeed","subtitleEnabled","subtitleStyle","autoCover","bgm"].includes(event.target.id)) { readStyleForm(); updateStyleSummary(); }
  if (event.target.matches("[data-editor-field]")) {
    editorDraft[event.target.dataset.editorField] = event.target.type === "number" ? Number(event.target.value) : event.target.value;
    const flag = document.querySelector(".unsaved"); if (flag) flag.hidden = false;
  }
  if (event.target.matches("[data-setting]")) {
    settings[event.target.dataset.setting] = event.target.type === "checkbox" ? event.target.checked : event.target.value;
    saveSettings(); toast("设置已保存");
  }
}

function render() {
  clearTimeout(generationTimer);
  page.classList.remove("editor-shell");
  setRouteProject(routePath());
  const path = routePath();
  updateTopbar(path);
  document.querySelectorAll("[data-route]").forEach((link) => {
    const route = link.dataset.route;
    link.classList.toggle("active", route === "/" ? path === "/" : path.startsWith(route));
  });
  if (path === "/") renderDashboard();
  else if (path === "/projects") renderProjects();
  else if (path === "/create") renderCreate();
  else if (path === "/create/script") renderScript();
  else if (path === "/create/series-script") renderSeriesScript();
  else if (path === "/create/series-analysis") renderSeriesAnalysis();
  else if (path === "/create/series-bible") renderSeriesBible();
  else if (path === "/create/episode-plan") renderEpisodePlan();
  else if (path === "/create/style") renderStyle();
  else if (path === "/create/analysis") renderAnalysis();
  else if (path === "/create/characters") renderCharacters();
  else if (path === "/create/storyboard") renderStoryboard();
  else if (path === "/create/generating") renderGenerating();
  else if (/^\/project\/[^/]+\/editor$/.test(path)) renderEditor();
  else if (/^\/project\/[^/]+\/export$/.test(path)) renderExport();
  else if (/^\/series\/[^/]+\/episode\/[^/]+\/storyboard$/.test(path)) { const parts=routeSeriesParts(path); renderSeriesEpisodeStoryboard(parts.seriesId,parts.episodeId); }
  else if (/^\/series\/[^/]+\/episode\/[^/]+\/generating$/.test(path)) { const parts=routeSeriesParts(path); renderSeriesEpisodeGenerating(parts.seriesId,parts.episodeId); }
  else if (/^\/series\/[^/]+\/batch-generate$/.test(path)) { const parts=routeSeriesParts(path); renderBatchGeneration(parts.seriesId); }
  else if (/^\/series\/[^/]+$/.test(path)) { const parts=routeSeriesParts(path); renderSeriesDetail(parts.seriesId); }
  else if (path === "/assets") renderAssets();
  else if (path === "/templates") renderTemplates();
  else if (path === "/settings") renderSettings();
  else if (path === "/help") renderHelp();
  else renderDashboard();
  page.focus({ preventScroll: true });
  window.scrollTo({ top: 0, behavior: "instant" });
}

page.addEventListener("click", handlePageClick);
page.addEventListener("input", handlePageInput);
page.addEventListener("change", handlePageInput);
document.addEventListener("click", (event) => {
  const globalGo = event.target.closest("[data-go]");
  if (globalGo && !page.contains(globalGo)) {
    workspaceMenu.hidden = true;
    return go(globalGo.dataset.go);
  }
  const createShortcut = event.target.closest("[data-create-shortcut]");
  if (createShortcut) return startCreateShortcut(createShortcut.dataset.createShortcut);
  const searchGo = event.target.closest("[data-search-go]");
  if (searchGo) {
    searchSuggestions.hidden = true;
    shell.classList.remove("menu-open");
    return go(searchGo.dataset.searchGo);
  }
  if (event.target.closest("[data-modal-close]")) modalRoot.innerHTML = "";
  if (event.target.closest("[data-force-character-next]")) charactersNext(true);
  if (event.target.closest("[data-save-new-character]")) {
    const fields = Object.fromEntries([...modalRoot.querySelectorAll("[data-character-field^='new.']")].map((input) => [input.dataset.characterField.slice(4), input.value.trim()]));
    if (!fields.name || !fields.identity) return toast("请填写角色姓名和身份");
    const project = ensureProject();
    const role = fields.importance === "核心主角" ? "protagonist" : fields.importance === "反派" ? "villain" : fields.importance === "群演" ? "extra" : fields.importance === "普通配角" ? "supporting" : "main_supporting";
    const character = normalizeCharacter({ id:`char_${Date.now()}`, name:fields.name, identity:fields.identity, importance:fields.importance, role, gender:fields.gender, age:fields.age, personality:fields.description || "待设置", visualKeywords:[], needsVoice:true, referenceImages:[], expressionImages:[], poseImages:[], status:"draft" }, project, project.characters.length);
    project.characters.push(character); activeCharacterId = character.id; activeCharacterTab = "base"; patchProject({}); modalRoot.innerHTML = ""; go("/create/characters"); renderCharacters(); toast("新角色已创建");
  }
  if (event.target.closest("[data-save-new-outfit]")) {
    const character = ensureProject().characters.find((item) => item.id === activeCharacterId);
    const name = document.querySelector("#newOutfitName")?.value.trim();
    if (!name) return toast("请填写服装名称");
    character.outfits.push({
      id:`outfit_${Date.now()}`, name,
      description: document.querySelector("#newOutfitDescription")?.value.trim() || "待补充服装描述",
      mainColor: document.querySelector("#newOutfitColor")?.value.trim() || "待设定",
      usageScene: document.querySelector("#newOutfitScene")?.value.trim() || "特殊剧情",
      appearsInEpisodes: splitList(document.querySelector("#newOutfitEpisodes")?.value).map(Number).filter(Boolean),
      referenceImageUrl:"", isDefault:false, isLocked:false
    });
    patchProject({}); modalRoot.innerHTML = ""; renderCharacters(); toast("服装设定已添加");
  }
  if (event.target.closest("[data-save-new-prop]")) {
    const character = ensureProject().characters.find((item) => item.id === activeCharacterId);
    const name = document.querySelector("#newPropName")?.value.trim();
    if (!name) return toast("请填写道具名称");
    character.props.push({
      id:`prop_${Date.now()}`, name,
      description: document.querySelector("#newPropDescription")?.value.trim() || "待补充道具描述",
      storyMeaning: document.querySelector("#newPropMeaning")?.value.trim() || "普通剧情道具",
      appearsInEpisodes: splitList(document.querySelector("#newPropEpisodes")?.value).map(Number).filter(Boolean),
      isKeyProp: Boolean(document.querySelector("#newPropKey")?.checked)
    });
    patchProject({}); modalRoot.innerHTML = ""; renderCharacters(); toast("道具设定已添加");
  }
  if (event.target.closest("[data-save-new-expression]")) {
    const character = ensureProject().characters.find((item) => item.id === activeCharacterId);
    const name = document.querySelector("#newExpressionName")?.value.trim();
    if (!name) return toast("请填写表情名称");
    const type = `custom_${Date.now()}`;
    const reference = makeReference(character, type, name, expressionPrompt(character, `${name}：${document.querySelector("#newExpressionDescription")?.value.trim() || ""}`, ensureProject()), "generating");
    character.expressionImages.push(reference);
    patchProject({}); modalRoot.innerHTML = ""; renderCharacters();
    setTimeout(() => {
      reference.status = "generated"; patchProject({});
      if (routePath() === "/create/characters" && activeCharacterId === character.id) renderCharacters();
      toast(`${name}表情已生成`);
    }, 850);
  }
  const deleteReference = event.target.closest("[data-delete-reference]");
  if (deleteReference) {
    const character = ensureProject().characters.find((item) => item.id === activeCharacterId);
    const reference = character.referenceImages.find((item) => item.id === deleteReference.dataset.deleteReference);
    modalRoot.innerHTML = `<section class="modal"><div class="modal-warning-icon">!</div><h2>删除这张参考图？</h2><p>${escapeHtml(reference?.label || "参考图")} 删除后需要重新生成，且可能影响角色一致性。</p><div class="modal-actions"><button class="secondary" data-modal-close>取消</button><button class="danger-button" data-confirm-delete-reference="${deleteReference.dataset.deleteReference}">确认删除</button></div></section>`;
  }
  const confirmDeleteReference = event.target.closest("[data-confirm-delete-reference]");
  if (confirmDeleteReference) {
    const character = ensureProject().characters.find((item) => item.id === activeCharacterId);
    character.referenceImages = character.referenceImages.filter((item) => item.id !== confirmDeleteReference.dataset.confirmDeleteReference);
    patchProject({}); modalRoot.innerHTML = ""; renderCharacters(); toast("参考图已删除");
  }
  const welcome = event.target.closest("[data-welcome]");
  if (welcome) {
    if (document.querySelector("#hideWelcome")?.checked) localStorage.setItem(WELCOME_KEY, "1");
    modalRoot.innerHTML = "";
    go(welcome.dataset.welcome === "start" ? "/create" : "/templates");
  }
  const saveShot = event.target.closest("[data-save-shot]");
  if (saveShot) {
    const project = ensureProject(); const shot = project.shots.find((item) => item.id === saveShot.dataset.saveShot);
    Object.assign(shot,{visualDescription:document.querySelector("#modalVisual").value,dialogue:document.querySelector("#modalDialogue").value,narration:document.querySelector("#modalNarration").value,shotSize:document.querySelector("#modalShotSize").value,cameraMotion:document.querySelector("#modalMotion").value,duration:Math.max(1,Math.min(10,Number(document.querySelector("#modalDuration").value))),emotion:document.querySelector("#modalEmotion").value,modified:true});
    patchProject({}); modalRoot.innerHTML=""; renderStoryboard(); toast("镜头已保存");
  }
  const saveEpisode = event.target.closest("[data-save-episode]");
  if (saveEpisode) {
    const series=ensureSeries(); const episode=series.episodes.find((item)=>item.id===saveEpisode.dataset.saveEpisode);
    Object.assign(episode,{title:document.querySelector("#episodeTitle").value,summary:document.querySelector("#episodeSummary").value,openingHook:document.querySelector("#episodeOpening").value,coreConflict:document.querySelector("#episodeConflict").value,emotionalBeat:document.querySelector("#episodeEmotion").value,targetDuration:Number(document.querySelector("#episodeDuration").value),endingHook:document.querySelector("#episodeEnding").value,previousEpisodeSummary:document.querySelector("#episodePrevious").value,nextEpisodeHook:document.querySelector("#episodeNext").value,updatedAt:new Date().toISOString()});
    patchSeries({},series,0); modalRoot.innerHTML=""; routePath().includes("/episode-plan")?renderEpisodePlan():renderSeriesDetail(series.id); toast("单集大纲已保存");
  }
  const startBatchButton = event.target.closest("[data-start-batch]");
  if (startBatchButton) {
    const series=state.seriesProjects.find((item)=>item.id===startBatchButton.dataset.startBatch);
    if(!series)return;
    const range=document.querySelector("#batchRange").value;
    modalRoot.innerHTML="";
      startBatch(series,range);
  }
  if (!event.target.closest(".create-menu-wrap")) {
    createProjectMenu.hidden = true;
    topbarCreate.setAttribute("aria-expanded", "false");
  }
  if (!event.target.closest(".top-search-wrap")) searchSuggestions.hidden = true;
  if (!event.target.closest(".sidebar-foot")) {
    workspaceMenu.hidden = true;
    workspaceButton.setAttribute("aria-expanded", "false");
  }
});
document.querySelector("#menuButton").addEventListener("click", () => shell.classList.toggle("menu-open"));
document.querySelector("#mobileMask").addEventListener("click", () => shell.classList.remove("menu-open"));
document.querySelector(".sidebar").addEventListener("click", (event) => { if (event.target.closest("a")) shell.classList.remove("menu-open"); });
document.querySelector("#sidebarCollapse").addEventListener("click", () => {
  const collapsed = shell.classList.toggle("sidebar-collapsed");
  localStorage.setItem(SIDEBAR_COLLAPSE_KEY, collapsed ? "1" : "0");
  document.querySelector("#sidebarCollapse").setAttribute("aria-label", collapsed ? "展开侧边栏" : "折叠侧边栏");
  document.querySelector("#sidebarCollapse").title = collapsed ? "展开侧边栏" : "折叠侧边栏";
});
topbarCreate.addEventListener("click", () => {
  const willOpen = createProjectMenu.hidden;
  createProjectMenu.hidden = !willOpen;
  topbarCreate.setAttribute("aria-expanded", String(willOpen));
  searchSuggestions.hidden = true;
});
workspaceButton.addEventListener("click", () => {
  const willOpen = workspaceMenu.hidden;
  workspaceMenu.hidden = !willOpen;
  workspaceButton.setAttribute("aria-expanded", String(willOpen));
});
document.querySelector("#notificationButton").addEventListener("click", () => toast("暂时没有新的通知"));
globalSearch.addEventListener("focus", renderSearchSuggestions);
globalSearch.addEventListener("input", (event) => {
  searchTerm = event.target.value;
  renderSearchSuggestions();
  if (routePath() === "/projects") renderProjects();
  if (routePath() === "/assets") renderAssets();
});
document.addEventListener("keydown", (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    if (topSearchWrap.hidden) return toast("当前创作步骤已隐藏全局搜索");
    globalSearch.focus();
    globalSearch.select();
    renderSearchSuggestions();
  }
  if (event.key === "Escape") {
    searchSuggestions.hidden = true;
    createProjectMenu.hidden = true;
    workspaceMenu.hidden = true;
    shell.classList.remove("menu-open");
  }
});
window.addEventListener("hashchange", render);
window.addEventListener("beforeunload", () => {
  clearTimeout(generationTimer); clearInterval(playbackTimer); clearTimeout(seriesSaveTimer);
  clearTimeout(seriesAnalysisTimer); clearTimeout(batchTimer);
});
renderSidebarNavigation();
if (localStorage.getItem(SIDEBAR_COLLAPSE_KEY) === "1" && innerWidth >= 1024) shell.classList.add("sidebar-collapsed");
render();
setTimeout(welcomeModal, 250);
