const DB_NAME = "noonai-ai-drama";
const DB_VERSION = 1;
const STORE_NAME = "series-projects";

function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME, { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function withStore(mode, callback) {
  const db = await openDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, mode);
    const store = transaction.objectStore(STORE_NAME);
    const request = callback(store);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
    transaction.oncomplete = () => db.close();
    transaction.onerror = () => reject(transaction.error);
  });
}

export async function loadSeriesProjects() {
  try {
    return await withStore("readonly", (store) => store.getAll());
  } catch {
    return [];
  }
}

export async function saveSeriesProject(project) {
  return withStore("readwrite", (store) => store.put(structuredClone(project)));
}

export async function deleteSeriesProject(id) {
  return withStore("readwrite", (store) => store.delete(id));
}

export async function clearSeriesProjects() {
  return withStore("readwrite", (store) => store.clear());
}
