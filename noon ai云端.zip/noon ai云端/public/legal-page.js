const documentKey = document.body.dataset.document;
const documentData = window.LEGAL_DOCUMENTS?.[documentKey];
const documentRoot = document.querySelector("#legalDocument");

const classNames = {
  title: "legal-title",
  date: "legal-date",
  paragraph: "legal-paragraph",
  "heading-1": "legal-heading-1",
  "heading-2": "legal-heading-2",
  "heading-3": "legal-heading-3",
  "toc-item": "legal-toc-item"
};

const tagNames = {
  title: "h1",
  "heading-1": "h2",
  "heading-2": "h3",
  "heading-3": "h4"
};

if (!documentData || !documentRoot) {
  if (documentRoot) {
    documentRoot.innerHTML = '<p class="legal-error">协议内容暂时无法加载，请稍后重试。</p>';
  }
} else {
  const fragment = document.createDocumentFragment();

  documentData.items.forEach((item) => {
    const element = document.createElement(tagNames[item.type] || "p");
    element.className = classNames[item.type] || classNames.paragraph;
    element.textContent = item.text;
    fragment.appendChild(element);
  });

  documentRoot.replaceChildren(fragment);
  const title = documentData.items.find((item) => item.type === "title")?.text;
  if (title) document.title = `${title} - NoonAI`;
}
