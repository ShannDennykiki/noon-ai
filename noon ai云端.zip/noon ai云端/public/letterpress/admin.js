const state = {
  voices: [],
  selectedVoice: "元首",
  clips: [],
};

const $ = (id) => document.getElementById(id);

const els = {
  serverStatus: $("serverStatus"),
  librarySummary: $("librarySummary"),
  filePicker: $("filePicker"),
  voiceInput: $("voiceInput"),
  voiceFilter: $("voiceFilter"),
  uploadQueue: $("uploadQueue"),
  clipList: $("clipList"),
  refreshButton: $("refreshButton"),
};

const API_ORIGIN = window.location.protocol === "file:" ? "http://127.0.0.1:5177" : "/letterpress-api";
const MAX_UPLOAD_BYTES = 25 * 1024 * 1024;

function apiUrl(path) {
  return path.startsWith("http") ? path : `${API_ORIGIN}${path}`;
}

async function requestJson(url, options = {}) {
  let response;
  try {
    response = await fetch(apiUrl(url), options);
  } catch {
    throw new Error("无法连接本地服务。请确认已运行 .\\run.ps1。");
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = data.detail ? `：${data.detail}` : "";
    throw new Error(`${data.error || `请求失败：${response.status}`}${detail}`);
  }
  return data;
}

function postJson(url, payload) {
  return requestJson(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function labelFromFilename(file) {
  return file.name.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " ").trim();
}

function aliasesFromText(value) {
  return String(value || "")
    .split(/[,，、\n]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

async function loadVoices() {
  const health = await requestJson("/api/health");
  const data = await requestJson("/api/voices");
  state.voices = data.voices || [];
  if (!state.voices.includes(state.selectedVoice)) state.voices.unshift(state.selectedVoice);
  els.serverStatus.textContent = health.has_env_key ? "智能匹配" : "本地匹配";
  renderVoiceFilter();
}

function renderVoiceFilter() {
  els.voiceFilter.innerHTML = "";
  for (const voice of state.voices) {
    const option = document.createElement("option");
    option.value = voice;
    option.textContent = voice;
    if (voice === state.selectedVoice) option.selected = true;
    els.voiceFilter.append(option);
  }
}

async function loadLibrary() {
  await loadVoices();
  const library = await requestJson(`/api/library?voice=${encodeURIComponent(state.selectedVoice)}`);
  state.clips = library.clips || [];
  els.librarySummary.textContent = `${state.selectedVoice} 共有 ${state.clips.length} 个音节`;
  renderClips();
}

async function uploadFiles(files) {
  const voice = els.voiceInput.value.trim() || "默认";
  state.selectedVoice = voice;
  els.uploadQueue.innerHTML = "";
  for (const file of files) {
    const row = document.createElement("div");
    row.className = "queueItem";
    row.textContent = `${file.name}：准备上传`;
    els.uploadQueue.append(row);

    try {
      if (file.size > MAX_UPLOAD_BYTES) {
        throw new Error("超过 25MB，请先压缩或剪短");
      }
      row.textContent = `${file.name}：读取中`;
      const audio_base64 = await fileToDataUrl(file);
      row.textContent = `${file.name}：上传中`;
      const result = await postJson("/api/library", {
        voice,
        filename: file.name,
        mime: file.type || "application/octet-stream",
        label: labelFromFilename(file),
        audio_base64,
      });
      row.textContent = `${file.name}：已上传到 ${voice}，标签 ${result.clip.label}`;
    } catch (error) {
      row.textContent = `${file.name}：${error.message}`;
      row.classList.add("error");
    }
  }
  await loadLibrary();
}

function renderClips() {
  els.clipList.innerHTML = "";
  if (!state.clips.length) {
    const empty = document.createElement("div");
    empty.className = "hint";
    empty.textContent = "这个音色的音节库还是空的。";
    els.clipList.append(empty);
    return;
  }

  for (const clip of state.clips) {
    const item = document.createElement("article");
    item.className = "clipItem";
    item.innerHTML = `
      <div class="clipMeta">
        <div class="clipName" title="${escapeHtml(clip.filename)}">${escapeHtml(clip.voice)} · ${escapeHtml(clip.filename)}</div>
        <div class="clipActions">
          <button class="smallButton" data-action="save" data-id="${clip.id}">保存</button>
          <button class="smallButton danger" data-action="delete" data-id="${clip.id}">删除</button>
        </div>
      </div>
      <audio controls src="${apiUrl(clip.url)}"></audio>
      <label>
        音节标签
        <input data-action="label" data-id="${clip.id}" value="${escapeHtml(clip.label)}" />
      </label>
      <label>
        同音/谐音别名
        <input data-action="aliases" data-id="${clip.id}" value="${escapeHtml((clip.aliases || []).join('，'))}" />
      </label>
    `;
    els.clipList.append(item);
  }
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

els.filePicker.addEventListener("change", (event) => {
  uploadFiles([...event.target.files]);
  event.target.value = "";
});

els.refreshButton.addEventListener("click", () => {
  loadLibrary().catch((error) => {
    els.librarySummary.textContent = error.message;
  });
});

els.voiceFilter.addEventListener("change", () => {
  state.selectedVoice = els.voiceFilter.value;
  els.voiceInput.value = state.selectedVoice;
  loadLibrary().catch((error) => {
    els.librarySummary.textContent = error.message;
  });
});

els.clipList.addEventListener("input", (event) => {
  const clip = state.clips.find((item) => item.id === event.target.dataset.id);
  if (!clip) return;
  if (event.target.dataset.action === "label") clip.label = event.target.value;
  if (event.target.dataset.action === "aliases") clip.aliases = aliasesFromText(event.target.value);
});

els.clipList.addEventListener("click", async (event) => {
  const button = event.target.closest("button");
  if (!button) return;
  const clip = state.clips.find((item) => item.id === button.dataset.id);
  if (!clip) return;
  button.disabled = true;
  try {
    if (button.dataset.action === "save") {
      await postJson("/api/library/update", {
        id: clip.id,
        voice: clip.voice,
        label: clip.label,
        aliases: clip.aliases || [],
      });
    }
    if (button.dataset.action === "delete") {
      await postJson("/api/library/delete", { id: clip.id });
    }
    await loadLibrary();
  } catch (error) {
    els.librarySummary.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});

loadLibrary().catch((error) => {
  els.serverStatus.textContent = "服务未启动";
  els.librarySummary.textContent = error.message;
});
