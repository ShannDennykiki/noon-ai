const state = {
  voices: [],
  selectedVoice: "",
  clips: [],
  decoded: new Map(),
  currentPlan: null,
  outputBlob: null,
  outputUrl: null,
  outputSamples: null,
  outputSampleRate: null,
  previewContext: null,
  previewSource: null,
  history: [],
  editingStepIndex: null,
  contextMenuTarget: null,
  choiceEditorStepIndex: null,
  clipEditor: null,
  clipEditorWaveform: null,
  activeView: "studio",
  historyQuery: "",
  historyVoice: "",
};

const $ = (id) => document.getElementById(id);

const els = {
  backToNoonAi: $("backToNoonAi"),
  serverStatus: $("serverStatus"),
  librarySummary: $("librarySummary"),
  voiceSelect: $("voiceSelect"),
  targetText: $("targetText"),
  buildButton: $("buildButton"),
  timeline: $("timeline"),
  playButton: $("playButton"),
  downloadButton: $("downloadButton"),
  saveHistoryButton: $("saveHistoryButton"),
  message: $("message"),
  gapMs: $("gapMs"),
  gapValue: $("gapValue"),
  gain: $("gain"),
  gainValue: $("gainValue"),
  downloadFormat: $("downloadFormat"),
  historySummary: $("historySummary"),
  historyList: $("historyList"),
  clearHistoryButton: $("clearHistoryButton"),
  shell: $("letterpressShell"),
  adminLibrarySummary: $("adminLibrarySummary"),
  filePicker: $("filePicker"),
  voiceInput: $("voiceInput"),
  voiceFilter: $("voiceFilter"),
  uploadQueue: $("uploadQueue"),
  clipList: $("clipList"),
  refreshButton: $("refreshButton"),
  currentVoiceName: $("currentVoiceName"),
  asideVoiceName: $("asideVoiceName"),
  coverageCount: $("coverageCount"),
  coverageBar: $("coverageBar"),
  characterCount: $("characterCount"),
  clearComposerButton: $("clearComposerButton"),
  resultCard: $("resultCard"),
  resultStatus: $("resultStatus"),
  resultEmpty: $("resultEmpty"),
  resultOutput: $("resultOutput"),
  outputAudio: $("outputAudio"),
  outputFileName: $("outputFileName"),
  outputMeta: $("outputMeta"),
  recentHistoryList: $("recentHistoryList"),
  voiceStat: $("voiceStat"),
  clipStat: $("clipStat"),
  missingStat: $("missingStat"),
  uploadStat: $("uploadStat"),
  voiceCountBadge: $("voiceCountBadge"),
  clipCountBadge: $("clipCountBadge"),
  voiceSearch: $("voiceSearch"),
  voiceList: $("voiceList"),
  libraryVoiceTitle: $("libraryVoiceTitle"),
  uploadDropzone: $("uploadDropzone"),
  historySearch: $("historySearch"),
  historyVoiceFilter: $("historyVoiceFilter"),
  mobileMenuButton: $("mobileMenuButton"),
  mainNav: $("mainNav"),
  toastRegion: $("toastRegion"),
  confirmDialog: $("confirmDialog"),
  confirmTitle: $("confirmTitle"),
  confirmText: $("confirmText"),
  confirmCancel: $("confirmCancel"),
  confirmAccept: $("confirmAccept"),
  settingsFormat: $("settingsFormat"),
  settingsGain: $("settingsGain"),
  settingsGainValue: $("settingsGainValue"),
  settingsGap: $("settingsGap"),
  settingsGapValue: $("settingsGapValue"),
  compactModeToggle: $("compactModeToggle"),
  exportSettingsButton: $("exportSettingsButton"),
};

const API_ORIGIN = window.location.protocol === "file:" ? "http://127.0.0.1:5177" : "/letterpress-api";
const HISTORY_KEY = "letterpress.history.v1";
const HISTORY_LIMIT = 12;
const MAX_UPLOAD_BYTES = 25 * 1024 * 1024;
const LETTERPRESS_ENTRY_KEY = "noonai.letterpress-entry.v1";
const RETURN_NEW_CHAT_KEY = "noonai.return-new-chat.v1";

function returnToNoonAi(event) {
  event.preventDefault();
  let canRestorePreviousPage = false;
  try {
    const entry = JSON.parse(sessionStorage.getItem(LETTERPRESS_ENTRY_KEY) || "null");
    const referrerPath = document.referrer ? new URL(document.referrer).pathname : "";
    const cameFromNoonAi = referrerPath === "/"
      || referrerPath.endsWith("/index.html")
      || referrerPath.endsWith("/public/");
    canRestorePreviousPage = Boolean(
      (
        (entry?.url && Date.now() - Number(entry.createdAt || 0) < 12 * 60 * 60 * 1000)
        || cameFromNoonAi
      )
      && window.history.length > 1
    );
    sessionStorage.removeItem(LETTERPRESS_ENTRY_KEY);
    sessionStorage.setItem(RETURN_NEW_CHAT_KEY, "1");
  } catch {}

  if (canRestorePreviousPage) {
    window.history.back();
    return;
  }

  window.location.replace(els.backToNoonAi.href);
}

function apiUrl(path) {
  return path.startsWith("http") ? path : `${API_ORIGIN}${path}`;
}

function setMessage(text, kind = "") {
  els.message.textContent = text;
  els.message.className = kind;
}

function showToast(text, kind = "success") {
  const toast = document.createElement("div");
  toast.className = `toast ${kind}`;
  toast.textContent = text;
  els.toastRegion.append(toast);
  setTimeout(() => toast.remove(), 3200);
}

function requestConfirmation({ title = "确认删除？", text = "删除后无法恢复。", accept = "确认删除" } = {}) {
  return new Promise((resolve) => {
    els.confirmTitle.textContent = title;
    els.confirmText.textContent = text;
    els.confirmAccept.textContent = accept;
    els.confirmDialog.hidden = false;

    const finish = (value) => {
      els.confirmDialog.hidden = true;
      els.confirmCancel.removeEventListener("click", cancel);
      els.confirmAccept.removeEventListener("click", confirm);
      resolve(value);
    };
    const cancel = () => finish(false);
    const confirm = () => finish(true);
    els.confirmCancel.addEventListener("click", cancel);
    els.confirmAccept.addEventListener("click", confirm);
  });
}

function switchView(name) {
  state.activeView = name;
  document.querySelectorAll("[data-view-panel]").forEach((panel) => {
    const active = panel.dataset.viewPanel === name;
    panel.hidden = !active;
    panel.classList.toggle("active", active);
  });
  document.querySelectorAll(".navItem").forEach((button) => {
    button.classList.toggle("active", button.dataset.view === name);
  });
  els.mainNav.classList.remove("open");
  els.mobileMenuButton.setAttribute("aria-expanded", "false");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

async function requestJson(url, options = {}) {
  let response;
  try {
    response = await fetch(apiUrl(url), options);
  } catch {
    throw new Error("无法连接本地服务。请确认已运行 .\\run.ps1，并用 http://127.0.0.1:5177 打开应用。");
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = data.detail ? `：${data.detail}` : "";
    throw new Error(`${data.error || `请求失败：${response.status}`}${detail}`);
  }
  return data;
}

function postJson(url, payload) {
  return requestJson(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
}

async function loadVoices() {
  const health = await requestJson("/api/health");
  const voiceData = await requestJson("/api/voices");
  state.voices = voiceData.voices || [];
  if (!state.voices.length) state.voices = ["默认"];
  if (!state.selectedVoice || !state.voices.includes(state.selectedVoice)) {
    state.selectedVoice = state.voices.includes("元首") ? "元首" : state.voices[0];
  }
  els.serverStatus.textContent = health.has_env_key ? "智能匹配" : "本地匹配";
  renderVoices();
  renderAdminVoiceFilter();
}

function renderVoices() {
  els.voiceSelect.innerHTML = "";
  for (const voice of state.voices) {
    const option = document.createElement("option");
    option.value = voice;
    option.textContent = voice;
    if (voice === state.selectedVoice) option.selected = true;
    els.voiceSelect.append(option);
  }
  if (els.voiceInput) els.voiceInput.value = state.selectedVoice;
  els.currentVoiceName.textContent = state.selectedVoice || "默认";
  els.asideVoiceName.textContent = state.selectedVoice || "默认";
  els.libraryVoiceTitle.textContent = state.selectedVoice || "音色详情";
  els.voiceStat.textContent = String(state.voices.length);
  els.voiceCountBadge.textContent = String(state.voices.length);
  renderVoiceList();
}

function renderAdminVoiceFilter() {
  els.voiceFilter.innerHTML = "";
  els.historyVoiceFilter.innerHTML = '<option value="">全部音色</option>';
  for (const voice of state.voices) {
    const option = document.createElement("option");
    option.value = voice;
    option.textContent = voice;
    if (voice === state.selectedVoice) option.selected = true;
    els.voiceFilter.append(option);
    const historyOption = document.createElement("option");
    historyOption.value = voice;
    historyOption.textContent = voice;
    els.historyVoiceFilter.append(historyOption);
  }
  if (els.voiceInput) els.voiceInput.value = state.selectedVoice;
}

function renderVoiceList() {
  const query = els.voiceSearch?.value.trim().toLowerCase() || "";
  els.voiceList.innerHTML = "";
  for (const voice of state.voices.filter((item) => item.toLowerCase().includes(query))) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = `voiceListItem${voice === state.selectedVoice ? " active" : ""}`;
    button.dataset.voice = voice;
    button.innerHTML = `<span>${escapeHtml(voice)}</span><i aria-hidden="true"></i>`;
    els.voiceList.append(button);
  }
}

async function loadLibrary() {
  const library = await requestJson(`/api/library?voice=${encodeURIComponent(state.selectedVoice)}`);
  state.clips = library.clips || [];
  state.decoded.clear();
  const summary = state.clips.length
    ? `${state.selectedVoice} 音色已有 ${state.clips.length} 个音节`
    : `${state.selectedVoice} 音色的音节库还是空的`;
  els.librarySummary.textContent = summary;
  els.adminLibrarySummary.textContent = summary;
  els.clipStat.textContent = String(state.clips.length);
  els.clipCountBadge.textContent = `${state.clips.length} 个音节`;
  els.coverageCount.textContent = String(state.clips.length);
  els.coverageBar.style.width = `${Math.min(100, Math.max(8, state.clips.length / 2))}%`;
  els.libraryVoiceTitle.textContent = state.selectedVoice;
  renderVoiceList();
  renderClips();
}

function clipsForPlan() {
  return state.clips
    .map((clip) => ({
      id: clip.id,
      label: clip.label.trim(),
      aliases: clip.aliases || [],
      segmentBoundaries: clip.segmentBoundaries || [],
      segments: clip.segments || [],
      category: clip.category || clip.syllableType || "phrase",
      syllableType: clip.syllableType || clip.category || "phrase",
    }))
    .filter((clip) => clip.label);
}

async function buildPlan() {
  const text = els.targetText.value.trim();
  if (!state.clips.length) {
    setMessage("当前音色的音节库为空，请先进入后台导入音节。", "error");
    return;
  }
  if (!text) {
    setMessage("请输入要生成的一句话。", "error");
    return;
  }

  setBuildLoading(true);
  els.resultStatus.textContent = "生成中";
  els.resultCard.classList.remove("errorState");
  setMessage(`正在用“${state.selectedVoice}”音色做同音/谐音分析...`);
  try {
    const plan = await postJson("/api/plan", {
      text,
      voice: state.selectedVoice,
      clips: clipsForPlan(),
    });
    state.currentPlan = plan;
    renderTimeline(plan);
    await renderOutputAudio(plan);
    const missing = plan.missing?.length ? `，缺少 ${plan.missing.length} 个声音` : "";
    const source = plan.source === "ai" ? "智能匹配" : "本地匹配";
    els.missingStat.textContent = String(plan.missing?.length || 0);
    els.resultStatus.textContent = "已生成";
    setMessage(`${source}完成${missing}。调好后可点击“保存记录”。`, plan.missing?.length ? "warn" : "ok");
  } catch (error) {
    els.resultStatus.textContent = "生成失败";
    els.resultCard.classList.add("errorState");
    setMessage(error.message, "error");
  } finally {
    setBuildLoading(false);
  }
}

function setBuildLoading(loading) {
  for (const button of [els.buildButton, ...document.querySelectorAll(".mirrorBuildButton")]) {
    button.disabled = loading || !els.targetText.value.trim();
    button.textContent = loading ? "生成中…" : "生成拼接";
  }
}

function renderTimeline(plan) {
  hideTimelineContextMenu();
  els.timeline.innerHTML = "";
  for (const item of plan.homophoneAnalysis || []) {
    const token = document.createElement("span");
    token.className = "token analysis";
    const phonetic = item.phoneticText && item.phoneticText !== item.inputText ? `（${item.phoneticText}）` : "";
    token.textContent = `${item.inputText}${phonetic} → ${item.chosenLabel}`;
    els.timeline.append(token);
  }
  (plan.sequence || []).forEach((step, index) => {
    const token = document.createElement("span");
    token.className = `token ${step.type}`;
    token.dataset.stepIndex = String(index);
    if (step.type === "clip") {
      token.classList.add("selectable");
      token.type = "button";
      token.textContent = clipStepLabel(step);
      token.title = "右键打开候选音节，双击编辑文字";
      token.addEventListener("dblclick", (event) => startTokenEdit(event, token, index));
      token.addEventListener("contextmenu", (event) => showTimelineContextMenu(event, { kind: "step", stepIndex: index }));
    } else if (step.type === "gap") {
      token.textContent = `停顿 ${step.durationMs || 120}ms`;
      token.title = "右键删除";
      token.addEventListener("contextmenu", (event) => showTimelineContextMenu(event, { kind: "step", stepIndex: index }));
    } else {
      token.textContent = `缺少：${step.text}`;
      token.title = "双击编辑文字，右键删除";
      token.addEventListener("dblclick", (event) => startTokenEdit(event, token, index));
      token.addEventListener("contextmenu", (event) => showTimelineContextMenu(event, { kind: "step", stepIndex: index }));
    }
    els.timeline.append(token);
  });
}

function ensureTimelineContextMenu() {
  let menu = document.getElementById("timelineContextMenu");
  if (menu) return menu;

  menu = document.createElement("div");
  menu.id = "timelineContextMenu";
  menu.className = "contextMenu";
  menu.hidden = true;

  const openButton = document.createElement("button");
  openButton.type = "button";
  openButton.className = "contextMenuItem";
  openButton.textContent = "打开";
  openButton.addEventListener("click", () => {
    const target = state.contextMenuTarget;
    hideTimelineContextMenu();
    if (target) openContextTarget(target);
  });

  const deleteButton = document.createElement("button");
  deleteButton.type = "button";
  deleteButton.className = "contextMenuItem danger";
  deleteButton.textContent = "删除";
  deleteButton.addEventListener("click", async () => {
    const target = state.contextMenuTarget;
    hideTimelineContextMenu();
    if (target) {
      await deleteContextTarget(target);
    }
  });

  menu.append(openButton, deleteButton);
  document.body.append(menu);
  return menu;
}

function showTimelineContextMenu(event, target) {
  event.preventDefault();
  event.stopPropagation();
  const old = els.timeline.querySelector(".choicePanel");
  if (old && target.kind !== "choice") old.remove();

  state.contextMenuTarget = target;
  const menu = ensureTimelineContextMenu();
  const openButton = menu.querySelector(".contextMenuItem:not(.danger)");
  const canOpen = canOpenContextTarget(target);
  openButton.disabled = !canOpen;
  menu.hidden = false;
  menu.style.left = `${Math.min(event.clientX + 8, window.innerWidth - 104)}px`;
  menu.style.top = `${Math.min(event.clientY + 8, window.innerHeight - 88)}px`;
}

function hideTimelineContextMenu() {
  const menu = document.getElementById("timelineContextMenu");
  if (menu) menu.hidden = true;
  state.contextMenuTarget = null;
}

function resolveClipEditTarget(target) {
  if (!target) return null;
  const step = state.currentPlan?.sequence?.[target.stepIndex];
  if (target.kind === "choice") {
    const choice = target.choice;
    const clip = state.clips.find((item) => item.id === choice?.clipId);
    return clip && step ? { step, choice, clip, kind: "choice", target } : null;
  }
  if (!step || step.type !== "clip") return null;
  const clip = state.clips.find((item) => item.id === step.clipId);
  return clip ? { step, clip, kind: "step", target } : null;
}

function canOpenContextTarget(target) {
  if (!target) return false;
  if (target.kind === "choice") return Boolean(resolveClipEditTarget(target));
  const step = state.currentPlan?.sequence?.[target.stepIndex];
  return Boolean(step && step.type === "clip");
}

function openContextTarget(target) {
  if (target.kind === "choice") {
    openClipEditor(target);
    return;
  }
  const step = state.currentPlan?.sequence?.[target.stepIndex];
  if (step?.type === "clip") {
    openChoiceLibrary(target.stepIndex);
  }
}

async function deleteContextTarget(target) {
  if (target.kind === "choice") {
    const step = state.currentPlan?.sequence?.[target.stepIndex];
    if (!step) return;
    if (isCurrentChoice(step, target.choice)) {
      await removeTimelineStep(target.stepIndex, "已删除当前音节块。");
      return;
    }
    step.alternatives = (step.alternatives || []).filter((choice) => choice !== target.choice);
    renderTimeline(state.currentPlan);
    renderChoiceLibrary();
    setMessage("已删除这个候选项。", "ok");
    return;
  }
  await removeTimelineStep(target.stepIndex, "已删除音节块。");
}

function ensureChoiceLibrary() {
  let library = document.getElementById("choiceLibrary");
  if (library) return library;

  library = document.createElement("div");
  library.id = "choiceLibrary";
  library.className = "choiceLibrary";
  library.hidden = true;
  library.innerHTML = `
    <div class="choiceLibraryPanel" role="dialog" aria-modal="true" aria-labelledby="choiceLibraryTitle">
      <div class="clipEditorHeader">
        <div>
          <h3 id="choiceLibraryTitle">可用音节</h3>
          <p id="choiceLibraryMeta"></p>
        </div>
        <button type="button" class="smallButton" id="choiceLibraryClose">关闭</button>
      </div>
      <div id="choiceLibraryList" class="choiceLibraryList"></div>
      <p class="choiceLibraryHint">左键改用音节，右键可打开剪切或删除。</p>
    </div>
  `;
  document.body.append(library);

  library.querySelector("#choiceLibraryClose").addEventListener("click", closeChoiceLibrary);
  library.addEventListener("click", (event) => {
    if (event.target === library) closeChoiceLibrary();
  });
  return library;
}

function openChoiceLibrary(stepIndex) {
  const step = state.currentPlan?.sequence?.[stepIndex];
  if (!step || step.type !== "clip") return;
  const library = ensureChoiceLibrary();
  state.choiceEditorStepIndex = stepIndex;
  library.hidden = false;
  renderChoiceLibrary();
}

function closeChoiceLibrary() {
  const library = document.getElementById("choiceLibrary");
  if (library) library.hidden = true;
  state.choiceEditorStepIndex = null;
}

function currentChoiceFromStep(step) {
  return {
    clipId: step.clipId,
    label: step.label,
    matchedBy: step.matchedBy,
    sliceLabel: step.sliceLabel,
    sliceStartRatio: Number(step.sliceStartRatio || 0),
    sliceEndRatio: Number(step.sliceEndRatio || 1),
    gainMultiplier: Number(step.gainMultiplier || 1),
  };
}

function choicesForStep(step) {
  const choices = [...(step.alternatives || [])];
  if (!choices.some((choice) => isCurrentChoice(step, choice))) {
    choices.unshift(currentChoiceFromStep(step));
  }
  return choices;
}

function renderChoiceLibrary() {
  const library = document.getElementById("choiceLibrary");
  if (!library || library.hidden || state.choiceEditorStepIndex === null) return;
  const stepIndex = state.choiceEditorStepIndex;
  const step = state.currentPlan?.sequence?.[stepIndex];
  if (!step || step.type !== "clip") {
    closeChoiceLibrary();
    return;
  }

  library.querySelector("#choiceLibraryMeta").textContent = clipStepLabel(step);
  const list = library.querySelector("#choiceLibraryList");
  list.innerHTML = "";
  const choices = choicesForStep(step);
  if (!choices.length) {
    const empty = document.createElement("p");
    empty.className = "choiceLibraryEmpty";
    empty.textContent = "暂无可用音节";
    list.append(empty);
    return;
  }

  for (const choice of choices) {
    const item = document.createElement("span");
    item.className = isCurrentChoice(step, choice) ? "choiceItem active" : "choiceItem";
    item.addEventListener("contextmenu", (event) =>
      showTimelineContextMenu(event, { kind: "choice", stepIndex, choice })
    );

    const preview = document.createElement("button");
    preview.type = "button";
    preview.className = "previewButton";
    preview.innerHTML = speakerIcon();
    preview.setAttribute("aria-label", "试听这个候选音节");
    preview.title = "只播放这个候选音节";
    preview.addEventListener("click", async (event) => {
      event.stopPropagation();
      await playChoicePreview(choice);
    });

    const button = document.createElement("button");
    button.type = "button";
    button.className = "choiceButton";
    button.textContent = choiceLabel(step.text, choice);
    button.addEventListener("contextmenu", (event) =>
      showTimelineContextMenu(event, { kind: "choice", stepIndex, choice })
    );
    button.addEventListener("click", async (event) => {
      event.stopPropagation();
      await applyChoiceFromLibrary(stepIndex, choice);
    });

    item.append(preview, button);
    list.append(item);
  }
}

async function applyChoiceFromLibrary(stepIndex, choice) {
  const step = state.currentPlan?.sequence?.[stepIndex];
  if (!step || step.type !== "clip") return;
  applyChoice(step, choice);
  renderTimeline(state.currentPlan);
  renderChoiceLibrary();
  await renderOutputAudio(state.currentPlan);
  setMessage(`已改用：${choiceLabel(step.text, choice)}`, "ok");
}

function ensureClipEditor() {
  let editor = document.getElementById("clipEditor");
  if (editor) return editor;

  editor = document.createElement("div");
  editor.id = "clipEditor";
  editor.className = "clipEditor";
  editor.hidden = true;
  editor.innerHTML = `
    <div class="clipEditorPanel" role="dialog" aria-modal="true" aria-labelledby="clipEditorTitle">
      <div class="clipEditorHeader">
        <div>
          <h3 id="clipEditorTitle">剪切音节</h3>
          <p id="clipEditorMeta"></p>
        </div>
        <button type="button" class="smallButton" id="clipEditorClose">关闭</button>
      </div>
      <div class="clipEditorPreview">
        <div class="clipEditorTrack">
          <canvas id="clipEditorWaveform"></canvas>
          <div id="clipEditorSelection"></div>
          <button type="button" class="trimHandle start" id="clipStartHandle" aria-label="拖动起点"></button>
          <button type="button" class="trimHandle end" id="clipEndHandle" aria-label="拖动终点"></button>
        </div>
        <div class="clipEditorScale">
          <span>低</span>
          <span>音量强弱</span>
          <span>高</span>
        </div>
      </div>
      <div class="clipEditorReadout">
        <span>剪切 <strong id="clipRangeValue">0%-100%</strong></span>
        <span>音量 <strong id="clipGainValue">100</strong>%</span>
      </div>
      <label class="clipGainControl">
        单音量
        <input id="clipGain" type="range" min="0" max="500" step="5" value="100" />
      </label>
      <div class="clipEditorActions">
        <button type="button" id="clipPreviewButton">试听剪切</button>
        <button type="button" id="clipSaveButton">保存</button>
      </div>
    </div>
  `;
  document.body.append(editor);

  editor.querySelector("#clipEditorClose").addEventListener("click", closeClipEditor);
  editor.addEventListener("click", (event) => {
    if (event.target === editor) closeClipEditor();
  });
  editor.querySelector("#clipGain").addEventListener("input", updateClipEditorReadout);
  editor.querySelector("#clipStartHandle").addEventListener("pointerdown", (event) => startTrimDrag(event, "start"));
  editor.querySelector("#clipEndHandle").addEventListener("pointerdown", (event) => startTrimDrag(event, "end"));
  editor.querySelector("#clipPreviewButton").addEventListener("click", previewClipEditor);
  editor.querySelector("#clipSaveButton").addEventListener("click", saveClipEditor);
  return editor;
}

function openClipEditor(target) {
  const resolved = resolveClipEditTarget(target);
  if (!resolved) return;
  const editor = ensureClipEditor();
  const editable = resolved.choice || resolved.step;
  state.clipEditor = resolved;
  state.clipEditorWaveform = null;

  editor.dataset.startRatio = String(Number(editable.sliceStartRatio ?? 0));
  editor.dataset.endRatio = String(Number(editable.sliceEndRatio ?? 1));
  editor.querySelector("#clipGain").value = String(clamp(Math.round(Number(editable.gainMultiplier ?? 1) * 100), 0, 500));
  editor.querySelector("#clipEditorMeta").textContent =
    `${resolved.clip.label} · ${resolved.kind === "choice" ? "候选项" : "当前音节"}`;
  editor.hidden = false;
  updateClipEditorReadout();
  renderClipEditorWaveform();
}

function closeClipEditor() {
  const editor = document.getElementById("clipEditor");
  if (editor) editor.hidden = true;
  state.clipEditor = null;
  state.clipEditorWaveform = null;
}

function clipEditorValues() {
  const editor = ensureClipEditor();
  const start = Number(editor.dataset.startRatio || 0);
  const end = Number(editor.dataset.endRatio || 1);
  const low = Math.min(start, end);
  const high = Math.max(start, end);
  return {
    sliceStartRatio: low,
    sliceEndRatio: high > low ? high : Math.min(1, low + 0.01),
    gainMultiplier: Number(editor.querySelector("#clipGain").value) / 100,
  };
}

function updateClipEditorReadout() {
  const editor = ensureClipEditor();
  const values = clipEditorValues();
  const startPercent = Math.round(values.sliceStartRatio * 100);
  const endPercent = Math.round(values.sliceEndRatio * 100);
  const gainPercent = Math.round(values.gainMultiplier * 100);
  editor.querySelector("#clipRangeValue").textContent = `${startPercent}%-${endPercent}%`;
  editor.querySelector("#clipGainValue").textContent = String(gainPercent);
  const selection = editor.querySelector("#clipEditorSelection");
  selection.style.left = `${startPercent}%`;
  selection.style.width = `${Math.max(1, endPercent - startPercent)}%`;
  editor.querySelector("#clipStartHandle").style.left = `${startPercent}%`;
  editor.querySelector("#clipEndHandle").style.left = `${endPercent}%`;
  editor.querySelector(".clipEditorPreview").style.setProperty("--clip-gain", String(values.gainMultiplier));
  drawClipEditorWaveform();
}

function startTrimDrag(event, edge) {
  event.preventDefault();
  event.stopPropagation();
  const editor = ensureClipEditor();
  const track = editor.querySelector(".clipEditorTrack");

  const move = (moveEvent) => {
    const rect = track.getBoundingClientRect();
    const ratio = clamp((moveEvent.clientX - rect.left) / rect.width, 0, 1);
    const values = clipEditorValues();
    if (edge === "start") {
      editor.dataset.startRatio = String(Math.min(ratio, values.sliceEndRatio - 0.01));
    } else {
      editor.dataset.endRatio = String(Math.max(ratio, values.sliceStartRatio + 0.01));
    }
    updateClipEditorReadout();
  };
  const up = () => {
    window.removeEventListener("pointermove", move);
    window.removeEventListener("pointerup", up);
  };
  window.addEventListener("pointermove", move);
  window.addEventListener("pointerup", up);
}

async function renderClipEditorWaveform() {
  if (!state.clipEditor) return;
  const editor = ensureClipEditor();
  const canvas = editor.querySelector("#clipEditorWaveform");
  const rect = canvas.getBoundingClientRect();
  const width = Math.max(240, Math.floor(rect.width || 480));
  const height = Math.max(52, Math.floor(rect.height || 72));
  canvas.width = width;
  canvas.height = height;

  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, width, height);
  const audioContext = new AudioContext();
  const buffer = await decodeClip(audioContext, state.clipEditor.clip);
  const data = buffer.getChannelData(0);
  await audioContext.close();

  const columns = width;
  const peaks = [];
  for (let x = 0; x < columns; x++) {
    const start = Math.floor((x / columns) * data.length);
    const end = Math.floor(((x + 1) / columns) * data.length);
    let peak = 0;
    for (let i = start; i < end; i++) {
      peak = Math.max(peak, Math.abs(data[i] || 0));
    }
    peaks.push(peak);
  }
  state.clipEditorWaveform = { peaks, width, height };
  drawClipEditorWaveform();
}

function drawClipEditorWaveform() {
  if (!state.clipEditor || !state.clipEditorWaveform) return;
  const editor = ensureClipEditor();
  const canvas = editor.querySelector("#clipEditorWaveform");
  const { peaks, width, height } = state.clipEditorWaveform;
  const ctx = canvas.getContext("2d");
  const center = height / 2;
  const gain = clipEditorValues().gainMultiplier;
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "rgba(37, 99, 235, 0.28)";
  ctx.fillRect(0, center - 1, width, 2);
  for (let x = 0; x < peaks.length; x++) {
    const peak = peaks[x] || 0;
    const scaledPeak = Math.min(1, peak * gain);
    const bar = gain > 0 ? Math.max(2, scaledPeak * height * 0.9) : 1;
    const intensity = Math.round(112 + scaledPeak * 130);
    ctx.fillStyle = `rgb(37 ${Math.min(150, intensity)} 235)`;
    ctx.fillRect(x, center - bar / 2, 1, bar);
  }
}

async function previewClipEditor() {
  if (!state.clipEditor) return;
  await playClipPreview(state.clipEditor.clip, clipEditorValues());
}

async function saveClipEditor() {
  if (!state.clipEditor) return;
  const values = clipEditorValues();
  const target = state.clipEditor.target;
  const step = state.currentPlan?.sequence?.[target.stepIndex];
  if (!step) return;

  if (target.kind === "choice") {
    Object.assign(target.choice, values, { sliced: true });
    applyChoice(step, target.choice);
  } else {
    Object.assign(step, values, { sliced: true });
  }

  closeClipEditor();
  renderTimeline(state.currentPlan);
  renderChoiceLibrary();
  await rerenderAfterTimelineEdit("已保存剪切设置。");
}

function clipStepLabel(step) {
  const matched = step.matchedBy && step.matchedBy !== step.label ? ` / ${step.matchedBy}` : "";
  const phonetic = step.phoneticText && step.phoneticText !== step.text ? `（${step.phoneticText}）` : "";
  const slice = step.sliced && step.sliceLabel ? ` · 取“${step.sliceLabel}”` : "";
  const gain = Number(step.gainMultiplier ?? 1);
  const gainText = gain !== 1 ? ` · 音量 ${Math.round(gain * 100)}%` : "";
  return `${step.text || step.label}${phonetic} → ${step.label}${matched}${slice}${gainText}`;
}

function showAlternatives(token, stepIndex) {
  if (state.editingStepIndex !== null) return;
  const old = els.timeline.querySelector(".choicePanel");
  if (old) {
    if (old.dataset.stepIndex === String(stepIndex)) {
      old.remove();
      return;
    }
    old.remove();
  }

  const step = state.currentPlan?.sequence?.[stepIndex];
  if (!step || step.type !== "clip") return;

  const choices = step.alternatives || [];
  if (!choices.length) {
    setMessage("这个音节暂时没有其他候选项。", "warn");
    return;
  }

  const panel = document.createElement("span");
  panel.className = "choicePanel";
  panel.dataset.stepIndex = String(stepIndex);
  for (const choice of choices) {
    const item = document.createElement("span");
    item.className = isCurrentChoice(step, choice) ? "choiceItem active" : "choiceItem";
    item.addEventListener("contextmenu", (event) =>
      showTimelineContextMenu(event, { kind: "choice", stepIndex, choice })
    );

    const preview = document.createElement("button");
    preview.type = "button";
    preview.className = "previewButton";
    preview.innerHTML = speakerIcon();
    preview.setAttribute("aria-label", "试听这个候选音节");
    preview.title = "只播放这个候选音节";
    preview.addEventListener("click", async (event) => {
      event.stopPropagation();
      await playChoicePreview(choice);
    });

    const button = document.createElement("button");
    button.type = "button";
    button.className = "choiceButton";
    button.textContent = choiceLabel(step.text, choice);
    button.addEventListener("contextmenu", (event) =>
      showTimelineContextMenu(event, { kind: "choice", stepIndex, choice })
    );
    button.addEventListener("click", async (event) => {
      event.stopPropagation();
      applyChoice(step, choice);
      renderTimeline(state.currentPlan);
      await renderOutputAudio(state.currentPlan);
      setMessage(`已改用：${choiceLabel(step.text, choice)}`, "ok");
    });
    item.append(preview, button);
    panel.append(item);
  }
  token.after(panel);
}

function stepEditableText(step) {
  return step?.text || step?.phoneticText || step?.label || "";
}

function startTokenEdit(event, token, stepIndex) {
  event.preventDefault();
  event.stopPropagation();
  const step = state.currentPlan?.sequence?.[stepIndex];
  if (!step || step.type === "gap") return;

  const old = els.timeline.querySelector(".choicePanel");
  if (old) old.remove();
  closeChoiceLibrary();

  state.editingStepIndex = stepIndex;
  token.classList.add("editing");
  token.innerHTML = "";

  const input = document.createElement("input");
  input.className = "tokenEditInput";
  input.value = stepEditableText(step);
  input.setAttribute("aria-label", "编辑音节文字");
  token.append(input);
  input.focus();
  input.select();

  let committed = false;
  const commit = async () => {
    if (committed) return;
    committed = true;
    const nextText = input.value.trim();
    state.editingStepIndex = null;
    await replaceTimelineStep(stepIndex, nextText);
  };
  const cancel = () => {
    if (committed) return;
    committed = true;
    state.editingStepIndex = null;
    renderTimeline(state.currentPlan);
  };

  input.addEventListener("keydown", (inputEvent) => {
    if (inputEvent.key === "Enter") {
      inputEvent.preventDefault();
      commit();
    } else if (inputEvent.key === "Escape") {
      inputEvent.preventDefault();
      cancel();
    }
  });
  input.addEventListener("blur", commit);
}

async function replaceTimelineStep(stepIndex, nextText) {
  const step = state.currentPlan?.sequence?.[stepIndex];
  if (!step) return;
  const previousText = stepEditableText(step);
  if (!nextText) {
    await removeTimelineStep(stepIndex, "已删除空内容音节块。");
    return;
  }
  if (nextText === previousText) {
    renderTimeline(state.currentPlan);
    return;
  }

  setMessage(`正在重新匹配“${nextText}”...`);
  try {
    const replacementPlan = await postJson("/api/plan", {
      text: nextText,
      voice: state.selectedVoice,
      clips: clipsForPlan(),
    });
    const replacementSequence = (replacementPlan.sequence || []).filter((item) => item.type);
    if (!replacementSequence.length) {
      throw new Error("没有匹配到可替换的音节。");
    }
    state.currentPlan.sequence.splice(stepIndex, 1, ...replacementSequence);
    state.currentPlan.homophoneAnalysis = [];
    state.currentPlan.source = replacementPlan.source || state.currentPlan.source;
    normalizeCurrentPlanAfterManualEdit();
    renderTimeline(state.currentPlan);
    await rerenderAfterTimelineEdit(`已将“${previousText}”改为“${nextText}”。`);
  } catch (error) {
    renderTimeline(state.currentPlan);
    setMessage(error.message, "error");
  }
}

async function removeTimelineStep(stepIndex, message) {
  if (!state.currentPlan?.sequence?.[stepIndex]) return;
  const old = els.timeline.querySelector(".choicePanel");
  if (old) old.remove();
  closeChoiceLibrary();
  state.currentPlan.sequence.splice(stepIndex, 1);
  state.currentPlan.homophoneAnalysis = [];
  normalizeCurrentPlanAfterManualEdit();
  renderTimeline(state.currentPlan);
  await rerenderAfterTimelineEdit(message);
}

function normalizeCurrentPlanAfterManualEdit() {
  if (!state.currentPlan) return;
  state.currentPlan.missing = (state.currentPlan.sequence || [])
    .filter((step) => step.type === "missing" && step.text)
    .map((step) => step.text);
  els.targetText.value = textFromSequence(state.currentPlan.sequence || []);
}

function textFromSequence(sequence) {
  return sequence
    .map((step) => {
      if (step.type === "gap") return step.text || "";
      if (step.type === "clip" || step.type === "missing") return step.text || "";
      return "";
    })
    .join("");
}

async function rerenderAfterTimelineEdit(message) {
  const hasRenderableAudio = (state.currentPlan.sequence || []).some((step) => step.type === "clip");
  if (!hasRenderableAudio) {
    revokeOutput();
    setMessage("已删除所有可拼接音节。", "warn");
    return;
  }
  try {
    await renderOutputAudio(state.currentPlan);
    setMessage(`${message}已重新合成。`, "ok");
  } catch (error) {
    setMessage(error.message, "error");
  }
}

function stopPreview() {
  if (state.previewSource) {
    try {
      state.previewSource.stop();
    } catch {}
    state.previewSource = null;
  }
  if (state.previewContext) {
    state.previewContext.close().catch(() => {});
    state.previewContext = null;
  }
}

async function playChoicePreview(choice) {
  const clip = state.clips.find((item) => item.id === choice.clipId);
  if (!clip) {
    setMessage("无法试听：未找到这个候选音节。", "error");
    return;
  }

  await playClipPreview(clip, choice);
}

async function playClipPreview(clip, options = {}) {
  stopPreview();
  const audioContext = new AudioContext();
  state.previewContext = audioContext;
  const buffer = await decodeClip(audioContext, clip);
  const range = bufferSliceRange(buffer, {
    sliceStartRatio: options.sliceStartRatio,
    sliceEndRatio: options.sliceEndRatio,
    sliced: Number(options.sliceStartRatio || 0) > 0 || Number(options.sliceEndRatio || 1) < 1,
  });
  const source = audioContext.createBufferSource();
  const gainNode = audioContext.createGain();
  gainNode.gain.value = (Number(els.gain.value) / 100) * Number(options.gainMultiplier || 1);
  source.buffer = buffer;
  source.connect(gainNode).connect(audioContext.destination);
  source.onended = () => {
    if (state.previewSource === source) {
      state.previewSource = null;
      audioContext.close().catch(() => {});
      if (state.previewContext === audioContext) state.previewContext = null;
    }
  };
  state.previewSource = source;
  source.start(0, range.start / buffer.sampleRate, (range.end - range.start) / buffer.sampleRate);
}

function isCurrentChoice(step, choice) {
  return (
    step.clipId === choice.clipId &&
    Number(step.sliceStartRatio || 0) === Number(choice.sliceStartRatio || 0) &&
    Number(step.sliceEndRatio || 1) === Number(choice.sliceEndRatio || 1)
  );
}

function choiceLabel(text, choice) {
  const slice = choice.sliceLabel && choice.sliceLabel !== choice.label ? `（取 ${choice.sliceLabel}）` : "";
  const matched = choice.matchedBy && choice.matchedBy !== text ? ` / ${choice.matchedBy}` : "";
  const gain = Number(choice.gainMultiplier ?? 1);
  const gainText = gain !== 1 ? ` · 音量 ${Math.round(gain * 100)}%` : "";
  return `${text} → ${choice.label}${matched}${slice}${gainText}`;
}

function applyChoice(step, choice) {
  step.clipId = choice.clipId;
  step.label = choice.label;
  step.matchedBy = choice.matchedBy;
  step.sliceLabel = choice.sliceLabel;
  step.sliceStartRatio = Number(choice.sliceStartRatio || 0);
  step.sliceEndRatio = Number(choice.sliceEndRatio || 1);
  step.gainMultiplier = Number(choice.gainMultiplier || 1);
  step.sliced = step.sliceStartRatio > 0 || step.sliceEndRatio < 1;
}

async function renderOutputAudio(plan) {
  revokeOutput();
  const rendered = await stitchWav(plan);
  state.outputBlob = rendered.blob;
  state.outputSamples = rendered.samples;
  state.outputSampleRate = rendered.sampleRate;
  state.outputUrl = URL.createObjectURL(rendered.blob);
  els.outputAudio.src = state.outputUrl;
  els.outputFileName.textContent = `${state.selectedVoice}-letterpress-audio.wav`;
  els.outputMeta.textContent = `${formatDuration((rendered.samples.length / rendered.sampleRate) * 1000)} · ${state.selectedVoice} · 刚刚生成`;
  els.resultEmpty.hidden = true;
  els.resultOutput.hidden = false;
  els.resultOutput.classList.remove("ready");
  requestAnimationFrame(() => els.resultOutput.classList.add("ready"));
  els.playButton.disabled = false;
  els.downloadButton.disabled = false;
  els.saveHistoryButton.disabled = false;
  updateDownloadLabel();
}

function revokeOutput() {
  stopPreview();
  if (state.outputUrl) URL.revokeObjectURL(state.outputUrl);
  state.outputBlob = null;
  state.outputUrl = null;
  state.outputSamples = null;
  state.outputSampleRate = null;
  els.outputAudio.removeAttribute("src");
  els.outputAudio.load();
  els.resultOutput.hidden = true;
  els.resultEmpty.hidden = false;
  els.resultStatus.textContent = "等待生成";
  els.playButton.disabled = true;
  els.downloadButton.disabled = true;
  els.saveHistoryButton.disabled = true;
}

async function decodeClip(audioContext, clip) {
  if (state.decoded.has(clip.id)) return state.decoded.get(clip.id);
  const response = await fetch(apiUrl(clip.url));
  if (!response.ok) throw new Error(`无法读取音节：${clip.label}`);
  const data = await response.arrayBuffer();
  const buffer = await audioContext.decodeAudioData(data.slice(0));
  state.decoded.set(clip.id, buffer);
  return buffer;
}

async function stitchWav(plan) {
  const audioContext = new AudioContext();
  const sampleRate = audioContext.sampleRate;
  const clipMap = new Map(state.clips.map((clip) => [clip.id, clip]));
  const baseGap = Number(els.gapMs.value);
  const gain = Number(els.gain.value) / 100;

  let totalSamples = 0;
  const parts = [];
  for (const step of plan.sequence || []) {
    if (step.type === "clip" && clipMap.has(step.clipId)) {
      const clip = clipMap.get(step.clipId);
      const buffer = await decodeClip(audioContext, clip);
      const range = bufferSliceRange(buffer, step);
      parts.push({ type: "clip", buffer, gainMultiplier: Number(step.gainMultiplier || 1), ...range });
      totalSamples += range.end - range.start;
      const gapSamples = Math.round((baseGap / 1000) * sampleRate);
      if (gapSamples > 0) {
        parts.push({ type: "gap", samples: gapSamples });
        totalSamples += gapSamples;
      }
    } else if (step.type === "gap") {
      const gapMs = Number(step.durationMs || 120) + baseGap;
      const gapSamples = Math.round((gapMs / 1000) * sampleRate);
      parts.push({ type: "gap", samples: gapSamples });
      totalSamples += gapSamples;
    }
  }

  if (!parts.length || totalSamples <= 0) {
    await audioContext.close();
    throw new Error("没有可拼接的音节。");
  }

  const left = new Float32Array(totalSamples);
  let offset = 0;
  for (const part of parts) {
    if (part.type === "gap") {
      offset += part.samples;
      continue;
    }

    const source = part.buffer.getChannelData(0);
    for (let i = part.start; i < part.end && offset < left.length; i++) {
      left[offset] += source[i] * gain * part.gainMultiplier;
      offset += 1;
    }
  }

  await audioContext.close();
  return {
    blob: encodeWav(left, sampleRate),
    samples: left,
    sampleRate,
  };
}

function bufferSliceRange(buffer, step) {
  const startRatio = clamp(Number(step.sliceStartRatio ?? 0), 0, 1);
  const endRatio = clamp(Number(step.sliceEndRatio ?? 1), 0, 1);
  let start = Math.floor(buffer.length * Math.min(startRatio, endRatio));
  let end = Math.ceil(buffer.length * Math.max(startRatio, endRatio));
  const startPad = step.sliced ? Math.round(buffer.sampleRate * 0.01) : 0;
  const endPad = step.sliced ? Math.round(buffer.sampleRate * 0.004) : 0;
  start = clamp(start - startPad, 0, buffer.length - 1);
  end = clamp(end + endPad, start + 1, buffer.length);
  return { start, end };
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function encodeWav(samples, sampleRate) {
  const bytesPerSample = 2;
  const blockAlign = bytesPerSample;
  const buffer = new ArrayBuffer(44 + samples.length * bytesPerSample);
  const view = new DataView(buffer);
  writeString(view, 0, "RIFF");
  view.setUint32(4, 36 + samples.length * bytesPerSample, true);
  writeString(view, 8, "WAVE");
  writeString(view, 12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * blockAlign, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, 16, true);
  writeString(view, 36, "data");
  view.setUint32(40, samples.length * bytesPerSample, true);
  let offset = 44;
  for (const sample of samples) {
    const clipped = Math.max(-1, Math.min(1, sample));
    view.setInt16(offset, clipped < 0 ? clipped * 0x8000 : clipped * 0x7fff, true);
    offset += 2;
  }
  return new Blob([view], { type: "audio/wav" });
}

function supportedMp3MimeType() {
  if (!window.MediaRecorder || !MediaRecorder.isTypeSupported) return "";
  return ["audio/mpeg", "audio/mp3"].find((type) => MediaRecorder.isTypeSupported(type)) || "";
}

async function encodeMp3FromSamples(samples, sampleRate) {
  const mimeType = supportedMp3MimeType();
  if (!mimeType) {
    throw new Error("当前浏览器不支持直接编码 MP3。请先下载 WAV，或换用支持 audio/mpeg 录制的浏览器。");
  }

  const audioContext = new AudioContext({ sampleRate });
  const destination = audioContext.createMediaStreamDestination();
  const buffer = audioContext.createBuffer(1, samples.length, sampleRate);
  buffer.copyToChannel(samples, 0);

  const source = audioContext.createBufferSource();
  source.buffer = buffer;
  source.connect(destination);

  const recorder = new MediaRecorder(destination.stream, {
    mimeType,
    audioBitsPerSecond: 192000,
  });
  const chunks = [];
  recorder.ondataavailable = (event) => {
    if (event.data && event.data.size) chunks.push(event.data);
  };

  await audioContext.resume();
  recorder.start();
  source.start();
  await new Promise((resolve) => {
    source.onended = resolve;
  });
  await new Promise((resolve) => {
    recorder.onstop = resolve;
    recorder.stop();
  });
  await audioContext.close();

  if (!chunks.length) {
    throw new Error("MP3 编码失败，请改用 WAV 下载。");
  }
  return new Blob(chunks, { type: recorder.mimeType || mimeType });
}

function updateDownloadLabel() {
  if (!els.downloadFormat) return;
  els.downloadButton.textContent = `下载 ${els.downloadFormat.value.toUpperCase()}`;
  $("formatReadout").textContent = els.downloadFormat.value.toUpperCase();
}

function downloadBlob(blob, extension) {
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `${state.selectedVoice}-letterpress-audio.${extension}`;
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
}

function downloadDataUrl(dataUrl, filename) {
  const link = document.createElement("a");
  link.href = dataUrl;
  link.download = filename;
  link.click();
}

function loadHistory() {
  try {
    const stored = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
    state.history = Array.isArray(stored) ? stored.filter((item) => item?.audioDataUrl).slice(0, HISTORY_LIMIT) : [];
  } catch {
    state.history = [];
  }
  renderHistory();
}

async function saveHistoryEntry(text, plan) {
  if (!state.outputBlob || !state.outputSamples || !state.outputSampleRate) return false;
  const audioDataUrl = await blobToDataUrl(state.outputBlob);
  const entry = {
    id: crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    text,
    voice: state.selectedVoice,
    createdAt: Date.now(),
    audioDataUrl,
    gapMs: Number(els.gapMs.value),
    gain: Number(els.gain.value),
    source: plan.source || "local",
    missingCount: plan.missing?.length || 0,
    durationMs: Math.round((state.outputSamples.length / state.outputSampleRate) * 1000),
    summary: summarizePlan(plan),
  };
  state.history = [entry, ...state.history].slice(0, HISTORY_LIMIT);
  return persistHistory();
}

function persistHistory() {
  let entries = state.history.slice(0, HISTORY_LIMIT);
  while (entries.length) {
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(entries));
      state.history = entries;
      renderHistory();
      return true;
    } catch {
      entries = entries.slice(0, -1);
    }
  }
  localStorage.removeItem(HISTORY_KEY);
  state.history = [];
  renderHistory();
  return false;
}

function renderHistory() {
  els.historyList.innerHTML = "";
  els.clearHistoryButton.disabled = !state.history.length;
  els.historySummary.textContent = state.history.length
    ? `已保存 ${state.history.length} 条生成结果`
    : "调好后点击保存记录，会保存在这里";

  renderRecentHistory();
  const query = state.historyQuery.toLowerCase();
  const visibleHistory = state.history.filter((item) => {
    const matchesText = !query || String(item.text || "").toLowerCase().includes(query);
    const matchesVoice = !state.historyVoice || item.voice === state.historyVoice;
    return matchesText && matchesVoice;
  });

  if (!visibleHistory.length) {
    const empty = document.createElement("div");
    empty.className = "historyEmpty";
    empty.textContent = state.history.length ? "没有符合筛选条件的记录" : "暂无历史记录";
    els.historyList.append(empty);
    return;
  }

  for (const item of visibleHistory) {
    const row = document.createElement("article");
    row.className = "historyItem";

    const top = document.createElement("div");
    top.className = "historyTop";

    const textBlock = document.createElement("div");
    const title = document.createElement("div");
    title.className = "historyText";
    title.textContent = item.text || "未命名生成";
    const meta = document.createElement("div");
    meta.className = "historyMeta";
    meta.textContent = `${formatDate(item.createdAt)} · ${item.voice || "默认"} · ${formatDuration(item.durationMs)} · ${item.source === "ai" ? "智能匹配" : "本地匹配"}`;
    textBlock.append(title, meta);

    const actions = document.createElement("div");
    actions.className = "historyActions";
    const restore = makeSmallButton("回填", () => restoreHistoryItem(item));
    const download = makeSmallButton("下载 WAV", () => downloadDataUrl(item.audioDataUrl, `${item.voice || "voice"}-history-${item.createdAt}.wav`));
    const remove = makeSmallButton("删除", () => deleteHistoryItem(item.id), "danger");
    actions.append(restore, download, remove);

    top.append(textBlock, actions);

    const audio = document.createElement("audio");
    audio.controls = true;
    audio.src = item.audioDataUrl;

    const summary = document.createElement("div");
    summary.className = "historyPlan";
    summary.textContent = item.summary || "";

    row.append(top, audio);
    if (summary.textContent) row.append(summary);
    els.historyList.append(row);
  }
}

function renderRecentHistory() {
  els.recentHistoryList.innerHTML = "";
  if (!state.history.length) {
    const empty = document.createElement("div");
    empty.className = "recentItem";
    empty.innerHTML = "<strong>还没有保存记录</strong><span>生成后可保存到这里</span>";
    els.recentHistoryList.append(empty);
    return;
  }
  for (const item of state.history.slice(0, 3)) {
    const row = document.createElement("div");
    row.className = "recentItem";
    row.innerHTML = `<strong>${escapeHtml(item.text || "未命名生成")}</strong><span>${escapeHtml(item.voice || "默认")} · ${formatDate(item.createdAt)}</span>`;
    els.recentHistoryList.append(row);
  }
}

function makeSmallButton(text, onClick, variant = "") {
  const button = document.createElement("button");
  button.type = "button";
  button.className = variant ? `smallButton ${variant}` : "smallButton";
  button.textContent = text;
  button.addEventListener("click", onClick);
  return button;
}

async function restoreHistoryItem(item) {
  els.targetText.value = item.text || "";
  if (item.voice && state.voices.includes(item.voice)) {
    state.selectedVoice = item.voice;
    els.voiceSelect.value = item.voice;
    await loadLibrary();
  }
  window.scrollTo({ top: 0, behavior: "smooth" });
  setMessage("已回填历史文本，可重新生成或调整参数。", "ok");
}

async function saveCurrentHistory() {
  if (!state.currentPlan || !state.outputBlob) {
    setMessage("请先生成一段语音，再保存记录。", "error");
    return;
  }
  const text = els.targetText.value.trim();
  if (!text) {
    setMessage("请输入要保存的文本。", "error");
    return;
  }
  els.saveHistoryButton.disabled = true;
  try {
    const saved = await saveHistoryEntry(text, state.currentPlan);
    setMessage(saved ? "已保存到历史记录。" : "历史记录空间不足，未保存。", saved ? "ok" : "warn");
    if (saved) showToast("已保存到历史记录");
  } catch (error) {
    setMessage(error.message, "error");
  } finally {
    els.saveHistoryButton.disabled = false;
  }
}

async function deleteHistoryItem(id) {
  const confirmed = await requestConfirmation({
    title: "删除这条历史记录？",
    text: "对应的本地音频也会一并移除，此操作无法撤销。",
  });
  if (!confirmed) return;
  state.history = state.history.filter((item) => item.id !== id);
  persistHistory();
  showToast("历史记录已删除");
}

async function clearHistory() {
  if (!state.history.length) return;
  const confirmed = await requestConfirmation({
    title: "清空全部历史记录？",
    text: `将删除当前保存的 ${state.history.length} 条记录和本地音频。`,
    accept: "确认清空",
  });
  if (!confirmed) return;
  state.history = [];
  localStorage.removeItem(HISTORY_KEY);
  renderHistory();
  showToast("历史记录已清空");
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

function labelFromFilename(file) {
  return file.name.replace(/\.[^.]+$/, "").replace(/[_-]+/g, " ").trim();
}

function aliasesFromText(value) {
  return String(value || "")
    .split(/[,，、\n]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

async function uploadFiles(files) {
  if (!files.length) return;
  const voice = els.voiceInput.value.trim() || state.selectedVoice || "默认";
  state.selectedVoice = voice;
  els.uploadQueue.innerHTML = "";

  for (const file of files) {
    const row = document.createElement("div");
    row.className = "queueItem";
    row.textContent = `${file.name}：准备上传`;
    els.uploadQueue.append(row);

    try {
      if (file.size > MAX_UPLOAD_BYTES) {
        throw new Error("超过 25MB，请先压缩或剪短");
      }
      row.textContent = `${file.name}：读取中`;
      const audio_base64 = await fileToDataUrl(file);
      row.textContent = `${file.name}：上传中`;
      const result = await postJson("/api/library", {
        voice,
        filename: file.name,
        mime: file.type || "application/octet-stream",
        label: labelFromFilename(file),
        audio_base64,
      });
      row.textContent = `${file.name}：已上传到 ${voice}，标签 ${result.clip.label}`;
      els.uploadStat.textContent = "刚刚";
      showToast(`${file.name} 上传成功`);
    } catch (error) {
      row.textContent = `${file.name}：${error.message}`;
      row.classList.add("error");
    }
  }

  await loadVoices();
  await loadLibrary();
}

function renderClips() {
  els.clipList.innerHTML = "";
  if (!state.clips.length) {
    const empty = document.createElement("div");
    empty.className = "hint";
    empty.textContent = "这个音色的音节库还是空的。";
    els.clipList.append(empty);
    return;
  }

  for (const clip of state.clips) {
    const item = document.createElement("article");
    item.className = "clipItem";
    item.innerHTML = `
      <div class="clipMeta">
        <div class="clipName" title="${escapeHtml(clip.filename)}">${escapeHtml(clip.voice)} · ${escapeHtml(clip.filename)}</div>
      </div>
      <audio controls src="${apiUrl(clip.url)}"></audio>
      <label>
        音节标签
        <input data-action="label" data-id="${clip.id}" value="${escapeHtml(clip.label)}" />
      </label>
      <label>
        同音/谐音别名
        <input data-action="aliases" data-id="${clip.id}" value="${escapeHtml((clip.aliases || []).join("，"))}" />
      </label>
      <div class="clipActions">
        <button class="smallButton" data-action="save" data-id="${clip.id}">保存</button>
        <button class="smallButton danger" data-action="delete" data-id="${clip.id}">删除</button>
      </div>
    `;
    els.clipList.append(item);
  }
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function summarizePlan(plan) {
  return (plan.sequence || [])
    .filter((step) => step.type === "clip" || step.type === "missing")
    .slice(0, 10)
    .map((step) => (step.type === "missing" ? `缺少 ${step.text}` : `${step.text || step.label}→${step.label}`))
    .join("  ");
}

function formatDate(timestamp) {
  return new Intl.DateTimeFormat("zh-CN", {
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(timestamp || Date.now()));
}

function formatDuration(ms) {
  if (!ms) return "0.0 秒";
  return `${(ms / 1000).toFixed(1)} 秒`;
}

function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

function writeString(view, offset, text) {
  for (let i = 0; i < text.length; i++) {
    view.setUint8(offset + i, text.charCodeAt(i));
  }
}

function speakerIcon() {
  return `
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M4 9v6h4l5 4V5L8 9H4z"></path>
      <path d="M16 8.5c1 1 1.5 2.2 1.5 3.5S17 14.5 16 15.5"></path>
      <path d="M18.5 6c1.7 1.7 2.5 3.7 2.5 6s-.8 4.3-2.5 6"></path>
    </svg>
  `;
}

async function selectVoice(voice) {
  if (!voice || voice === state.selectedVoice) return;
  state.selectedVoice = voice;
  state.currentPlan = null;
  revokeOutput();
  setMessage("");
  renderVoices();
  renderAdminVoiceFilter();
  await loadLibrary();
  els.timeline.innerHTML = "";
}

document.querySelectorAll(".navItem, .navTarget").forEach((button) => {
  button.addEventListener("click", () => switchView(button.dataset.view));
});
document.querySelectorAll(".mirrorBuildButton").forEach((button) => {
  button.addEventListener("click", buildPlan);
});
els.mobileMenuButton.addEventListener("click", () => {
  const open = els.mainNav.classList.toggle("open");
  els.mobileMenuButton.setAttribute("aria-expanded", String(open));
});
els.voiceSearch.addEventListener("input", renderVoiceList);
els.voiceList.addEventListener("click", (event) => {
  const button = event.target.closest("[data-voice]");
  if (!button) return;
  selectVoice(button.dataset.voice).catch((error) => {
    els.adminLibrarySummary.textContent = error.message;
  });
});
els.historySearch.addEventListener("input", () => {
  state.historyQuery = els.historySearch.value.trim();
  renderHistory();
});
els.historyVoiceFilter.addEventListener("change", () => {
  state.historyVoice = els.historyVoiceFilter.value;
  renderHistory();
});
els.targetText.addEventListener("input", () => {
  els.characterCount.textContent = String(els.targetText.value.length);
  setBuildLoading(false);
});
els.clearComposerButton.addEventListener("click", () => {
  els.targetText.value = "";
  els.characterCount.textContent = "0";
  state.currentPlan = null;
  els.timeline.innerHTML = "";
  revokeOutput();
  setMessage("");
  setBuildLoading(false);
});
els.uploadDropzone.addEventListener("dragover", (event) => {
  event.preventDefault();
  els.uploadDropzone.classList.add("dragging");
});
els.uploadDropzone.addEventListener("dragleave", () => els.uploadDropzone.classList.remove("dragging"));
els.uploadDropzone.addEventListener("drop", (event) => {
  event.preventDefault();
  els.uploadDropzone.classList.remove("dragging");
  uploadFiles([...event.dataTransfer.files]).catch((error) => {
    els.adminLibrarySummary.textContent = error.message;
    showToast(error.message, "error");
  });
});

els.filePicker.addEventListener("change", (event) => {
  uploadFiles([...event.target.files]).catch((error) => {
    els.adminLibrarySummary.textContent = error.message;
  });
  event.target.value = "";
});

els.refreshButton.addEventListener("click", () => {
  loadVoices()
    .then(loadLibrary)
    .catch((error) => {
      els.adminLibrarySummary.textContent = error.message;
    });
});

els.voiceFilter.addEventListener("change", () => {
  state.selectedVoice = els.voiceFilter.value;
  state.currentPlan = null;
  revokeOutput();
  setMessage("");
  renderVoices();
  loadLibrary().catch((error) => {
    els.adminLibrarySummary.textContent = error.message;
  });
  els.timeline.innerHTML = "";
});

els.clipList.addEventListener("input", (event) => {
  const clip = state.clips.find((item) => item.id === event.target.dataset.id);
  if (!clip) return;
  if (event.target.dataset.action === "label") clip.label = event.target.value;
  if (event.target.dataset.action === "aliases") clip.aliases = aliasesFromText(event.target.value);
});

els.clipList.addEventListener("click", async (event) => {
  const button = event.target.closest("button");
  if (!button) return;
  const clip = state.clips.find((item) => item.id === button.dataset.id);
  if (!clip) return;
  button.disabled = true;
  try {
    if (button.dataset.action === "save") {
      await postJson("/api/library/update", {
        id: clip.id,
        voice: clip.voice,
        label: clip.label,
        aliases: clip.aliases || [],
      });
      showToast("音节信息已保存");
    }
    if (button.dataset.action === "delete") {
      const confirmed = await requestConfirmation({
        title: `删除音节“${clip.label || clip.filename}”？`,
        text: "删除后，该音节将不再参与语音拼接。",
      });
      if (!confirmed) return;
      await postJson("/api/library/delete", { id: clip.id });
      showToast("音节已删除");
    }
    await loadVoices();
    await loadLibrary();
  } catch (error) {
    els.adminLibrarySummary.textContent = error.message;
  } finally {
    button.disabled = false;
  }
});

els.voiceSelect.addEventListener("change", async () => {
  await selectVoice(els.voiceSelect.value);
});

els.buildButton.addEventListener("click", buildPlan);

els.playButton.addEventListener("click", () => {
  if (!state.outputUrl) return;
  new Audio(state.outputUrl).play();
});

els.downloadButton.addEventListener("click", async () => {
  if (!state.outputBlob) return;
  const format = els.downloadFormat?.value || "wav";
  if (format === "mp3") {
    try {
      els.downloadButton.disabled = true;
      setMessage("正在导出 MP3...");
      const blob = await encodeMp3FromSamples(state.outputSamples, state.outputSampleRate);
      downloadBlob(blob, "mp3");
      setMessage("MP3 已开始下载。", "ok");
    } catch (error) {
      setMessage(error.message, "error");
    } finally {
      els.downloadButton.disabled = false;
    }
    return;
  }
  downloadBlob(state.outputBlob, "wav");
});

els.downloadFormat.addEventListener("change", updateDownloadLabel);
els.backToNoonAi.addEventListener("click", returnToNoonAi);
els.saveHistoryButton.addEventListener("click", saveCurrentHistory);
els.clearHistoryButton.addEventListener("click", clearHistory);
document.addEventListener("click", hideTimelineContextMenu);
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") hideTimelineContextMenu();
});

for (const input of [els.gapMs, els.gain]) {
  input.addEventListener("input", async () => {
    els.gapValue.textContent = els.gapMs.value;
    els.gainValue.textContent = els.gain.value;
    if (state.currentPlan) {
      await renderOutputAudio(state.currentPlan);
    }
  });
}

els.settingsFormat.addEventListener("change", () => {
  els.downloadFormat.value = els.settingsFormat.value;
  updateDownloadLabel();
  showToast("默认下载格式已更新");
});
els.settingsGain.addEventListener("input", () => {
  els.gain.value = els.settingsGain.value;
  els.gainValue.textContent = els.settingsGain.value;
  els.settingsGainValue.textContent = els.settingsGain.value;
});
els.settingsGap.addEventListener("input", () => {
  els.gapMs.value = els.settingsGap.value;
  els.gapValue.textContent = els.settingsGap.value;
  els.settingsGapValue.textContent = els.settingsGap.value;
});
els.compactModeToggle.addEventListener("change", () => {
  document.body.classList.toggle("compact", els.compactModeToggle.checked);
});
els.exportSettingsButton.addEventListener("click", () => {
  const config = {
    format: els.downloadFormat.value,
    gain: Number(els.gain.value),
    gapMs: Number(els.gapMs.value),
    compactMode: els.compactModeToggle.checked,
  };
  const blob = new Blob([JSON.stringify(config, null, 2)], { type: "application/json" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = "letterpress-settings.json";
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
  showToast("配置已导出");
});

setBuildLoading(false);
updateDownloadLabel();

loadVoices()
  .then(loadLibrary)
  .catch((error) => {
    els.serverStatus.textContent = "服务未启动";
    els.librarySummary.textContent = error.message;
  });
loadHistory();
