const STORAGE_KEY = "noonai.model-evaluation.v2";
const API_BASE = window.location.protocol === "file:" ? "http://localhost:3000" : "";
const DOMAINS = ["LOG", "QNT", "ALG", "SCI", "LNG", "KNO", "CTX", "EQI", "SOC", "ETH", "MET", "CRE"];
const AUTOMATIC_BATCH_VERSION = 3;
const AUTOMATIC_ITEM_BATCHES = [[1, 2], [3, 4], [5, 6], [7, 8], [9], [10], [11], [12]];
const DOMAIN_LABELS = {
  LOG: "逻辑", QNT: "数理", ALG: "算法", SCI: "科学", LNG: "语言", KNO: "知识",
  CTX: "指令", EQI: "情商", SOC: "社交", ETH: "伦理", MET: "元认知", CRE: "创造"
};
const CUSTOM_API_KEY_STORAGE = "noonai.model-evaluation.custom-api-key";
const state = loadState();
const els = Object.fromEntries([...document.querySelectorAll("[id]")].map((el) => [el.id, el]));
let modules = [];
let benchmark = {};
let activeDomain = state.activeDomain || "";
let historyRecords = [];
let historyLoading = false;
let historyError = "";
const selectedHistoryIds = new Set();
let automaticRunning = false;
let automaticStopRequested = false;
let automaticController = null;
let automaticCurrentDomain = "";
let automaticBatchProgress = 0;
let automaticErrorDomain = "";
let automaticMessage = "";
let externalWorkflow = Boolean(state.externalWorkflow);
let batchRunning = false;
let automaticPollTimer = null;
let currentView = state.currentView || "dashboard";

init();

async function init() {
  els.modelName.value = state.modelName || "";
  bindEvents();
  setView(currentView, false);
  try {
    const response = await evaluationFetch("/api/model-evaluation/modules");
    if (!response.ok) throw new Error("题库读取失败");
    const payload = await response.json();
    modules = payload.modules || [];
    benchmark = payload.benchmark || {};
    activeDomain = modules.some((item) => item.domain === activeDomain) ? activeDomain : modules[0]?.domain;
    render();
    await resumeBackgroundRun();
  } catch (error) {
    els.moduleTitle.textContent = error.message;
    els.statusText.textContent = "请确认 NoonAI 服务端已经启动。";
  }
}

function bindEvents() {
  document.addEventListener("click", (event) => {
    const viewButton = event.target.closest("[data-view]");
    if (viewButton) setView(viewButton.dataset.view);
    const resultDomain = event.target.closest("[data-result-domain]");
    if (resultDomain) openDomainDetail(resultDomain.dataset.resultDomain);
  });
  els.moduleList.addEventListener("click", (event) => {
    const button = event.target.closest("[data-domain]");
    if (!button) return;
    if (automaticRunning) return showToast("自动测评进行中");
    saveDraft();
    activeDomain = button.dataset.domain;
    state.activeDomain = activeDomain;
    saveState();
    render();
    setView("workspace");
  });
  els.modelName.addEventListener("input", () => {
    state.modelName = els.modelName.value;
    saveState();
    renderDashboard();
  });
  els.answerInput.addEventListener("input", () => {
    state.answers ||= {};
    state.answers[activeDomain] = els.answerInput.value;
    els.answerCount.textContent = `${els.answerInput.value.length} 字`;
    renderWorkspaceStatus();
    saveState();
  });
  els.copyButton.addEventListener("click", copyModule);
  els.gradeButton.addEventListener("click", gradeModule);
  els.externalModelName.value = state.externalModelName || "";
  els.externalModelName.addEventListener("input", () => {
    state.externalModelName = els.externalModelName.value;
    saveState();
  });
  els.customApiName.value = state.customApiName || "";
  els.customApiBaseUrl.value = state.customApiBaseUrl || "";
  els.customApiModel.value = state.customApiModel || "";
  els.customApiKey.value = sessionStorage.getItem(CUSTOM_API_KEY_STORAGE) || "";
  for (const input of [els.customApiName, els.customApiBaseUrl, els.customApiModel]) {
    input.addEventListener("input", () => {
      state.customApiName = els.customApiName.value;
      state.customApiBaseUrl = els.customApiBaseUrl.value;
      state.customApiModel = els.customApiModel.value;
      saveState();
      renderCustomApiStatus();
    });
  }
  els.customApiKey.addEventListener("input", () => {
    sessionStorage.setItem(CUSTOM_API_KEY_STORAGE, els.customApiKey.value);
    renderCustomApiStatus();
  });
  els.testCustomApiButton.addEventListener("click", testCustomApi);
  els.startCustomApiButton.addEventListener("click", startCustomApiEvaluation);
  els.externalContinueButton.addEventListener("click", toggleExternalWorkflow);
  els.batchImportButton.addEventListener("click", openBatchImport);
  els.copyFullBookletButton.addEventListener("click", copyFullBooklet);
  els.downloadFullBookletButton.addEventListener("click", downloadFullBooklet);
  els.batchCloseButton.addEventListener("click", closeBatchImport);
  els.batchOverlay.addEventListener("click", (event) => {
    if (event.target === els.batchOverlay) closeBatchImport();
  });
  els.copyBatchTemplateButton.addEventListener("click", copyBatchTemplate);
  els.runBatchImportButton.addEventListener("click", runBatchImport);
  els.saveResultButton.addEventListener("click", () => saveCurrentEvaluation(false));
  els.historyButton.addEventListener("click", openHistory);
  els.dashboardHistoryButton.addEventListener("click", openHistory);
  els.historyCloseButton.addEventListener("click", closeHistory);
  els.historyOverlay.addEventListener("click", (event) => {
    if (event.target === els.historyOverlay) closeHistory();
  });
  els.historyContent.addEventListener("click", handleHistoryClick);
  els.historyContent.addEventListener("change", handleHistoryChange);
  els.resetButton.addEventListener("click", resetEvaluation);
  els.startManualButton.addEventListener("click", () => {
    if (!els.modelName.value.trim()) {
      els.modelName.focus();
      return showToast("请先填写被测模型名称");
    }
    setView("workspace");
  });
  els.saveDraftButton.addEventListener("click", () => {
    saveDraft();
    showToast("草稿已保存");
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && !els.historyOverlay.hidden) closeHistory();
    if (event.key === "Escape" && !els.batchOverlay.hidden) closeBatchImport();
    if (event.key === "Enter" && (event.ctrlKey || event.metaKey) && externalWorkflow) {
      gradeModule();
    }
  });
}

function setView(view, persist = true) {
  const allowed = ["dashboard", "setup", "workspace", "progress", "results", "domain-detail", "settings"];
  currentView = allowed.includes(view) ? view : "dashboard";
  document.querySelectorAll("[data-page]").forEach((page) => {
    page.hidden = page.dataset.page !== currentView;
  });
  document.querySelectorAll(".topnav [data-view]").forEach((button) => {
    button.classList.toggle("active", button.dataset.view === currentView || (currentView === "domain-detail" && button.dataset.view === "results"));
  });
  if (persist) {
    state.currentView = currentView;
    saveState();
  }
  window.scrollTo({ top: 0, behavior: persist ? "smooth" : "auto" });
}

function openDomainDetail(domain) {
  if (!DOMAINS.includes(domain)) return;
  activeDomain = domain;
  state.activeDomain = domain;
  saveState();
  render();
  setView(state.results?.[domain] ? "domain-detail" : "workspace");
}

function render() {
  if (!modules.some((item) => item.domain === activeDomain)) activeDomain = modules[0]?.domain;

  renderModuleList();
  const module = modules.find((item) => item.domain === activeDomain);
  if (!module) return;
  els.moduleIndex.textContent = `模块 ${String(module.number).padStart(2, "0")} · ${module.domain}`;
  els.moduleTitle.textContent = module.title;
  els.moduleMeta.textContent = `${module.itemCount} 题 · 8 核心 + 4 前沿 · 建议限时 12 分钟`;
  els.sendInstruction.textContent = "请在站外模型中新建对话，关闭外部工具，采用低温度，一次性回答本模块全部 12 题。";
  els.promptPreview.textContent = module.content;
  els.answerInput.value = state.answers?.[activeDomain] || "";
  els.answerInput.placeholder = `在这里粘贴站外 AI 对 ${activeDomain} 模块 12 道题的完整回答…`;
  els.answerCount.textContent = `${els.answerInput.value.length} 字`;
  els.answerInput.disabled = automaticRunning;
  els.modelName.disabled = automaticRunning;
  els.copyButton.disabled = automaticRunning;
  els.gradeButton.disabled = automaticRunning;
  els.gradeButton.textContent = externalWorkflow ? "评分并复制下一模块" : "开始评分";
  els.detailDomainCode.textContent = `${module.domain} · DOMAIN ${String(module.number).padStart(2, "0")}`;
  els.detailDomainTitle.textContent = module.title;
  els.detailDomainMeta.textContent = `${module.itemCount} 道题 · 8 核心 + 4 前沿`;
  renderResult(state.results?.[activeDomain]);
  renderDashboard();
  renderAutomaticPanel();
  renderWorkspaceStatus();
  renderCapabilityGrid();
  renderResultOverview();
}

function renderModuleList() {
  els.moduleList.innerHTML = modules.map((module) => `
    <button class="module-button ${module.domain === activeDomain ? "active" : ""} ${state.results?.[module.domain] ? "done" : ""}" data-domain="${module.domain}" type="button">
      <b>${String(module.number).padStart(2, "0")}</b><span>${escapeHtml(module.title)}</span><i></i>
    </button>
  `).join("");
}

function renderWorkspaceStatus() {
  const answer = els.answerInput.value.trim();
  const result = state.results?.[activeDomain];
  els.workspaceStatus.textContent = result ? "已评分" : answer ? "已填写" : "未填写";
  els.workspaceStatus.className = `status-badge ${result ? "pass" : ""}`;
  els.gradeButton.disabled = automaticRunning || !answer;
}

function renderCapabilityGrid() {
  els.capabilityGrid.innerHTML = modules.map((module) => {
    const result = state.results?.[module.domain];
    return `
      <button class="capability-card ${result ? "done" : ""}" data-result-domain="${module.domain}" type="button">
        <header><span>${String(module.number).padStart(2, "0")} · ${module.domain}</span><i></i></header>
        <h4>${escapeHtml(module.title)}</h4>
        <p>${result ? "评分已完成，查看领域详情" : "等待回答与评分"}</p>
        <strong>${result ? formatScore(result.score) : "—"}</strong>
      </button>`;
  }).join("");
}

function renderAutomaticPanel() {
  const completed = DOMAINS.filter((domain) => state.results?.[domain]?.items?.length === 12).length;
  els.automaticProgressText.textContent = automaticCurrentDomain
    ? `${completed} / 12 · 批次 ${automaticBatchProgress} / 8`
    : `${completed} / 12`;
  els.automaticProgressBar.style.width = `${completed / 12 * 100}%`;
  els.automaticStatus.textContent = automaticMessage || (
    completed === 12 ? "全部模块已完成" : completed ? "可从未完成模块继续" : "尚未开始"
  );
  els.automaticDomains.innerHTML = DOMAINS.map((domain) => {
    const done = state.results?.[domain]?.items?.length === 12;
    const className = done ? "done" : domain === automaticErrorDomain ? "error" : domain === automaticCurrentDomain ? "active" : "";
    return `<span class="${className}">${domain}</span>`;
  }).join("");
  els.externalContinueButton.textContent = externalWorkflow ? "结束连续采集" : "开始连续采集";
  els.externalContinueButton.classList.toggle("active", externalWorkflow);
  els.externalModelName.disabled = automaticRunning || externalWorkflow;
  els.batchImportButton.disabled = automaticRunning || batchRunning;
  for (const input of [els.customApiName, els.customApiBaseUrl, els.customApiModel, els.customApiKey]) {
    input.disabled = automaticRunning;
  }
  els.testCustomApiButton.disabled = automaticRunning;
  els.startCustomApiButton.disabled = false;
  els.startCustomApiButton.textContent = automaticRunning ? "停止 API 测评" : "使用此 API 一键测评";
  els.progressModelName.textContent = state.modelName || state.customApiName || "未命名模型";
  renderCustomApiStatus();
}

function customApiConfig() {
  return {
    name: els.customApiName.value.trim(),
    baseUrl: els.customApiBaseUrl.value.trim(),
    model: els.customApiModel.value.trim(),
    apiKey: els.customApiKey.value.trim()
  };
}

function renderCustomApiStatus(message = "") {
  const config = customApiConfig();
  const status = message || (
    config.baseUrl && config.model && config.apiKey ? "配置已填写，等待测试" : "尚未配置"
  );
  els.customApiStatus.textContent = status;
  els.setupApiStatus.textContent = config.baseUrl && config.model && config.apiKey ? "API 配置已填写" : "前往配置 API";
}

async function testCustomApi() {
  const config = customApiConfig();
  if (!config.baseUrl || !config.model || !config.apiKey) return showToast("请完整填写 API 配置");
  els.testCustomApiButton.disabled = true;
  renderCustomApiStatus("正在测试连接…");
  try {
    const response = await evaluationFetch("/api/model-evaluation/custom-api/test", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(config)
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || "连接失败");
    renderCustomApiStatus(`连接成功 · ${payload.model}`);
    showToast("外部 API 连接成功");
  } catch (error) {
    renderCustomApiStatus(`连接失败：${error.message}`);
    showToast(error.message || "连接失败");
  } finally {
    els.testCustomApiButton.disabled = false;
  }
}

async function startCustomApiEvaluation() {
  if (automaticRunning) {
    return stopBackgroundEvaluation();
  }
  const config = customApiConfig();
  if (!config.name || !config.baseUrl || !config.model || !config.apiKey) {
    return showToast("请完整填写外部 API 配置");
  }
  await startBackgroundEvaluation(config);
}

async function startBackgroundEvaluation(config) {
  const completed = DOMAINS.filter((domain) => state.results?.[domain]?.items?.length === 12);
  const runIdentity = `custom:${config.baseUrl}:${config.model}`;
  if (completed.length === 12) {
    if (!confirm("正式测评已经完成。是否清空当前页面结果并创建新的后台测评？")) return;
    clearFullEvaluationResults();
  } else if (completed.length && state.automaticRunModel !== runIdentity) {
    if (!confirm("当前页面已有其他模型的结果。为避免混合报告，需要清空后开始。是否继续？")) return;
    clearFullEvaluationResults();
  }
  state.automaticRunModel = runIdentity;
  state.modelName = config.name;
  els.modelName.value = config.name;
  saveState();
  automaticRunning = true;
  automaticMessage = "正在创建服务端后台任务…";
  render();
  setView("progress");
  try {
    const response = await evaluationFetch("/api/model-evaluation/run", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        modelName: config.name,
        customApi: {
          baseUrl: config.baseUrl,
          model: config.model,
          apiKey: config.apiKey
        },
        results: state.results || {}
      })
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok && response.status !== 409) throw new Error(payload.error || "无法启动后台测评。");
    syncBackgroundJob(payload.job);
    scheduleBackgroundPoll();
  } catch (error) {
    automaticRunning = false;
    automaticMessage = `启动失败：${error.message}`;
    render();
    showToast(error.message || "无法启动后台测评");
  }
}

async function stopBackgroundEvaluation() {
  automaticMessage = "正在请求服务器停止任务…";
  renderAutomaticPanel();
  try {
    const response = await evaluationFetch("/api/model-evaluation/run", { method: "DELETE" });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || "停止任务失败。");
    syncBackgroundJob(payload.job);
    scheduleBackgroundPoll();
  } catch (error) {
    showToast(error.message || "停止任务失败");
  }
}

async function resumeBackgroundRun() {
  try {
    const response = await evaluationFetch("/api/model-evaluation/run");
    if (!response.ok) return;
    const payload = await response.json();
    if (!payload.job) return;
    syncBackgroundJob(payload.job);
    if (["running", "pending"].includes(payload.job.status)) scheduleBackgroundPoll();
  } catch {
    // A missing background job must not block the manual workflow.
  }
}

function scheduleBackgroundPoll() {
  clearTimeout(automaticPollTimer);
  automaticPollTimer = setTimeout(pollBackgroundRun, 2500);
}

async function pollBackgroundRun() {
  try {
    const response = await evaluationFetch("/api/model-evaluation/run");
    const payload = await response.json().catch(() => ({}));
    if (response.ok && payload.job) syncBackgroundJob(payload.job);
    if (payload.job && ["running", "pending"].includes(payload.job.status)) {
      scheduleBackgroundPoll();
    }
  } catch {
    scheduleBackgroundPoll();
  }
}

function syncBackgroundJob(job) {
  if (!job) return;
  automaticRunning = ["running", "pending"].includes(job.status);
  automaticCurrentDomain = job.currentDomain || "";
  automaticBatchProgress = Number(job.batch || 0);
  automaticMessage = job.message || "";
  automaticErrorDomain = job.status === "failed" ? job.currentDomain || "" : "";
  if (job.results && typeof job.results === "object") {
    state.results = { ...(state.results || {}), ...job.results };
  }
  if (job.currentDomain && DOMAINS.includes(job.currentDomain)) {
    activeDomain = job.currentDomain;
    state.activeDomain = activeDomain;
  }
  if (job.historyRecord && !historyRecords.some((record) => record.id === job.historyRecord.id)) {
    historyRecords.unshift(job.historyRecord);
  }
  saveState();
  render();
  if (job.status === "complete") {
    setView("results");
    showToast("AIX-144 全链路完成，报告已保存");
  }
  if (job.status === "failed") {
    setView("progress");
    showToast(job.error || "后台测评任务失败");
  }
}

function renderDashboard() {
  const results = DOMAINS.map((domain) => state.results?.[domain]).filter(Boolean);
  const hasResults = results.length > 0;
  const targetCount = 12;
  const quality = average(results.map((result) => Number(result.score)));

  els.totalScore.textContent = quality === null ? "—" : quality.toFixed(1);
  els.dashboardScore.textContent = quality === null ? "—" : quality.toFixed(1);
  els.scoreRing.style.setProperty("--score", quality || 0);
  els.progressText.textContent = `${results.length} / ${targetCount}`;
  els.workspaceProgressText.textContent = `${results.length} / ${targetCount}`;
  els.progressBar.style.width = `${results.length / targetCount * 100}%`;
  els.setupReadyStatus.textContent = state.modelName?.trim() ? "模型名称已填写" : "待填写模型名";
  els.dashboardEmptyState.hidden = hasResults;
  els.dashboardMetrics.hidden = !hasResults;
  els.scoreCardKicker.textContent = hasResults ? "LATEST EVALUATION" : "READY TO START";

  const pass = evaluatePass(results);
  els.passStatus.textContent = hasResults ? pass.label : "待开始";
  els.passStatus.className = hasResults ? pass.className : "";
  els.passNote.textContent = hasResults ? pass.note : "尚未创建测评";
  els.saveResultButton.disabled = !isCurrentEvaluationComplete() || !els.modelName.value.trim();
  els.saveResultButton.textContent = isCurrentEvaluationComplete() ? "保存结果" : "完成后保存";

  if (!results.length) {
    els.strongestDomain.textContent = "—";
    els.weakestDomain.textContent = "—";
    els.strongestDomainNote.textContent = "等待评分";
    els.weakestDomainNote.textContent = "等待评分";
    els.reportTitle.textContent = "还没有测评结果";
    els.reportSummary.textContent = "创建首次测评后，这里会显示模型总分、能力强弱项与完成进度。";
    return;
  }
  const sorted = [...results].sort((a, b) => b.score - a.score);
  const model = state.modelName?.trim() || "该模型";
  els.strongestDomain.textContent = sorted[0].domain;
  els.strongestDomainNote.textContent = `${DOMAIN_LABELS[sorted[0].domain]} · ${formatScore(sorted[0].score)}`;
  els.weakestDomain.textContent = sorted.at(-1).domain;
  els.weakestDomainNote.textContent = `${DOMAIN_LABELS[sorted.at(-1).domain]} · ${formatScore(sorted.at(-1).score)}`;
  els.reportTitle.textContent = `${model} 已完成 ${results.length} / 12 个能力域`;
  els.reportSummary.textContent = results.length === 12
    ? `正式 Quality ${quality.toFixed(1)}；最高域 ${sorted[0].domain}（${sorted[0].score}），最低域 ${sorted.at(-1).domain}（${sorted.at(-1).score}）。${pass.note}`
    : `当前 Quality ${quality.toFixed(1)} 为已完成模块的临时值；最高域 ${sorted[0].domain}（${sorted[0].score}），最低域 ${sorted.at(-1).domain}（${sorted.at(-1).score}）。`;
}

function renderResultOverview() {
  const results = currentEvaluationResults();
  const hasResults = results.length > 0;
  const quality = average(results.map((result) => Number(result.score)));
  const sorted = [...results].sort((a, b) => Number(b.score) - Number(a.score));
  const pass = evaluatePass(results);
  const strongest = sorted[0];
  const weakest = sorted.at(-1);
  const modelName = state.modelName?.trim() || "未命名模型";

  els.resultModelName.textContent = hasResults ? modelName : "测评结果";
  els.resultMeta.textContent = hasResults
    ? `${benchmark.name || "AIX-144"} · ${results.length} / 12 个能力域 · ${new Date().toLocaleDateString()}`
    : "当前还没有已评分的能力域";
  els.resultEmptyState.hidden = hasResults;
  els.resultScorePanel.hidden = !hasResults;
  els.resultMetrics.hidden = !hasResults;
  els.resultDistribution.hidden = !hasResults;
  els.resultTotalScore.textContent = quality === null ? "—" : quality.toFixed(1);
  els.resultMetricScore.textContent = quality === null ? "—" : quality.toFixed(1);
  els.resultPassStatus.textContent = pass.label;
  els.resultPassStatus.className = `status-badge ${pass.className}`;
  els.resultPassNote.textContent = pass.note;
  els.resultStrongest.textContent = strongest?.domain || "—";
  els.resultStrongestNote.textContent = strongest ? `${DOMAIN_LABELS[strongest.domain]} · ${formatScore(strongest.score)}` : "等待评分";
  els.resultWeakest.textContent = weakest?.domain || "—";
  els.resultWeakestNote.textContent = weakest ? `${DOMAIN_LABELS[weakest.domain]} · ${formatScore(weakest.score)}` : "等待评分";
  els.resultConclusion.textContent = !results.length
    ? "完成测评后生成综合结论"
    : results.length < 12
      ? `已完成 ${results.length} 个能力域，当前结果仍为阶段性表现。`
      : `${modelName} 在 ${DOMAIN_LABELS[strongest.domain]} 维度表现最佳，${DOMAIN_LABELS[weakest.domain]} 是当前主要改进方向。`;

  els.resultDomainList.innerHTML = modules.map((module) => {
    const result = state.results?.[module.domain];
    const score = Number(result?.score) || 0;
    return `
      <button class="result-domain-row" data-result-domain="${module.domain}" type="button">
        <span><b>${module.domain}</b> ${escapeHtml(module.title)}</span>
        <i><em style="width:${Math.max(0, Math.min(100, score))}%"></em></i>
        <strong>${result ? formatScore(score) : "—"}</strong>
        <small>${result ? "查看详情" : "待评分"}</small>
      </button>`;
  }).join("");
}

function isCurrentEvaluationComplete() {
  return DOMAINS.every((domain) => state.results?.[domain]?.items?.length === 12);
}

function currentEvaluationResults() {
  return DOMAINS.map((domain) => state.results?.[domain]).filter(Boolean);
}

function evaluatePass(results) {
  if (results.length < 12) {
    return { label: "待完成", className: "", note: `还需完成 ${12 - results.length} 个模块` };
  }
  const byDomain = Object.fromEntries(results.map((result) => [result.domain, Number(result.score)]));
  const quality = average(results.map((result) => Number(result.score))) || 0;
  const frontier = average(results.map((result) => Number(result.frontierScore))) || 0;
  const analytical = average(["LOG", "QNT", "ALG", "SCI"].map((domain) => byDomain[domain])) || 0;
  const human = average(["EQI", "SOC", "ETH", "MET"].map((domain) => byDomain[domain])) || 0;
  const calibrated = results.flatMap((result) => result.items || [])
    .filter((item) => (item.correct === 0 || item.correct === 1) && Number.isFinite(Number(item.confidence)));
  const wrong = calibrated.filter((item) => item.correct === 0);
  const overclaim = wrong.length
    ? wrong.filter((item) => Number(item.confidence) >= 90).length / wrong.length
    : 0;
  const failed = [];
  if (quality < 50) failed.push("Quality < 50");
  if (frontier < 30) failed.push("前沿分 < 30");
  if (Math.min(...Object.values(byDomain)) < 30) failed.push("存在能力域 < 30");
  if (analytical < 45) failed.push("分析域均分 < 45");
  if (human < 45) failed.push("人本域均分 < 45");
  if (calibrated.length < 40) failed.push("有效校准题不足 40");
  if (overclaim > 0.2) failed.push("过度自信率 > 20%");
  return failed.length
    ? { label: "未通过", className: "fail", note: failed.join("；") }
    : { label: "通过", className: "pass", note: "满足 AIX-144 v1.0 全部暂定门槛" };
}

function renderResult(result) {
  els.resultPanel.hidden = !result;
  if (!result) {
    els.detailStatus.textContent = "待评分";
    return;
  }
  els.moduleScore.textContent = Number(result.score).toFixed(1);
  els.detailStatus.textContent = Number(result.score) >= 50 ? "表现稳定" : "需要提升";
  els.moduleSummary.textContent = `${result.summary || "评分完成。"} 核心 ${Number(result.coreScore).toFixed(1)}，前沿 ${Number(result.frontierScore).toFixed(1)}。`;
  els.itemResults.innerHTML = result.items.map((item) => {
    const confidence = Number.isFinite(Number(item.confidence)) ? ` · 置信度 ${item.confidence}%` : "";
    const correctness = item.correct === 1 ? " · 客观正确" : item.correct === 0 ? " · 客观错误" : "";
    const errors = item.errorCodes?.length ? `<p class="error-codes">规则标记：${escapeHtml(item.errorCodes.join("、"))}</p>` : "";
    return `
      <article class="item ${item.tier}">
        <header>
          <strong>${escapeHtml(item.itemId)} <em>${item.tier === "frontier" ? "前沿" : "核心"}</em></strong>
          <strong>${item.score} / 10</strong>
        </header>
        <p>${escapeHtml(item.verdict)}${confidence}${correctness}</p>
        <p>改进：${escapeHtml(item.improvement)}</p>
        ${errors}
      </article>
    `;
  }).join("");
}

async function copyModule() {
  const module = modules.find((item) => item.domain === activeDomain);
  if (!module) return;
  const prompt = [
    "Answer the following AIX evaluation without web access, retrieval, code execution, calculators, or other external tools.",
    "Use a fresh context, follow every item-specific output contract exactly, and preserve every item ID.",
    "Answer all 12 items in this module in one response.",
    "For every objective item, include Confidence: N% unless the exact-output grammar requires confidence to be collected separately.",
    "",
    module.content
  ].join("\n");
  await navigator.clipboard.writeText(prompt);
  showToast(`${module.domain} 的 12 道题已复制`);
}

async function toggleExternalWorkflow() {
  if (externalWorkflow) {
    externalWorkflow = false;
    state.externalWorkflow = false;
    saveState();
    render();
    return showToast("已结束外部模型连续采集");
  }
  const name = els.externalModelName.value.trim();
  if (!name) {
    els.externalModelName.focus();
    return showToast("请先填写外部模型名称");
  }
  if (automaticRunning) return showToast("站内自动测评正在进行");
  const completed = DOMAINS.filter((domain) => state.results?.[domain]?.items?.length === 12).length;
  const previousName = state.externalRunModel || state.modelName || "";
  if (completed && previousName && previousName !== name) {
    if (!confirm("当前正式测评中已有其他模型的结果。为避免混合报告，需要先清空正式测评进度。是否继续？")) return;
    clearFullEvaluationResults();
  }
  state.externalModelName = name;
  state.externalRunModel = name;
  state.modelName = name;
  state.evaluationAdministration = "module-separated-manual";
  els.modelName.value = name;
  externalWorkflow = true;
  state.externalWorkflow = true;
  const nextDomain = DOMAINS.find((domain) => !state.results?.[domain]?.items?.length) || DOMAINS[0];
  activeDomain = nextDomain;
  state.activeDomain = nextDomain;
  saveState();
  render();
  await copyModule();
  showToast(`${nextDomain} 题目已复制，去外部网站粘贴即可`);
}

function openBatchImport() {
  const name = els.externalModelName.value.trim();
  if (!name) {
    els.externalModelName.focus();
    return showToast("请先填写外部模型名称");
  }
  els.batchOverlay.hidden = false;
  document.body.classList.add("modal-open");
  els.batchImportStatus.textContent = "等待粘贴";
  setTimeout(() => els.batchAnswerInput.focus(), 0);
}

function closeBatchImport() {
  if (batchRunning) return showToast("批量评分进行中");
  els.batchOverlay.hidden = true;
  if (els.historyOverlay.hidden) document.body.classList.remove("modal-open");
}

async function copyBatchTemplate() {
  const template = DOMAINS.map((domain) => `[${domain}]\nPaste the complete ${domain} module response here.`).join("\n\n");
  await navigator.clipboard.writeText(template);
  showToast("12 模块回答模板已复制");
}

function buildFullBookletDocument() {
  const modelName = els.externalModelName.value.trim() || "External Model";
  const sections = modules.map((module) => [
    `# [${module.domain}] ${module.title}`,
    "",
    `Begin this domain's response with \`[${module.domain}]\` on a separate line and preserve every item ID.`,
    "",
    module.content
  ].join("\n"));
  return [
    "# AIX-144 External Model Full-Booklet Edition",
    "",
    `Tested model: ${modelName}`,
    "",
    "## Response Instructions",
    "",
    "- Answer in English.",
    "- Do not use web access, retrieval, code execution, calculators, or any other external tools.",
    "- Answer all 144 items in one response and follow every item-specific output contract exactly.",
    "- Before each domain, output its marker on a separate line: [LOG], [QNT], [ALG], [SCI], [LNG], [KNO], [CTX], [EQI], [SOC], [ETH], [MET], [CRE].",
    "- Preserve every item ID, such as LOG-01.",
    "- For every objective item, provide `Confidence: N%`. If an exact-output item forbids extra text, put the confidence on a separate line immediately after that answer.",
    "- If the output limit prevents completion, do not silently omit items. Explicitly state the last completed item ID so truncation can be detected.",
    "",
    "> Note: This full-booklet convenience mode reduces manual work, but it does not satisfy the standard AIX-144 requirement for a separate context per module.",
    "",
    ...sections
  ].join("\n\n");
}

async function copyFullBooklet() {
  if (!modules.length) return showToast("题库尚未加载");
  await navigator.clipboard.writeText(buildFullBookletDocument());
  showToast("AIX-144 整卷已复制");
}

function downloadFullBooklet() {
  if (!modules.length) return showToast("题库尚未加载");
  const blob = new Blob([buildFullBookletDocument()], { type: "text/markdown;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `AIX-144-${safeFilename(els.externalModelName.value.trim() || "external-model")}.md`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
  showToast("Markdown 整卷已下载");
}

function safeFilename(value) {
  return String(value || "model").replace(/[<>:"/\\|?*\u0000-\u001F]+/g, "_").slice(0, 80);
}

function parseBatchAnswers(text) {
  const source = String(text || "");
  const marker = /^\s*(?:#{1,6}\s*)?\[(LOG|QNT|ALG|SCI|LNG|KNO|CTX|EQI|SOC|ETH|MET|CRE)\](?:[^\r\n]*)$/gm;
  let matches = [...source.matchAll(marker)];
  if (!matches.length) {
    const itemMarker = /^\s*(?:#{1,6}\s*)?(LOG|QNT|ALG|SCI|LNG|KNO|CTX|EQI|SOC|ETH|MET|CRE)-0?1\b[^\r\n]*$/gm;
    matches = [...source.matchAll(itemMarker)];
  }
  const answers = {};
  matches.forEach((match, index) => {
    const start = match.index + match[0].length;
    const end = matches[index + 1]?.index ?? source.length;
    const answer = `${match[0]}\n${source.slice(start, end)}`.trim();
    if (answer && !answers[match[1]]) answers[match[1]] = answer;
  });
  return answers;
}

async function runBatchImport() {
  const answers = parseBatchAnswers(els.batchAnswerInput.value);
  const domains = DOMAINS.filter((domain) => answers[domain] && !state.results?.[domain]?.items?.length);
  if (!domains.length) return showToast("没有识别到领域标记或各领域第 01 题");
  const missingDomains = DOMAINS.filter((domain) => !answers[domain] && !state.results?.[domain]?.items?.length);
  if (missingDomains.length) {
    const proceed = confirm(`整份回答缺少 ${missingDomains.join("、")}，可能已被外部模型截断。是否先评分已识别的 ${domains.length} 个领域？`);
    if (!proceed) return;
  }
  const modelName = els.externalModelName.value.trim();
  batchRunning = true;
  let completedAll = false;
  els.runBatchImportButton.disabled = true;
  els.batchAnswerInput.disabled = true;
  state.modelName = modelName;
  state.evaluationAdministration = "full-booklet-convenience";
  els.modelName.value = modelName;
  saveState();

  try {
    for (let index = 0; index < domains.length; index += 1) {
      const domain = domains[index];
      els.batchImportStatus.textContent = `正在评分 ${domain}（${index + 1} / ${domains.length}）`;
      state.answers ||= {};
      state.answers[domain] = answers[domain];
      const grade = await requestGrade(domain, answers[domain], modelName);
      state.results ||= {};
      state.results[domain] = grade;
      saveState();
    }
    els.batchImportStatus.textContent = `已完成 ${domains.length} 个模块`;
    render();
    showToast(`已导入并评分 ${domains.length} 个模块`);
    if (isCurrentEvaluationComplete()) {
      await saveCurrentEvaluation(true);
      completedAll = true;
    }
  } catch (error) {
    els.batchImportStatus.textContent = `中断：${error.message}`;
    showToast(error.message || "批量评分中断");
  } finally {
    batchRunning = false;
    els.runBatchImportButton.disabled = false;
    els.batchAnswerInput.disabled = false;
    if (completedAll) closeBatchImport();
  }
}

async function startAutomaticEvaluation(customApi = null) {
  if (!customApi) throw new Error("必须提供外部 API 配置。");
  externalWorkflow = false;
  state.externalWorkflow = false;
  state.evaluationAdministration = "module-separated";
  const modelLabel = customApi.name;
  const runIdentity = `custom:${customApi.baseUrl}:${customApi.model}`;
  const completed = DOMAINS.filter((domain) => state.results?.[domain]?.items?.length === 12);
  const previousAutomaticModel = state.automaticRunModel || "";

  if (completed.length === 12) {
    if (!confirm("正式测评已经完成。是否清空现有结果并重新自动测评？")) return;
    clearFullEvaluationResults();
  } else if (completed.length && previousAutomaticModel !== runIdentity) {
    if (!confirm("当前已有其他模型或手动完成的模块。为避免混合结果，开始自动测评会清空正式测评进度。是否继续？")) return;
    clearFullEvaluationResults();
  }

  state.automaticRunModel = runIdentity;
  if (state.automaticBatchVersion !== AUTOMATIC_BATCH_VERSION) {
    state.automaticAnswerChunks = {};
    state.automaticBatchVersion = AUTOMATIC_BATCH_VERSION;
  }
  state.modelName = modelLabel;
  els.modelName.value = modelLabel;
  automaticRunning = true;
  automaticStopRequested = false;
  automaticErrorDomain = "";
  automaticMessage = "正在准备自动测评…";
  saveState();
  render();

  try {
    for (const domain of DOMAINS) {
      if (automaticStopRequested) break;
      if (state.results?.[domain]?.items?.length === 12) continue;

      automaticCurrentDomain = domain;
      activeDomain = domain;
      state.activeDomain = domain;
      state.automaticAnswerChunks ||= {};
      state.automaticAnswerChunks[domain] ||= {};

      for (let batchIndex = 0; batchIndex < AUTOMATIC_ITEM_BATCHES.length; batchIndex += 1) {
        if (automaticStopRequested) break;
        const batchKey = String(batchIndex);
        if (state.automaticAnswerChunks[domain][batchKey]) continue;
        const itemIds = AUTOMATIC_ITEM_BATCHES[batchIndex]
          .map((number) => `${domain}-${String(number).padStart(2, "0")}`);
        automaticBatchProgress = batchIndex + 1;
        automaticMessage = `${domain}：正在作答第 ${batchIndex + 1} / 8 批（${itemIds[0]}${itemIds.length > 1 ? `–${itemIds.at(-1)}` : ""}）`;
        saveState();
        render();
        const chunk = await requestAutomaticAnswerBatch(domain, itemIds, customApi);
        state.automaticAnswerChunks[domain][batchKey] = chunk;
        saveState();
      }
      if (automaticStopRequested) break;

      const chunks = AUTOMATIC_ITEM_BATCHES.map((_, index) => state.automaticAnswerChunks[domain][String(index)] || "");
      if (chunks.some((chunk) => !chunk)) throw new Error(`${domain} 的分批回答不完整`);
      const answer = chunks.map((chunk, index) => [
        `[Administrator batch ${index + 1}; the marker is not part of the candidate response]`,
        chunk
      ].join("\n")).join("\n\n");

      state.answers ||= {};
      state.answers[domain] = answer;
      automaticMessage = `${domain}：回答完成，正在评分…`;
      saveState();
      render();

      automaticController = new AbortController();
      const grade = await requestGrade(domain, answer, modelLabel, automaticController.signal, true);
      state.results ||= {};
      state.results[domain] = grade;
      delete state.automaticAnswerChunks[domain];
      automaticMessage = `${domain} 完成，Quality ${Number(grade.score).toFixed(1)}`;
      automaticBatchProgress = 0;
      saveState();
      render();
    }

    if (automaticStopRequested) {
      automaticMessage = "已停止，可稍后继续未完成模块";
      showToast("自动测评已停止，进度已保留");
    } else if (DOMAINS.every((domain) => state.results?.[domain]?.items?.length === 12)) {
      automaticMessage = "12 个模块全部完成，报告已自动保存";
      render();
      await saveCurrentEvaluation(true);
    }
  } catch (error) {
    if (error.name === "AbortError" || automaticStopRequested) {
      automaticMessage = "已停止，可稍后继续未完成模块";
    } else {
      automaticErrorDomain = automaticCurrentDomain;
      automaticMessage = `${automaticCurrentDomain} 失败：${error.message}`;
      showToast(error.message || "自动测评中断");
    }
  } finally {
    automaticRunning = false;
    automaticController = null;
    automaticCurrentDomain = "";
    automaticBatchProgress = 0;
    render();
  }
}

async function requestAutomaticAnswerBatch(domain, itemIds, customApi) {
  let lastError = null;
  for (let attempt = 1; attempt <= 3; attempt += 1) {
    if (automaticStopRequested) throw new DOMException("Stopped", "AbortError");
    automaticController = new AbortController();
    try {
      const response = await evaluationFetch("/api/model-evaluation/answer", {
        method: "POST",
        signal: automaticController.signal,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          domain,
          itemIds,
          customApi: {
            baseUrl: customApi.baseUrl,
            model: customApi.model,
            apiKey: customApi.apiKey
          }
        })
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.error || `${itemIds[0]}–${itemIds.at(-1)} 作答失败`);
      const answer = String(payload.answer || "").trim();
      if (!answer) throw new Error(`${itemIds[0]}–${itemIds.at(-1)} 没有返回回答`);
      return answer;
    } catch (error) {
      if (error.name === "AbortError" || automaticStopRequested) throw error;
      lastError = error;
      const batchNumber = AUTOMATIC_ITEM_BATCHES.findIndex((batch) => batch.includes(Number(itemIds[0].slice(-2)))) + 1;
      automaticMessage = `${domain}：第 ${batchNumber} 批失败，正在重试 ${attempt} / 3…`;
      renderAutomaticPanel();
      if (attempt < 3) await delay(1500 * attempt);
    }
  }
  throw lastError || new Error(`${domain} 分批作答失败`);
}

function delay(milliseconds) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

function clearFullEvaluationResults() {
  state.results = {};
  state.answers ||= {};
  state.automaticAnswerChunks = {};
  state.automaticBatchVersion = AUTOMATIC_BATCH_VERSION;
  for (const domain of DOMAINS) delete state.answers[domain];
  automaticErrorDomain = "";
  automaticMessage = "";
  saveState();
}

async function requestGrade(domain, answer, modelName, signal, batched = false) {
  const response = await evaluationFetch("/api/model-evaluation/grade", {
    method: "POST",
    signal,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ domain, answer, modelName, batched })
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(response.status === 401
      ? "请先返回 NoonAI 登录，再进行评分。"
      : payload.error || `${domain} 评分失败`);
  }
  return payload;
}

async function gradeModule() {
  const answer = els.answerInput.value.trim();
  if (!answer) return showToast("请先粘贴模型回答");
  els.gradeButton.disabled = true;
  els.gradeButton.textContent = "评分中…";
  els.statusText.textContent = "裁判正在按原子判据核对答案，并应用格式、致命推理与置信度规则…";
  try {
    const payload = await requestGrade(activeDomain, answer, els.modelName.value.trim());
    state.results ||= {};
    state.results[activeDomain] = payload;
    saveState();
    render();
    showToast(`${activeDomain} Quality：${payload.score}`);
    if (!externalWorkflow) setView("domain-detail");
    if (externalWorkflow) {
      const currentIndex = DOMAINS.indexOf(activeDomain);
      const nextDomain = DOMAINS.slice(currentIndex + 1)
        .find((domain) => !state.results?.[domain]?.items?.length)
        || DOMAINS.find((domain) => !state.results?.[domain]?.items?.length);
      if (nextDomain) {
        activeDomain = nextDomain;
        state.activeDomain = nextDomain;
        saveState();
        render();
        await copyModule();
        showToast(`${nextDomain} 题目已复制`);
      } else {
        externalWorkflow = false;
        state.externalWorkflow = false;
        saveState();
        render();
        await saveCurrentEvaluation(true);
      }
    }
  } catch (error) {
    els.statusText.textContent = error.message;
    showToast(error.message);
  } finally {
    els.gradeButton.disabled = !els.answerInput.value.trim();
    els.gradeButton.textContent = externalWorkflow ? "评分并复制下一模块" : "重新评分";
    const result = state.results?.[activeDomain];
    if (result) {
      const fallback = result.usedFallback ? "（首选裁判不可用，已自动切换）" : "";
      els.statusText.textContent = `AIX-144 v1.0 · 裁判模型：${result.graderModel || "deepseek-v4-pro"} ${fallback} · ${new Date(result.gradedAt).toLocaleString()}`;
    }
  }
}

async function saveCurrentEvaluation(automatic = false) {
  if (!isCurrentEvaluationComplete()) return showToast("请先完成当前测评");
  const modelName = els.modelName.value.trim();
  if (!modelName) {
    els.modelName.focus();
    return showToast("请先填写被测模型名称");
  }
  if (!automatic) {
    els.saveResultButton.disabled = true;
    els.saveResultButton.textContent = "保存中…";
  }
  try {
    const response = await evaluationFetch("/api/model-evaluation/history", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        modelName,
        mode: "full",
        administration: state.evaluationAdministration || "module-separated-manual",
        results: currentEvaluationResults()
      })
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || "保存失败");
    historyRecords.unshift(payload.record);
    state.lastSavedEvaluationId = payload.record.id;
    saveState();
    showToast(automatic ? "自动测评完成，报告已保存" : `${modelName} 的测评结果已保存`);
  } catch (error) {
    showToast(automatic ? `测评已完成，但自动保存失败：${error.message}` : error.message || "保存失败");
  } finally {
    renderDashboard();
  }
}

async function openHistory() {
  els.historyOverlay.hidden = false;
  document.body.classList.add("modal-open");
  renderHistoryLoading();
  await loadHistory();
}

function closeHistory() {
  els.historyOverlay.hidden = true;
  document.body.classList.remove("modal-open");
}

async function loadHistory() {
  historyLoading = true;
  historyError = "";
  renderHistoryLoading();
  try {
    const response = await evaluationFetch("/api/model-evaluation/history");
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || "无法读取历史记录");
    historyRecords = payload.records || [];
    for (const id of [...selectedHistoryIds]) {
      if (!historyRecords.some((record) => record.id === id)) selectedHistoryIds.delete(id);
    }
  } catch (error) {
    historyError = error.message || "无法读取历史记录";
  } finally {
    historyLoading = false;
    renderHistoryList();
  }
}

function renderHistoryLoading() {
  els.historyTitle.textContent = "历史记录";
  els.historyContent.innerHTML = `<div class="history-state"><span class="history-spinner"></span><strong>正在读取测评档案…</strong></div>`;
}

function renderHistoryList() {
  els.historyTitle.textContent = "历史记录";
  if (historyLoading) return renderHistoryLoading();
  if (historyError) {
    els.historyContent.innerHTML = `
      <div class="history-state history-error">
        <strong>读取失败</strong><p>${escapeHtml(historyError)}</p>
        <button class="primary" type="button" data-history-retry>重试</button>
      </div>`;
    return;
  }
  if (!historyRecords.length) {
    els.historyContent.innerHTML = `
      <div class="history-state">
        <strong>还没有保存的测评</strong>
        <p>完成一个模型的 AIX-144 测评后，点击“保存结果”，报告就会出现在这里。</p>
      </div>`;
    return;
  }
  const selectedCount = selectedHistoryIds.size;
  els.historyContent.innerHTML = `
    <div class="history-toolbar">
      <p>共 ${historyRecords.length} 份报告，可勾选 2–6 个模型进行横向对比。</p>
      <button class="primary" type="button" data-history-compare ${selectedCount < 2 ? "disabled" : ""}>
        对比已选模型${selectedCount ? `（${selectedCount}）` : ""}
      </button>
    </div>
    <div class="history-list">
      ${historyRecords.map(renderHistoryCard).join("")}
    </div>`;
}

function renderHistoryCard(record) {
  const status = historyStatus(record);
  const checked = selectedHistoryIds.has(record.id);
  return `
    <article class="history-card ${checked ? "selected" : ""}">
      <label class="history-check" title="加入模型对比">
        <input type="checkbox" data-history-select="${record.id}" ${checked ? "checked" : ""} />
        <span></span>
      </label>
      <button class="history-open" type="button" data-history-open="${record.id}">
        <div class="history-card-main">
          <span>${escapeHtml(record.benchmark)} · ${administrationLabel(record.administration)} · ${formatDate(record.createdAt)}</span>
          <h3>${escapeHtml(record.modelName)}</h3>
          <p>${escapeHtml(record.passNote || "")}</p>
        </div>
        <div class="history-card-score"><strong>${formatScore(record.quality)}</strong><span>Quality</span></div>
        <div class="history-card-metrics">
          <span>核心 <b>${formatScore(record.coreScore)}</b></span>
          <span>前沿 <b>${formatScore(record.frontierScore)}</b></span>
          <span class="${status.className}">${status.label}</span>
        </div>
      </button>
    </article>`;
}

function handleHistoryChange(event) {
  const checkbox = event.target.closest("[data-history-select]");
  if (!checkbox) return;
  const id = checkbox.dataset.historySelect;
  if (checkbox.checked) {
    if (selectedHistoryIds.size >= 6) {
      checkbox.checked = false;
      showToast("最多同时对比 6 个模型");
      return;
    }
    selectedHistoryIds.add(id);
  } else {
    selectedHistoryIds.delete(id);
  }
  renderHistoryList();
}

async function handleHistoryClick(event) {
  if (event.target.closest("[data-history-retry]")) return loadHistory();
  if (event.target.closest("[data-history-back]")) return renderHistoryList();
  if (event.target.closest("[data-history-compare]")) return renderHistoryComparison();
  const deleteButton = event.target.closest("[data-history-delete]");
  if (deleteButton) return deleteHistoryRecord(deleteButton.dataset.historyDelete);
  const openButton = event.target.closest("[data-history-open]");
  if (openButton) return openHistoryRecord(openButton.dataset.historyOpen);
}

async function openHistoryRecord(id) {
  els.historyTitle.textContent = "测评报告";
  renderHistoryLoading();
  try {
    const response = await evaluationFetch(`/api/model-evaluation/history/${id}`);
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || "无法读取测评报告");
    renderHistoryReport(payload.record);
  } catch (error) {
    els.historyContent.innerHTML = `
      <div class="history-state history-error">
        <strong>报告读取失败</strong><p>${escapeHtml(error.message)}</p>
        <button class="primary" type="button" data-history-back>返回历史记录</button>
      </div>`;
  }
}

function renderHistoryReport(record) {
  els.historyTitle.textContent = record.modelName;
  const status = historyStatus(record);
  const domainEntries = DOMAINS
    .filter((domain) => Number.isFinite(Number(record.domainScores?.[domain])));
  els.historyContent.innerHTML = `
    <div class="report-nav">
      <button type="button" data-history-back>← 返回历史记录</button>
      <button class="danger-link" type="button" data-history-delete="${record.id}">删除报告</button>
    </div>
    <section class="saved-report-hero">
      <div><span>${escapeHtml(record.benchmark)} · ${administrationLabel(record.administration)} · ${formatDate(record.createdAt)}</span><h2>${escapeHtml(record.modelName)}</h2><p>${escapeHtml(record.passNote)}</p></div>
      <div class="saved-quality"><strong>${formatScore(record.quality)}</strong><span>Quality</span></div>
    </section>
    <div class="saved-metrics">
      <div><span>核心分</span><strong>${formatScore(record.coreScore)}</strong></div>
      <div><span>前沿分</span><strong>${formatScore(record.frontierScore)}</strong></div>
      <div><span>判定</span><strong class="${status.className}">${status.label}</strong></div>
    </div>
    ${domainEntries.length ? `
      <section class="report-section">
        <h3>能力域画像</h3>
        <div class="domain-report-grid">${domainEntries.map((domain) => renderDomainBar(domain, record.domainScores[domain])).join("")}</div>
      </section>` : ""}
    ${renderNoteSection("主要优势", record.strengths)}
    ${renderNoteSection("改进方向", record.weaknesses)}
    <section class="report-section">
      <h3>逐模块报告</h3>
      <div class="saved-modules">${(record.results || []).map(renderSavedModule).join("")}</div>
    </section>`;
}

function renderDomainBar(domain, score) {
  const safeScore = Math.max(0, Math.min(100, Number(score) || 0));
  return `
    <div class="domain-report-row">
      <span><b>${domain}</b> ${DOMAIN_LABELS[domain]}</span>
      <i><em style="width:${safeScore}%"></em></i>
      <strong>${formatScore(score)}</strong>
    </div>`;
}

function renderNoteSection(title, notes) {
  if (!notes?.length) return "";
  return `
    <section class="report-section">
      <h3>${title}</h3>
      <div class="report-notes">${notes.map((note) => `<p>${escapeHtml(note)}</p>`).join("")}</div>
    </section>`;
}

function renderSavedModule(result) {
  return `
    <details class="saved-module">
      <summary>
        <span><b>${escapeHtml(result.domain)}</b>${result.summary ? ` · ${escapeHtml(result.summary)}` : ""}</span>
        <strong>${formatScore(result.score)}</strong>
      </summary>
      <div class="saved-module-metrics">
        <span>核心 ${formatScore(result.coreScore)}</span><span>前沿 ${formatScore(result.frontierScore)}</span>
      </div>
      <div class="saved-items">${(result.items || []).map((item) => `
        <article>
          <header><b>${escapeHtml(item.itemId)}</b><strong>${item.score} / 10</strong></header>
          <p>${escapeHtml(item.verdict)}</p>
          <p>改进：${escapeHtml(item.improvement)}</p>
        </article>`).join("")}</div>
    </details>`;
}

function renderHistoryComparison() {
  const records = historyRecords.filter((record) => selectedHistoryIds.has(record.id));
  if (records.length < 2) return showToast("请至少选择两个模型");
  els.historyTitle.textContent = "模型对比";
  const bestQuality = Math.max(...records.map((record) => Number(record.quality) || 0));
  els.historyContent.innerHTML = `
    <div class="report-nav"><button type="button" data-history-back>← 返回历史记录</button></div>
    <section class="comparison-intro">
      <span>AIX COMPARISON</span>
      <h2>${records.length} 个模型横向对比</h2>
      <p>同一指标按分数直接比较；建议对比采用相同运行方式的 AIX-144 报告。</p>
    </section>
    <div class="comparison-table-wrap">
      <table class="comparison-table">
        <thead><tr><th>指标</th>${records.map((record) => `<th>${escapeHtml(record.modelName)}<small>${escapeHtml(record.benchmark)}</small></th>`).join("")}</tr></thead>
        <tbody>
          ${comparisonRow("Quality", records, "quality", bestQuality)}
          ${comparisonRow("核心分", records, "coreScore")}
          ${comparisonRow("前沿分", records, "frontierScore")}
          ${DOMAINS.map((domain) => comparisonDomainRow(domain, records)).join("")}
        </tbody>
      </table>
    </div>
    <section class="comparison-cards">
      ${records.map((record) => {
        const strongest = topDomain(record.domainScores, true);
        const weakest = topDomain(record.domainScores, false);
        return `<article>
          <span>${escapeHtml(record.benchmark)}</span><h3>${escapeHtml(record.modelName)}</h3>
          <p>优势域：${strongest ? `${strongest[0]} ${formatScore(strongest[1])}` : "—"}</p>
          <p>相对短板：${weakest ? `${weakest[0]} ${formatScore(weakest[1])}` : "—"}</p>
        </article>`;
      }).join("")}
    </section>`;
}

function comparisonRow(label, records, key, highlightedValue = null) {
  return `<tr><th>${label}</th>${records.map((record) => {
    const value = Number(record[key]);
    const highlighted = highlightedValue !== null && value === highlightedValue;
    return `<td class="${highlighted ? "comparison-best" : ""}">${formatScore(value)}</td>`;
  }).join("")}</tr>`;
}

function comparisonDomainRow(domain, records) {
  const values = records.map((record) => Number(record.domainScores?.[domain]));
  const valid = values.filter(Number.isFinite);
  const best = valid.length ? Math.max(...valid) : null;
  return `<tr><th>${domain} ${DOMAIN_LABELS[domain]}</th>${values.map((value) => `
    <td class="${best !== null && value === best ? "comparison-best" : ""}">${formatScore(value)}</td>`).join("")}</tr>`;
}

async function deleteHistoryRecord(id) {
  const record = historyRecords.find((entry) => entry.id === id);
  if (!record || !confirm(`确定删除“${record.modelName}”的测评报告吗？`)) return;
  try {
    const response = await evaluationFetch(`/api/model-evaluation/history/${id}`, { method: "DELETE" });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || "删除失败");
    historyRecords = historyRecords.filter((entry) => entry.id !== id);
    selectedHistoryIds.delete(id);
    renderHistoryList();
    showToast("测评报告已删除");
  } catch (error) {
    showToast(error.message || "删除失败");
  }
}

function historyStatus(record) {
  if (record.passStatus === "passed") return { label: "通过", className: "pass" };
  if (record.passStatus === "failed") return { label: "未通过", className: "fail" };
  return { label: "筛查", className: "" };
}

function administrationLabel(value) {
  if (value === "full-booklet-convenience") return "整卷便捷运行";
  if (value === "module-separated") return "自动独立模块";
  if (value === "module-separated-manual") return "手动独立模块";
  return "历史运行";
}

function topDomain(domainScores, highest) {
  const entries = Object.entries(domainScores || {}).filter(([, score]) => Number.isFinite(Number(score)));
  return entries.sort((a, b) => highest ? b[1] - a[1] : a[1] - b[1])[0] || null;
}

function formatDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? "未知时间" : date.toLocaleString();
}

function formatScore(value) {
  const number = Number(value);
  return Number.isFinite(number) ? number.toFixed(1) : "—";
}

function evaluationFetch(url, options = {}) {
  const token = sessionStorage.getItem("noonai.session-token") || "";
  return fetch(`${API_BASE}${url}`, {
    credentials: "same-origin",
    ...options,
    headers: {
      ...(options.headers || {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    }
  });
}

function resetEvaluation() {
  if (!confirm("确定清空所有已粘贴回答和评分结果吗？")) return;
  localStorage.removeItem(STORAGE_KEY);
  location.reload();
}

function average(values) {
  const valid = values.filter(Number.isFinite);
  return valid.length ? valid.reduce((sum, value) => sum + value, 0) / valid.length : null;
}

function saveDraft() {
  state.answers ||= {};
  if (activeDomain) state.answers[activeDomain] = els.answerInput.value;
  saveState();
}

function loadState() {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {}; } catch { return {}; }
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function showToast(message) {
  els.toast.textContent = message;
  els.toast.hidden = false;
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => { els.toast.hidden = true; }, 2200);
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[char]));
}
