(() => {
  const APPEARANCE_KEY = "noonai.appearance.v1";
  const APPEARANCE_MODE_KEY = "noonai.appearance-mode.v1";
  const systemAppearanceMedia = window.matchMedia("(prefers-color-scheme: light)");

  function applyTheme() {
    let mode = "system";
    let appearance = systemAppearanceMedia.matches ? "light" : "dark";
    try {
      const storedMode = localStorage.getItem(APPEARANCE_MODE_KEY);
      if (["system", "dark", "light"].includes(storedMode)) mode = storedMode;
      if (mode !== "system") appearance = mode;
      localStorage.setItem(APPEARANCE_KEY, appearance);
    } catch {
      // Keep the detected system appearance when storage is unavailable.
    }
    document.documentElement.dataset.theme = appearance;
    document.documentElement.style.colorScheme = appearance;
  }

  applyTheme();
  if (typeof systemAppearanceMedia.addEventListener === "function") {
    systemAppearanceMedia.addEventListener("change", applyTheme);
  } else {
    systemAppearanceMedia.addListener(applyTheme);
  }
  window.addEventListener("storage", (event) => {
    if (event.key === APPEARANCE_KEY || event.key === APPEARANCE_MODE_KEY) applyTheme();
  });
})();
