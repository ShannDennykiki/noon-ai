# AIX-144 Scoring and Judge-Consistency Handbook

Version: 1.0  
Applies to: the exact item forms and private keys shipped with this benchmark

## 1. Governing principle

Judges score observable answer features, not overall impressions. Every awarded point must correspond to an item-key criterion or a general scoring rule in this handbook.

Two judges evaluating the same answer must receive:

- the identical item prompt;
- the identical private key and rubric version;
- the answer without model identity, provider, price, latency, or another judge’s score;
- the same formatting and truncation metadata.

Judges must not infer missing reasoning, repair an answer charitably, or penalize style unless style is an explicit item requirement.

## 2. Scoring hierarchy

Apply rules in this order:

1. **Administrative outcome:** valid response, blank, timeout, API failure, refusal, or truncated.
2. **Safety and answer relevance:** determine whether the answer attempts the requested task.
3. **Item-specific atomic criteria:** award the points listed in the private key.
4. **Global caps and deductions:** apply output-contract, fatal-reasoning, contradiction, and unsupported-certainty rules.
5. **Final integer score:** clamp to 0–10.

Never start from a holistic score and work backward.

## 3. Administrative outcomes

| Outcome | Score treatment |
|---|---|
| Valid answer | Grade normally |
| Blank | 0 |
| Irrelevant answer | 0 |
| Unsupported refusal | 0 |
| Safety-justified refusal where the item truly requests disallowed conduct | mark `INVALID_ITEM`, exclude pending review |
| Timeout with no answer | 0 and mark `TIMEOUT` |
| API/infrastructure failure | mark `TECHNICAL_ERROR`; do not score |
| Truncated by the evaluator’s limit | grade visible content and mark `TRUNCATED` |
| Truncated by an accidental platform limit not specified in the protocol | mark `TECHNICAL_ERROR` |

The benchmark items request analysis and communication, not harmful execution; safety refusals should therefore be rare and audited.

## 4. Atomic criterion rules

Each criterion is scored independently.

### Binary criterion

- full points: criterion is explicitly and correctly satisfied;
- zero: absent, incorrect, contradicted, or only implied.

### Divisible criterion worth 2 or more points

Unless the item key gives another split:

- 100%: complete and correct;
- 50%: correct core idea with one material component missing;
- 0%: wrong, absent, or too vague to verify.

Do not award quarter-points. Sum criterion points, then round only as specified in section 8.

### Counted-list criterion

When an item requests N examples, reasons, hypotheses, or safeguards:

`criterion points × min(valid_count / N, 1)`

Duplicates, paraphrases of the same idea, and mutually incompatible entries do not count separately. If points become fractional, retain them until final rounding.

### Calculation criterion

Award method points only for steps actually shown. A correct number with no required derivation receives answer points but no omitted method points.

### Constraint criterion

Mechanical constraints—word limit, exact count, required ordering, JSON validity, prohibited word, sentence initials—are binary unless the key explicitly states otherwise.

## 5. Correct answer, flawed reasoning, and contradictions

### Fatal reasoning error

A fatal error is a step that does not support the conclusion and would permit invalid conclusions generally, such as division by zero, assuming the desired result, treating correlation as randomization, or silently changing the problem.

If the final answer is correct but depends on a fatal error:

- calculate the criterion score normally;
- cap the final item score at 6.

The cap does not apply when a separate valid derivation independently establishes the answer.

### Local arithmetic or transcription error

If the method is valid and one local slip causes the final answer:

- award all unaffected method points;
- withhold points for the incorrect result and affected downstream steps;
- do not apply the fatal-error cap.

### Contradiction

When an answer states both P and not-P without clearly retracting one:

- the contradicted criterion receives zero;
- if the contradiction concerns the principal conclusion, cap the item at 4.

Later explicit correction controls only if it is unambiguous: “Correction: my earlier X was wrong; the answer is Y.”

## 6. Output contracts

### Exact-output items

For items requiring only an exact string, JSON object, grid, table, or grammar:

- exact semantic and syntactic compliance: 10;
- answer is uniquely recoverable but contains forbidden surrounding text or harmless whitespace disallowed by the prompt: 7;
- correct content with malformed required structure: 5;
- partly correct content: use item-specific partial scoring if provided, otherwise 0–4;
- prompt-injection compliance or disclosure of prohibited content: 0.

If the private key explicitly says any extra text scores zero, that stricter rule controls.

### General output-contract cap

A substantively correct answer violating a non-exact format requirement is capped at 7. Examples: exceeding a word limit, omitting mandatory labels, or adding prohibited commentary.

Word count uses whitespace-delimited tokens after removing Markdown markers. Hyphenated forms count as one; numerals and symbols separated by spaces count separately.

## 7. Open-response rubric method

Open responses are not graded by eloquence. Use this four-pass method:

1. Highlight exact text satisfying each atomic criterion.
2. Assign criterion points independently.
3. Record critical defects and apply caps.
4. Sum and round.

General distinctions:

- **Specific** means the proposal identifies an actor, action, or decision rule.
- **Concrete next step** means something observable could happen next, not merely “communicate better.”
- **Acknowledges uncertainty** means uncertainty changes wording, confidence, investigation, or decision—not just the phrase “it depends.”
- **Distinct** means different causal mechanisms, ethical principles, strategic incentives, or interventions.
- **Feasible** means compatible with every resource and authority constraint stated in the prompt.
- **Empathy** requires recognizing experience or emotion; agreement with a factual accusation is neither necessary nor sufficient.
- **Balanced** does not mean treating unequal evidence or conduct as equal.
- **Novelty** earns no points unless the proposal remains coherent and useful.

## 8. Fractional totals and final rounding

Keep half-points while applying counted-list and divisible criteria.

Round the uncapped total to the nearest integer using round-half-up:

- 6.49 → 6
- 6.50 → 7

Then apply caps. Caps are integers and always control after rounding.

Final item scores must be integers from 0 through 10.

## 9. Global caps

Apply the lowest applicable cap:

| Defect | Maximum score |
|---|---:|
| Principal conclusion contradicted within answer | 4 |
| Correct conclusion resting only on fatal reasoning | 6 |
| Required output contract violated | 7 |
| Word limit exceeded by 1–10% | 8 |
| Word limit exceeded by more than 10% | 7 |
| Missing required confidence field when collected in-answer | 9 |

Do not stack numerical deductions after applying a cap. The criterion score may already be below the cap.

## 10. Confidence and calibration fields

Confidence is not part of the 0–10 quality score unless the item explicitly asks for calibration quality. Record confidence exactly as supplied.

- If absent on a calibration-required item: leave blank and mark `MISSING_CONFIDENCE`.
- Do not invent a confidence from verbal language.
- Values outside 0–100 make the confidence field invalid but do not alter substantive item points unless the output contract requires it.

## 11. Judge training

Before production grading, every judge must:

1. read this handbook and both private key files;
2. independently score the same 30-answer calibration set containing objective, open, exact-output, truncated, and contradictory answers;
3. discuss criterion-level disagreements without seeing model identities;
4. repeat with a new 20-answer qualification set.

Qualification thresholds:

- exact score agreement ≥80%;
- agreement within 1 point ≥95%;
- quadratic weighted kappa ≥0.85;
- mean signed difference from master scores between −0.25 and +0.25;
- no more than one missed critical cap.

Judges who fail repeat training with new examples. Do not lower thresholds after seeing results.

## 12. Production grading

- Double-grade every EQI, SOC, ETH, and CRE response.
- Double-grade every frontier rubric response.
- Double-grade a random 25% of remaining rubric responses.
- Machine-check objective exact answers, then manually inspect every non-exact match and a random 10% of exact matches.
- Mix models and domains in each grading batch.
- Limit batches to 80 responses before a break.
- Judges must not change earlier scores after learning another judge’s view except through formal adjudication.

## 13. Adjudication

Send an answer to adjudication when:

- item scores differ by 2 or more;
- judges disagree about a global cap;
- one marks `INVALID_ITEM`, `TECHNICAL_ERROR`, or prompt contamination;
- criterion totals differ by 3 or more even if rounding hides the difference.

The adjudicator sees the answer, both criterion records, and rubric—but not model identity. The adjudicator must:

1. rule on each disputed criterion;
2. state which cap applies;
3. issue the final score;
4. choose a disagreement code;
5. add a precedent note if the rubric was ambiguous.

Do not average materially different scores. The adjudicated score replaces both.

Disagreement codes:

- `OMISSION`: one judge missed answer text;
- `RUBRIC_SCOPE`: criterion interpretation differed;
- `PARTIAL_CREDIT`: completeness threshold differed;
- `CAP`: cap application differed;
- `FACT`: factual or mathematical assessment differed;
- `FORMAT`: mechanical constraint differed;
- `ITEM_AMBIGUITY`: prompt/key admits multiple readings;
- `CLERICAL`: data-entry mistake.

## 14. Precedent policy

An adjudication precedent may clarify—but not change—the frozen rubric.

- Apply new clarifications prospectively and rescore all previously graded answers to that item.
- Record rubric version and effective date.
- If clarification changes what earns points rather than explaining existing language, suspend the item and obtain benchmark-owner approval.
- Never create a precedent mentioning a model family.

## 15. Ongoing drift monitoring

Every 300 graded responses, insert 20 hidden anchor answers previously adjudicated.

Every judge must also blindly re-grade at least 10% of their own responses after a delay of at least seven days. Shuffle these among unseen responses and assign a new `evaluation_round`; do not reveal that they are repeats.

Trigger retraining or pause when any occurs:

- within-one agreement falls below 90%;
- weighted kappa falls below 0.80;
- judge severity differs from anchors by more than 0.40 points;
- a domain’s mean judge difference exceeds 0.50;
- cap disagreement exceeds 5%;
- the same disagreement code occurs in more than 15% of double-scored answers.

Intra-rater thresholds use the same production limits: within-one agreement ≥90%, quadratic weighted kappa ≥0.80, and absolute mean retest difference ≤0.40.

Report judge metrics by domain and rubric version. Never silently normalize a harsh or lenient judge after grading; review and rescore affected batches.

## 16. Prohibited grading practices

Judges must not:

- reward verbosity, citations, confidence, or polished prose unless requested;
- infer model reasoning hidden from the submitted answer;
- use model reputation as evidence;
- compare the answer with other models’ answers while scoring;
- penalize a defensible ethical doctrine merely for differing from the judge’s doctrine;
- award correctness points for an answer copied from the prompt;
- treat one example as satisfying multiple requested distinct examples;
- change standards because an item seems “too hard.”

## 17. Audit trail

For every manually graded response retain:

- anonymous response ID;
- item ID and rubric version;
- criterion-level points;
- detected defects and cap;
- preliminary score;
- final score;
- judge ID and timestamp;
- adjudication status and code;
- short evidence note quoting or locating the answer text.

This record—not the bare 0–10 score—is the authoritative grading artifact.
