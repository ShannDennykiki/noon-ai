# Calibration Protocol: Keeping Models Near the Pass Region Without Hiding Differences

Difficulty cannot be fixed by intuition alone. Use this protocol before treating AIX-144 as a ranking instrument.

## 1. Freeze the target population

Write down which systems “most models” means—for example, currently maintained general-purpose models above a chosen price or parameter class. Do not redefine the population after seeing scores.

## 2. Pilot

Run at least:

- 20 distinct model families;
- 3 seeds per model;
- identical context, tools, limits, and grader conditions;
- at least two blinded graders for every rubric item.

Do not include fine-tunes derived from the same base model as if they were independent population samples.

## 3. Diagnose the distribution

Desired pilot properties:

- median Quality 48–52;
- interquartile range at least 12;
- 10th–90th percentile span at least 25;
- fewer than 10% above 85;
- fewer than 10% below 15;
- seed standard deviation below 4 for most models;
- no domain with more than 70% of models at either floor or ceiling.

A median of 50 with a narrow spread is not useful. It creates many arbitrary rank reversals around the pass line.

## 4. Estimate item quality

Fit a graded-response or partial-credit IRT model. For each item estimate difficulty and discrimination. Flag:

- empirical mean above 8.5/10: likely too easy;
- mean below 1/10: likely uninformative shared failure;
- item-total discrimination below 0.25;
- negative discrimination;
- grader disagreement above 2 points on more than 15% of responses;
- success strongly predicted by formatting quirks or model-family identity after controlling for total ability.

Retain a few easier anchor items for scale linking. Replace low-discrimination items before merely making their wording longer.

## 5. Center without manipulating winners

Use an anonymous pilot table with model names hidden. Permitted seasonal adjustments:

1. replace weak items with isomorphic harder/easier variants;
2. adjust the core/frontier mixture globally;
3. equate the pass score through IRT;
4. add high-information items around the estimated pass ability.

Do not tune individual item weights after identifying which named model benefits.

The default mixture is:

`Quality = 0.40 × Core + 0.60 × Frontier`.

If the reference median exceeds 60 and frontier median exceeds 50, replace frontier items rather than raising their weight beyond 70%. If the median is below 40, add intermediate bridge items or reduce frontier weight. Extreme weighting makes scores fragile.

## 6. Use adaptive routing when API cost matters

A shorter adaptive version may administer:

- 24 anchor items to everyone;
- 24 items selected near the provisional ability estimate;
- 12 frontier items for systems above the pass estimate;
- 12 bridge items for systems below it.

Score with IRT theta, not raw percent correct, because candidates receive different items. Keep at least 30% common anchors for paired comparisons and equating.

## 7. Declare superiority

Do not rank by a one- or two-point raw difference. Require:

- paired 95% bootstrap interval excluding zero;
- mean Quality difference at least 2 points;
- replicated direction on at least two of three seeds;
- no unexplained grader or timeout asymmetry;
- report of domain trade-offs and resource use.

Use a leaderboard tier when models are statistically indistinguishable.

## 8. Refresh

Retire or regenerate 20–30% of frontier items each evaluation season. Re-equate new forms using common private anchors. If public contamination is suspected, do not “correct” scores after the fact; invalidate the affected form.

