#!/usr/bin/env python3
"""Validate AIX judge records and report repeatability/adjudication metrics."""

from __future__ import annotations

import argparse
import csv
import math
import statistics
import sys
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path


VALID_STATUSES = {"M", "P", "N", "X", "NA"}


def as_float(value: str, field: str, row: int, *, optional: bool = False) -> float | None:
    text = (value or "").strip()
    if optional and not text:
        return None
    try:
        result = float(text)
    except ValueError as exc:
        raise ValueError(f"row {row}: {field} must be numeric") from exc
    if not math.isfinite(result):
        raise ValueError(f"row {row}: {field} must be finite")
    return result


def as_int(value: str, field: str, row: int) -> int:
    result = as_float(value, field, row)
    assert result is not None
    if result != int(result):
        raise ValueError(f"row {row}: {field} must be an integer")
    return int(result)


@dataclass(frozen=True)
class ItemScore:
    response_id: str
    model: str
    run: str
    item_id: str
    grader_id: str
    attempt: int
    rubric_version: str
    raw_score: float
    cap: float
    final_score: float
    correct: int | None
    error_codes: tuple[str, ...]

    @property
    def key(self) -> tuple[str, str, str, int]:
        return self.response_id, self.item_id, self.grader_id, self.attempt


@dataclass(frozen=True)
class Criterion:
    response_id: str
    item_id: str
    grader_id: str
    attempt: int
    rubric_version: str
    criterion_id: str
    status: str
    points: float
    maximum: float
    evidence: str

    @property
    def score_key(self) -> tuple[str, str, str, int]:
        return self.response_id, self.item_id, self.grader_id, self.attempt


def read_manifest(path: Path) -> dict[str, dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    result = {row["item_id"].strip().upper(): row for row in rows}
    if len(result) != len(rows):
        raise ValueError("manifest contains duplicate item IDs")
    return result


def read_item_scores(path: Path) -> list[ItemScore]:
    required = {
        "response_id", "model", "run", "item_id", "grader_id", "attempt",
        "rubric_version", "raw_score", "cap", "final_score", "correct",
        "error_codes",
    }
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        missing = required - set(reader.fieldnames or ())
        if missing:
            raise ValueError(f"item score file missing columns: {sorted(missing)}")
        output: list[ItemScore] = []
        seen = set()
        for row_number, row in enumerate(reader, 2):
            raw = as_float(row["raw_score"], "raw_score", row_number)
            cap = as_float(row["cap"], "cap", row_number)
            final = as_float(row["final_score"], "final_score", row_number)
            correct_f = as_float(row["correct"], "correct", row_number, optional=True)
            assert raw is not None and cap is not None and final is not None
            if not all(0 <= value <= 10 for value in (raw, cap, final)):
                raise ValueError(f"row {row_number}: scores and cap must be in [0,10]")
            if abs(final - min(raw, cap)) > 1e-9:
                raise ValueError(
                    f"row {row_number}: final_score must equal min(raw_score, cap)"
                )
            if correct_f is not None and correct_f not in (0, 1):
                raise ValueError(f"row {row_number}: correct must be 0, 1, or blank")
            record = ItemScore(
                row["response_id"].strip(),
                row["model"].strip(),
                row["run"].strip(),
                row["item_id"].strip().upper(),
                row["grader_id"].strip(),
                as_int(row["attempt"], "attempt", row_number),
                row["rubric_version"].strip(),
                raw, cap, final,
                int(correct_f) if correct_f is not None else None,
                tuple(code.strip() for code in row["error_codes"].split(";") if code.strip()),
            )
            if not all((record.response_id, record.item_id, record.grader_id,
                        record.rubric_version)):
                raise ValueError(f"row {row_number}: identifying fields cannot be blank")
            if record.key in seen:
                raise ValueError(f"row {row_number}: duplicate score record {record.key}")
            seen.add(record.key)
            output.append(record)
    return output


def read_criteria(path: Path) -> list[Criterion]:
    required = {
        "response_id", "item_id", "grader_id", "attempt", "rubric_version",
        "criterion_id", "status", "points_awarded", "max_points", "evidence_span",
    }
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        missing = required - set(reader.fieldnames or ())
        if missing:
            raise ValueError(f"criteria file missing columns: {sorted(missing)}")
        output: list[Criterion] = []
        seen = set()
        for row_number, row in enumerate(reader, 2):
            status = row["status"].strip().upper()
            if status not in VALID_STATUSES:
                raise ValueError(f"row {row_number}: invalid criterion status {status!r}")
            points = as_float(row["points_awarded"], "points_awarded", row_number)
            maximum = as_float(row["max_points"], "max_points", row_number)
            assert points is not None and maximum is not None
            if not 0 <= points <= maximum:
                raise ValueError(f"row {row_number}: criterion points outside [0,max]")
            if status in {"N", "X", "NA"} and points != 0:
                raise ValueError(f"row {row_number}: {status} criterion must receive 0")
            if status == "M" and points != maximum:
                raise ValueError(f"row {row_number}: M criterion must receive full points")
            if status == "P" and not 0 < points < maximum:
                raise ValueError(f"row {row_number}: P criterion must receive partial points")
            criterion = Criterion(
                row["response_id"].strip(),
                row["item_id"].strip().upper(),
                row["grader_id"].strip(),
                as_int(row["attempt"], "attempt", row_number),
                row["rubric_version"].strip(),
                row["criterion_id"].strip(),
                status, points, maximum, row["evidence_span"].strip(),
            )
            unique = criterion.score_key + (criterion.criterion_id,)
            if unique in seen:
                raise ValueError(f"row {row_number}: duplicate criterion {unique}")
            seen.add(unique)
            output.append(criterion)
    return output


def quadratic_weighted_kappa(pairs: list[tuple[float, float]]) -> float | None:
    if not pairs:
        return None
    rounded = [(round(a), round(b)) for a, b in pairs]
    n = len(rounded)
    observed = [[0 for _ in range(11)] for _ in range(11)]
    left = [0 for _ in range(11)]
    right = [0 for _ in range(11)]
    for a, b in rounded:
        observed[a][b] += 1
        left[a] += 1
        right[b] += 1
    observed_loss = 0.0
    expected_loss = 0.0
    for i in range(11):
        for j in range(11):
            weight = ((i - j) / 10) ** 2
            observed_loss += weight * observed[i][j] / n
            expected_loss += weight * left[i] * right[j] / (n * n)
    if expected_loss == 0:
        return 1.0 if observed_loss == 0 else None
    return 1 - observed_loss / expected_loss


def agreement_report(name: str, pairs: list[tuple[float, float]]) -> None:
    if not pairs:
        print(f"{name}: no comparable pairs")
        return
    differences = [abs(a - b) for a, b in pairs]
    exact = sum(diff == 0 for diff in differences) / len(pairs)
    within_one = sum(diff <= 1 for diff in differences) / len(pairs)
    kappa = quadratic_weighted_kappa(pairs)
    print(
        f"{name}: n={len(pairs)}, exact={exact:.1%}, within1={within_one:.1%}, "
        f"MAD={statistics.fmean(differences):.3f}, max_diff={max(differences):.1f}, "
        f"QWK={kappa:.3f}" if kappa is not None else
        f"{name}: n={len(pairs)}, QWK unavailable"
    )


def validate(
    scores: list[ItemScore],
    criteria: list[Criterion],
    manifest: dict[str, dict[str, str]],
) -> list[str]:
    warnings: list[str] = []
    criteria_by_score: dict[tuple[str, str, str, int], list[Criterion]] = defaultdict(list)
    for criterion in criteria:
        criteria_by_score[criterion.score_key].append(criterion)
    score_keys = {score.key for score in scores}
    for score in scores:
        if score.item_id not in manifest:
            raise ValueError(f"unknown item ID {score.item_id}")
        required_correct = manifest[score.item_id]["calibration_required"].strip().lower() == "yes"
        if required_correct and score.correct is None:
            warnings.append(f"{score.key}: calibrated objective item has blank correct")
        if not required_correct and score.correct is not None:
            warnings.append(f"{score.key}: non-calibration item should leave correct blank")
        rows = criteria_by_score.get(score.key, [])
        if not rows:
            warnings.append(f"{score.key}: no criterion records")
            continue
        versions = {row.rubric_version for row in rows}
        if versions != {score.rubric_version}:
            warnings.append(f"{score.key}: score and criterion rubric versions differ")
        maximum = sum(row.maximum for row in rows if row.status != "NA")
        points = sum(row.points for row in rows)
        if abs(maximum - 10) > 1e-9:
            warnings.append(f"{score.key}: active criterion maxima sum to {maximum}, not 10")
        if abs(points - score.raw_score) > 1e-9:
            warnings.append(
                f"{score.key}: criterion points {points} != raw_score {score.raw_score}"
            )
        for row in rows:
            if row.status in {"M", "P"} and not row.evidence:
                warnings.append(f"{score.key}/{row.criterion_id}: awarded points lack evidence")
    for key in criteria_by_score:
        if key not in score_keys:
            warnings.append(f"{key}: criteria exist without an item score")
    return warnings


def latest_by_grader(scores: list[ItemScore]) -> dict[tuple[str, str, str], ItemScore]:
    latest: dict[tuple[str, str, str], ItemScore] = {}
    for score in scores:
        key = score.response_id, score.item_id, score.grader_id
        if key not in latest or score.attempt > latest[key].attempt:
            latest[key] = score
    return latest


def comparison_and_queue(scores: list[ItemScore]) -> tuple[
    list[tuple[float, float]], list[tuple[float, float]], list[dict[str, str]]
]:
    intra_pairs: list[tuple[float, float]] = []
    attempts: dict[tuple[str, str, str], list[ItemScore]] = defaultdict(list)
    for score in scores:
        attempts[(score.response_id, score.item_id, score.grader_id)].append(score)
    for records in attempts.values():
        records.sort(key=lambda record: record.attempt)
        if len(records) >= 2:
            intra_pairs.append((records[0].final_score, records[-1].final_score))

    latest = latest_by_grader(scores)
    by_answer: dict[tuple[str, str], list[ItemScore]] = defaultdict(list)
    for score in latest.values():
        by_answer[(score.response_id, score.item_id)].append(score)
    inter_pairs: list[tuple[float, float]] = []
    queue: list[dict[str, str]] = []
    for (response_id, item_id), records in sorted(by_answer.items()):
        records.sort(key=lambda record: record.grader_id)
        if len(records) < 2:
            continue
        for index in range(len(records) - 1):
            a, b = records[index], records[index + 1]
            inter_pairs.append((a.final_score, b.final_score))
            reasons = []
            if abs(a.final_score - b.final_score) >= 2:
                reasons.append("SCORE_DIFF_GE_2")
            if a.correct != b.correct:
                reasons.append("CORRECT_MISMATCH")
            if a.cap != b.cap:
                reasons.append("CAP_MISMATCH")
            if a.rubric_version != b.rubric_version:
                reasons.append("RUBRIC_VERSION_MISMATCH")
            if "KEY-AMBIGUITY" in a.error_codes or "KEY-AMBIGUITY" in b.error_codes:
                reasons.append("KEY_AMBIGUITY")
            if reasons:
                queue.append({
                    "response_id": response_id,
                    "item_id": item_id,
                    "grader_a": a.grader_id,
                    "score_a": str(a.final_score),
                    "grader_b": b.grader_id,
                    "score_b": str(b.final_score),
                    "reasons": ";".join(reasons),
                })
    return intra_pairs, inter_pairs, queue


def write_queue(path: Path, queue: list[dict[str, str]]) -> None:
    fields = [
        "response_id", "item_id", "grader_a", "score_a",
        "grader_b", "score_b", "reasons",
    ]
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(queue)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("item_scores", type=Path)
    parser.add_argument("criteria", type=Path)
    parser.add_argument(
        "--manifest", type=Path,
        default=Path(__file__).with_name("item_manifest.csv"),
    )
    parser.add_argument("--adjudication-out", type=Path)
    args = parser.parse_args()
    try:
        manifest = read_manifest(args.manifest)
        scores = read_item_scores(args.item_scores)
        criteria = read_criteria(args.criteria)
        warnings = validate(scores, criteria, manifest)
        intra, inter, queue = comparison_and_queue(scores)
        print(f"Validated {len(scores)} item-score records and {len(criteria)} criteria.")
        agreement_report("Intra-grader repeatability", intra)
        agreement_report("Inter-grader agreement", inter)
        print(f"Adjudication cases: {len(queue)}")
        if warnings:
            print(f"Warnings: {len(warnings)}")
            for warning in warnings:
                print(f"  - {warning}")
        if args.adjudication_out:
            write_queue(args.adjudication_out, queue)
            print(f"Wrote adjudication queue: {args.adjudication_out}")
        return 1 if warnings else 0
    except (OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
