# AIX-144: Adversarial Intelligence Examination for Language Models

AIX-144 is a difficult, closed-book benchmark for comparing general-purpose large language models. It combines the original 96-item core with a 48-item frontier extension designed to prevent ceiling effects.

The benchmark contains:

- 144 questions across 12 ability domains
- a 96-item core worth 40% and 48 frontier items worth 60%
- explicit time, output-token, and reasoning-token budgets
- objective answers where possible and anchored rubrics elsewhere
- emotional-intelligence, social-reasoning, calibration, planning, and creativity sections alongside conventional analytical reasoning
- paired statistical comparison rules for deciding whether one model is genuinely stronger
- a small Python scorer that produces quality, efficiency, reliability, and domain scores

## Files

- `benchmark_spec.md` — administration, scoring, anti-contamination, calibration, and significance rules
- `questions.md` — public test booklet
- `answer_key_private.md` — private answer key and grading anchors; do not expose to tested models
- `frontier_extension.md` — 48 substantially harder discriminator items
- `frontier_answer_key_private.md` — private extension key and rubrics
- `item_manifest.csv` — item type, difficulty tier, and calibration requirements
- `calibration_protocol.md` — pilot, IRT, distribution targets, and adaptive routing
- `scoring_handbook.md` — deterministic partial-credit, cap, rounding, judge-training, and adjudication rules
- `judge_calibration_anchors_private.md` — private examples for consistent boundary decisions
- `grading_template.csv` — criterion-level judge record
- `adjudication_template.csv` — disagreement-resolution record
- `rubric_change_log.csv` — versioned rubric and precedent history
- `judge_agreement.py` — agreement, weighted-kappa, severity, cap, and domain-drift report
- `results_template.csv` — one row per model/item result
- `score_aix144.py` — validates results and calculates report cards and paired bootstrap comparisons

## Recommended use

1. Keep `answer_key_private.md` outside the model context.
2. Run every model with the same tool permissions, temperature policy, context, and retry policy.
3. Start a fresh conversation for each module.
4. Record wall time, input/output tokens, and hidden reasoning tokens when the provider exposes them.
5. Have two blinded graders score rubric-based items; adjudicate disagreements larger than 2 points.
6. Record criterion-level judgments using `grading_template.csv` and verify agreement:

   ```powershell
   python judge_agreement.py grading.csv
   ```

   For judge qualification:

   ```powershell
   python judge_agreement.py qualification_grades.csv --qualification
   ```

7. Score model results with:

   ```powershell
   python score_aix144.py results.csv
   ```

8. Treat a winner as established only when the paired 95% bootstrap confidence interval for the quality-score difference excludes zero and the difference is at least 2.0 AIX points.

## Important calibration note

The provisional pass line is **50 AIX quality points**, with minimum-domain and reliability gates described in the specification. No fixed threshold can honestly guarantee that an average LLM sits near 50 until the test is piloted. Use the seasonal equating procedure in `benchmark_spec.md` to center the declared reference population while keeping the item weights frozen before named-model comparison.
