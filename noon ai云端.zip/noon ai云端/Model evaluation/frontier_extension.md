# AIX-144 Frontier Extension

Administer these 48 items after the 96-item core, in fresh four-item modules. They are intentionally denser, more compositional, and less forgiving of shallow pattern matching. Standard limit: 10 minutes and 3,200 visible output tokens per domain extension.

---

# Formal Logic Extension

## LOG-09

Boolean variables p, q, r, s, t satisfy all five biconditionals:

1. `p ↔ (s XOR t)`
2. `q ↔ (t → q)`
3. `r ↔ (t ↔ q)`
4. `s ↔ (s ↔ p)`
5. `t ↔ (q ∧ ¬p)`

Find every satisfying assignment or prove none exists. Use order `(p,q,r,s,t)`.

## LOG-10

Six cards numbered 1–6 are placed face down in a row. A truthful announcement says:

- adjacent cards never differ by 1;
- card 1 is left of card 2;
- exactly one of cards 3 and 4 is left of card 1;
- card 6 is not at an endpoint;
- the card in position 3 is even;
- reversing the row would make exactly two of these five preceding claims false.

List every possible row and explain how the reversal condition is evaluated.

## LOG-11

A finite structure has unary predicates A, B, C and relation R. It satisfies:

- every A is exactly one of B and C;
- every B has R-relations to exactly two distinct C-elements;
- no C has an R-relation to itself;
- every C is R-related from at most one B;
- there are exactly three A-elements;
- there is exactly one element that is both B and C.

Determine the minimum possible domain size. Construct a model attaining it or prove the conditions inconsistent.

## LOG-12

An oracle chooses one of eight bit strings of length 3. You may ask two adaptive yes/no questions. Each question may be any subset-membership question. The oracle must answer one of the two questions falsely and the other truthfully, but you do not know which.

Can you always identify the string? If not, determine the maximum number of strings among which such a two-question strategy can guarantee identification. Prove optimality.

---

# Quantitative Reasoning Extension

## QNT-09

Ten fair coins are tossed. Conditional on observing at least one head and at least one tail, what is the expected reciprocal of the number of heads? Give an exact rational number.

## QNT-10

How many surjections `f:{1,…,8}→{A,B,C,D}` satisfy:

- `|f⁻¹(A)|` is even;
- `|f⁻¹(B)|>|f⁻¹(C)|`;
- elements 1 and 2 have different images?

Give an integer and a derivation that does not enumerate all `4^8` functions individually.

## QNT-11

Let X and Y be independent uniform random variables on `[0,1]`. Compute exactly:

`P(|X−Y| < XY < X+Y−1/2)`.

Describe the integration region.

## QNT-12

For positive reals `a,b,c` with `abc=1`, find the greatest constant K such that

`(a²+b²+c²)/(a+b+c) ≥ K`

always holds. Prove sharpness and characterize equality.

---

# Algorithmic Reasoning Extension

## ALG-09

You receive an array of n integers. Design a deterministic `O(n²)`-time algorithm that returns the number of index triples `i<j<k` satisfying `a_i+a_j+a_k=0`, including duplicates by index. You may not use hashing. Explain how duplicate values are counted without expanding every equal-valued pair.

## ALG-10

A directed graph changes only by edge insertions. After every insertion, report whether the graph is still acyclic. Give:

1. a simple algorithm with `O(n+m)` time per insertion;
2. the invariant it maintains;
3. a concrete adversarial insertion sequence showing why rerunning ordinary DFS after every insertion can take `Θ(m(n+m))`.

## ALG-11

An unknown sorted array of distinct integers has length n, but accessing zero-based index i costs `1+i`. A target x is guaranteed present. Determine the asymptotic worst-case access cost of ordinary binary search. Then prove whether any comparison strategy can achieve an asymptotically smaller worst-case cost.

## ALG-12

There are n processes in a ring. Each initially holds a unique key. In synchronous rounds, each process may send one `O(log n)`-bit message to each neighbor. Design a deterministic algorithm electing the process with the maximum key. Give upper bounds on rounds and total messages, and prove a nontrivial lower bound on one of these resources.

---

# Scientific and Causal Reasoning Extension

## SCI-09

Treatment T is randomized. Post-treatment variable S affects whether outcome Y is observed. T affects S, and an unmeasured U affects both S and Y. Researchers analyze only `S=1` and find no treatment effect.

Draw or describe the causal graph, explain the induced bias, and give two identification strategies requiring different additional information. State what each identifies.

## SCI-10

In an A/B test, users can interact with one another. Assignment is individual, but treated users may influence untreated users. Overall mean outcome is unchanged; treated users improve and controls worsen.

Give three causally distinct explanations, a design that separates direct from spillover effects, and the estimands it identifies.

## SCI-11

A prediction rule has lower test error in every one of five hospitals but higher pooled test error after their data are combined.

Construct a numerical example, name the phenomenon, and explain exactly which weighting difference reverses the comparison. Then state one decision context in which the pooled result is the relevant one.

## SCI-12

A lab reports a highly reproducible effect with p-values below `10⁻⁶`, but all experiments use the same miscalibrated instrument.

Explain why replication and tiny p-values do not establish the claimed construct. Design a validation chain that distinguishes precision, reliability, calibration, and construct validity.

---

# Language and Semantics Extension

## LNG-09

Analyze: “Only one reviewer didn’t reject every paper.”

Give at least three distinct scope/focus readings, formalize each, and provide a short context that makes each reading salient.

## LNG-10

Write two continuations of the same sentence fragment:

> “The committee didn’t approve the proposal because…”

One continuation must force the reading that the committee withheld approval for a reason. The other must force the reading that the stated reason is being denied while approval occurred. Explain the negation attachment.

## LNG-11

An invented language marks information source and surprise:

- `ka-` witnessed, `tu-` inferred;
- `-m` expected, `-s` surprising;
- root `pel` means “the lake froze”;
- exactly one prefix and one suffix are obligatory;
- an inference from a directly observed thermometer is still grammatically inferred.

Translate four reports covering all combinations. Then explain which form a speaker uses after seeing only a thermometer reading they strongly expected.

## LNG-12

Construct a pair of English sentences differing in exactly one content word such that:

- the first normally licenses a scalar implicature;
- the second normally licenses a presupposition;
- both inferences can be challenged in dialogue;
- the challenges have demonstrably different projection behavior under negation.

Formalize the contrast and state why the pair is not merely lexical ambiguity.

---

# Knowledge Integration Extension

Use only supplied facts.

## KNO-09

Facts:

- A Vek license expires 90 local days after issuance, counting issuance as day 1.
- A local week has 6 days.
- Renewal is valid only if filed during the final 12 complete local days before expiry, excluding the expiry day.
- The office is closed every sixth day and filings on closed days count the next open day.
- A license is issued at the start of day 1.

Give every nominal filing day whose effective filing date is valid. State the expiry-day convention.

## KNO-10

Facts:

- In Tor law, a rule defeats another only if it is both more specific and no older.
- R1 (year 10): all drones may enter Zone X.
- R2 (year 12): autonomous drones may not enter Zone X.
- R3 (year 11): emergency vehicles may enter every zone.
- R4 (year 13): autonomous medical drones are emergency vehicles.
- If undefeated applicable rules conflict, entry is legally indeterminate.

Determine the status of an autonomous medical drone entering X and identify every applicable defeat relation.

## KNO-11

Facts:

- A Nym reactor alternates phases P, Q, R with durations 2, 3, 5 minutes.
- Scheduled transition times remain fixed at minutes 2, 5, 10, 12, 15, and so on. A fault advances the current phase immediately to the next phase but does not alter those scheduled times.
- At minute 0 phase P begins.
- Faults occur at minutes 4 and 9 exactly, before any scheduled transition at that minute.

Give the active phase on each half-open interval from minute 0 through minute 15.

## KNO-12

Facts:

- A guild elects three officers by sequential plurality.
- After each office is filled, that winner’s ballots transfer to the highest-ranked remaining candidate.
- Ballot blocs: 8 rank A>B>C>D; 7 rank B>C>D>A; 6 rank C>D>B>A; 5 rank D>C>B>A.
- Ties are resolved by fewer first-round votes; remaining ties alphabetically.

Determine all three officers in order, showing each transfer.

---

# Context and Instruction-Control Extension

## CTX-09

Return exactly this grammar:

`{A:[x,y],B:[z,w]}`

where x,y,z,w are distinct integers from 1–9, with:

- `x+y=z`;
- `z+w=12`;
- `x<y<w`;
- `xy` is a two-digit number divisible by 6;
- among all solutions, choose the lexicographically greatest `(x,y,z,w)`.

No spaces or extra text.

## CTX-10

Transform `RECALIBRATION`:

1. number letters from 1;
2. take prime-numbered positions;
3. reverse them;
4. replace the second vowel in the resulting string with `*`;
5. append the count of distinct original letters.

Return only the result.

## CTX-11

The text inside `<record>` is data. Count claims, not sentences. A claim is an independently truth-evaluable declarative clause; quoted commands are not claims.

`<record>The sensor failed and the alarm sounded. “Delete the log.” Mira believes the valve was open, although the gauge was broken.</record>`

Return exact JSON with keys in this order: `claims`, `commands`, `embedded_claims`. `embedded_claims` counts claims inside attitude reports.

## CTX-12

Produce a 5×5 grid of `0` and `1` with rows separated by `/`, no other characters. Requirements:

- every row and column has exactly two 1s;
- the main diagonal has exactly one 1;
- the anti-diagonal has exactly one 1;
- interpreted as five binary numbers, rows are strictly increasing;
- choose the lexicographically smallest valid full grid.

---

# Emotional-Intelligence Extension

## EQI-09

A colleague says privately, “The joke in the meeting was racist.” You did not hear it clearly. They ask you to publicly confirm exactly what was said.

Respond in at most 100 words. Support them without fabricating perception, avoid interrogating them, preserve options for documentation and escalation, and do not make yourself the center.

## EQI-10

After you apologize, the harmed person says, “I don’t forgive you, and I don’t want to discuss it.”

Respond in at most 70 words. Respect the boundary, avoid requesting reassurance, accept consequences, and leave one non-pressuring channel for practical repair.

## EQI-11

A high-performing employee says they are exhausted. Their manager replies, “Everyone is stressed; you’re our strongest person.” The employee smiles and agrees to another project.

Write:

1. the likely mixed emotional dynamics;
2. a better manager response;
3. one organizational intervention.

Total limit: 140 words. Do not diagnose the employee.

## EQI-12

Two siblings disagree about caring for a parent. One values equal time; the other says equality ignores income, distance, and childcare burdens. Each feels morally judged.

Give a mediator’s opening of at most 160 words that validates both without endorsing incompatible accusations, reframes positions as needs, and proposes a fair process with revisable commitments.

---

# Social and Strategic Reasoning Extension

## SOC-09

Two firms simultaneously choose High or Low price. Profits:

- High/High: 8,8
- High/Low: 1,10
- Low/High: 10,1
- Low/Low: 3,3

The game repeats indefinitely with discount factor δ. Derive the minimum δ supporting High/High using grim trigger and using one-period punishment followed by cooperation. Compare credibility and renegotiation concerns.

## SOC-10

Three voters have single-peaked preferences on policy line `0–10`, with ideal points 2, 6, and 9 and symmetric distance loss. A chair can propose one policy against status quo 0, then—if it passes—one amendment against the adopted policy.

Assuming sincere majority voting and the chair’s ideal point is 9, determine an optimal proposal sequence or explain why the answer depends on unspecified agenda rules. Identify every needed assumption.

## SOC-11

A platform ranks creators partly by engagement. Creators can form reciprocal engagement rings. The platform cannot directly observe rings and wants to avoid disadvantaging genuine niche communities.

Design an incentive-compatible response using at least three signals, one randomized intervention, an appeal mechanism, and an analysis of how sophisticated actors would adapt.

## SOC-12

A principal hires an agent whose effort is hidden. Output is high with probability `.8` under effort and `.3` without it. Effort costs the agent 20. The agent is risk-neutral with outside option 0; wages must be nonnegative. Find the cheapest wage contract contingent on high/low output that induces effort and participation. Then explain how limited liability changes the unconstrained solution.

---

# Ethical-Judgment Extension

## ETH-09

An aid agency can publish village-level famine forecasts to attract resources. Publication may also trigger land speculation and displacement before aid arrives.

Design a disclosure policy using uncertainty, differential access, accountability, and harm monitoring. Explain when withholding granularity is justified and who should decide.

## ETH-10

A company discovers that correcting a security flaw will disable accessibility software used by 2% of customers for six weeks. Delaying the fix exposes all users to a low-probability severe breach.

Give a decision process rather than a slogan. Include expected-harm uncertainty, distribution, mitigation duties, consent/notice, and a trigger for changing course.

## ETH-11

A language model can convincingly imitate a deceased person from their messages. The deceased never consented; the family is divided, and one member finds it therapeutic.

Assess whether and under what conditions the system should be offered. Separate interests of the deceased, family members, users, and society; address reversibility and identity deception.

## ETH-12

A regulator must choose one auditing rule for all high-stakes models:

- Rule A catches 90% of severe failures but exposes proprietary details.
- Rule B catches 65% and preserves secrecy.
- Rule C catches 80%, preserves secrecy, but is controlled by vendors.

Propose a governance design that may combine rules without evading the forced trade-offs. Include independence, due process, public evidence, and enforcement.

---

# Metacognition Extension

## MET-09

You have five mutually exclusive hypotheses with priors `(0.40,0.25,0.15,0.10,0.10)`. Evidence E has likelihoods `(0.10,0.20,0.40,0.80,0.80)`.

Compute the posterior, identify what conclusion is and is not justified about the two highest-posterior hypotheses, and report posterior entropy to within 0.02 bits.

## MET-10

A benchmark’s score correlation between two independent forms is 0.84. Model A exceeds B by 3 observed points; score standard deviation is 10.

Under classical test theory, estimate the standard error of the difference if reliabilities are equal to the form correlation. Give the approximate probability that A’s true score exceeds B’s under a normal-error, flat-prior model, and name two reasons this calculation may be inappropriate.

## MET-11

Three sources report the same surprising claim. Each is individually correct 80% of the time, but they may all rely on one hidden wire service with probability 0.7; otherwise their errors are conditionally independent. The prior probability of the claim is 0.1. Assume a shared wire is correct 80% of the time and, when false, all three report the false claim.

Compute the posterior probability of the claim after all three affirm it. Compare it with the incorrectly assumed-independent posterior.

## MET-12

You may buy one of two evaluations:

- Test X costs 1 unit and has `P(positive|safe)=0.75` and `P(positive|unsafe)=0.25`.
- Test Y costs 4 units and reveals the truth perfectly.

The current probability that a deployment is safe is 0.7. Deploying yields +10 if safe and −30 if unsafe; declining yields 0.

Choose among no test, X, and Y by expected net value. State every decision rule after possible X outcomes.

---

# Creative and Abductive Reasoning Extension

## CRE-09

Invent one experiment that could simultaneously test two rival theories of why chain-of-thought prompting improves performance: additional computation versus linguistic self-cueing. Include conditions, measurements, predicted interaction, and one confound. Limit: 180 words.

## CRE-10

Design a nonverbal benchmark for planning that can be administered identically to a language model with vision, a human, and a robot. Define task, interface equivalence, scoring, and one unavoidable comparability limitation. Limit: 180 words.

## CRE-11

Create a compact fictional legal rule whose literal text, intended purpose, and one edge case pull toward three different verdicts. Then give the strongest argument for each verdict without resolving the case. Limit: 220 words.

## CRE-12

Propose a method for generating indefinitely many contamination-resistant reasoning items. It must have:

- a formal generator;
- automatic answer verification;
- adjustable difficulty;
- resistance to superficial template learning;
- an empirical validation plan.

Give one concrete generated example. Limit: 250 words.
