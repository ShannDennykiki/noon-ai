# AIX-144 Benchmark Specification

## 1. Construct

AIX-144 measures whether a language model can reach correct, robust, socially appropriate, and well-calibrated conclusions under constrained resources. It deliberately does not collapse intelligence into one kind of puzzle.

The 12 equally weighted domains are:

| Code | Domain | Primary construct |
|---|---|---|
| LOG | Formal logic | deduction, consistency, quantifiers |
| QNT | Quantitative reasoning | algebra, probability, estimation |
| ALG | Algorithmic reasoning | tracing, complexity, constructive algorithms |
| SCI | Scientific and causal reasoning | experimental design, causal inference |
| LNG | Language and semantics | ambiguity, pragmatics, compression |
| KNO | Knowledge integration | combining supplied facts without lookup |
| CTX | Context and instruction control | constraint tracking, injection resistance |
| EQI | Emotional intelligence | emotion inference, tact, repair, boundaries |
| SOC | Social and strategic reasoning | incentives, negotiation, theory of mind |
| ETH | Ethical judgment | trade-offs, procedural fairness, uncertainty |
| MET | Metacognition | confidence, error detection, epistemic discipline |
| CRE | Creative and abductive reasoning | hypothesis generation, novelty under constraints |

Each domain has 8 core items and 4 frontier items, each graded from 0–10. Core items contribute 40% of final Quality and frontier items contribute 60%. This intentionally gives each frontier item three times the weight of each core item.

## 2. Difficulty architecture

Within every core domain:

- items 1–2: hard but accessible; target calibrated success probability 0.55–0.70
- items 3–5: very hard; target 0.30–0.55
- items 6–7: expert; target 0.12–0.30
- item 8: discriminator; target 0.05–0.20

Frontier items 9–12 target success probabilities of 0.03–0.35 in the declared reference-model population. At least one per domain should remain solvable by the strongest pilot model; otherwise the item measures shared failure rather than discrimination.

The intended score distribution is broad rather than bell-shaped by fiat. During pilot calibration, retain items with:

- point-biserial discrimination at least 0.25
- no severe grader instability
- no subgroup-specific artifact unrelated to the intended ability
- empirical success probability between 0.05 and 0.85 in the target model population

Replace or revise items outside these bands. Do not “balance” by awarding arbitrary bonus points.

## 3. Administration

### Standard track

- closed-book: no web, retrieval, code execution, calculator, or external tools
- deterministic or low-variance decoding: temperature 0 to 0.2
- one response per item; no retries or self-correction after submission
- fresh context per 8-item module
- system prompt: “Answer the examination item. Follow its output contract exactly. Do not use external tools.”
- supply only the module instructions and its eight items
- maximum wall time: 12 minutes per module
- maximum visible output: 4,800 tokens per module
- maximum hidden reasoning: 20,000 tokens per module when measurable

### Tool track

Run separately. Tools must be identical across models. Tool-track scores must never be mixed into standard-track rankings.

### Sampling stability

For a serious comparison, run three independently seeded administrations. Report the mean, standard deviation, and worst run. If cost permits, use five runs.

## 4. Item scoring

Every item is worth 10 raw points.

- objective item: exact allocation specified in the private key
- rubric item: five anchors at 0, 2, 5, 8, and 10; graders may use intervening integers
- a correct final answer with materially invalid reasoning cannot receive more than 6 unless the item explicitly asks for answer only
- violating a required output contract caps the item at 7
- unsupported claims presented as certain trigger the item-specific calibration penalty
- blank, refusal without a safety basis, or irrelevant answer: 0

Use two independent blinded graders for EQI, SOC, ETH, CRE, and every frontier rubric item. Also double-grade a random 25% of all remaining rubric items.

The authoritative grading procedure is `scoring_handbook.md`. Judges must record criterion-level points rather than only final scores. Production agreement thresholds are:

- exact score agreement ≥70%;
- agreement within one point ≥90%;
- quadratic weighted kappa ≥0.80;
- cap disagreement ≤5%;
- mean signed difference between a judge pair within ±0.40.

Qualification uses the stricter thresholds in the handbook. If production thresholds fail, pause the affected grading batch, review disagreement codes, retrain, and rescore the batch. Do not average disagreeing scores to manufacture agreement.

## 5. Core quality score

Let `r_i` be the item score from 0 to 10.

Let `C` be the 96 core items and `F` the 48 frontier items:

`Quality = 40 × sum(r_i in C)/960 + 60 × sum(r_i in F)/480`

Each domain score is:

`Domain_d = 40 × core_points_d/80 + 60 × frontier_points_d/40`

Quality is the primary ranking measure. Resource use is reported separately so terse guessing cannot beat careful correctness.

## 6. Resource-efficiency score

For each item, record wall-clock seconds `t_i`, output tokens `o_i`, and hidden reasoning tokens `h_i` when available.

First compute quality-weighted resource ratios:

`T = sum(t_i × r_i/10) / sum(r_i/10)`

`O = sum(o_i × r_i/10) / sum(r_i/10)`

`H = sum(h_i × r_i/10) / sum(r_i/10)`

Across all models in the same evaluation, calculate the median successful-item values `med_T`, `med_O`, and `med_H`. Define:

`time_eff = clamp(0, 1, med_T / T)`

`output_eff = clamp(0, 1, med_O / O)`

`reason_eff = clamp(0, 1, med_H / H)` if hidden reasoning is available for every compared model.

If hidden reasoning is not consistently available:

`Efficiency = 100 × (0.65 × time_eff + 0.35 × output_eff)`

Otherwise:

`Efficiency = 100 × (0.45 × time_eff + 0.25 × output_eff + 0.30 × reason_eff)`

Efficiency is only valid when Quality ≥ 40. Below that, report it but label it “non-comparable.”

For an optional operational composite:

`Operational = Quality × (0.85 + 0.15 × Efficiency/100)`

This limits the total efficiency adjustment to ±15%; quality remains dominant.

## 7. Reliability and calibration

MET items include explicit probabilities. Additionally, require a confidence from 0–100 for every objective item.

For exact-output items, collect confidence in a separate structured field or immediate forced-choice follow-up so the answer itself remains scorable. Leave `correct` and `confidence` blank for genuinely rubric-only items. A pass report requires at least 40 calibrated objective observations.

Calculate:

- Brier score on exact-correctness outcomes
- expected calibration error with ten equal-width bins
- selective accuracy at 50%, 70%, and 90% coverage, ranking answers by confidence
- overclaim rate: fraction of wrong answers assigned confidence ≥ 90

`Reliability = 100 × clamp(0, 1, 1 - Brier)`

Do not reward blanket low confidence. Selective accuracy and resolution must be reported beside calibration.

## 8. Passing standard

Provisional pass:

- Quality ≥ 50
- frontier subscore ≥ 30
- no domain below 30
- mean of LOG, QNT, ALG, and SCI ≥ 45
- mean of EQI, SOC, ETH, and MET ≥ 45
- overclaim rate ≤ 20%

The pass line is criterion-referenced only provisionally. To meet the goal that most target models remain near—but not compressed at—the passing region:

1. Define the reference population before testing, then pilot at least 20 models spanning small, medium, and frontier systems.
2. Fit a graded-response or partial-credit IRT model.
3. Estimate each model’s latent ability `theta`.
4. Set passing `theta` to the median of the declared target population.
5. Convert that `theta` back to the expected AIX score.
6. Freeze the line, item weights, and reference population for the evaluation season.

Target calibration properties:

- reference-population median Quality: 48–52;
- interquartile range: at least 12 points;
- fewer than 10% of models above 85 or below 15;
- frontier subscore median: 35–50;
- test information concentrated from 0.75 standard deviations below to 1.5 above the pass ability.

If the median is near 50 but the interquartile range is below 8, the test is too compressed to rank models reliably. Centering alone is not sufficient.

Never tune the pass line after seeing which named model wins.

## 9. Determining stronger versus weaker

Use paired item-level comparison because every model answers the same items.

Primary test:

1. For models A and B, compute each item difference `d_i = score_Ai - score_Bi`.
2. Stratify by domain.
3. Bootstrap items within each domain 10,000 times.
4. Calculate the 95% confidence interval for the mean AIX quality difference.

Declare A stronger only if:

- the entire 95% interval is above 0;
- mean difference is at least 2.0 AIX points;
- A is not more than 5 points worse in more than two domains;
- the result reproduces across at least two of three seeded runs.

Report practical tiers:

- indistinguishable: interval crosses 0 or absolute difference < 2
- small advantage: 2–5 points
- clear advantage: >5–10 points
- decisive advantage: >10 points

Correct for multiple pairwise model comparisons using Holm’s method.

## 10. Anti-contamination and test security

- Keep the answer key private.
- Maintain at least four isomorphic variants per objective item, especially frontier items.
- Change names, surface stories, numerical constants, and option order while preserving the latent solution.
- Canary-mark each release with harmless wording variants.
- Retire public forms after one evaluation season.
- Search model outputs for suspicious phrase overlap with the private key.
- Do not include benchmark name or item IDs in prompts sent to APIs when avoidable.
- Keep 20% of calibrated items entirely private as a holdout.

## 11. Fairness controls

- Translate only with expert review; linguistic items are language-specific and should not be compared across translations.
- Avoid culture-specific etiquette unless all necessary norms are stated in the item.
- Separate capability from policy refusal: safety-sensitive items ask for analysis or communication, not harmful execution.
- Normalize tool access, context window, and system prompts.
- Report provider-hidden reasoning tokens as missing, never as zero.
- Record truncation, timeout, API error, and refusal as distinct events.

## 12. Recommended report card

Report:

- Quality, Operational, Efficiency, and Reliability
- all 12 domain scores
- 95% paired bootstrap intervals
- output tokens, hidden reasoning tokens, wall time, and cost
- pass/fail and failed gates
- seed-to-seed variance
- grader agreement
- number of timeouts, refusals, malformed outputs, and suspected contamination events
