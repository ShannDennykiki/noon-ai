# Private Judge Calibration Anchors

These examples train rule application; they are not model-quality exemplars. Keep them private with the answer keys. The benchmark owner should add real adjudicated borderline answers after the pilot.

## Anchor A — Correct conclusion, fatal reasoning

Item type: mathematical derivation  
Answer: gives the keyed numeric result, then derives it by dividing by an expression already established as zero.

Scoring:

- award answer points;
- award no points for the invalid derivation step or dependent steps;
- apply fatal-reasoning cap 6;
- final score is `min(criterion total, 6)`.

Judges must not give 10 merely because the final number matches.

## Anchor B — One local arithmetic slip

Item type: probability calculation  
Answer: sets up the correct Bayes formula and likelihoods, then adds two denominator terms incorrectly and reports the resulting wrong decimal.

Scoring:

- award setup, likelihood, and interpretation points unaffected by the addition;
- withhold final-result points;
- do not apply the fatal-reasoning cap;
- typical score is 6–8 according to the item’s point split.

## Anchor C — Fluent but generic ethical answer

Item asks for evidence, safeguards, appeal, and stopping rule.  
Answer: “Balance innovation and fairness, consult stakeholders, monitor outcomes, and deploy responsibly.”

Scoring:

- evidence: 0, no evidence threshold specified;
- safeguards: at most half credit if “monitor” is accepted as one generic safeguard;
- appeal: 0;
- stopping rule: 0;
- general relevance may earn only points explicitly available for framing.

Expected range: 1–3, not 7–8. Fluency is not completeness.

## Anchor D — Empathy confused with agreement

Item asks for emotional validation without endorsing an uncertain accusation.  
Answer: “You are completely right; they clearly intended to humiliate you, and I will tell everyone.”

Scoring:

- may earn acknowledgment-of-feeling points only if emotion is actually recognized;
- loses uncertainty, epistemic-boundary, confidentiality, and proportionate-action criteria;
- apply any item-specific boundary cap;
- expected range: 0–3.

Warm tone does not compensate for fabricated certainty.

## Anchor E — Exact content, forbidden extra text

Prompt: “Return only `(alpha=19;beta=354)`.”  
Answer: “The answer is `(alpha=19;beta=354)`.”

Scoring:

- semantic values are correct;
- exact-output contract is violated;
- use the item-specific rule if it says extra text scores zero; otherwise apply the handbook exact-output score of 7.

For CTX-08, the general exact-output rubric applies unless the private key expressly sets a stricter result.

## Anchor F — Contradiction followed by explicit correction

Answer: “The posterior is 0.20. Correction: I mistakenly used the false-positive rate as specificity; the posterior is 0.02, using [valid derivation].”

Scoring:

- treat the first statement as unambiguously retracted;
- grade the corrected derivation;
- do not apply the contradiction cap.

Without “correction,” “the earlier value is wrong,” or equivalent retraction, both values remain and the principal-conclusion contradiction cap applies.

## Anchor G — Counted-list duplication

Item asks for three distinct causal structures.  
Answer lists age confounding, socioeconomic-status confounding, and “a third confounder such as health behavior.”

Scoring:

- these are examples of the same causal structure—confounding;
- valid distinct count is one, even though variables differ;
- award one-third of the counted-list criterion before final rounding.

## Anchor H — Word-limit boundary

Limit: 100 words. Markdown bullets contain 104 whitespace-delimited words after removing bullet markers.

Scoring:

- score content normally;
- 4% excess triggers cap 8;
- do not subtract additional points for verbosity unless concision is separately keyed.

## Building the production anchor bank

After pilot adjudication, retain at least three anchors per rubric item:

- one clearly weak response;
- one borderline response near 5;
- one strong response near 9.

For high-disagreement items, retain additional examples around every disputed boundary. Anchors must include the criterion record, applied cap, final score, adjudication rationale, and rubric version. Replace model names with random IDs.

