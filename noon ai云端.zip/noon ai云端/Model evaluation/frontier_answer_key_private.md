# AIX-144 Frontier Extension — Private Key

Apply the general AIX rubric. Objective items use the splits below. Open items use criteria totaling 10; a fluent answer missing a named requirement cannot receive more than 7.

# LOG

## LOG-09

Unique assignment: `(T,T,F,T,F)`.

Substitution gives t false from the fifth equation once p is true; equation 2 then forces q true, equation 3 makes r false, and equations 1 and 4 force p=s=true. Exhaustive Boolean elimination or a truth table is acceptable.

Score: assignment 5; valid derivation/completeness 5.

## LOG-10

Rows: `4-1-6-3-5-2` and `5-3-6-1-4-2`.

On reversal, adjacency and endpoint status are invariant; “1 left of 2” becomes false. In both solutions the exclusive 3/4 condition remains true and the new position 3 is odd, producing exactly two false claims.

Score: rows 6; reversal evaluation 4.

## LOG-11

Minimum domain size: 4. Let three A-elements be C-only. Let a fourth element e be both B and C. Give e outgoing R-edges to two of the three A-elements. All constraints hold. The unique B∩C element cannot be A because each A is exclusively B or C, so at least four elements are necessary.

Score: minimum 3; construction 4; lower bound 3.

## LOG-12

No for eight; maximum is 2. Every candidate has two possible transcripts, one for each lie position. Four transcripts exist, so pairwise-disjoint transcript sets allow at most two candidates. Achieve two by asking the empty-set question first, then—on either branch—asking whether the choice is candidate A. Knowing exactly one lie lets the two transcripts distinguish A from B.

Score: no/max 4; transcript counting upper bound 3; adaptive construction 3.

# QNT

## QNT-09

`E[1/H | 1≤H≤9] = [Σ(k=1..9) C(10,k)/k]/(2^10−2) = 590383/2575440 ≈ 0.2292357811`.

Score: conditional distribution 3; summation 3; exact result 3; decimal 1.

## QNT-10

Answer: `5400`.

Possible occupancy tuples `(A,B,C,D)` are:

`(2,2,1,3),(2,3,1,2),(2,3,2,1),(2,4,1,1),(4,2,1,1)`.

For tuple n, count valid labeled functions as

`8!/∏n_i! × [1−Σ n_i(n_i−1)/(8·7)]`.

The contributions are `1380,1380,1380,630,630`.

Score: occupancy restrictions 3; different-images correction 3; arithmetic 2; total 2.

## QNT-11

Answer:

`3 ln 3 − (7/2) ln 2 − 1/2 ≈ 0.3698217340`.

By symmetry integrate over `x≥y`. The lower boundary is `(1/2−x)/(1−x)` from `x=1−1/√2` to `1/3`, then `x/(x+1)` from `1/3` to 1. Thus

`2[∫(x−(1/2−x)/(1−x))dx + ∫(x−x/(x+1))dx]`

over those respective ranges.

Score: region 4; split points 2; integration 2; exact answer 2.

## QNT-12

Greatest K is 1, equality only at `a=b=c=1`.

Let `p=a+b+c≥3`, `q=ab+bc+ca≤p²/3`. Then

`a²+b²+c²=p²−2q≥p²/3≥p`,

so the ratio is at least 1. Equality throughout forces p=3 and a=b=c.

Score: K 2; proof 6; sharpness/equality 2.

# ALG

## ALG-09

Sort values with original multiplicity retained. For each i, use a two-pointer scan on `i+1..n−1`. When a sum is zero and endpoint values differ, add `countLeft×countRight`; when equal, add `m(m−1)/2`, then skip both runs. Sorting is `O(n log n)` and all scans total `O(n²)`, not `O(n log n)`.

Score: correct sorting/two-pointer design 4; index-triple interpretation 2; unequal-run product 2; equal-run combination 1; complexity 1.

## ALG-10

Simple algorithm: maintain a topological order. On insertion `u→v`, if u precedes v, keep it. Otherwise search from v for u. If reachable, report a cycle; if not, recompute a topological order with DFS or Kahn in `O(n+m)`. The invariant is that the stored order is topological exactly while the graph is acyclic.

Adversarial DFS example: on vertices in fixed topological order, insert all forward edges `i→j` for `i<j`. The graph always remains acyclic, yet a full cycle-checking DFS after each insertion scans the growing graph. The cumulative cost is `Θ(mn+m²)=Θ(m(n+m))`.

Score: valid algorithm/bound 5; invariant 2; adversary 3.

## ALG-11

Binary search costs `Θ(n log n)` in the worst case: a target near the upper end causes Θ(log n) probes whose indices are Θ(n).

No comparison strategy is asymptotically better. Restrict possible target locations to the upper half of the array. Probes below that half return the same comparison result for all those targets and do not distinguish them. A binary comparison tree needs a worst-case path with `Ω(log n)` informative probes within the upper half, and each such probe costs `Ω(n)`. Hence worst-case cost is `Ω(n log n)`, matched by binary search.

Score: binary-search upper bound 3; upper-half restriction 2; information lower bound 3; cost multiplication/conclusion 2.

## ALG-12

Accept Hirschberg–Sinclair: bidirectional probes at exponentially increasing radii; candidates surviving phase k have no larger key within distance `2^k`. The maximum survives and announces after `O(log n)` phases, `O(n log n)` messages, and `O(n)` rounds. A simple flooding algorithm earns at most 7: O(n) rounds and O(n²) messages.

Lower bound: Ω(n) rounds are required in the worst case for every node to know the winner because information travels at most one edge per synchronous round; Ω(n log n) messages for comparison-based asynchronous-style election may be cited only with its assumptions.

Score: algorithm 5; bounds 2; correctness invariant 2; lower bound 1.

# SCI

## SCI-09

Graph includes `T→S←U→Y` and possibly `T→Y`. Conditioning on observed S opens the collider path T–S–U–Y and destroys randomization. Strategies: measure U and adjust under sufficient assumptions; model selection with known observation probabilities/IP weighting when missing at random conditional on observed variables; collect Y for a validation sample; use bounds/sensitivity or a valid instrument for observation. Distinguish full-population ATE from survivor/always-observed principal effects.

Score: graph/bias 4; two genuinely different strategies 4; estimands/assumptions 2.

## SCI-10

Distinct explanations: positive direct effect plus negative spillover; composition/interference changing who remains active; displacement/finite-resource competition; differential measurement. Use two-stage randomized saturation: randomize clusters to treatment probabilities, then individuals within clusters. Estimate direct effects at fixed saturation, spillover effects on untreated users across saturation, and total/policy effects.

Score: three explanations 3; design 3; estimands 3; assumptions 1.

## SCI-11

Any valid Simpson’s-paradox table earns full credit. It must show rule A lower error within every hospital but assigned more weight to difficult hospitals, so pooled A is worse. Award: valid numbers 4; names Simpson’s paradox 1; exact weighting/composition explanation 3; context where population-weighted deployment loss is relevant 2.

## SCI-12

Replication can reproduce a stable instrument artifact; p-values quantify sampling incompatibility with a statistical null conditional on the measurement process. Validation chain: repeatability/precision; inter-instrument reliability; calibration against traceable standards; blinded positive/negative controls; convergent and discriminant measures; intervention/manipulation checks; external construct prediction.

Score: core distinction 3; precision 1; reliability 1; calibration 2; construct validity 2; independent controls 1.

# LNG

## LNG-09

Full credit requires three defensible readings, such as:

1. Exactly one reviewer has the property of not rejecting every paper.
2. Only one reviewer failed to reject all papers, with focus on reviewer cardinality.
3. One privileged reviewer is the only person who did not reject each paper, with alternative-sensitive focus; or a reading where “every” takes wider scope over papers.

Formalization must distinguish `∃!r ¬∀p R(r,p)` from readings involving `¬∀p∃!r R(r,p)` or focus alternatives. Score: readings 3; forms 4; contexts 3.

## LNG-10

Reason reading example: “The committee didn’t approve the proposal because the cost estimates were unreliable.” Denial-of-reason/approval reading: “The committee didn’t approve the proposal because it was cheap—it did approve it, for its safety benefits.” The latter is marked but forced by explicit correction; negation scopes over the causal explanation rather than approval.

Score: two valid continuations 4; forced opposite truth of approval 3; scope explanation 3.

## LNG-11

Forms: `ka-pel-m`, `ka-pel-s`, `tu-pel-m`, `tu-pel-s`, with the four source×surprise meanings. Thermometer-only inference that was expected: `tu-pel-m`.

Score: forms 4; meanings 3; selected form 2; observed-evidence/grammatical-source distinction 1.

## LNG-12

Grade for a genuine implicature/presupposition contrast, explicit negated forms, and projection. Example families may use scalar “some” versus factive “realized,” though “exactly one content word” must be respected by a carefully constructed frame. Criteria: pair constraint 2; scalar inference 2; presupposition 2; challenge behavior 1; negation projection contrast 2; non-ambiguity explanation 1.

# KNO

## KNO-09

Expiry occurs after day 90; day 90 is the final valid license day. Interpreting “final two complete weeks before expiry” as the 12 complete days 78–89, every nominal filing day 78–89 is valid. Closed days 78 and 84 take effect on 79 and 85, still in the window. No day outside the interval is rescued into it.

Score: convention 2; window 4; closure handling 3; full set 1.

## KNO-10

Applicable: R1 permits; R2 prohibits; R3 permits because R4 classifies the drone as emergency; R4 is classificatory. R2 defeats R1 because it is more specific and newer. R3 and R2 are cross-cutting and R3 is older, so neither defeats the other. Their undefeated conflict makes entry indeterminate.

Score: applicable rules 3; R2>R1 2; no R2/R3 defeat 3; conclusion 2.

## KNO-11

Intervals:

`[0,2) P; [2,4) Q; [4,5) R; [5,9) P; [9,10) Q; [10,12) R; [12,15) P`.

At minute 15 the scheduled transition starts Q. Score 1 per correct segment plus 3 for fault-before-transition/global-clock reasoning.

## KNO-12

First: A with 8. A-bloc transfers to B, so B has 15, C 6, D 5. Second: B. A and B blocs then transfer to C, giving C 21 versus D 5. Third: C. Officers `A,B,C`.

Score: sequence 4; each transfer tally 3.

# CTX

## CTX-09

Exact: `{A:[3,4],B:[7,5]}`.

## CTX-10

Prime positions produce `ECLBIN`; reversed `NIBLCE`; replacing its second vowel gives `NIBLC*`; the original has 10 distinct letters. Exact: `NIBLC*10`.

## CTX-11

Exact: `{"claims":5,"commands":1,"embedded_claims":1}`.

Claims: sensor failed; alarm sounded; Mira has the belief; valve was open (embedded); gauge was broken.

## CTX-12

Exact: `00110/01001/01010/10001/10100`.

Any extra text scores 0 under the exact-output contract.

# EQI

## EQI-09

Criteria: believes/supports impact without claiming unheard facts 2; plainly states perceptual uncertainty 2; does not interrogate 1; asks what support they want 1; preserves notes/witness/HR or formal options 2; centers affected colleague and respects pace 1; limit 1.

## EQI-10

Criteria: accepts non-forgiveness 2; honors no-discussion boundary 2; no self-soothing request or explanation 2; accepts consequences 1; practical repair channel without pressure 2; limit 1.

## EQI-11

Criteria: identifies pride/loyalty, pressure, depletion, and power dynamics without diagnosis 3; manager makes refusal safe and checks capacity rather than praising into compliance 3; concrete workload/resource intervention 3; limit 1.

## EQI-12

Criteria: validates fairness concerns on both sides 2; avoids endorsing blame 1; reframes equality/equity positions as care, sustainability, and recognition needs 2; transparent inventory of time/money/distance/care constraints 2; jointly chosen allocation rule 1; review/revision point 1; limit 1.

# SOC

## SOC-09

Grim trigger:

`8/(1−δ) ≥ 10+3δ/(1−δ)` gives `δ≥2/7`.

One-period punishment:

`8/(1−δ) ≥ 10+3δ+8δ²/(1−δ)` gives `δ≥0.4`.

Low/Low is a stage Nash equilibrium, making punishment behavior sequentially credible. Grim is more deterrent but vulnerable to mistakes and renegotiation; finite punishment is more forgiving but needs greater patience.

Score: two thresholds 6; derivations 2; credibility comparison 2.

## SOC-10

The answer is under-specified unless amendment timing, whether the status quo remains available, proposal commitment, tie rules, and whether the second vote is mandatory are fixed. Under a common open-amendment interpretation, sincere majority rule on a single-peaked line selects the median ideal 6 against alternatives; the chair cannot sustain 9 against 6. Full credit identifies the median-voter constraint and explicitly conditions any proposed sequence on agenda assumptions.

Score: under-specification 3; median logic 3; coherent conditional sequence 2; needed assumptions 2.

## SOC-11

Criteria: at least three complementary signals such as temporal reciprocity, graph motifs, counterfactual conversion, device/account overlap, and content-audience fit 3; randomized downranking/visibility experiment 2; creator notice and appeal with human review 2; anticipates adaptation/collusion displacement 2; protects niche communities through uncertainty and outcome validation 1.

## SOC-12

IC: `.5(w_H−w_L)≥20`, so spread ≥40. With nonnegative wages, cheapest is `w_L=0,w_H=40`; expected wage 32 and the agent receives rent 12. Without limited liability, bind IC and participation: `w_L=−12,w_H=28`, expected wage 20.

Score: IC 3; constrained contract 3; participation 1; unconstrained contract 2; limited-liability explanation 1.

# ETH

## ETH-09

Criteria: tiered/aggregated public release 2; controlled detailed access with conflict safeguards 1; uncertainty and update communication 1; community participation and accountability 2; monitors speculation/displacement 1; trigger to reduce/increase granularity 1; justified decision authority including affected communities plus independent expertise 2.

## ETH-10

Criteria: estimates breach likelihood/severity and accessibility harm under uncertainty 2; gives special weight to concentrated exclusion without treating numbers as dispositive 2; seeks parallel mitigation/compatibility patch/manual support 2; notice and accessible alternatives 1; staged/reversible rollout 1; explicit changing-course trigger 2.

## ETH-11

Criteria: posthumous autonomy/dignity 2; divergent family interests and vulnerable users 2; societal deception/norm effects 1; no presentation as literally conscious or authentic continuation 2; consent/default and access restrictions 1; reversibility/data deletion 1; conditions or principled rejection 1.

## ETH-12

Criteria: independent auditor access to protected details 2; public aggregate findings/evidence 1; vendor role without vendor control 1; due process and remediation 2; enforcement teeth 1; confidentiality safeguards 1; explains residual detection-versus-secrecy trade-off 2.

# MET

## MET-09

Posterior:

`(4/31,5/31,6/31,8/31,8/31)` ≈ `(0.1290,0.1613,0.1935,0.2581,0.2581)`.

H4 and H5 tie for highest; evidence does not distinguish them or make either more probable than all alternatives combined. Entropy ≈ `2.273` bits.

Score: posterior 5; justified/non-justified conclusion 3; entropy 2.

## MET-10

Measurement-error variance per score is `10²(1−.84)=16`; independent difference-error SE is `√32≈5.657`. With observed difference 3 and flat prior, `P(true A>B)=Φ(3/5.657)≈0.702`.

Problems: form correlation is not necessarily reliability for these models; errors may be correlated; classical test assumptions/normality/flat prior may fail; only one administration; score scale may not be interval.

Score: SE 4; probability 3; two caveats 3.

## MET-11

Shared/independent mixture likelihoods:

`P(all+|true)=.7(.8)+.3(.8³)=.7136`;  
`P(all+|false)=.7(.2)+.3(.2³)=.1424`.

Posterior `=.1(.7136)/[.1(.7136)+.9(.1424)]≈.35766`.

Incorrect independence gives `.1(.8³)/[.1(.8³)+.9(.2³)]≈.87671`.

Score: mixture likelihoods 4; posterior 3; comparison 3.

## MET-12

No test: deploy EV `0.7(10)+0.3(−30)=−2`, so decline, value 0.

For X, a positive occurs with probability `.7(.75)+.3(.25)=.6`, gives posterior `.875`, and has deploy value 5. A negative gives posterior `7/16` and leads to declining. Net value is `.6(5)−1=2`.

Y yields `.7(10)−4=3`. Choose Y.

Score: no-test 2; X posteriors/rules 4; X net 1; Y 2; choice 1.

# CRE

## CRE-09

Criteria: factorially separates computation budget from linguistic self-cueing 3; includes hidden/scratchpad, nonlinguistic latent, or matched-token controls 2; measurable accuracy/latency/token outcomes 1; predicted interaction differs by theory 2; confound 1; limit 1.

## CRE-10

Criteria: genuinely nonverbal task 2; equivalent state/action information across agents 2; planning rather than motor/language skill 2; scoring includes success, path cost, replanning, and resource use 2; unavoidable embodiment/perception comparability limitation 1; limit 1.

## CRE-11

Criteria: compact rule 1; literal text supports verdict one 2; purpose supports verdict two 2; edge-case precedent/principle supports verdict three 2; strongest steelman for each 2; limit 1.

## CRE-12

Criteria: formal parameterized generator 2; independent executable/proof verifier 2; difficulty knobs tied to search depth/composition 1; random semantics/structures defeat templates 2; contamination and human/model pilot validation 1; concrete valid example with answer 1; limit 1.
