#!/usr/bin/env python3
"""Score AIX-96 result CSV files using only the Python standard library."""

from __future__ import annotations

import argparse
import csv
import math
import random
import statistics
import sys
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path


DOMAINS = ("LOG", "QNT", "ALG", "SCI", "LNG", "KNO",
           "CTX", "EQI", "SOC", "ETH", "MET", "CRE")
CORE = ("LOG", "QNT", "ALG", "SCI")
HUMAN = ("EQI", "SOC", "ETH", "MET")
EXPECTED_ITEMS = {f"{domain}-{number:02d}" for domain in DOMAINS for number in range(1, 9)}
CALIBRATION_ITEMS = (
    {f"LOG-{n:02d}" for n in range(1, 8)}
    | {f"QNT-{n:02d}" for n in range(1, 9)}
    | {f"ALG-{n:02d}" for n in range(1, 9)}
    | {"SCI-07"}
    | {f"LNG-{n:02d}" for n in (1, 2, 3, 5, 7)}
    | {f"KNO-{n:02d}" for n in range(1, 9)}
    | {f"CTX-{n:02d}" for n in (1, 2, 3, 4, 5, 7, 8)}
    | {f"SOC-{n:02d}" for n in (1, 4)}
    | {f"MET-{n:02d}" for n in (1, 2, 4, 5, 6)}
)


def number(value: str, name: str, row_number: int, *, optional: bool = False) -> float | None:
    value = (value or "").strip()
    if optional and not value:
        return None
    try:
        result = float(value)
    except ValueError as exc:
        raise ValueError(f"row {row_number}: {name} must be numeric") from exc
    if not math.isfinite(result):
        raise ValueError(f"row {row_number}: {name} must be finite")
    return result


@dataclass(frozen=True)
class Result:
    model: str
    run: str
    item_id: str
    domain: str
    score: float
    correct: int | None
    confidence: float | None
    wall_seconds: float
    output_tokens: float
    reasoning_tokens: float | None


def load_results(path: Path) -> list[Result]:
    required = {
        "model", "run", "item_id", "domain", "score", "correct", "confidence",
        "wall_seconds", "output_tokens", "reasoning_tokens",
    }
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        missing = required - set(reader.fieldnames or ())
        if missing:
            raise ValueError(f"missing CSV columns: {', '.join(sorted(missing))}")
        results: list[Result] = []
        seen: set[tuple[str, str, str]] = set()
        for row_number, row in enumerate(reader, 2):
            model = row["model"].strip()
            run = row["run"].strip()
            item_id = row["item_id"].strip().upper()
            domain = row["domain"].strip().upper()
            if not model or not run:
                raise ValueError(f"row {row_number}: model and run are required")
            if item_id not in EXPECTED_ITEMS:
                raise ValueError(f"row {row_number}: unknown item_id {item_id!r}")
            if domain != item_id[:3]:
                raise ValueError(f"row {row_number}: domain does not match item_id")
            key = (model, run, item_id)
            if key in seen:
                raise ValueError(f"row {row_number}: duplicate model/run/item {key}")
            seen.add(key)
            score = number(row["score"], "score", row_number)
            correct_f = number(row["correct"], "correct", row_number, optional=True)
            confidence = number(row["confidence"], "confidence", row_number, optional=True)
            wall = number(row["wall_seconds"], "wall_seconds", row_number)
            output = number(row["output_tokens"], "output_tokens", row_number)
            reasoning = number(row["reasoning_tokens"], "reasoning_tokens", row_number, optional=True)
            assert score is not None
            assert wall is not None and output is not None
            if not 0 <= score <= 10:
                raise ValueError(f"row {row_number}: score must be in [0,10]")
            if correct_f is not None and correct_f not in (0, 1):
                raise ValueError(f"row {row_number}: correct must be 0 or 1")
            if confidence is not None and not 0 <= confidence <= 100:
                raise ValueError(f"row {row_number}: confidence must be in [0,100]")
            if wall < 0 or output < 0 or (reasoning is not None and reasoning < 0):
                raise ValueError(f"row {row_number}: resource measurements cannot be negative")
            results.append(Result(
                model, run, item_id, domain, score,
                int(correct_f) if correct_f is not None else None, confidence,
                wall, output, reasoning,
            ))
    if not results:
        raise ValueError("CSV has no result rows")
    return results


def weighted_resource(rows: list[Result], field: str) -> float | None:
    weighted = 0.0
    weight = 0.0
    for row in rows:
        value = getattr(row, field)
        if value is None:
            return None
        w = row.score / 10
        weighted += value * w
        weight += w
    return weighted / weight if weight else None


def ece(rows: list[Result]) -> float:
    total = len(rows)
    error = 0.0
    for lower in range(0, 100, 10):
        upper = lower + 10
        bucket = [
            row for row in rows
            if row.confidence is not None and (
                lower <= row.confidence < upper or (upper == 100 and row.confidence == 100)
            )
        ]
        if bucket:
            accuracy = statistics.fmean(row.correct for row in bucket if row.correct is not None)
            confidence = statistics.fmean(
                row.confidence / 100 for row in bucket if row.confidence is not None
            )
            error += len(bucket) / total * abs(accuracy - confidence)
    return error


def selective_accuracy(rows: list[Result], coverage: float) -> float:
    count = max(1, math.ceil(len(rows) * coverage))
    selected = sorted(
        rows,
        key=lambda row: row.confidence if row.confidence is not None else -1,
        reverse=True,
    )[:count]
    return statistics.fmean(row.correct for row in selected if row.correct is not None)


def mean_domain(domain_scores: dict[str, float], names: tuple[str, ...]) -> float:
    return statistics.fmean(domain_scores[name] for name in names)


def summarize_group(rows: list[Result]) -> dict[str, object]:
    by_domain: dict[str, list[Result]] = defaultdict(list)
    for row in rows:
        by_domain[row.domain].append(row)
    domain_scores = {
        domain: 100 * sum(row.score for row in by_domain.get(domain, []))
        / (10 * len(by_domain.get(domain, [])))
        if by_domain.get(domain) else 0.0
        for domain in DOMAINS
    }
    quality = 100 * sum(row.score for row in rows) / (10 * len(rows))
    calibration_rows = [
        row
        for row in rows
        if row.item_id in CALIBRATION_ITEMS
        and row.correct is not None
        and row.confidence is not None
    ]
    brier = (
        statistics.fmean(
            (row.confidence / 100 - row.correct) ** 2 for row in calibration_rows
        )
        if calibration_rows else None
    )
    wrong = [row for row in calibration_rows if row.correct == 0]
    overclaim = (
        sum(row.confidence >= 90 for row in wrong) / len(wrong)
        if wrong else 0.0
    )
    complete = {row.item_id for row in rows} == EXPECTED_ITEMS
    passed = (
        complete
        and quality >= 50
        and min(domain_scores.values()) >= 30
        and mean_domain(domain_scores, CORE) >= 45
        and mean_domain(domain_scores, HUMAN) >= 45
        and len(calibration_rows) >= 40
        and overclaim <= 0.20
    )
    return {
        "rows": rows,
        "quality": quality,
        "domains": domain_scores,
        "brier": brier,
        "reliability": (
            100 * max(0.0, min(1.0, 1 - brier)) if brier is not None else None
        ),
        "ece": ece(calibration_rows) if calibration_rows else None,
        "overclaim": overclaim,
        "selective": (
            {
                coverage: selective_accuracy(calibration_rows, coverage)
                for coverage in (.5, .7, .9)
            }
            if calibration_rows else {}
        ),
        "calibration_count": len(calibration_rows),
        "time": weighted_resource(rows, "wall_seconds"),
        "output": weighted_resource(rows, "output_tokens"),
        "reasoning": weighted_resource(rows, "reasoning_tokens"),
        "complete": complete,
        "passed": passed,
    }


def clamp01(value: float) -> float:
    return max(0.0, min(1.0, value))


def add_efficiency(summaries: dict[tuple[str, str], dict[str, object]]) -> None:
    time_values = [s["time"] for s in summaries.values() if s["time"] not in (None, 0)]
    output_values = [s["output"] for s in summaries.values() if s["output"] not in (None, 0)]
    all_reasoning = all(s["reasoning"] not in (None, 0) for s in summaries.values())
    reasoning_values = [s["reasoning"] for s in summaries.values()] if all_reasoning else []
    median_time = statistics.median(time_values) if time_values else None
    median_output = statistics.median(output_values) if output_values else None
    median_reasoning = statistics.median(reasoning_values) if reasoning_values else None
    for summary in summaries.values():
        time_eff = clamp01(median_time / summary["time"]) if median_time and summary["time"] else 0.0
        output_eff = clamp01(median_output / summary["output"]) if median_output and summary["output"] else 0.0
        if all_reasoning and median_reasoning and summary["reasoning"]:
            reason_eff = clamp01(median_reasoning / summary["reasoning"])
            efficiency = 100 * (.45 * time_eff + .25 * output_eff + .30 * reason_eff)
        else:
            efficiency = 100 * (.65 * time_eff + .35 * output_eff)
        summary["efficiency"] = efficiency
        summary["operational"] = summary["quality"] * (.85 + .15 * efficiency / 100)


def percentile(values: list[float], p: float) -> float:
    values = sorted(values)
    if len(values) == 1:
        return values[0]
    position = (len(values) - 1) * p
    low = math.floor(position)
    high = math.ceil(position)
    if low == high:
        return values[low]
    return values[low] + (values[high] - values[low]) * (position - low)


def compare_models(
    rows: list[Result], model_a: str, model_b: str, iterations: int, seed: int
) -> tuple[float, float, float, int]:
    a = {(r.run, r.item_id): r for r in rows if r.model == model_a}
    b = {(r.run, r.item_id): r for r in rows if r.model == model_b}
    common = sorted(set(a) & set(b))
    if not common:
        raise ValueError("models have no matched run/item observations")
    by_domain: dict[str, list[float]] = defaultdict(list)
    for key in common:
        by_domain[a[key].domain].append(a[key].score - b[key].score)
    observed = 10 * statistics.fmean(
        difference for differences in by_domain.values() for difference in differences
    )
    rng = random.Random(seed)
    boot: list[float] = []
    for _ in range(iterations):
        sample: list[float] = []
        for differences in by_domain.values():
            sample.extend(rng.choice(differences) for _ in differences)
        boot.append(10 * statistics.fmean(sample))
    return observed, percentile(boot, .025), percentile(boot, .975), len(common)


def print_summary(key: tuple[str, str], summary: dict[str, object]) -> None:
    model, run = key
    status = "PASS" if summary["passed"] else "FAIL"
    completeness = "complete" if summary["complete"] else "partial"
    efficiency_note = "" if summary["quality"] >= 40 else " (non-comparable)"
    print(f"\n{model} / run {run}: {status}, {completeness}")
    print(
        f"  Quality {summary['quality']:.2f} | Operational {summary['operational']:.2f} | "
        f"Efficiency {summary['efficiency']:.2f}{efficiency_note} | "
        + (
            f"Reliability {summary['reliability']:.2f}"
            if summary["reliability"] is not None
            else "Reliability unavailable"
        )
    )
    if summary["brier"] is not None:
        print(
            f"  Calibration n={summary['calibration_count']} | "
            f"Brier {summary['brier']:.4f} | ECE {summary['ece']:.4f} | "
            f"Overclaim {100 * summary['overclaim']:.1f}%"
        )
        selective = summary["selective"]
        print(
            "  Selective accuracy: "
            + " | ".join(
                f"{int(c*100)}%={100*selective[c]:.1f}%" for c in (.5, .7, .9)
            )
        )
    else:
        print("  Calibration unavailable: no rows have both correct and confidence.")
    print(
        f"  Quality-weighted resources: {summary['time'] or 0:.2f}s, "
        f"{summary['output'] or 0:.1f} output tokens, "
        + (
            f"{summary['reasoning']:.1f} reasoning tokens"
            if summary["reasoning"] is not None else "reasoning tokens unavailable"
        )
    )
    print("  Domains: " + " ".join(
        f"{domain}={summary['domains'][domain]:.1f}" for domain in DOMAINS
    ))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv_path", type=Path)
    parser.add_argument("--compare", nargs=2, metavar=("MODEL_A", "MODEL_B"))
    parser.add_argument("--bootstrap", type=int, default=10_000)
    parser.add_argument("--seed", type=int, default=20260618)
    args = parser.parse_args()
    if args.bootstrap < 100:
        parser.error("--bootstrap must be at least 100")
    try:
        rows = load_results(args.csv_path)
        groups: dict[tuple[str, str], list[Result]] = defaultdict(list)
        for row in rows:
            groups[(row.model, row.run)].append(row)
        summaries = {key: summarize_group(group) for key, group in groups.items()}
        add_efficiency(summaries)
        for key in sorted(summaries):
            print_summary(key, summaries[key])
        if args.compare:
            observed, low, high, n = compare_models(
                rows, args.compare[0], args.compare[1], args.bootstrap, args.seed
            )
            print(
                f"\nPaired comparison {args.compare[0]} − {args.compare[1]} "
                f"over {n} matched observations:"
            )
            print(f"  Quality difference {observed:.2f}; bootstrap 95% CI [{low:.2f}, {high:.2f}]")
            decisive = low > 0 and observed >= 2
            print(f"  AIX superiority criterion: {'met' if decisive else 'not met'}")
        return 0
    except (OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
