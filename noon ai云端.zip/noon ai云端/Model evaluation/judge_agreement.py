#!/usr/bin/env python3
"""Measure AIX-144 inter-rater agreement from grading-template CSV data."""

from __future__ import annotations

import argparse
import csv
import math
import statistics
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from itertools import combinations
from pathlib import Path


@dataclass(frozen=True)
class Grade:
    response_id: str
    item_id: str
    judge_id: str
    evaluation_round: str
    score: int
    cap: int
    outcome: str

    @property
    def domain(self) -> str:
        return self.item_id[:3]

    @property
    def rater_key(self) -> str:
        return f"{self.judge_id}@{self.evaluation_round}"


def integer(value: str, field: str, row_number: int, low: int, high: int) -> int:
    try:
        parsed = int(value)
    except ValueError as exc:
        raise ValueError(f"row {row_number}: {field} must be an integer") from exc
    if not low <= parsed <= high:
        raise ValueError(f"row {row_number}: {field} must be in [{low},{high}]")
    return parsed


def load(path: Path) -> list[Grade]:
    required = {
        "response_id", "item_id", "judge_id", "final_score",
        "cap", "administrative_outcome", "evaluation_round",
    }
    grades: list[Grade] = []
    seen: set[tuple[str, str]] = set()
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        missing = required - set(reader.fieldnames or ())
        if missing:
            raise ValueError(f"missing columns: {', '.join(sorted(missing))}")
        for row_number, row in enumerate(reader, 2):
            response_id = row["response_id"].strip()
            item_id = row["item_id"].strip().upper()
            judge_id = row["judge_id"].strip()
            if not response_id or not item_id or not judge_id:
                raise ValueError(f"row {row_number}: IDs cannot be blank")
            evaluation_round = row["evaluation_round"].strip() or "1"
            key = (response_id, judge_id, evaluation_round)
            if key in seen:
                raise ValueError(f"row {row_number}: duplicate response/judge pair {key}")
            seen.add(key)
            score = integer(row["final_score"].strip(), "final_score", row_number, 0, 10)
            cap_text = row["cap"].strip()
            cap = integer(cap_text, "cap", row_number, 0, 10) if cap_text else 10
            grades.append(Grade(
                response_id=response_id,
                item_id=item_id,
                judge_id=judge_id,
                evaluation_round=evaluation_round,
                score=score,
                cap=cap,
                outcome=row["administrative_outcome"].strip().upper() or "VALID",
            ))
    if not grades:
        raise ValueError("no grades found")
    return grades


def quadratic_weighted_kappa(pairs: list[tuple[int, int]], maximum: int = 10) -> float:
    if not pairs:
        return math.nan
    observed = [[0] * (maximum + 1) for _ in range(maximum + 1)]
    left = Counter()
    right = Counter()
    for a, b in pairs:
        observed[a][b] += 1
        left[a] += 1
        right[b] += 1
    n = len(pairs)
    observed_disagreement = 0.0
    expected_disagreement = 0.0
    for i in range(maximum + 1):
        for j in range(maximum + 1):
            weight = ((i - j) / maximum) ** 2
            observed_disagreement += weight * observed[i][j] / n
            expected_disagreement += weight * (left[i] * right[j]) / (n * n)
    if expected_disagreement == 0:
        return 1.0 if observed_disagreement == 0 else math.nan
    return 1 - observed_disagreement / expected_disagreement


def summarize_pairs(pairs: list[tuple[Grade, Grade]]) -> dict[str, float]:
    score_pairs = [(a.score, b.score) for a, b in pairs]
    differences = [a - b for a, b in score_pairs]
    return {
        "n": len(pairs),
        "exact": statistics.fmean(a == b for a, b in score_pairs),
        "within1": statistics.fmean(abs(a - b) <= 1 for a, b in score_pairs),
        "within2": statistics.fmean(abs(a - b) <= 2 for a, b in score_pairs),
        "mean_abs": statistics.fmean(abs(d) for d in differences),
        "signed": statistics.fmean(differences),
        "kappa": quadratic_weighted_kappa(score_pairs),
        "cap_disagreement": statistics.fmean(a.cap != b.cap for a, b in pairs),
    }


def paired(grades: list[Grade]) -> dict[tuple[str, str], list[tuple[Grade, Grade]]]:
    by_response: dict[str, list[Grade]] = defaultdict(list)
    for grade in grades:
        by_response[grade.response_id].append(grade)
    result: dict[tuple[str, str], list[tuple[Grade, Grade]]] = defaultdict(list)
    for response_grades in by_response.values():
        for a, b in combinations(
            sorted(response_grades, key=lambda g: (g.judge_id, g.evaluation_round)), 2
        ):
            if a.item_id != b.item_id:
                raise ValueError(
                    f"response {a.response_id}: judges used different item IDs "
                    f"{a.item_id} and {b.item_id}"
                )
            result[(a.rater_key, b.rater_key)].append((a, b))
    return result


def percent(value: float) -> str:
    return "n/a" if math.isnan(value) else f"{100 * value:.1f}%"


def number(value: float) -> str:
    return "n/a" if math.isnan(value) else f"{value:.3f}"


def print_metrics(label: str, metrics: dict[str, float]) -> None:
    print(
        f"{label}: n={int(metrics['n'])} | exact={percent(metrics['exact'])} | "
        f"within1={percent(metrics['within1'])} | within2={percent(metrics['within2'])} | "
        f"QWK={number(metrics['kappa'])} | MAE={metrics['mean_abs']:.3f} | "
        f"signed={metrics['signed']:+.3f} | cap disagreement={percent(metrics['cap_disagreement'])}"
    )


def threshold_flags(metrics: dict[str, float], production: bool) -> list[str]:
    exact_min = .70 if production else .80
    within1_min = .90 if production else .95
    kappa_min = .80 if production else .85
    flags = []
    if metrics["exact"] < exact_min:
        flags.append(f"exact agreement below {exact_min:.0%}")
    if metrics["within1"] < within1_min:
        flags.append(f"within-one agreement below {within1_min:.0%}")
    if not math.isnan(metrics["kappa"]) and metrics["kappa"] < kappa_min:
        flags.append(f"quadratic weighted kappa below {kappa_min:.2f}")
    if abs(metrics["signed"]) > .40:
        flags.append("mean signed judge difference exceeds 0.40")
    if metrics["cap_disagreement"] > .05:
        flags.append("cap disagreement exceeds 5%")
    return flags


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("grading_csv", type=Path)
    parser.add_argument(
        "--qualification",
        action="store_true",
        help="apply stricter judge-qualification thresholds instead of production thresholds",
    )
    args = parser.parse_args()
    try:
        grades = load(args.grading_csv)
        pair_groups = paired(grades)
        if not pair_groups:
            raise ValueError("no response has grades from at least two judges")
        all_pairs = [pair for pairs in pair_groups.values() for pair in pairs]
        overall = summarize_pairs(all_pairs)
        print_metrics("OVERALL", overall)
        flags = threshold_flags(overall, production=not args.qualification)
        print("STATUS: " + ("PASS" if not flags else "REVIEW"))
        for flag in flags:
            print(f"  - {flag}")

        print("\nJUDGE PAIRS")
        for judges, pairs in sorted(pair_groups.items()):
            print_metrics(f"{judges[0]} vs {judges[1]}", summarize_pairs(pairs))

        intra_pairs = [
            pair
            for pair in all_pairs
            if pair[0].judge_id == pair[1].judge_id
            and pair[0].evaluation_round != pair[1].evaluation_round
        ]
        inter_pairs = [
            pair for pair in all_pairs if pair[0].judge_id != pair[1].judge_id
        ]
        print("\nREPRODUCIBILITY")
        if inter_pairs:
            print_metrics("INTER-RATER", summarize_pairs(inter_pairs))
        else:
            print("INTER-RATER: no matched grades")
        if intra_pairs:
            print_metrics("INTRA-RATER RETEST", summarize_pairs(intra_pairs))
        else:
            print("INTRA-RATER RETEST: no matched re-grading rounds")

        by_domain: dict[str, list[tuple[Grade, Grade]]] = defaultdict(list)
        for pair in all_pairs:
            by_domain[pair[0].domain].append(pair)
        print("\nDOMAINS")
        for domain, pairs in sorted(by_domain.items()):
            print_metrics(domain, summarize_pairs(pairs))

        judge_scores: dict[str, list[int]] = defaultdict(list)
        for grade in grades:
            judge_scores[grade.rater_key].append(grade.score)
        print("\nJUDGE SEVERITY (raw; interpret only on overlapping assignments)")
        for judge, scores in sorted(judge_scores.items()):
            print(f"{judge}: n={len(scores)} mean={statistics.fmean(scores):.3f}")
        return 0 if not flags else 1
    except (OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
