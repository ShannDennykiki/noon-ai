import { createHash, createHmac, randomBytes, randomInt, scryptSync, timingSafeEqual } from "node:crypto";
import { appendFile, mkdir, readFile, readdir, rename, rm, unlink, writeFile } from "node:fs/promises";
import path from "node:path";

const CODE_TTL_MS = 5 * 60 * 1000;
const CODE_COOLDOWN_MS = 60 * 1000;
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const MAX_CODE_ATTEMPTS = 5;
const codes = new Map();
const captchaChallenges = new Map();
const captchaTokens = new Map();
const signupTokens = new Map();
const rateWindows = new Map();
let writeQueue = Promise.resolve();

export function createAuthService({ rootDir }) {
  const configuredDataDir = process.env.DATA_DIR || "data";
  const dataDir = path.isAbsolute(configuredDataDir)
    ? configuredDataDir
    : path.resolve(rootDir, configuredDataDir);
  const storePath = path.join(dataDir, "auth-store.json");
  const backupDir = path.join(dataDir, "backups");
  let storeCache = null;

  async function handle(req, res, url) {
    if (!url.pathname.startsWith("/api/auth/") && url.pathname !== "/api/user-data") return false;

    if (req.method === "GET" && url.pathname === "/api/auth/me") {
      const auth = await authenticate(req);
      if (!auth) return reply(res, 200, { user: null });
      const storedUser = auth.store.users[auth.user.id];
      return reply(res, 200, loginPayload(auth.store, storedUser));
    }

    if (req.method === "POST" && url.pathname === "/api/auth/captcha") {
      const challengeId = randomBytes(18).toString("base64url");
      const target = randomInt(86, 232);
      const top = randomInt(38, 88);
      const theme = randomInt(0, 8);
      const shape = randomInt(0, 4);
      const artwork = captchaArtwork(target, top, theme, shape);
      captchaChallenges.set(challengeId, {
        target,
        expiresAt: Date.now() + 2 * 60 * 1000,
        attempts: 0
      });
      return reply(res, 200, {
        challengeId,
        image: artwork.image,
        piece: artwork.piece,
        pieceTop: top,
        width: 300,
        pieceWidth: 52
      });
    }

    if (req.method === "POST" && url.pathname === "/api/auth/verify-captcha") {
      const body = await readBody(req);
      const challenge = captchaChallenges.get(String(body.challengeId || ""));
      if (!challenge || challenge.expiresAt <= Date.now() || challenge.attempts >= 5) {
        return reply(res, 400, { error: "滑块验证已过期，请刷新后重试。" });
      }
      challenge.attempts += 1;
      const position = Number(body.position);
      if (!Number.isFinite(position) || Math.abs(position - challenge.target) > 7) {
        return reply(res, 400, { error: "滑块位置不正确，请重试。" });
      }
      captchaChallenges.delete(String(body.challengeId || ""));
      const captchaToken = randomBytes(24).toString("base64url");
      captchaTokens.set(hashToken(captchaToken), { expiresAt: Date.now() + 2 * 60 * 1000 });
      return reply(res, 200, { captchaToken });
    }

    if (req.method === "POST" && url.pathname === "/api/auth/send-code") {
      const body = await readBody(req);
      const phone = normalizePhone(body.phone);
      const purpose = body.purpose === "reset" ? "reset" : body.purpose === "register" ? "register" : "login";
      if (!phone) return reply(res, 400, { error: "请输入有效的中国大陆手机号。" });
      if (!consumeCaptchaToken(body.captchaToken)) {
        return reply(res, 400, { error: "请先完成滑块验证。" });
      }
      if (!takeRateLimit(`sms-phone:${phone}`, 10, 60 * 60 * 1000)
        || !takeRateLimit(`sms-ip:${clientIp(req)}`, 30, 60 * 60 * 1000)) {
        return reply(res, 429, { error: "验证码请求次数过多，请稍后再试。" });
      }

      const store = await loadStore();
      const exists = Boolean(store.phoneIndex[phone]);
      if (purpose === "register" && exists) return reply(res, 409, { error: "该手机号已注册，请直接登录。" });
      if (purpose === "reset" && !exists) return reply(res, 404, { error: "该手机号尚未注册。" });

      const key = `${purpose}:${phone}`;
      const previous = codes.get(key);
      if (previous && Date.now() - previous.sentAt < CODE_COOLDOWN_MS) {
        return reply(res, 429, { error: "验证码发送过于频繁，请稍后再试。" });
      }

      const code = String(randomInt(100000, 1000000));
      try {
        await sendSmsCode(phone, code, purpose);
      } catch (error) {
        return reply(res, 502, { error: error.message || "短信发送失败，请稍后再试。" });
      }
      codes.set(key, { hash: hashToken(code), expiresAt: Date.now() + CODE_TTL_MS, sentAt: Date.now(), attempts: 0 });
      const payload = { ok: true, expiresIn: CODE_TTL_MS / 1000 };
      if (process.env.NODE_ENV !== "production" && smsMode() === "console") payload.devCode = code;
      return reply(res, 200, payload);
    }

    if (req.method === "POST" && url.pathname === "/api/auth/register") {
      const body = await readBody(req);
      const phone = normalizePhone(body.phone);
      const passwordError = validatePassword(body.password);
      if (!phone) return reply(res, 400, { error: "请输入有效的中国大陆手机号。" });
      if (passwordError) return reply(res, 400, { error: passwordError });
      if (!verifyCode(phone, "register", body.code)) return reply(res, 400, { error: "验证码无效或已过期。" });

      const store = await loadStore();
      if (store.phoneIndex[phone]) return reply(res, 409, { error: "该手机号已注册。" });
      const id = randomBytes(16).toString("hex");
      const salt = randomBytes(16).toString("hex");
      const now = new Date().toISOString();
      store.users[id] = { id, phone, salt, passwordHash: hashPassword(body.password, salt), createdAt: now };
      store.phoneIndex[phone] = id;
      store.userData[id] = defaultUserData(phone);
      const token = createSession(store, id);
      await saveStore(store);
      codes.delete(`register:${phone}`);
      setSessionCookie(req, res, token);
      return reply(res, 201, loginPayload(store, store.users[id], true, token));
    }

    if (req.method === "POST" && url.pathname === "/api/auth/login/password") {
      const body = await readBody(req);
      const phone = normalizePhone(body.phone);
      if (!takeRateLimit(`login:${clientIp(req)}:${phone}`, 15, 15 * 60 * 1000)) {
        return reply(res, 429, { error: "登录尝试次数过多，请稍后再试。" });
      }
      const store = await loadStore();
      const user = store.users[store.phoneIndex[phone] || ""];
      if (!user || !checkPassword(body.password, user)) return reply(res, 401, { error: "手机号或密码错误。" });
      const token = createSession(store, user.id);
      await saveStore(store);
      setSessionCookie(req, res, token);
      return reply(res, 200, loginPayload(store, user, false, token));
    }

    if (req.method === "POST" && url.pathname === "/api/auth/login/code") {
      const body = await readBody(req);
      const phone = normalizePhone(body.phone);
      if (!phone || !verifyCode(phone, "login", body.code)) return reply(res, 400, { error: "验证码无效或已过期。" });
      const store = await loadStore();
      const user = store.users[store.phoneIndex[phone] || ""];
      if (!user) {
        const signupToken = randomBytes(24).toString("base64url");
        signupTokens.set(hashToken(signupToken), { phone, expiresAt: Date.now() + 5 * 60 * 1000 });
        codes.delete(`login:${phone}`);
        return reply(res, 200, { needsPassword: true, signupToken, phone });
      }
      const token = createSession(store, user.id);
      await saveStore(store);
      codes.delete(`login:${phone}`);
      setSessionCookie(req, res, token);
      return reply(res, 200, loginPayload(store, user, false, token));
    }

    if (req.method === "POST" && url.pathname === "/api/auth/complete-registration") {
      const body = await readBody(req);
      const pending = signupTokens.get(hashToken(body.signupToken || ""));
      const passwordError = validatePassword(body.password);
      if (!pending || pending.expiresAt <= Date.now()) return reply(res, 400, { error: "注册凭证已过期，请重新获取验证码。" });
      if (passwordError) return reply(res, 400, { error: passwordError });
      const store = await loadStore();
      if (store.phoneIndex[pending.phone]) return reply(res, 409, { error: "该手机号已注册，请直接登录。" });
      const id = randomBytes(16).toString("hex");
      const salt = randomBytes(16).toString("hex");
      const now = new Date().toISOString();
      store.users[id] = { id, phone: pending.phone, salt, passwordHash: hashPassword(body.password, salt), createdAt: now };
      store.phoneIndex[pending.phone] = id;
      store.userData[id] = defaultUserData(pending.phone);
      const token = createSession(store, id);
      signupTokens.delete(hashToken(body.signupToken || ""));
      await saveStore(store);
      setSessionCookie(req, res, token);
      return reply(res, 201, loginPayload(store, store.users[id], true, token));
    }

    if (req.method === "POST" && url.pathname === "/api/auth/reset-password") {
      const body = await readBody(req);
      const phone = normalizePhone(body.phone);
      const passwordError = validatePassword(body.password);
      if (!phone) return reply(res, 400, { error: "请输入有效的中国大陆手机号。" });
      if (passwordError) return reply(res, 400, { error: passwordError });
      if (!verifyCode(phone, "reset", body.code)) return reply(res, 400, { error: "验证码无效或已过期。" });
      const store = await loadStore();
      const user = store.users[store.phoneIndex[phone] || ""];
      if (!user) return reply(res, 404, { error: "该手机号尚未注册。" });
      const salt = randomBytes(16).toString("hex");
      user.salt = salt;
      user.passwordHash = hashPassword(body.password, salt);
      for (const [key, session] of Object.entries(store.sessions)) {
        if (session.userId === user.id) delete store.sessions[key];
      }
      codes.delete(`reset:${phone}`);
      const token = createSession(store, user.id);
      await saveStore(store);
      setSessionCookie(req, res, token);
      return reply(res, 200, loginPayload(store, user, false, token));
    }

    if (req.method === "POST" && url.pathname === "/api/auth/logout") {
      const token = sessionToken(req);
      if (token) {
        const store = await loadStore();
        delete store.sessions[hashToken(token)];
        await saveStore(store);
      }
      clearSessionCookie(req, res);
      return reply(res, 200, { ok: true });
    }

    const auth = await authenticate(req);
    if (!auth) return reply(res, 401, { error: "请先登录。" });

    if (req.method === "DELETE" && url.pathname === "/api/auth/account") {
      const body = await readBody(req);
      if (String(body.confirmation || "") !== "确认删除") {
        return reply(res, 400, { error: "请输入“确认删除”后再继续。" });
      }

      const userId = auth.user.id;
      const phone = auth.user.phone;
      const generatedImages = collectGeneratedImageNames(
        auth.store.userData[userId],
        auth.store.userDataBackups[userId]
      );

      delete auth.store.users[userId];
      delete auth.store.phoneIndex[phone];
      delete auth.store.userData[userId];
      delete auth.store.userDataBackups[userId];
      for (const [key, session] of Object.entries(auth.store.sessions)) {
        if (session.userId === userId) delete auth.store.sessions[key];
      }

      codes.delete(`register:${phone}`);
      codes.delete(`login:${phone}`);
      codes.delete(`reset:${phone}`);
      for (const [key, pending] of signupTokens) {
        if (pending.phone === phone) signupTokens.delete(key);
      }
      for (const key of rateWindows.keys()) {
        if (key.includes(phone)) rateWindows.delete(key);
      }

      const retainedImages = collectGeneratedImageNames(auth.store.userData, auth.store.userDataBackups);
      await saveStore(auth.store);
      await removeAccountFiles(dataDir, backupDir, userId, phone, generatedImages, retainedImages);
      clearSessionCookie(req, res);
      return reply(res, 200, { ok: true });
    }

    if (req.method === "GET" && url.pathname === "/api/user-data") {
      return reply(res, 200, auth.store.userData[auth.user.id] || defaultUserData(auth.user.phone));
    }

    if (req.method === "PUT" && url.pathname === "/api/user-data") {
      const body = await readBody(req, 12 * 1024 * 1024);
      const previous = auth.store.userData[auth.user.id] || null;
      const next = sanitizeUserData(body, auth.user.phone, previous);
      archiveUserData(auth.store, auth.user.id, previous, next);
      auth.store.userData[auth.user.id] = next;
      await saveStore(auth.store);
      return reply(res, 200, { ok: true, updatedAt: auth.store.userData[auth.user.id].updatedAt });
    }

    return reply(res, 405, { error: "Method not allowed" });
  }

  async function requireUser(req, res) {
    const auth = await authenticate(req);
    if (auth) return auth.user;
    reply(res, 401, { error: "请先登录。" });
    return null;
  }

  async function authenticate(req) {
    const token = sessionToken(req);
    if (!token) return null;
    const store = await loadStore();
    const session = store.sessions[hashToken(token)];
    if (!session || session.expiresAt <= Date.now()) return null;
    const user = store.users[session.userId];
    if (!user) return null;
    return { user: publicUser(user), store };
  }

  async function loadStore() {
    if (storeCache) return storeCache;
    await mkdir(dataDir, { recursive: true });
    try {
      const rawStore = await readFile(storePath, "utf8");
      storeCache = normalizeStore(JSON.parse(rawStore));
      await createStartupBackup(rawStore);
    } catch (error) {
      if (error.code !== "ENOENT") console.error("Unable to read auth store:", error.message);
      storeCache = normalizeStore({});
    }
    return storeCache;
  }

  function saveStore(store) {
    writeQueue = writeQueue.then(async () => {
      await mkdir(dataDir, { recursive: true });
      const tempPath = `${storePath}.${randomBytes(6).toString("hex")}.tmp`;
      await writeFile(tempPath, JSON.stringify(store, null, 2), "utf8");
      await rename(tempPath, storePath);
    });
    return writeQueue;
  }

  async function createStartupBackup(rawStore) {
    try {
      await mkdir(backupDir, { recursive: true });
      const stamp = new Date().toISOString().replace(/[:.]/g, "-");
      await writeFile(path.join(backupDir, `auth-store-${stamp}.json`), rawStore, "utf8");
      const backups = (await readdir(backupDir))
        .filter((name) => /^auth-store-.*\.json$/.test(name))
        .sort()
        .reverse();
      await Promise.all(backups.slice(10).map((name) => unlink(path.join(backupDir, name))));
    } catch (error) {
      console.warn("Unable to create auth store backup:", error.message);
    }
  }

  return { handle, requireUser };
}

function normalizeStore(value) {
  const store = value && typeof value === "object" ? value : {};
  store.users = store.users && typeof store.users === "object" ? store.users : {};
  store.phoneIndex = store.phoneIndex && typeof store.phoneIndex === "object" ? store.phoneIndex : {};
  store.sessions = store.sessions && typeof store.sessions === "object" ? store.sessions : {};
  store.userData = store.userData && typeof store.userData === "object" ? store.userData : {};
  store.userDataBackups = store.userDataBackups && typeof store.userDataBackups === "object" ? store.userDataBackups : {};
  for (const [key, session] of Object.entries(store.sessions)) {
    if (!session || session.expiresAt <= Date.now()) delete store.sessions[key];
  }
  return store;
}

function defaultUserData(phone) {
  return {
    initialized: false,
    state: { sessions: [] },
    profile: { displayName: phone, username: phone, avatar: "" },
    settings: {},
    updatedAt: new Date().toISOString()
  };
}

function sanitizeUserData(body, phone, previous = null) {
  const incomingProfile = body?.profile && typeof body.profile === "object" ? body.profile : {};
  const previousProfile = previous?.profile && typeof previous.profile === "object" ? previous.profile : {};
  let displayName = String(incomingProfile.displayName || phone).trim() || phone;
  let avatar = typeof incomingProfile.avatar === "string" ? incomingProfile.avatar : "";
  if (body?.allowProfileReset !== true) {
    if (displayName === phone && previousProfile.displayName && previousProfile.displayName !== phone) {
      displayName = previousProfile.displayName;
    }
    if (!avatar && previousProfile.avatar) avatar = previousProfile.avatar;
  }
  return {
    initialized: true,
    state: body?.state && typeof body.state === "object" ? body.state : { sessions: [] },
    profile: {
      displayName,
      username: phone,
      avatar
    },
    settings: body?.settings && typeof body.settings === "object" ? body.settings : {},
    updatedAt: new Date().toISOString()
  };
}

function archiveUserData(store, userId, previous, next) {
  if (!previous?.initialized) return;
  const previousProfile = JSON.stringify(previous.profile || {});
  const nextProfile = JSON.stringify(next.profile || {});
  if (previousProfile === nextProfile) return;
  const backups = Array.isArray(store.userDataBackups[userId]) ? store.userDataBackups[userId] : [];
  backups.unshift({ ...previous, archivedAt: new Date().toISOString() });
  store.userDataBackups[userId] = backups.slice(0, 5);
}

function collectGeneratedImageNames(...values) {
  const filenames = new Set();
  const visit = (value) => {
    if (typeof value === "string") {
      for (const match of value.matchAll(/\/api\/generated-images\/([a-zA-Z0-9._-]+)/g)) {
        filenames.add(match[1]);
      }
      return;
    }
    if (Array.isArray(value)) {
      value.forEach(visit);
      return;
    }
    if (value && typeof value === "object") Object.values(value).forEach(visit);
  };
  values.forEach(visit);
  return filenames;
}

async function removeAccountFiles(dataDir, backupDir, userId, phone, generatedImages, retainedImages) {
  await rm(path.join(dataDir, "user-storage", userId), { recursive: true, force: true });
  await scrubAccountFromBackups(backupDir, userId, phone, generatedImages, retainedImages);
  await Promise.all([...generatedImages].filter((filename) => !retainedImages.has(filename)).map((filename) =>
    unlink(path.join(dataDir, "generated-images", path.basename(filename))).catch(() => {})
  ));
}

async function scrubAccountFromBackups(backupDir, userId, phone, generatedImages, retainedImages) {
  let names = [];
  try {
    names = (await readdir(backupDir)).filter((name) => /^auth-store-.*\.json$/.test(name));
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    return;
  }

  for (const name of names) {
    const backupPath = path.join(backupDir, name);
    let backup;
    try {
      backup = JSON.parse(await readFile(backupPath, "utf8"));
    } catch {
      continue;
    }

    collectGeneratedImageNames(backup.userData?.[userId], backup.userDataBackups?.[userId])
      .forEach((filename) => generatedImages.add(filename));
    if (backup.users && typeof backup.users === "object") delete backup.users[userId];
    if (backup.phoneIndex && typeof backup.phoneIndex === "object") delete backup.phoneIndex[phone];
    if (backup.userData && typeof backup.userData === "object") delete backup.userData[userId];
    if (backup.userDataBackups && typeof backup.userDataBackups === "object") delete backup.userDataBackups[userId];
    if (backup.sessions && typeof backup.sessions === "object") {
      for (const [key, session] of Object.entries(backup.sessions)) {
        if (session?.userId === userId) delete backup.sessions[key];
      }
    }
    collectGeneratedImageNames(backup.userData, backup.userDataBackups)
      .forEach((filename) => retainedImages.add(filename));

    const tempPath = `${backupPath}.${randomBytes(6).toString("hex")}.tmp`;
    await writeFile(tempPath, JSON.stringify(backup, null, 2), "utf8");
    await rename(tempPath, backupPath);
  }
}

function publicUser(user) {
  return { id: user.id, phone: user.phone, account: user.phone, createdAt: user.createdAt };
}

function loginPayload(store, user, autoLogin = false, sessionTokenValue = "") {
  return {
    user: publicUser(user),
    userData: store.userData[user.id] || defaultUserData(user.phone),
    ...(sessionTokenValue ? { sessionToken: sessionTokenValue } : {}),
    ...(autoLogin ? { autoLogin: true } : {})
  };
}

function normalizePhone(value) {
  const digits = String(value || "").replace(/\D/g, "").replace(/^86(?=1\d{10}$)/, "");
  return /^1[3-9]\d{9}$/.test(digits) ? digits : "";
}

function validatePassword(value) {
  const password = String(value || "");
  if (password.length < 6) return "密码至少需要 6 位。";
  if (password.length > 128) return "密码不能超过 128 位。";
  const categories = [/[A-Za-z]/.test(password), /\d/.test(password), /[^A-Za-z\d]/.test(password)].filter(Boolean).length;
  if (categories < 2) return "密码需包含字母、数字、特殊字符中的至少两类。";
  return "";
}

function hashPassword(password, salt) {
  return scryptSync(String(password), Buffer.from(salt, "hex"), 64).toString("hex");
}

function checkPassword(password, user) {
  if (!password || !user?.passwordHash || !user?.salt) return false;
  const actual = Buffer.from(hashPassword(password, user.salt), "hex");
  const expected = Buffer.from(user.passwordHash, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

function verifyCode(phone, purpose, value) {
  const key = `${purpose}:${phone}`;
  const record = codes.get(key);
  if (!record || record.expiresAt <= Date.now() || record.attempts >= MAX_CODE_ATTEMPTS) return false;
  record.attempts += 1;
  const actual = Buffer.from(hashToken(String(value || "")));
  const expected = Buffer.from(record.hash);
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

function createSession(store, userId) {
  const token = randomBytes(32).toString("base64url");
  store.sessions[hashToken(token)] = { userId, expiresAt: Date.now() + SESSION_TTL_MS };
  return token;
}

function hashToken(value) {
  return createHash("sha256").update(String(value)).digest("hex");
}

function consumeCaptchaToken(value) {
  const key = hashToken(value || "");
  const record = captchaTokens.get(key);
  captchaTokens.delete(key);
  return Boolean(record && record.expiresAt > Date.now());
}

function captchaArtwork(target, top, theme, shape) {
  const palettes = [
    ["#d7e7f3", "#6f93ad", "#29495f"],
    ["#dce8d4", "#78956b", "#34503a"],
    ["#e4dddd", "#9a7777", "#513737"],
    ["#dedbed", "#8179a8", "#413b65"],
    ["#f0dfc5", "#b78454", "#65422b"],
    ["#cae7e2", "#4c9b91", "#20534f"],
    ["#e7d5e7", "#a15f9a", "#593152"],
    ["#d8e1f2", "#687fac", "#2d4269"]
  ];
  const [light, mid, dark] = palettes[theme] || palettes[0];
  const seed = randomInt(1000, 9999);
  const circleX = randomInt(35, 105);
  const circleY = randomInt(25, 105);
  const secondX = randomInt(145, 270);
  const secondY = randomInt(28, 118);
  const shapePaths = [
    "M2 8 H17 C17 0 29 0 29 8 H50 V23 C42 23 42 35 50 35 V50 H31 C31 42 19 42 19 50 H2 V34 C10 34 10 22 2 22 Z",
    "M2 2 H19 C19 10 31 10 31 2 H50 V19 C42 19 42 31 50 31 V50 H34 C34 42 22 42 22 50 H2 V31 C10 31 10 19 2 19 Z",
    "M2 8 H18 C18 0 30 0 30 8 H50 V28 C42 28 42 40 50 40 V50 H28 C28 42 16 42 16 50 H2 V32 C10 32 10 20 2 20 Z",
    "M2 2 H21 C21 10 33 10 33 2 H50 V17 C42 17 42 29 50 29 V50 H32 C32 42 20 42 20 50 H2 V36 C10 36 10 24 2 24 Z"
  ];
  const localPath = shapePaths[shape] || shapePaths[0];
  const scene = `<defs>
      <linearGradient id="g${seed}" x1="0" y1="0" x2="1" y2="1"><stop stop-color="${light}"/><stop offset=".55" stop-color="${mid}"/><stop offset="1" stop-color="${dark}"/></linearGradient>
      <radialGradient id="sun${seed}"><stop stop-color="#fff" stop-opacity=".9"/><stop offset="1" stop-color="${light}" stop-opacity="0"/></radialGradient>
    </defs>
    <rect width="300" height="150" rx="10" fill="url(#g${seed})"/>
    <circle cx="${circleX}" cy="${circleY}" r="${randomInt(24, 44)}" fill="${mid}" opacity=".7"/>
    <circle cx="${secondX}" cy="${secondY}" r="${randomInt(25, 55)}" fill="${light}" opacity=".38"/>
    <circle cx="${randomInt(80, 240)}" cy="${randomInt(15, 70)}" r="58" fill="url(#sun${seed})"/>
    <path d="M0 ${randomInt(105, 135)} Q55 ${randomInt(65, 110)} 112 ${randomInt(100, 138)} T225 ${randomInt(84, 126)} T300 ${randomInt(102, 140)} V150 H0Z" fill="${dark}" opacity=".52"/>
    <path d="M12 ${randomInt(18, 48)} Q70 ${randomInt(66, 98)} 128 ${randomInt(20, 48)} T230 ${randomInt(24, 72)} T292 ${randomInt(12, 42)}" fill="none" stroke="white" stroke-opacity=".28" stroke-width="${randomInt(5, 10)}"/>
    <g opacity=".25" fill="#fff"><circle cx="${randomInt(20, 280)}" cy="${randomInt(15, 135)}" r="4"/><circle cx="${randomInt(20, 280)}" cy="${randomInt(15, 135)}" r="7"/><circle cx="${randomInt(20, 280)}" cy="${randomInt(15, 135)}" r="3"/></g>`;
  const backgroundSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="300" height="150" viewBox="0 0 300 150">${scene}<path d="${localPath}" transform="translate(${target} ${top})" fill="#101216" fill-opacity=".48" stroke="#fff" stroke-opacity=".92" stroke-width="2"/></svg>`;
  const pieceSvg = `<svg xmlns="http://www.w3.org/2000/svg" width="52" height="52" viewBox="0 0 52 52"><defs><clipPath id="piece"><path d="${localPath}"/></clipPath></defs><g clip-path="url(#piece)" transform="translate(${-target} ${-top})">${scene}</g><path d="${localPath}" fill="none" stroke="#fff" stroke-width="2"/></svg>`;
  return {
    image: svgDataUrl(backgroundSvg),
    piece: svgDataUrl(pieceSvg)
  };
}

function svgDataUrl(svg) {
  return `data:image/svg+xml;base64,${Buffer.from(svg).toString("base64")}`;
}

function takeRateLimit(key, max, windowMs) {
  const cutoff = Date.now() - windowMs;
  const recent = (rateWindows.get(key) || []).filter((timestamp) => timestamp > cutoff);
  if (recent.length >= max) return false;
  recent.push(Date.now());
  rateWindows.set(key, recent);
  return true;
}

function clientIp(req) {
  return String(req.headers["x-forwarded-for"] || req.socket?.remoteAddress || "unknown").split(",")[0].trim();
}

function sessionToken(req) {
  const authorization = String(req.headers.authorization || "");
  if (/^Bearer\s+/i.test(authorization)) return authorization.replace(/^Bearer\s+/i, "").trim();
  const cookies = String(req.headers.cookie || "").split(";");
  for (const cookie of cookies) {
    const [name, ...parts] = cookie.trim().split("=");
    if (name === "noonai_session") return decodeURIComponent(parts.join("="));
  }
  return "";
}

function setSessionCookie(req, res, token) {
  res.setHeader("Set-Cookie", `noonai_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_TTL_MS / 1000}${isHttps(req) ? "; Secure" : ""}`);
}

function clearSessionCookie(req, res) {
  res.setHeader("Set-Cookie", `noonai_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${isHttps(req) ? "; Secure" : ""}`);
}

function isHttps(req) {
  return req.socket?.encrypted || String(req.headers["x-forwarded-proto"] || "").split(",")[0].trim() === "https";
}

function smsMode() {
  return String(process.env.SMS_PROVIDER || "console").toLowerCase();
}

async function sendSmsCode(phone, code, purpose) {
  const mode = smsMode();
  const message = `【中午AI】${code} 是您的短信验证码，5分钟内有效，请勿泄露。`;
  if (mode === "console" && process.env.NODE_ENV !== "production") {
    console.log(`[SMS ${purpose}] ${phone}: ${message}`);
    return;
  }
  if (mode === "aliyun") {
    await sendAliyunSmsCode(phone, code);
    return;
  }
  await sendSmsWebhook(phone, code, purpose, message);
}

async function sendAliyunSmsCode(phone, code) {
  const accessKeyId = requiredEnv("ALIYUN_ACCESS_KEY_ID");
  const accessKeySecret = requiredEnv("ALIYUN_ACCESS_KEY_SECRET");
  const signName = requiredEnv("ALIYUN_SMS_SIGN_NAME");
  const templateCode = requiredEnv("ALIYUN_SMS_TEMPLATE_CODE");
  const params = {
    AccessKeyId: accessKeyId,
    Action: "SendSms",
    Format: "JSON",
    PhoneNumbers: phone,
    RegionId: process.env.ALIYUN_SMS_REGION_ID || "cn-hangzhou",
    SignatureMethod: "HMAC-SHA1",
    SignatureNonce: randomBytes(16).toString("hex"),
    SignatureVersion: "1.0",
    SignName: signName,
    TemplateCode: templateCode,
    TemplateParam: JSON.stringify({ code }),
    Timestamp: new Date().toISOString().replace(/\.\d{3}Z$/, "Z"),
    Version: "2017-05-25"
  };
  const canonicalized = Object.keys(params)
    .sort()
    .map((key) => `${aliyunPercentEncode(key)}=${aliyunPercentEncode(params[key])}`)
    .join("&");
  const stringToSign = `POST&${aliyunPercentEncode("/")}&${aliyunPercentEncode(canonicalized)}`;
  const signature = createHmac("sha1", `${accessKeySecret}&`).update(stringToSign).digest("base64");
  const body = new URLSearchParams({ ...params, Signature: signature });
  const endpoint = process.env.ALIYUN_SMS_ENDPOINT || "https://dysmsapi.aliyuncs.com/";
  const response = await fetch(endpoint, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded;charset=utf-8" },
    body,
    signal: AbortSignal.timeout(10000)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok || payload.Code !== "OK") {
    const providerCode = payload.Code || `HTTP_${response.status}`;
    console.error("Aliyun SMS failed:", providerCode, payload.Message || "", payload.RequestId || "");
    await writeSmsDiagnostic({
      status: "failed",
      code: providerCode,
      message: payload.Message || "",
      requestId: payload.RequestId || ""
    });
    throw new Error(`短信发送失败（${providerCode}），请稍后再试。`);
  }
  console.log("Aliyun SMS accepted:", {
    bizId: payload.BizId || "",
    requestId: payload.RequestId || ""
  });
  await writeSmsDiagnostic({
    status: "accepted",
    bizId: payload.BizId || "",
    requestId: payload.RequestId || ""
  });
}

async function writeSmsDiagnostic(entry) {
  try {
    const configuredDataDir = process.env.DATA_DIR || "data";
    const dataDir = path.isAbsolute(configuredDataDir)
      ? configuredDataDir
      : path.resolve(process.cwd(), configuredDataDir);
    await mkdir(dataDir, { recursive: true });
    await appendFile(
      path.join(dataDir, "sms-delivery.log"),
      `${JSON.stringify({ time: new Date().toISOString(), ...entry })}\n`,
      "utf8"
    );
  } catch (error) {
    console.error("Unable to write SMS diagnostic log:", error.message);
  }
}

function aliyunPercentEncode(value) {
  return encodeURIComponent(String(value))
    .replace(/\!/g, "%21")
    .replace(/'/g, "%27")
    .replace(/\(/g, "%28")
    .replace(/\)/g, "%29")
    .replace(/\*/g, "%2A");
}

function requiredEnv(name) {
  const value = String(process.env[name] || "").trim();
  if (!value) throw new Error(`短信服务尚未配置 ${name}。`);
  return value;
}

async function sendSmsWebhook(phone, code, purpose, message) {
  const webhook = process.env.SMS_WEBHOOK_URL;
  if (!webhook) throw new Error("生产环境尚未配置 SMS_WEBHOOK_URL。" );
  const response = await fetch(webhook, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(process.env.SMS_WEBHOOK_TOKEN ? { Authorization: `Bearer ${process.env.SMS_WEBHOOK_TOKEN}` } : {})
    },
    body: JSON.stringify({
      phone,
      code,
      purpose,
      app: "中午AI",
      expiresIn: CODE_TTL_MS / 1000,
      message,
      content: message
    }),
    signal: AbortSignal.timeout(10000)
  });
  if (!response.ok) throw new Error(`短信服务返回 HTTP ${response.status}`);
}

async function readBody(req, maxBytes = 64 * 1024) {
  let raw = "";
  for await (const chunk of req) {
    raw += chunk;
    if (Buffer.byteLength(raw) > maxBytes) throw new Error("Request body is too large");
  }
  return raw ? JSON.parse(raw) : {};
}

function reply(res, status, payload) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload));
  return true;
}
