# NoonAI

一个对标 ChatGPT 网页端体验的 OpenAI API 聊天应用。前端负责会话和交互，Node 服务端负责安全读取 `OPENAI_API_KEY` 并代理请求到 OpenAI Responses API。

## 本地运行

1. 写入本地 API key：

   ```powershell
   cd F:\桌面\noonai
   .\set-openai-key.ps1
   ```

   或者手动创建 `F:\桌面\noonai\.env`：

   ```env
   OPENAI_BASE_URL=https://www.maitokens.com/v1
   OPENAI_API_KEY=sk-...
   OPENAI_MODEL=gpt-5.5
   OPENAI_IMAGE_MODEL=gpt-image-2
   PORT=3000
   ```

2. 启动服务：

   ```powershell
   npm start
   ```

3. 打开：

   ```text
   http://localhost:3000
   ```

4. 检查后端是否读到 key：

   ```text
   http://localhost:3000/api/health
   ```

   正常应返回 `"hasApiKey": true`，并显示当前 `baseUrl`、`chatModel`、`imageModel`。

## 部署

- 不要把真实 API key 写入前端代码或提交到 Git。
- 在线上平台配置环境变量 `OPENAI_API_KEY`、`OPENAI_BASE_URL`、`OPENAI_MODEL`、`OPENAI_IMAGE_MODEL`。
- 服务启动命令使用 `npm start`。
- 默认端口读取 `PORT`，适配 Render、Railway、Fly.io、Vercel Serverless 以外的常规 Node 托管环境。

## 功能

- ChatGPT 风格三栏体验：侧边会话、模型选择、对话区和底部输入框。
- 支持 OpenAI-compatible `chat/completions` 流式输出。
- 支持 OpenAI-compatible `images/generations` 图片生成。
- 支持本地会话历史、搜索、清空、复制、重新生成、停止生成。
- 支持浅色和深色主题。
